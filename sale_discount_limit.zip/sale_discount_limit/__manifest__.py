{
    'name': " Sale Discount Limit",
    'version': '16.0.1.0.0',
    'category': 'Sale',
    'author': 'Klystron Global',
    'company': 'Klystron Global',
    'maintainer': 'Klystron Global',
    'website': 'https://www.klystronglobal.com',
    'depends': ['base','sale'],
    'data': [
        'view/discount_limit_view.xml',
    ],

    
    'installable': True,
    'application': True,
}