# -*- coding: utf-8 -*-
from odoo import fields, models, api
from odoo.exceptions import ValidationError
from odoo.tools import date_utils


class DiscountLimit(models.TransientModel):
    _inherit = 'res.config.settings'

    discount_limit = fields.Boolean(default=True)
    discount_limit_rate = fields.Float()

    def set_values(self):
        super(DiscountLimit, self).set_values()
        self.env['ir.config_parameter'].set_param('discount_limit', self.discount_limit)
        self.env['ir.config_parameter'].set_param('discount_limit_rate', self.discount_limit_rate)

    @api.model
    def get_values(self):
        res = super(DiscountLimit, self).get_values()
        icp = self.env['ir.config_parameter']
        res.update(
            discount_limit=icp.get_param('discount_limit'),
            discount_limit_rate=icp.get_param('discount_limit_rate')
        )
        return res


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()

        today = fields.date.today()
        current_month = date_utils.add(today, month=0)
        starting_current_month = date_utils.start_of(current_month, "month")
        ending_current_month = date_utils.end_of(current_month, "month")

        date_order = self.date_order.date()

        order_details = self.env['sale.order'].search(
            [('date_order', '>=', starting_current_month), ('date_order', '<=', ending_current_month)])

        total = sum(order_details.order_line.mapped('discount'))



        limit_discount = self.env['ir.config_parameter'].sudo().get_param('discount_limit_rate')

        if str(total) > limit_discount:
            raise ValidationError(('discount limit is exceeded'))

        return res
