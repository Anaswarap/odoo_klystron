from itertools import groupby
from datetime import datetime, timedelta

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import formatLang


class KGSoPoWizard(models.TransientModel):
    _name = 'kg.so.po.wizard'
    _description = 'kg.so.po.wizard'


    def select_all(self):
        print("select all")
        select_wiz_line = self.wiz_line
        for sel in select_wiz_line:
            sel.select = True
        return {
            'view_type': 'form',
            "view_mode": 'form',
            'res_model': 'kg.so.po.wizard',
            'res_id': self.id,
            'type': 'ir.actions.act_window',
            'target': 'new'
        }

    def delete(self):
        wiz_line = self.wiz_line

        for line in wiz_line:
            if line.select:
                line.unlink()

        return {
            'view_type': 'form',
            "view_mode": 'form',
            'res_model': 'kg.so.po.wizard',
            'res_id': self.id,
            'type': 'ir.actions.act_window',
            'target': 'new'
        }

    def create_po(self):
        wiz_line = self.wiz_line
        if not wiz_line:
            raise UserError(_('no lines found for generating PO'))
        partner_id = self.supplier_id and self.supplier_id.id
        line_vals_array = []
        so_id = self.sale_order_id and self.sale_order_id.id
        date_order = self.sale_order_id.date_order
        payment_term_id = self.payment_term_id and self.payment_term_id.id

        for line in wiz_line:

            product_id = line.product_id and line.product_id.id
            name = line.name
            product_uom = line.product_uom and line.product_uom.id
            tax_ids = []
            if line.tax_id:
                tax_ids.append(line.tax_id and line.tax_id.id or False)
            product_qty = line.qty
            price_unit = line.unit_price

            if line.product_id.type not in ('service', 'consu'):
                if line.select:
                    line_vals = (0, 0, {'product_id': product_id, 'product_qty': product_qty, 'price_unit': price_unit,
                                        'product_uom': product_uom, 'name': name, 'date_planned': date_order,
                                        'taxes_id': [(6, 0, tax_ids)]})

                    line_vals_array.append(line_vals)
        if not line.select:
            raise ValidationError(_('Select atleast one product'))

        vals = {'partner_id': partner_id, 'order_line': line_vals_array, 'kg_sale_order_id': so_id,
                'payment_term_id': payment_term_id}
        purchase_order_obj = self.env['purchase.order'].create(vals)
        purchase_line = self.sale_order_id and self.sale_order_id.kg_purchase_order_lines
        lpo = ''
        for line in purchase_line:
            lpo = lpo + "," + line.name

        lpo = lpo[1:]
        self.sale_order_id.kg_lpos = lpo

        return True

    @api.model
    def default_get(self, fields_list):
        print(fields_list)
        res = super(KGSoPoWizard, self).default_get(fields_list)
        print(res)
        sale_obj = self.env['sale.order'].browse(self._context.get('active_id'))
        sale_line = sale_obj.order_line
        currency_id = sale_obj.currency_id and sale_obj.currency_id.id
        line_vals_array = []
        for line in sale_line:
            product_id = line.product_id and line.product_id.id
            product_uom_qty = line.product_uom_qty
            name = line.name
            product_uom = line.product_uom and line.product_uom.id
            purchase_price = line.purchase_price
            tax_id = line.tax_id
            print(tax_id,"taxxxxxxxxxxxxxxxxxxx")

            if line.product_id.type not in ('service', 'consu'):
                vals = (0, 0,
                        {'product_id': product_id, 'qty': product_uom_qty, 'unit_price': purchase_price, 'name': name,
                         'product_uom': product_uom, 'tax_id': tax_id})
                print(vals,"valssssssssssssssssss")

                line_vals_array.append(vals)

        res.update({'sale_order_id': sale_obj.id, 'wiz_line': line_vals_array, 'currency_id': currency_id})
        return res

    wiz_line = fields.One2many('kg.so.po.wizard.line', 'wiz_id', string='Wiz Line', )
    supplier_id = fields.Many2one('res.partner', string='Vendor')
    sale_order_id = fields.Many2one('sale.order', string='Sale Order')
    currency_id = fields.Many2one('res.currency', string='Currency')
    payment_term_id = fields.Many2one('account.payment.term', string='Payment Term')


class KGSoPoWizardLine(models.TransientModel):
    _name = 'kg.so.po.wizard.line'
    _description = 'kg.so.po.wizard.line'

    wiz_id = fields.Many2one('kg.so.po.wizard', string='Wiz')
    product_id = fields.Many2one('product.product', string='Product')
    name = fields.Char(string='Description', )
    qty = fields.Integer(string="Qty")
    unit_price = fields.Float(string="Cost")
    tax_id = fields.Many2one('account.tax', string='Vat')
    product_uom = fields.Many2one('uom.category', string='Product Unit of Measure')
    select = fields.Boolean('Select')
