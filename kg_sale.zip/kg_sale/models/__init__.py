# -*- coding: utf-8 -*-

from . import product
from . import brand
from . import optional_product
from . import product_cost_history
from . import partner_payment_extension_line
from . import accounting_managers
from . import revisions
from . import product_category
from . import account_payment
from . import account_move
from . import sale_order
from . import res_partner
from . import stock_picking
from . import sale_report
