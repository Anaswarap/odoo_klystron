from odoo import api, fields, models, api


class SaleReport(models.Model):
    _inherit = 'sale.report'

    customer_types = fields.Selection([
        ('end_user', 'End User'),
        ('it_reseller', 'IT - Reseller'),
        ('export_customer', 'Export Customer')
    ], string='Customer Type')

    #
    # def _select_sale(self):
    #     res = super(SaleReport, self)._select_sale()
    #     print("res===============", res)
    #     select_str = res + """s.check_field as check_field"""
    #     return select_str
    #     # return res
