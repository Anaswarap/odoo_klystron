{
    'name': 'Show Product Details',
    'version': '16.0.1.0.0',
    'depends': ['base', 'sale'],
    'data': [

        'security/ir.model.access.csv',
        'views/sale_order_line_button_view.xml',
        'views/product_details_view.xml',

    ],

    'installable': True,
    'application': True
}
