from odoo import fields, models, api,_


class ProductDetailsShow(models.Model):
    _name = 'product.details.show'

    product_id = fields.Many2one('product.product', string='Products')
    on_hand_qty = fields.Float(related='product_id.qty_available', string='Quantity On Hand')
    reserved_qty = fields.Float(related='product_id.virtual_available', string='Forecasted Quantity')
    last_selling_price = fields.Float(string='Last Selling Price', compute='_compute_last_sale_price')
    qty = fields.Float(string='Ordered Qty')

    @api.depends('product_id')
    def _compute_last_sale_price(self):
        last_sale_price = self.env['sale.order.line'].search(
            [('product_id', '=', self.product_id.id), ('order_id.state', 'in', ['sale'])], order='id desc', limit=1)
        if last_sale_price:
            self.last_selling_price = last_sale_price.price_unit





class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    def product_details(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Products Details'),
            'view_mode': 'form',
            'res_model': 'product.details.show',
            'context': {'default_product_id': self.product_id.id,
                        'default_qty':self.product_uom_qty,
                        'create': False, 'edit': False},
            'target': 'new',
        }
