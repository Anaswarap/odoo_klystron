from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ReservationWizard(models.Model):
    _name = 'reservation.wizard'

    from_date = fields.Date(string='From Date')
    to_date = fields.Date(string='To Date')
    book_ids = fields.Many2many('product.product', string='Books')
    partner_id = fields.Many2one('res.partner', string='Customer')
    acquire_method = fields.Selection([('customer', 'Customer'),('product', 'Product')],required=True, default='customer')

    def reservation_report(self):
        print("test")
        query = ''' select res_partner.name as customer, contacts_product.state,contacts_product.create_date, contacts_product.reference_no,product_template.name->>'en_US' as product from contacts_product
inner join res_partner on contacts_product.partner_id = res_partner.id
inner join contacts_product_line on contacts_product.id = contacts_product_line.contact_product_id
inner join product_product on contacts_product_line.product_id = product_product.id
inner join product_template on  product_product.product_tmpl_id = product_template.id'''
        if self.partner_id:
            query += """ where contacts_product.partner_id = %d """ % self.partner_id

        if self.from_date:
            query += """ and contacts_product.create_date >= '%s' """ % self.from_date

        if self.to_date:
            query += """ and contacts_product.create_date <= '%s' """ % self.to_date

        for rec in self.book_ids:
            print("rec",rec)
            if rec:

                query += """ and contacts_product_line.product_id = %d """ % rec

        if self.from_date > self.to_date:
            raise ValidationError(_("Start Date must be less than End Date!"))

        self.env.cr.execute(query)
        fetch = self.env.cr.dictfetchall()
        print(fetch)
        data = {
            'form': self.read()[0],
            'fetch': fetch,
            'from_date': self.from_date,
            'to_date': self.to_date

        }
        print(data)

        return self.env.ref('book_details.book_reservation_report').report_action(None, data=data)
