{
    'name': 'Book Details',
    'version': '16.0.1.0.0',
    'depends': ['base','stock','contacts','product','sale','account'],
    'data': [
                'security/security_group_view.xml',
                'security/ir.model.access.csv',
                'wizards/reservation_report_view.xml',
                'views/view.xml',
                'views/contact_view.xml',
                'data/book_details_sequence_view.xml',
                'data/product_reservation_sequence_view.xml',
                'data/cron.xml',
                'report/book_reservation_template.xml',
                'report/book_reservation_report.xml'






    ],

    'installable': True,
    'application': True
}