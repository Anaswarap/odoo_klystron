from odoo import fields, models, api,_



class BookDetails(models.Model):
    _name = 'book.details'
    _rec_name = 'book_name'


    book_name = fields.Char(string='Name')
    book_image = fields.Image(string='image')
    book_author_ids = fields.Many2many('res.partner',string='Authors')
    book_category = fields.Selection(
        [('fantasy', 'Fantasy'), ('horror', 'Horror'), ('others', 'Others')],
        string='Category')
    book_issue_no = fields.Char(string='ISBN Number')
    book_publisher = fields.Char(string='Publisher Name')
    reference_no = fields.Char(string='serial Number', required=True, readonly=True, default=lambda self: _('New'))
    published_date = fields.Date(string='Published Date')
    available = fields.Boolean(string='Available Name', default=False)
    related_partner_id = fields.Many2one('res.partner',string='Related Partner')
    responsible_id = fields.Many2one('res.users',string='Responsible')
    book_price = fields.Float(string='Book Price')
    book_invoice_ref = fields.Char(string='Invoice Reference')


    @api.model
    def create(self, vals):
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code(
                'book.details') or _('New')
        res = super(BookDetails, self).create(vals)
        return res







class PartnerCheckField(models.Model):
    _inherit = 'res.partner'


    book_owner = fields.Boolean(string='Book Owner', default=False)

class RelatedProductField(models.Model):
    _inherit = 'product.template'


    related_product_id = fields.Many2one('book.details',string='Related Products')

    @api.onchange('related_product_id')
    def onchange_related_product(self):
        if self.related_product_id:
            self.list_price = self.related_product_id.book_price
            self.default_code = self.related_product_id.book_issue_no

class AccountPost(models.Model):
    _inherit = 'account.move'

    def action_post(self):
        res = super(AccountPost,self).action_post()
        invoice_ref = self.env['book.details'].search([])
        print(invoice_ref)
        invoice_ref.book_invoice_ref = self.name
        return res



