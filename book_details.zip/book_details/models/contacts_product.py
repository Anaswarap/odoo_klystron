from odoo import fields, models, api, _
from datetime import datetime, date


class ContactsProduct(models.Model):
    _name = 'contacts.product'

    reservation_name = fields.Char(string='Reservation Name')
    partner_id = fields.Many2one('res.partner', string='Customers')
    exp_date = fields.Date(string='Expiry Date')
    contact_product_ids = fields.One2many('contacts.product.line', 'contact_product_id', string='Multiple Products')
    reference_no = fields.Char(string='Reservation Sequence', required=True, readonly=True,
                               default=lambda self: _('New'))
    active = fields.Boolean(string='Active', default=True)
    related_user_id = fields.Many2one('res.users', string='Related User', default=lambda self: self.env.uid)
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm')], default="draft", string='state')
    # delivery_order_id = fields.Many2one('stock.picking')

    @api.model
    def create(self, vals):
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code(
                'contacts.product') or _('New')
        res = super(ContactsProduct, self).create(vals)
        return res

    def automatic_archive(self):
        for rec in self.env['contacts.product'].search([]):
            if rec.exp_date:
                if rec.exp_date < fields.date.today():
                    rec.active = False

    def action_confirm(self):
        self.state = 'confirm'


class ContactsProductLine(models.Model):
    _name = 'contacts.product.line'

    contact_product_id = fields.Many2one('contacts.product')

    product_id = fields.Many2one('product.product', string='Product')
    product_qty = fields.Float(string='Quantity')
    product_price = fields.Float(string='Price')
    locn_id = fields.Many2one('stock.picking.type')


class SmartButtonReservation(models.Model):
    _inherit = 'res.partner'

    reservation_count = fields.Integer(compute='_compute_reservation_count')

    def _compute_reservation_count(self):
        for rec in self:
            rec.reservation_count = self.env['contacts.product'].search_count([('partner_id', '=', self.id)])
            # print(rec.reservation_count)

    def reservation_product(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Products',
            'view_mode': 'tree,form',
            'res_model': 'contacts.product',
            'domain': [('partner_id', '=', self.id)],
            'context': "{'create': False}"
        }


class SaleAutoProductFill(models.Model):
    _inherit = 'sale.order'

    @api.onchange('partner_id')
    def onchange_customer(self):
        rec = self.env['contacts.product'].search([('partner_id', '=', self.partner_id.id)])
        for item in rec.contact_product_ids:
            self.order_line = [(0, 0, {
                'product_id': item.product_id.id,
                'product_uom_qty': item.product_qty,
                'price_unit': item.product_price
            })]


class BooleanField(models.Model):
    _inherit = 'res.partner'

    need_invoice = fields.Boolean(string='Need Invoice', default=False)
    need_dn = fields.Boolean(string='Need DN', defult=False)

    def create_invoice(self):

        for rec in self:
            rec.need_invoice = False
        orders = self.env['contacts.product'].search([('partner_id', '=', self.id)])
        print(orders)
        item = []
        for i in orders.contact_product_ids:
            print(i)
            item.append((0, 0, {
                'product_id': i.product_id.id,
                'quantity': i.product_qty,
                'price_unit': i.product_price,
                'account_id': i.product_id.property_account_income_id.id,

            }))
            print(item)
        invoice_create = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.id,
            'invoice_line_ids': item
        })
        print(invoice_create)


        # return {
        #     'name': 'invoices',
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'account.move',
        #     'res_id':invoice_create.id,
        #     'view_mode': 'form',
        #     'target': 'new',
        # }

    def create_delivery(self):

        global i
        for rec in self:
            rec.need_dn = False
        delivery_orders = self.env['contacts.product'].search([('partner_id', '=', self.id)])
        print(delivery_orders)
        item = []
        for i in delivery_orders.contact_product_ids:
            print(i)
            item.append((0, 0, {
                'product_id': i.product_id.id,
                'product_uom_qty': i.product_qty,
                'picking_type_id':i.locn_id.id,
                'location_id': i.locn_id.default_location_src_id.id,
                'location_dest_id':i.locn_id.default_location_dest_id.id,
                'name':"a"

            }))
            print(item)
        create_delivery = self.env['stock.picking'].create({
            'partner_id': self.id,
            'picking_type_id': i.locn_id.id,
            'location_id': i.locn_id.default_location_src_id.id,
            'location_dest_id': i.locn_id.default_location_dest_id.id,
            'move_ids': item,


        })
        print(create_delivery)



