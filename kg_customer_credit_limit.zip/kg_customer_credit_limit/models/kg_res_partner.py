from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class KGRespartnerInh(models.Model):
    _inherit = "res.partner"

    kg_credit_limit = fields.Boolean(string="Limit Credit", default=False)
    warn_amnt = fields.Monetary(string="Warning Amount")
    blck_amnt = fields.Monetary(string="Block Amount")


class SaleDueAmountWarning(models.Model):
    _inherit = 'sale.order'

    kg_credit_limit = fields.Boolean(string="Limit Credit", related='partner_id.kg_credit_limit')
    amount_due = fields.Monetary(string='Due Amount', related='partner_id.credit')
    warn_amnt = fields.Monetary(string="Warning Amount", related='partner_id.warn_amnt')
    blck_amnt = fields.Monetary(string="Block Amount", related='partner_id.blck_amnt')

    @api.onchange('order_line')
    def _onchange_warn(self):
        for val in self:
            if self.kg_credit_limit:
                if val.order_line:
                    blck_amnt = val.blck_amnt
                    amount_due = val.amount_due
                    grand_total = val.amount_total + amount_due
                    warn_amnt = val.warn_amnt
                    if amount_due > warn_amnt:
                        res = {'warning': {
                            'title': _('Warning'),
                            'message': _("Customer warning limit has been crossed %s", grand_total)
                        }}
                        if res:
                            return res
                    elif amount_due > blck_amnt:
                        raise ValidationError(_("credit limit Exceeded %s", grand_total))
