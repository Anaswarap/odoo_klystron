{
    'name': 'Customer Credit Limit',
    'version': '16.0.1.0.0',
    'depends': ['base', 'contacts', 'account','sale','account_followup'],
    'data': [
        'views/kg_res_partner_views.xml',
        'views/due_block_warning_sale_views.xml',

    ],

    'installable': True,
    'application': True
}
