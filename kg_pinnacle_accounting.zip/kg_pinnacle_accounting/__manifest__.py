# -*- coding: utf-8 -*-
{
    'name': "KG PINNACLE Accounts",
    'summary': """
        Cutomization of Accounts""",

    'description': """
        Cutomization of Accounts
    """,
    'author': "Klystronglobal",
    'website': "https://www.klystronglobal.com",
    'category': 'Accounts',
    'version': '16.0.0.0',
    'depends': ['base', 'account_accountant', 'web_approval','analytic','stock','sale'],
    'data': [
        # 'security/ir.model.access.csv',
        # 'reports/tax_invoice_template.xml',
        'reports/tax_invoice_template.xml',
        'views/account_move.xml',
        'views/account_payment.xml',
    ],
}
