import pytz
from odoo import api, fields, models, _
from odoo.addons.web_approval.models.approval_mixin import _APPROVAL_STATES
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare, float_is_zero, formatLang
from collections import defaultdict


class AccountMoveInh(models.Model):
    _name = "account.move"
    _inherit = ["account.move", 'approval.mixin']

    # APPROVAL
    approval_state = fields.Selection(string='Approval Status', selection=_APPROVAL_STATES, required=False, copy=False,
                                      is_approval_state=True, tracking=True)
    is_approver = fields.Boolean(compute='compute_is_approver')
    sale_order_id = fields.Many2one('sale.order', string="Sale Order")
    sale_order_customer_id = fields.Many2one('res.partner', string="Sale Order Customer",
                                             store=True)

    # @api.model
    # def create(self, vals):
    #     invoice = super(AccountMoveInh, self).create(vals)
    #     print("invoice---------",invoice)
    #     if invoice.move_type in ('in_invoice', 'out_invoice'):
    #         if invoice.sale_order_id:
    #             for line in invoice.invoice_line_ids:
    #                 line.quantity = line.sale_line_ids.product_uom_qty * 0.15
    #     return invoice



    def compute_is_approver(self):
        for rec in self:
            rec.is_approver = rec.show_approval_buttons()

    def action_post(self):
        for move in self:
            result = super(AccountMoveInh, self).action_post()
            if move.approval_state != 'approve' and move.move_type == 'in_invoice':
                raise ValidationError(_("You cannot do this action without approval"))
            elif move.move_type == 'in_invoice':
                print("tttttttttttttt")
                purchase_order_subtotal = move.invoice_line_ids.purchase_line_id.order_id.amount_total
                print("purchase_order_subtotal",purchase_order_subtotal)
                vendor_bill_subtotal = move.amount_total
                print("vendor_bill_subtotal", vendor_bill_subtotal)
                if purchase_order_subtotal < vendor_bill_subtotal:
                    raise ValidationError(
                        _("The subtotal amount in the purchase order is less than the vendor bill's subtotal. Please review the amounts before confirming the vendor bill."))
        return result

    def _get_invoiced_lot_values_by_product(self, product_id):
        """ Get and prepare data to show a table of invoiced lot on the invoice's report. """
        self.ensure_one()
        user_tz = self.env.context.get('tz')
        res = []
        if self.state == 'draft' or not self.invoice_date or self.move_type not in ('out_invoice', 'out_refund'):
            return res

        current_invoice_amls = self.invoice_line_ids.filtered(
            lambda aml: not aml.display_type and aml.product_id and aml.quantity)
        all_invoices_amls = current_invoice_amls.sale_line_ids.invoice_lines.filtered(
            lambda aml: aml.move_id.state == 'posted').sorted(lambda aml: (aml.date, aml.move_name, aml.id))
        index = all_invoices_amls.ids.index(current_invoice_amls[:1].id) if current_invoice_amls[
                                                                            :1] in all_invoices_amls else 0
        previous_amls = all_invoices_amls[:index]

        previous_qties_invoiced = previous_amls._get_invoiced_qty_per_product()
        invoiced_qties = current_invoice_amls._get_invoiced_qty_per_product()
        invoiced_products = invoiced_qties.keys()

        qties_per_lot = defaultdict(float)
        previous_qties_delivered = defaultdict(float)
        stock_move_lines = current_invoice_amls.sale_line_ids.move_ids.move_line_ids.filtered(
            lambda sml: sml.state == 'done' and sml.lot_id).sorted(lambda sml: (sml.date, sml.id))
        for sml in stock_move_lines:
            if sml.product_id not in invoiced_products:
                continue
            product = sml.product_id
            product_uom = product.uom_id
            qty_done = sml.product_uom_id._compute_quantity(sml.qty_done, product_uom)

            if sml.location_id.usage == 'customer':
                # Cha Change 12/10/2022
                returned_qty = min(qties_per_lot[sml.lot_id, sml.location_id.id], qty_done)
                qties_per_lot[sml.lot_id, sml.location_id.id] -= returned_qty
                qty_done = returned_qty - qty_done

            previous_qty_invoiced = previous_qties_invoiced[product]
            previous_qty_delivered = previous_qties_delivered[product]
            # If we return more than currently delivered (i.e., qty_done < 0), we remove the surplus
            # from the previously delivered (and qty_done becomes zero). If it's a delivery, we first
            # try to reach the previous_qty_invoiced
            if float_compare(qty_done, 0, precision_rounding=product_uom.rounding) < 0 or \
                    float_compare(previous_qty_delivered, previous_qty_invoiced,
                                  precision_rounding=product_uom.rounding) < 0:
                previously_done = qty_done if sml.location_id.usage == 'customer' else min(
                    previous_qty_invoiced - previous_qty_delivered, qty_done)
                previous_qties_delivered[product] += previously_done
                qty_done -= previously_done
            # Cha Change 12/10/2022
            qties_per_lot[sml.lot_id, sml.location_id.id] += qty_done

        # Cha Change 12/10/2022
        for lot_location, qty in qties_per_lot.items():
            # Cha Change 12/10/2022
            lot, location_id = lot_location
            if lot.product_id.id == product_id:
                # access the lot as a superuser in order to avoid an error
                # when a user prints an invoice without having the stock access
                lot = lot.sudo()
                if float_is_zero(invoiced_qties[lot.product_id], precision_rounding=lot.product_uom_id.rounding) \
                        or float_compare(qty, 0, precision_rounding=lot.product_uom_id.rounding) <= 0:
                    continue
                invoiced_lot_qty = min(qty, invoiced_qties[lot.product_id])
                invoiced_qties[lot.product_id] -= invoiced_lot_qty
                expiry_date = False
                if lot.expiration_date:
                    expiry_date = pytz.UTC.localize(lot.expiration_date)
                    expiry_date = expiry_date.astimezone(pytz.timezone(user_tz))

                res.append({
                    'product_name': lot.product_id.display_name,
                    'quantity': formatLang(self.env, invoiced_lot_qty, dp='Product Unit of Measure'),
                    'uom_name': lot.product_uom_id.name,
                    'lot_name': lot.name,
                    'expiry': expiry_date.strftime("%d/%m/%Y, %H:%M:%S") if lot.expiration_date else False,
                    # The lot id is needed by localizations to inherit the method and add custom fields on the invoice's report.
                    'lot_id': lot.id,
                    'product_id': lot.product_id.id,
                    # Cha Change 12/10/2022
                    'location_id': location_id,
                })

        return res


class AccountMoveLineInherit(models.Model):
    _inherit = "account.move.line"

    product_packaging_qty = fields.Float('Qty', default=1)
    package_id = fields.Many2one('product.packaging')
    pkg_unit_price = fields.Float()
    kg_analytic_account_id = fields.Many2one('account.analytic.account', string="Analytic Account")





class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    def _create_payments(self):
        self.ensure_one()
        batches = self._get_batches()
        first_batch_result = batches[0]
        edit_mode = self.can_edit_wizard and (len(first_batch_result['lines']) == 1 or self.group_payment)
        to_process = []

        if edit_mode:
            payment_vals = self._create_payment_vals_from_wizard(first_batch_result)
            to_process.append({
                'create_vals': payment_vals,
                'to_reconcile': first_batch_result['lines'],
                'batch': first_batch_result,
            })
        else:
            if not self.group_payment:
                new_batches = []
                for batch_result in batches:
                    for line in batch_result['lines']:
                        new_batches.append({
                            **batch_result,
                            'payment_values': {
                                **batch_result['payment_values'],
                                'payment_type': 'inbound' if line.balance > 0 else 'outbound'
                            },
                            'lines': line,
                        })
                batches = new_batches

            for batch_result in batches:
                to_process.append({
                    'create_vals': self._create_payment_vals_from_batch(batch_result),
                    'to_reconcile': batch_result['lines'],
                    'batch': batch_result,
                })
        payments = self._init_payments(to_process, edit_mode=edit_mode)
        if self._context.get('active_model') == 'account.move':
            move = self.env['account.move'].browse(self._context.get('active_ids', []))
            for mv in move:
                if mv.move_type != 'in_invoice':
                    self._post_payments(to_process, edit_mode=edit_mode)
                    self._reconcile_payments(to_process, edit_mode=edit_mode)
                break;
        return payments

    def action_create_payments(self):
        payments = self._create_payments()
        if self._context.get('dont_redirect_to_payments'):
            # account.view_account_payment_form
            return {
                'type': 'ir.actions.act_window',
                'name': 'Journal Entries',
                'view_mode': 'form',
                'res_model': 'account.payment',
                'res_id':payments.id,
                'domain': [('id', 'in', payments.ids)],
                'context': "{'create': False}"
            }

        action = {
            'name': _('Payments'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'context': {'create': False},
        }
        if len(payments) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': payments.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('id', 'in', payments.ids)],
            })
        return action
