from odoo import api, fields, models, _


class AccountPayment(models.Model):
    _inherit = "account.payment"

    analytic_account_id = fields.Many2one('account.analytic.account', string="Analytic Account")


    def _prepare_move_line_default_vals(self, write_off_line_vals=None):
        res = super(AccountPayment, self)._prepare_move_line_default_vals()
        print(res, "RESSSSSSSSSSS")
        for i in res:
            i.update({'kg_analytic_account_id': self.analytic_account_id.id})
        return res
