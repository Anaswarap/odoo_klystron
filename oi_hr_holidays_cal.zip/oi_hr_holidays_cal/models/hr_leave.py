'''
Created on Jan 27, 2019

@author: Zuhair Hammadi
'''
from odoo import models, api, _
from odoo.addons.resource.models.resource import HOURS_PER_DAY

from odoo.exceptions import UserError


class HolidaysRequest(models.Model):
    _inherit = "hr.leave"

    def _get_number_of_days(self, date_from, date_to, employee_id):
        if self.holiday_status_id.calc_type == 'work':
            days = (date_to - date_from).days
            return {'days': days, 'hours': HOURS_PER_DAY * days}

        else:
            days = (date_to - date_from).days + 1
            self.number_of_days = days
            return {'days': days, 'hours': HOURS_PER_DAY * days}

        return super(HolidaysRequest, self)._get_number_of_days(date_from, date_to, employee_id)

    def action_approve(self):
        current_user = self.env.user.id
        for holiday in self:
            if holiday.employee_id.parent_id.user_id.id != current_user:
                raise UserError(
                    _('You are not the manager of the employee. Only the manager can perform the first approval.'))
            else:
                self.write({'state': 'validate1'})
                return True

    def action_validate(self):
        current_user = self.env.user.id
        for holiday in self:
            if holiday.department_id.manager_id.user_id.id != current_user:
                raise UserError(
                    _('You are not the manager of the department. Only the department manager can perform the second approval.'))
            else:
                self.write({'state': 'validate'})
                return True
