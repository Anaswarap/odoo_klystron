# -*- coding: utf-8 -*-
# Copyright 2018 Openinside co. W.L.L.
{
    "name": "Leave - Calculate Number of Days by Calendar Days",
    "summary": "Calendar days calculation for leave/timeoff types, Working Days, Calendar Days",
    "version": "14.0.1.1.3",
    'category': 'Human Resources',
    "website": "https://www.open-inside.com",
	"description": """
		* Add Calculation Type [Working Days, Calendar Days] in Leave Types
    """,
	'images':[
        'static/description/cover.png'
	],
    "author": "Openinside",
    "license": "OPL-1",
    "price" : 30,
    "currency": 'EUR',
    "installable": True,
    "depends": [
        'hr_holidays'
    ],
    "data": [
        'view/hr_leave_type.xml'
    ],
    'odoo-apps' : True    
}

