from odoo import models, fields


class InventoryVolume(models.Model):
    _name = 'kg.inventory.volume'
    _inherit = 'mail.thread'

    name = fields.Char(string='Volume',required=True)