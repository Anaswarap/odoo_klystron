from odoo import models, fields, api, _
from odoo.exceptions import UserError


class Inventory(models.Model):
    _name = 'kg.inventory'
    _inherit = 'mail.thread'
    _description = 'Inventory In'

    source = fields.Many2one('kg.stock.source', string='Source')
    date = fields.Datetime(string='Date')
    gate_pass_no = fields.Char(string='Gate Pass No')
    driver_name = fields.Char(string='Name of the Driver')
    product_id = fields.Many2one('product.product', string='Product', domain="[('is_oil_product', '=', True)]",
                                 required=True)
    remarks = fields.Text(string='Remarks')
    inspected_by = fields.Char(string='Inspected By')
    tank_location = fields.Many2one('stock.location', string='Tank Location', domain="[('is_tank_locn', '=', True)]")
    tank_location_out = fields.Many2one('stock.location', string='Tank Location', domain="[('is_vlcc', '=', True)]")
    supplier_id = fields.Many2one('res.partner', string='Supplier/Customer')
    temperature = fields.Char(string='Temperature')
    volume = fields.Many2one('kg.inventory.volume', string='Volume')
    inventory_type = fields.Selection([
        ('in', 'Inventory In'),
        ('out', 'Inventory Out'), ('transfer', 'Transfer')
    ], string='Inventory Type')
    number = fields.Char(string='Number')
    qty = fields.Float(string='Quantity', required=True)
    source_locn = fields.Many2one('stock.location', string='Source Location', domain="[('is_tank_locn', '=', True)]",
                                  default=lambda self: self.env['stock.location'].search([('usage', '=', 'supplier')],
                                                                                         limit=1))
    destn_locn = fields.Many2one('stock.location', string='Destination Location',
                                 domain="['|',('is_tank_locn', '=', True),('is_vlcc', '=', True)]",
                                 default=lambda self: self.env['stock.location'].search([('usage', '=', 'customer')],
                                                                                        limit=1))

    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.user.company_id)
    name = fields.Char(string="Name", readonly=True, required=True, copy=False, default='New')
    uom_id = fields.Many2one('uom.uom', string='Unit of Measure', related='product_id.uom_id')
    picking_id = fields.Many2one('stock.picking')
    state = fields.Selection([('draft', 'Draft'),
                              ('confirm', 'Confirmed')], string='Status', default='draft', track_visibility='onchange')

    on_hand_qty = fields.Float('On Hand Quantity', compute='_compute_on_hand_qty')

    @api.onchange('tank_location')
    def onchange_tank_location(self):
        self.product_id = self.tank_location.product_id.id

    @api.onchange('tank_location_out')
    def _onchange_tank_location_out(self):
        self.product_id = self.tank_location_out.product_id.id

    @api.onchange('source_locn')
    def onchange_source_locn(self):
        self.product_id = self.source_locn.product_id.id

    @api.depends('product_id', 'source_locn')
    def _compute_on_hand_qty(self):
        for record in self:
            record.on_hand_qty = record.source_locn.quantity

    @api.onchange('inventory_type')
    def onchange_supplier_customer(self):
        domain = {}
        if self.inventory_type == 'in':
            domain = {
                'supplier_id': [
                    ('supplier', '=', True), ('is_company', '=', self.company_id.id)
                ],

            }
        elif self.inventory_type == 'out':
            domain = {
                'supplier_id': [
                    ('customer', '=', True), ('is_company', '=', self.company_id.id)
                ]
            }
        elif self.inventory_type == 'transfer':
            domain = {
                'supplier_id': [
                    '|',
                    ('customer', '=', True),
                    ('supplier', '=', True),
                ]
            }
        return {'domain': domain}

    @api.onchange('tank_location')
    def _onchange_tank_location(self):
        if self.inventory_type == 'transfer':
            self.source_locn = self.tank_location
            self.destn_locn = self.tank_location

    @api.model
    def create(self, vals):
        if vals['inventory_type'] == 'in':
            sequence = 'kg.inventory.in'
        elif vals['inventory_type'] == 'out':
            sequence = 'kg.inventory.out'
        else:
            sequence = 'kg.inventory'
        vals['name'] = self.env['ir.sequence'].next_by_code(sequence) or 'New'
        result = super(Inventory, self).create(vals)
        return result

    def action_confirm(self):
        if self.inventory_type == 'in':
            available_products = self.env['stock.quant'].search([('location_id', '=', self.tank_location.id)]).filtered(
                lambda x: x.quantity).mapped('product_id')
            if available_products and self.product_id.id not in available_products.ids:
                raise UserError(_('You cannot proceed, already other item available in same location'))

            pick_input = self.env['stock.picking'].create({
                'name': 'Inventory In - ' + self.name,
                'picking_type_id': self.env.ref('stock.picking_type_in').id,
                'location_id': self.source_locn.id,
                'location_dest_id': self.tank_location.id,
                'partner_id': self.supplier_id.id,
                'move_ids_without_package': [(0, 0, {
                    'name': self.name,
                    'product_id': self.product_id.id,
                    'product_uom': self.uom_id.id,
                    'product_uom_qty': self.qty,
                    'location_id': self.source_locn.id,
                    'location_dest_id': self.tank_location.id,
                    'quantity_done': self.qty,
                    'origin': self.name,
                    'scheduled_date': self.date,
                    'date_done': self.date
                })],
            })
            self.picking_id = pick_input
            pick_input.action_confirm()
            pick_input.action_assign()
            pick_input.action_done()
            self.state = 'confirm'
        elif self.inventory_type == 'out':
            if self.tank_location_out.product_id.id:
                available_qty = self.product_id.with_context(location=self.tank_location_out.id).qty_available
                if not self.tank_location_out.quant_ids.filtered(lambda quant: quant.product_id == self.product_id):
                    raise UserError(_('The selected tank location does not have the selected product'))
                elif self.qty > available_qty:
                    raise UserError(_('Ordered quantity is greater than on hand quantity'))
            else:
                raise UserError(_('The selected tank location does not have a Product'))

            pick_output = self.env['stock.picking'].create({
                'name': 'Inventory Out - ' + self.name,
                'picking_type_id': self.env.ref('stock.picking_type_out').id,
                'location_id': self.tank_location_out.id,
                'location_dest_id': self.destn_locn.id,
                'partner_id': self.supplier_id.id,
                'move_ids_without_package': [(0, 0, {
                    'name': self.name,
                    'product_id': self.product_id.id,
                    'product_uom': self.uom_id.id,
                    'product_uom_qty': self.qty,
                    'location_id': self.tank_location_out.id,
                    'location_dest_id': self.destn_locn.id,
                    'quantity_done': self.qty,
                    'origin': self.name,
                    'scheduled_date': self.date,
                    'date_done': self.date
                })],
            })
            self.picking_id = pick_output
            pick_output.action_confirm()
            pick_output.action_assign()
            pick_output.action_done()
            self.state = 'confirm'
        else:
            available_products = self.env['stock.quant'].search([('location_id', '=', self.destn_locn.id)
                                                                 ]).filtered(
                lambda x: x.quantity).mapped('product_id')

            if self.qty <= 0.0:
                raise UserError(_("Quantity must be greater than zero to proceed with the transfer."))

            elif available_products and self.product_id.id not in available_products.ids:
                raise UserError(_('You can not proceed, already other item available in same location'))

            elif self.product_id and self.source_locn:
                available_products_source = self.env['stock.quant'].search([
                    ('location_id', '=', self.source_locn.id),
                    ('product_id', '=', self.product_id.id)
                ])
                if not available_products_source:
                    raise UserError(_('The selected source location does not have the selected product.'))

                internal_transfer = self.env['stock.picking'].create({
                    'name': 'Internal Transfer - ' + self.name,
                    'picking_type_id': self.env.ref('stock.picking_type_internal').id,
                    'location_id': self.source_locn.id,
                    'location_dest_id': self.destn_locn.id,
                    'partner_id': self.env.user.partner_id.id,
                    'move_ids_without_package': [(0, 0, {
                        'name': self.name,
                        'product_id': self.product_id.id,
                        'product_uom': self.uom_id.id,
                        'product_uom_qty': self.qty,
                        'location_id': self.source_locn.id,
                        'location_dest_id': self.destn_locn.id,
                        'origin': self.name,
                        'scheduled_date': self.date,
                        'date_done': self.date,
                        'quantity_done': self.qty
                    })],
                })
                self.picking_id = internal_transfer
                internal_transfer.action_confirm()
                internal_transfer.action_assign()
                internal_transfer.action_done()
            self.state = 'confirm'

    def view_transfer(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Transfer',
            'view_mode': 'form',
            'res_id': self.picking_id.id,
            'res_model': 'stock.picking',
            'context': "{'create': False}"
        }
