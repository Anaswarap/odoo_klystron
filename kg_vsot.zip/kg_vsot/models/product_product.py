from odoo import models, fields




class ProductProduct(models.Model):
    _inherit = 'product.product'

    is_oil_product = fields.Boolean(string='Oil Product')
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.user.company_id)


