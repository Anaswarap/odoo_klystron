from odoo import models, fields



class StockSource(models.Model):
    _name = 'kg.stock.source'
    _inherit = 'mail.thread'
    _description = 'Source'



    name = fields.Char(string='Source', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.user.company_id)

