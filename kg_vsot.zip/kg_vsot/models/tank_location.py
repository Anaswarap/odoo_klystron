from odoo import models, fields


class StockLocation(models.Model):
    _inherit = 'stock.location'

    is_tank_locn = fields.Boolean(string='is a Tank Location?')
    is_vlcc = fields.Boolean(string="is a VLCC Location?")
    is_vessel = fields.Boolean(string="is a Vessel Location?")
    product_id = fields.Many2one('product.product', compute='_compute_product', string='Product')
    quantity = fields.Float(string='Quantity', compute='_compute_product')

    def _compute_product(self):
        for location in self:
            quants = location.quant_ids.filtered(lambda x: x.quantity)
            available_product_id = quants.mapped('product_id')
            if len(available_product_id) > 1:
                location.product_id = available_product_id[0].id
                prod_quants = quants.filtered(lambda x: x.product_id.id == int(available_product_id[0].id))
                location.quantity = sum(prod_quants.mapped('quantity'))
            elif len(available_product_id) == 1:
                location.product_id = available_product_id.id
                prod_quants = quants.filtered(lambda x: x.product_id.id == int(available_product_id.id))
                location.quantity = sum(prod_quants.mapped('quantity'))
            else:
                location.product_id = False
                location.quantity = 0

    def action_kg_inventory_in(self):
        transfer = self.env['kg.inventory'].sudo().search(
            [('inventory_type', '=', 'in'), ('tank_location', '=', self.id)])
        tree_view = self.env.ref('kg_vsot.kg_inventory_in_view_tree', False)
        form_view = self.env.ref('kg_vsot.kg_inventory_in_out_view_form', False)
        return {
            'name': 'Inventory In',
            'res_model': 'kg.inventory',
            'view_mode': 'tree,form',
            'views': [(tree_view.id, 'tree'), (form_view.id, 'form')],
            "context": {"create": False},
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', transfer.ids)],
        }

    def action_kg_inventory_out(self):
        transfer = self.env['kg.inventory'].sudo().search(
            [('inventory_type', '=', 'out'), ('tank_location_out', '=', self.id)])
        tree_view = self.env.ref('kg_vsot.kg_inventory_out_view_tree', False)
        form_view = self.env.ref('kg_vsot.kg_inventory_in_out_view_form', False)
        return {
            'name': 'Inventory Out',
            'res_model': 'kg.inventory',
            'view_mode': 'tree,form',
            'views': [(tree_view.id, 'tree'), (form_view.id, 'form')],
            "context": {"create": False},
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', transfer.ids)],
        }

    def action_kg_inventory_int(self):
        transfer = self.env['kg.inventory'].sudo().search(
            [('inventory_type', '=', 'transfer'), ('source_locn', '=', self.id)])
        tree_view = self.env.ref('kg_vsot.kg_internal_transfer_view_tree', False)
        form_view = self.env.ref('kg_vsot.kg_inventory_transfer_view_form', False)
        return {
            'name': 'Inventory Transfer',
            'res_model': 'kg.inventory',
            'view_mode': 'tree,form',
            'views': [(tree_view.id, 'tree'), (form_view.id, 'form')],
            "context": {"create": False},
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', transfer.ids)],
        }
