from odoo import models, fields, _, api
from odoo.exceptions import UserError
from odoo.tools import float_utils
from datetime import date


class InventoryAdjustment(models.Model):
    _name = 'kg.inventory.adjustment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Inventory Adjustment'

    @api.model
    def default_get(self, fields_list):
        res = super(InventoryAdjustment, self).default_get(fields_list)
        vals = []
        location_recs = self.env['stock.location'].search([]).filtered(lambda x: x.is_tank_locn or x.is_vlcc or x.is_vessel)
        for loc in location_recs:
            line_vals = {
                'location_id': loc.id,
                'product_id': loc.product_id.id,
                'current_stock_qty': loc.quantity,
                'qty': 0.00,
            }
            vals.append((0, 0, line_vals))
        res.update({
            'inventory_adjust_line_ids': vals,
        })
        return res

    name = fields.Char(string='Reference', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.user.company_id)
    date = fields.Date(string='Date', required=True, default=date.today())
    state = fields.Selection([('draft', 'Draft'), ('request', 'Requested'),
                              ('approved', 'Approved'),
                              ('cancelled', 'cancel'),
                              ('confirmed', 'Confirmed'), ('waiting', 'Waiting')], string='Status', default='draft',
                             track_visibility='onchange')
    inventory_adjust_line_ids = fields.One2many('kg.inventory.adjustment.line', 'inventory_adjustment_id')
    move_ids = fields.Many2many('stock.move', string='Stock Moves')

    def action_request(self):
        self.state = 'request'
        group_vsot_manager = self.env.ref('kg_vsot.group_vsot_manager')
        group_vsot_manager_mail = group_vsot_manager.users.mapped('partner_id').mapped('email')
        users_email = ",".join(group_vsot_manager_mail)
        email_values = {
            'email_to': users_email,
            'email_from': self.env.user.email,
            'author_id': self.env.user.id
        }
        template = self.env.ref('kg_vsot.email_template_adjustment')
        template.sudo().send_mail(self.id, force_send=True, email_values=email_values)

        self.activity_schedule(
            'kg_vsot.inventory_adjustment_approval_request_manager', user_id=self.env.user.id,
            note="Waiting For Approval Request")

    def action_cancel(self):
        self.state = 'cancelled'

    def action_approve1(self):
        if any(rec.product_id.id != rec.location_id.product_id.id and rec.location_id.product_id.id for rec in
               self.inventory_adjust_line_ids):
            raise UserError('You cannot proceed, already other item available in same location')
        self.state = 'waiting'

    def action_approve(self):
        if any(rec.product_id.id != rec.location_id.product_id.id and rec.location_id.product_id.id for rec in
               self.inventory_adjust_line_ids):
            raise UserError('You cannot proceed, already other item available in same location')
        self.state = 'approved'
        activity_type = self.env['mail.activity'].search([('res_id', '=', self.id), (
            'activity_type_id', '=', self.env.ref('kg_vsot.inventory_adjustment_approval_request_manager').id)])
        activity_type.unlink()

    def action_done(self):
        if any(rec.product_id.id != rec.location_id.product_id.id and rec.location_id.product_id.id for rec in
               self.inventory_adjust_line_ids):
            raise UserError('You cannot proceed, already other item available in same location')
        self.state = 'confirmed'
        for rec in self.inventory_adjust_line_ids:
            self.move_ids |= rec._generate_moves()
        self.move_ids._action_confirm()
        self.move_ids._action_assign()
        self.move_ids._action_done()

    def view_moves(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Stock Moves',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.move_ids.ids)],
            'res_model': 'stock.move',
            'context': "{'create': False}"
        }


class StockMove(models.Model):
    _inherit = 'stock.move'

    kg_inventory_id = fields.Many2one('kg.inventory.adjustment')


class KgInventoryAdjustmentLine(models.Model):
    _name = 'kg.inventory.adjustment.line'

    inventory_adjustment_id = fields.Many2one('kg.inventory.adjustment', string='Inventory Adjustment')
    location_id = fields.Many2one('stock.location', string='Location', required=True,
                                  domain="['|','|',('is_tank_locn', '=', True),('is_vlcc','=',True),('is_vessel','=',True)]")
    product_id = fields.Many2one('product.product', string='Product', required=True,
                                 domain="[('is_oil_product', '=', True)]")
    current_stock_qty = fields.Float(string='System Stock', readonly=True)
    qty = fields.Float(string='Physical Qty', default=0.0)

    def _generate_moves(self):
        vals_list = []
        for line in self:
            if float_utils.float_compare(line.current_stock_qty, line.qty,
                                         precision_rounding=line.product_id.uom_id.rounding) == 0:
                continue
            diff = line.current_stock_qty - line.qty
            if diff == 0:
                continue
            if diff < 0:
                vals = line._get_move_values(abs(diff), line.product_id.property_stock_inventory.id,
                                             line.location_id.id, False)
            else:
                vals = line._get_move_values(abs(diff), line.location_id.id,
                                             line.product_id.property_stock_inventory.id, True)
            vals['origin'] = 'Inventory Adjustment- ' + self.inventory_adjustment_id.name
            vals_list.append(vals)
        return self.env['stock.move'].create(vals_list)

    def _get_move_values(self, qty, location_id, location_dest_id, out):
        self.ensure_one()
        return {
            'name': _('INV:') + (self.inventory_adjustment_id.name or ''),
            'product_id': self.product_id.id,
            'product_uom': self.product_id.uom_id.id,
            'product_uom_qty': qty,
            'date': self.inventory_adjustment_id.date,
            'company_id': self.inventory_adjustment_id.company_id.id,
            'kg_inventory_id': self.inventory_adjustment_id.id,
            'state': 'confirmed',
            'restrict_partner_id': self.env.user.partner_id.id,
            'location_id': location_id,
            'location_dest_id': location_dest_id,
            'move_line_ids': [(0, 0, {
                'product_id': self.product_id.id,
                'lot_id': False,
                'product_uom_qty': 0,
                'product_uom_id': self.product_id.uom_id.id,
                'qty_done': qty,
                'package_id': False,
                'result_package_id': False,
                'location_id': location_id,
                'location_dest_id': location_dest_id,
                'owner_id': self.env.user.partner_id.id,
            })]
        }

    @api.onchange('location_id')
    def _onchange_location_id(self):
        self.product_id = self.location_id.product_id.id
        self.current_stock_qty = self.location_id.quantity
