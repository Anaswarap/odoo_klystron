{
    'name': 'Link Purchase Order',
    'version': '16.0.1.0.0',
    'depends': ['sale','purchase'],
    'data': [

                'views/purchase_link_view.xml',
                'views/sale_link_purchase_view.xml'






    ],

    'installable': True,
    'application': True
}