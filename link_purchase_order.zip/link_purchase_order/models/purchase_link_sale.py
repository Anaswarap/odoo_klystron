from odoo import api, fields, models, _



class SalePurchaseLink(models.Model):
    _inherit = 'sale.order'

    '''add two new fields in sale order'''

    project = fields.Char(string='Project')
    contract_no = fields.Char(string='Contract No')

    related_purchase_order_ids = fields.One2many('purchase.order','related_sale_order_id',string='Purchase Orders')




class PurchaseOrderField(models.Model):
    _inherit = 'purchase.order'

    '''add two new fields in purchase order'''

    contract_no = fields.Char(string='Contract No', readonly=True, related='related_sale_order_id.contract_no')
    related_sale_order_id = fields.Many2one('sale.order',string='Sale Order',required=True)


