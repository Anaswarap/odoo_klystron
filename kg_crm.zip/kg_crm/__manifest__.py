# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'KG CRM',
    'version': '1.8',
    'category': 'Sales/CRM',
    'sequence': 15,
    'summary': 'Customzation of CRM',
    'website': 'https://www.odoo.com/app/crm',
    'depends': [
        'crm', 'mail', 'product', 'purchase', 'web_approval', 'sale', 'sale_discount_total', 'sale_project', 'stock',
        'project', 'account_accountant', 'account', 'base','sign'
    ],
    'data':
        [
            'security/ir.model.access.csv',
            'security/security_group.xml',
            'data/ir_sequence.xml',
            'data/activity.xml',

            'wizard/template_wizard.xml',
            'wizard/rfq_from_item_line.xml',
            'wizard/crm_quotation_create.xml',
            'wizard/amount_set_wizard.xml',
            'wizard/project_update_wizard.xml',
            'wizard/invoice_from_project.xml',
            'wizard/estimation_import.xml',
            'reports/account_payment.xml',

            # 'reports/terms_condition.xml',
            'views/product.xml',
            'views/crm_lead.xml',
            'views/estimation.xml',
            'views/estimation_sub_tables.xml',
            'views/purchase.xml',
            'views/sale_order.xml',
            'views/project.xml',
            'views/partner.xml',
            'views/update_template.xml',
            'views/project_update.xml',
            'views/sales_return_form_view.xml',
            'views/return_code.xml',
            'views/account_payment.xml',
            'views/milestone_view.xml',
            'views/res_company.xml'

        ],
    'assets': {
        'web.assets_backend': [
            'kg_crm/static/src/js/action_manager.js',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
