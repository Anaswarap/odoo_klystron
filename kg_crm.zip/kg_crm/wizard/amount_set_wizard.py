from odoo import api, fields, models, _
from odoo.exceptions import UserError,ValidationError
from odoo.addons.website.tools import text_from_html


class Pofromestimation(models.TransientModel):
    _name = "amount.set.line"
    _description = "Setting Amount for line"

    @api.model
    def get_default_line_ids(self):
        print("inside------------>>>")
        # sale_orders = self.env['sale.order'].browse(self.so_ids.ids)
        return self.env['crm.estimation.category.line'].browse(self._context.get('active_ids', [])).ids
    @api.model
    def get_default_amount(self):
        cat_line = self.env['crm.estimation.category.line'].browse(self._context.get('active_ids', []))
        for rec in cat_line:
            if rec.is_amount_set:
                return rec.amount
            else:
                return 0.00
    @api.model
    def get_default_color(self):
        cat_line = self.env['crm.estimation.category.line'].browse(self._context.get('active_ids', []))
        for rec in cat_line:
            if rec.is_amount_set:
                return rec.color
            else:
                return ''

    line_ids = fields.Many2many('crm.estimation.category.line',default=get_default_line_ids)
    amount = fields.Float(required=True,default=get_default_amount)
    color = fields.Char(
        string="Color",
        help="Choose your color",
        size=7,default=get_default_color
    )
    tag = fields.Many2one('group.tag')


    def set_total_amount(self):
        for rec in self:
            tag_no = rec.line_ids[0].category_line_id.tag_no
            # amount_line = self.env['crm.estimation.category.line'].search([('category_line_id','=',rec.line_ids[0].category_line_id.id),('tag_ids','!=',False),('amount','=',rec.amount)])
            domain=[('category_line_id','=',rec.line_ids[0].category_line_id.id),('tag_ids','!=',False),('amount','=',rec.amount)]
            groups = self.env['crm.estimation.category.line'].read_group(domain, fields=['amount'], groupby=['tag_ids'],lazy=False)
            count = len(groups)
            name = 'Amount Slab'
            if count > 0 and count<10:
                name += ' 0'+str(count)
            elif count>10:
                name += ' ' + str(count)
            tag = self.env['group.tag'].create({'code':"group"+str(tag_no+1),'name':name+"("+str(float(rec.amount))+")"})
            for line in rec.line_ids:
                if line.is_amount_set == True:
                    raise ValidationError(_("Amount already set"))
                line.rate = 0.00
                line.amount = rec.amount
                line.is_amount_set = True
                line.tag_ids = tag.id
                line.category_line_id.tag_no = tag_no+1
