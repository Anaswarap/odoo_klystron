
from odoo import _, fields,api, models

class TempalteWizard(models.TransientModel):
    _name = 'estimation.template.wizard'
    _description = 'Template wizard'

    name = fields.Char()

    def action_create_template(self):
        est_id = self._context.get('active_id')
        estimation_id = self.env['crm.estimation'].search([('id','=',est_id)])
        for est in estimation_id:
            tmp = self.env['estimation.template'].create({'name':self.name,'estimation_id':est.id,'state':'draft'})
            category_list = []
            for cat_line in est.category_line_ids:
                category_vals ={
                    'template_id':tmp.id,
                    'sequence':cat_line.sequence,
                    'category_id':cat_line.category_id.id,
                    'discount':cat_line.discount,
                    'margin':cat_line.margin,
                    'budget':cat_line.budget,
                    'item_line_ids':[],
                    'estimation_id':False,
                    }
                for item_line in cat_line.item_line_ids:
                    category_vals['item_line_ids'].append(
                        (0, 0, item_line._prepare_item_line()))
                category_list.append((0, 0, category_vals))
                # print("category_vals---->>",category_vals)
                # print(err)
            tmp.category_tmp_line_ids = category_list
                # self.env['estimation.category.line.template'].create(category_vals)


