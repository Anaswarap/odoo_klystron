from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.addons.website.tools import text_from_html


class Pofromestimation(models.TransientModel):
    _name = "estimation.po.creation"
    _description = "PO from Estimation"

    @api.model
    def get_default_line_ids(self):
        # sale_orders = self.env['sale.order'].browse(self.so_ids.ids)
        return self.env['crm.estimation.category.line'].browse(self._context.get('active_ids', [])).ids

    line_ids = fields.Many2many('crm.estimation.category.line', default=get_default_line_ids)
    vendor_id = fields.Many2one('res.partner', required=True)

    def create_draft_po(self):
        line_items = self.env['crm.estimation.category.line'].browse(self.line_ids.ids)
        vals = self._prepare_po_vals()
        # for order in line_items:
        #     if order.po_created:
        #         raise ValidationError(_(
        #             "Purchase order already created for the Item %s with category %s.",
        #         )%(order.item.name,order.category_id.name))
        po = self.env['purchase.order'].sudo().create(vals)
        print("po---------",po)
        for so in line_items:
            # so.po_created = True
            so.category_line_id.update({'po_id': [(4, po.id)]})
            so.update({'po_ref': [(4, po.id)]})
        return {
            'name': _('PO'),
            'view_mode': 'form',
            'res_model': 'purchase.order',
            'view_id': self.env.ref('purchase.purchase_order_form').id,
            'type': 'ir.actions.act_window',
            'res_id': po.id,
        }

    def _prepare_po_vals(self):
        line_items = self.env['crm.estimation.category.line'].browse(self.line_ids.ids)
        po_lines = []
        for rec in line_items:
            text = text_from_html(rec.description, True)
            # po_lines.append((0, 0, {'product_id':rec.product_id.id,'product_qty':rec.quantity,'price_unit':rec.purchase_rate}))
            po_lines.append((0, 0, {'product_id': rec.category_id.product_id.id, 'name': text, 'product_qty': rec.qty,
                                    'price_unit': rec.budget, 'estimation_item_line_id': rec.id,
                                    'product_uom': rec.item.id,'analytic_distribution':rec.estimation_id.project_id.analytic_account_id.id}))
            print("polines---------",po_lines)
        if len(po_lines) == 0:
            raise ValidationError(_("No product list found for purchase order creation"))
        po_vals = {
            'partner_id': self.vendor_id.id,
            'company_id': self.env.company.id,
            'origin': rec.estimation_id.name,
            'order_line': po_lines,
            'estimation_id': line_items[0].estimation_id.id,
            'project_rel_id': rec.estimation_id.project_id.id
        }
        return po_vals
