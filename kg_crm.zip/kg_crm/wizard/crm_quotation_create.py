# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError,ValidationError


class Opportunity2Quotation(models.TransientModel):
    _name = 'crm.quotation.create'
    _description = 'Create new or use existing Customer on new Quotation'

    def default_partner(self):
        est_id = self._context.get('active_id')
        estimation_id = self.env['crm.estimation'].search([('id', '=', est_id)])
        return estimation_id.partner_id

    action = fields.Selection([
        ('create', 'Create a new customer'),
        ('exist', 'Link to an existing customer'),
    ], string='Quotation Customer')

    partner_id = fields.Many2one('res.partner', 'Customer',default=default_partner,required=True)

    def action_apply(self):
        """ Convert lead to opportunity or merge lead and opportunity and open
            the freshly created opportunity view.
        """
        self.ensure_one()
        estimation = self.env['crm.estimation'].browse(self._context.get('active_ids', [])).ids
        est = self.env['crm.estimation'].search([('id','=',estimation)])
        if self.action == 'create':
            partner = est.crm_id._create_customer()
        elif self.action == 'exist':
            partner = self.partner_id
        partner = self.partner_id
        self.create_draft_so(partner,est)

    def create_draft_so(self,partner,est):
        vals = self._prepare_so_vals(partner,est)
        so=self.env['sale.order'].sudo().create(vals)
        for es in est:
            es.rfq_created = True
            es.sale_id = so.id
        return {
        'name': _('SO'),
        'view_mode': 'form',
        'res_model': 'sale.order',
        'view_id': self.env.ref('sale.view_order_form').id,
        'type': 'ir.actions.act_window',
        'res_id':so.id,
        }

    def _prepare_so_vals  (self,partner,est):
        # lines = self.env['crm.estimation.category.line'].search([('estimation_id','=',est.id)],order='seq asc,category_id asc')
        # if len(lines) > 0:
        #     category_id = lines[0].category_id
        #     seqnc = lines[0].seq
        #     details_list = []
        #     if lines[0].category_id.parent_id:
        #         parent = lines[0].category_id.parent_id
        #         details_list.append((0, 0, {'display_type': 'line_section', 'name': lines[0].category_id.parent_id.name, 'product_id': False}))
        #         details_list.append((0, 0, {'display_type':'line_note','name':lines[0].category_id.name,'product_id':False}))
        #     else:
        #         details_list.append((0, 0, {'display_type': 'line_section',
        #                                     'name': lines[0].category_id.name,
        #                                     'product_id': False}))
        #     seq = 1
        #     for line in lines:
        #         if line.seq == seqnc:
        #             new_seq = line.seq +"."+ str(seq)
        #             if line.category_id == category_id:
        #                 details_list.append((0, 0, {'display_type': False, 'name': line.item.name,'product_id':line.item.id,'product_uom_qty':line.qty,'price_unit':line.rate+line.margin,
        #                                         'estimation_id':line.estimation_id.id,'category_id':line.category_id.id,'desc':line.description,'discount':line.discount}))
        #             else:
        #                 details_list.append(
        #                     (0, 0, {'display_type': 'line_note', 'name': line.category_id.name, 'product_id': False}))
        #                 details_list.append((0, 0, {'display_type': False, 'name': line.item.name,'product_id':line.item.id,'product_uom_qty':line.qty,'price_unit':line.rate+line.margin,
        #                                         'estimation_id':line.estimation_id.id,'category_id':line.category_id.id,'desc':line.description,'discount':line.discount}))
        #                 category_id = line.category_id
        #             seq+=1
        #         else:
        #             if line.category_id.parent_id:
        #                 parent = line.category_id.parent_id
        #                 details_list.append((0, 0, {'display_type': 'line_section',
        #                                             'name':line.category_id.parent_id.name, 'product_id': False}))
        #                 details_list.append(
        #                     (0, 0, {'display_type': 'line_note', 'name': line.category_id.name, 'product_id': False}))
        #             else:
        #                 details_list.append((0, 0, {'display_type': 'line_section',
        #                                             'name':line.category_id.name,
        #                                             'product_id': False}))
        #             details_list.append((0, 0, {'display_type': False, 'name': line.item.name,'product_id':line.item.id,'product_uom_qty':line.qty,'price_unit':line.rate+line.margin,
        #                                         'estimation_id':line.estimation_id.id,'category_id':line.category_id.id,'desc':line.description,'discount':line.discount}))
        #             category_id = line.category_id
        #             seq = 2
        #             seqnc = line.seq
        if len(est.category_line_ids)==0:
            raise ValidationError(_("No service found for sale order creation"))
        details_list =[]
        for line in est.category_line_ids:
            t_rate = 0
            tag_no = line.tag_no
            if tag_no != 0:
                for tag in range(1, tag_no+1):
                    tag_n = 'group'+str(tag)
                    itm_line = self.env['crm.estimation.category.line'].search([('tag_ids.code','=',tag_n),('category_line_id','=',line.id)])
                    if len(itm_line) != 0:
                        t_rate += itm_line[0].amount
            itm = self.env['crm.estimation.category.line'].search([('tag_ids', '=', False),('category_line_id','=',line.id)])
            for it in itm:
                t_rate += it.amount
            details_list.append((0, 0, {'display_type': False, 'name': line.category_id.product_id.name, 'product_id':line.category_id.product_id.id,
                                        'product_uom_qty': 1, 'price_unit': t_rate + line.margin,
                                                                                'estimation_id':line.estimation_id.id,'category_id':line.category_id.id,'discount':line.discount,'category_line_id':line.id}))

        rev_count = self.env['sale.order'].search_count([('estimation_id', '=', est.id)])
        so_vals = {
            'partner_id': partner.id,
            'company_id':self.env.company.id,
            'revision_number': 'REV' + str(rev_count),
            'origin':est.name,
            # 'project_id':est.project_id.id,
            'order_line':details_list,
            'estimation_id':est.id,

        }
        return so_vals

