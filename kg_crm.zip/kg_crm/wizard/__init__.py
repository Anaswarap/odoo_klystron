# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import template_wizard
from . import rfq_from_item_line
from . import crm_quotation_create
from . import amount_set_wizard
from . import project_update_wizard
from . import invoice_from_project
from . import estimation_import