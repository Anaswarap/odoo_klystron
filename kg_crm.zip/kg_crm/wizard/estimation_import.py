# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
import os
import time
import tempfile
import binascii
import xlrd
import io

from odoo.http import request
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from datetime import date, datetime
from odoo.exceptions import Warning, ValidationError, UserError
from odoo import models, fields, exceptions, api, _

import logging

_logger = logging.getLogger(__name__)

try:
    import csv
except ImportError:
    _logger.debug('Cannot `import csv`.')
try:
    import xlwt
except ImportError:
    _logger.debug('Cannot `import xlwt`.')
try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')
try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')


class EstimationImport(models.TransientModel):
    _name = 'estimation.import'
    _description = 'Estimation Import'

    file = fields.Binary('File')
    file_name = fields.Char("Image Filename")
    crm_estimation_id = fields.Many2one('crm.estimation')

    def import_xls(self):
        if self.file:
            if self.file_name.endswith(('.xlsx', '.xlsm', '.xlsb', '.xltx', '.xltm', '.xls', '.xlt', '.xls', '.xlam',
                                        '.xla', '.xlw', '.xlr')):
                fp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
                fp.write(binascii.a2b_base64(self.file))
                fp.seek(0)
                values = {}
                workbook = xlrd.open_workbook(fp.name)
                sheet = workbook.sheet_by_index(0)
                # print("sheet.nrows-->",sheet.nrows+1)
                for row_no in range(sheet.nrows):
                    val = {}
                    tax_line = ''
                    if row_no <= 0:
                        fields = map(lambda row: row.value.encode('utf-8'), sheet.row(row_no))
                    else:
                        estimation = self.env['crm.estimation'].browse(self._context.get('active_ids', [])).ids
                        est = self.env['crm.estimation'].search([('id', '=', estimation)])
                        line = list(
                            map(lambda row: isinstance(row.value, bytes) and row.value.encode('utf-8') or str(
                                row.value),
                                sheet.row(row_no)))
                        uom = self.chk_uom(line[7], line[8])
                        if line[0] != '':
                            parent_cat = self.env['work.categories'].search([('name','=',line[0])],limit=1)
                            if len(parent_cat) == 0:
                                parent_cat = self.create_category(line[0],uom)
                        if line[1] != '':
                            domain = [('name', '=', line[1])]
                            if len(parent_cat) != 0:
                                domain.append(('parent_id', '=', parent_cat.id))
                            sub_cat1 = self.env['work.categories'].search(domain, limit=1)
                            if len(sub_cat1) == 0:
                                sub_cat1 = self.create_category(line[1],uom)
                                sub_cat1.update({'parent_id':parent_cat.id})
                        if line[2] != '':
                            domain = [('name', '=', line[2])]
                            if len(sub_cat1) != 0:
                                domain.append(('parent_id', '=', sub_cat1.id))
                            sub_cat2 = self.env['work.categories'].search(domain, limit=1)
                            if len(sub_cat2) == 0:
                                sub_cat2 = self.create_category(line[2],uom)
                                sub_cat2.update({'parent_id': sub_cat1.id})
                        if line[2] != '':
                            catgr = sub_cat2
                        elif line[1] != '':
                            catgr = sub_cat1
                        elif line[0] != '':
                            catgr = parent_cat

                        category_line_vals = []
                        cat_list = []
                        category_line_vals.append((0, 0, {
                            'description': line[6],
                            'item': uom.id,
                            'qty': line[9],
                            'rate': line[10],
                            'amount':line[11],
                            'percent': line[12],
                            'budget': line[13],
                            'seq':  line[3],
                            'category_id': catgr.id,
                        }))
                        line_vals = { 'category_id':catgr.id,
                                        'estimation_id':self.id,
                                        'sequence': line[3],
                                        'margin':line[4],
                                        # 'seq': line[3],
                                        'item_line_ids':category_line_vals
                                        }
                        cat_list.append((0, 0,line_vals))
                        est.category_line_ids = cat_list
                        # self.env['estimation.category.line'].create(line_vals)
            else:
                raise UserError(_("This file type is not supported."))




    def chk_uom(self,unit,category):
        if category == '':
            raise UserError(_("Unit's Category is missing"))
        elif unit == '':
            raise UserError(_("Unit is missing"))
        cat = self.env['uom.category'].search([('name','=',category)],limit=1)
        if len(cat) == 0:
            cat = self.env['uom.category'].create({'name': category})
        uom = self.env['uom.uom'].search([('name','=',unit),('category_id','=',cat.id)],limit=1)
        if len(uom) == 0:
            uom = self.env['uom.uom'].create({'name':unit,'category_id':cat.id})
        return  uom

    def create_category(self,catg, uom):
        cat = self.env['work.categories'].create({'name':catg,'uom_id':uom.id})
        return cat;



    # def create_or_update_categories(self, category_names):
    #     parent_category = False
    #     uom_id = False
    #     product_id = False
    #     for name in category_names:
    #         print("name----------", name)
    #         category = self.env['work.categories'].search([
    #             ('name', '=', name),
    #             ('parent_id', '=', parent_category.id if parent_category else False),
    #             ('uom_id', '=', uom_id.id if uom_id else False),
    #             ('product_id', '=', product_id.id if product_id else False),
    #         ], limit=1)
    #         print("category55555555", category)
    #         if not category:
    #             default_values = {
    #                 'name': name,
    #                 'parent_id': parent_category.id if parent_category else False,
    #                 'uom_id': uom_id.id if uom_id else False,
    #                 'product_id': product_id.id if product_id else False
    #             }
    #             category = self.env['work.categories'].create(default_values)
    #             print("category123--------", category)
    #         else:
    #             category.write({'name': name})
    #             print("category.write({'name': name})-------", category.write({'name': name}))
    #         parent_category = category
    #         print("parent_category1111111", parent_category)
    #     return parent_category
