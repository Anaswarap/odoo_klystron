from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class ProjectWizard(models.TransientModel):
    _name = "project.update.wizard"

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    project_id = fields.Many2one('project.project', string="Project")

    def show_project_updates(self):
        if self.project_id:
            domain = [('project_id', '=', self.project_id.id)]
            if self.start_date:
                domain += [('date', '>=', self.start_date)]
            if self.end_date:
                domain += [('date', '<=', self.end_date)]
            updates = self.env['project.update'].search(domain)

            action = {
                'name': 'Project Update',
                'type': 'ir.actions.act_window',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.update',
                'context': {},
                'domain': [('id', 'in', updates.ids)],
                'target': 'current',
                'search_view_id': [self.env.ref('project.project_update_view_search').id]
            }
            return action
        else:
            raise UserError("Please choose a project for fetching updates")
