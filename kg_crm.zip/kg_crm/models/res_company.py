from odoo import models, fields

class ResCompany(models.Model):
    _inherit = 'res.company'

    terms_and_conditions = fields.Html(string="Terms and Conditions")