import base64
import io
from datetime import datetime

from odoo import api, fields, models, _, _lt
from odoo.exceptions import ValidationError, AccessError
import json
from odoo.tools import date_utils

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter
from io import BytesIO

try:
    from base64 import encodebytes
except ImportError:
    from base64 import encodestring as encodebytes


class ProjectTask(models.Model):
    _inherit = "project.task"

    estimation_item_line_id = fields.Many2one('crm.estimation.category.line')
    task_weightage = fields.Float("Weightage")
    task_completion = fields.Float("Task Completion")
    sub_task_comp = fields.Float("Task Completion", compute='compute_sub_task_completion')
    sub_task_weightage = fields.Float("Task Completion", compute='compute_sub_task_weightage')
    is_child = fields.Boolean('Is Child', compute='compute_parent_read_only', store=True)

    @api.depends('parent_id')
    def compute_parent_read_only(self):
        for task in self:
            if task.parent_id == True:
                task.is_child = True

    @api.depends('child_ids')
    def compute_sub_task_completion(self):
        for task in self:

            if task.child_ids:
                subtask_lenth = len(task._get_all_subtasks())

                task_com = 0
                no_of_task = subtask_lenth
                print(no_of_task, "no_of_task..")

                sub_tasks = self.env['project.task'].sudo().search([('parent_id', '=', task.id)])
                print(sub_tasks, "subtasks............")
                for tsk in sub_tasks:
                    print(tsk, "sub...............")
                    task_com += ((tsk.task_completion) / 100 / no_of_task) * 100
                    print(task_com, "task ", tsk.task_completion)

                print(task_com, "final")
                task.sub_task_comp = task_com
                task.write({'task_completion': task_com})


            else:
                # task.task_completion = 0.0
                task.sub_task_comp = 0.0

    @api.depends('child_ids')
    def compute_sub_task_weightage(self):
        for task in self:

            if task.child_ids:
                subtask_lenth = len(task._get_all_subtasks())

                task_com = 0
                no_of_task = subtask_lenth
                print(no_of_task, "no_of_task..")

                sub_tasks = self.env['project.task'].sudo().search([('parent_id', '=', task.id)])
                print(sub_tasks, "subtasks............")
                for tsk in sub_tasks:
                    print(tsk, "sub...............")
                    task_com += ((tsk.task_weightage) / 100 / no_of_task) * 100
                    print(task_com, "task ", tsk.task_weightage)

                print(task_com, "final")
                task.sub_task_weightage = task_com
                task.write({'task_weightage': task_com})


            else:
                # task.task_completion = 0.0
                task.sub_task_weightage = 0.0

    @api.constrains('task_weightage', 'child_ids')
    def validate_subtask_weightage(self):
        # project = self.env['project.project'].sudo().search(
        #     [('id', '=', self.project_id.id), ('task_ids', '!=', self.child_ids.ids)])
        # print(project,"<<<",project.task_ids,">>>",project.task_ids.child_ids.ids)
        # for tsk in project.task_ids.child_ids.ids:
        tasks = self.env['project.task'].sudo().search(
            [('project_id', '=', self.project_id.id), ('parent_id', '!=', False)])
        print(tasks, "<<subtask", self.child_ids.ids)
        for task in tasks:
            task_weightage_sum = sum(tasks.mapped('task_weightage'))

            task_weightage_sum *= 100
            print(task_weightage_sum, "totllllsubtask")

            if task_weightage_sum > 100:
                raise ValidationError("Total Subtask Weightage Percentage exceeded...")
            if task.task_completion > 100:
                raise ValidationError(_('Amount Exceeded.Possible Upto 100%'))


    @api.constrains('task_weightage')
    def validate_task_weightage(self):

        tasks = self.env['project.task'].sudo().search(
            [('project_id', '=', self.project_id.id), ('parent_id', '=', False)])
        print(tasks, "<<task", self.child_ids.ids)
        for task in tasks:
            task_weightage_sum = sum(tasks.mapped('task_weightage'))
            task_weightage_sum *= 100
            print(task_weightage_sum, "totlllllllllllllllllllllllllllllllllll")

            if task_weightage_sum > 100:
                raise ValidationError("Total Weightage Percentage exceeded...")
            if task.task_completion > 100:
                raise ValidationError(_('Amount Exceeded.Possible Upto 100%'))


class Project(models.Model):
    _inherit = "project.project"

    estimation_id = fields.Many2one('crm.estimation')
    category_line_ids = fields.One2many('estimation.category.line', 'project_id', copy=True)
    variation_category_line_ids = fields.One2many('estimation.category.line', 'vari_project_id', copy=True)
    count_received = fields.Integer(compute='_get_received_count')
    purchase_details_ids = fields.One2many('purchase.order', 'project_rel_id', string="Purchase Details")
    is_purchase = fields.Boolean(string="Is Purchase", default=False, compute='compute_is_purchase')
    mobilization_ids = fields.One2many('mobilization.expense.line', 'parent_id', string="Mobilization Expense")
    total_project_value = fields.Float(string="Total Invoice Value", compute='compute_total_expense')
    total_amount_received = fields.Float(string="Total Amount Received", compute='compute_total_expense')
    outstanding_amount = fields.Float(string="Outstanding Amount", compute='compute_total_expense')
    total_expense_open_liability = fields.Float(string="Total Expense + Open Liability",
                                                compute='compute_total_expense')
    fileout = fields.Binary('File', readonly=True)
    fileout_filename = fields.Char('Filename', readonly=True)
    sequence_import=fields.Char("Project Number")
    total_project_value_import= fields.Float(string="Total Project Value import")
    project_value= fields.Float(string="Project Value",compute='compute_project_value',store=True)
    total_variation_value = fields.Float(string="Total Variation Value",store=True)
    amount_paid= fields.Float(string="Amount Paid")
    total_paid= fields.Float(string="Total Paid",)
    project_completion = fields.Float("Project Completion",compute='compute_project_completion',store=True)
    # total_expense = fields.Float(string="Total Expense", compute='_compute_total_expense')
    total_expense = fields.Float(string="Total Expense",compute='_compute_total_expense_amount')
    # open_liability = fields.Float(string="Open Liability", compute='_compute_open_liability')
    open_liability = fields.Float(string="Open Liability",compute='_compute_open_liability')

    @api.depends('sale_line_id', 'task_ids.task_weightage', 'task_ids.task_completion')
    def compute_project_completion(self):
        for project in self:
            task_com = 0
            pro_task = self.env['project.task'].sudo().search(
                [('project_id', '=', project.id), ('id', '!=', project.task_ids.child_ids.ids)])
            for task in pro_task:
                task_com += (task.task_weightage * task.task_completion)
            project.project_completion = task_com * 100

    @api.depends('sale_order_id')
    def compute_project_value(self):
        for line in self:
            # items = line.category_line_ids.item_line_ids
            # line.project_value = sum(line.category_line_ids.mapped('budget_tot'))
            line.project_value = line.sale_order_id.amount_untaxed

    def create_invoice_from_project(self):
        self.ensure_one()
        action = self.env["ir.actions.actions"]._for_xml_id("kg_crm.action_view_project_invoice_wizard")
        action['context'] = {
            'default_project_id': self.id,

        }
        action['domain'] = [('project_id', '=', self.id)]
        return action

    @api.depends('purchase_details_ids')
    def compute_total_expense(self):
        for i in self:
            sales = i.sale_order_id
            invoice = sales.mapped('invoice_ids')
            total_pv = 0
            total_amt_rc = 0
            total_out_amt = 0
            for inv in invoice:
                total_pv += inv.amount_total
                print("total_pv", total_pv)
                total_amt_rc += (inv.amount_total - inv.amount_residual)
                total_out_amt += inv.amount_residual_signed
            i.total_project_value = total_pv
            i.total_paid = total_pv
            i.total_amount_received = total_amt_rc
            i.outstanding_amount = total_out_amt
            if i.purchase_details_ids:
                paid_amount = sum(i.purchase_details_ids.mapped('paid_amount'))
                balance_amount = sum(i.purchase_details_ids.mapped('balance_amount'))
                print("balance_amount", balance_amount)
                if i.mobilization_ids:
                    expense_amount = sum(i.mobilization_ids.mapped('amount'))
                    print("expense_amount", expense_amount)
                else:
                    expense_amount = 0.00
                i.total_expense_open_liability = paid_amount + abs(balance_amount) + expense_amount
                print(" i.total_expense_open_liability",   i.total_expense_open_liability)
                print(" paid_amount",   paid_amount)
                print("abs(balance_amount)",  abs(balance_amount))
                print("expense_amount",   expense_amount)
            else:
                if i.mobilization_ids:
                    expense_amount = sum(i.mobilization_ids.mapped('amount'))
                else:
                    expense_amount = 0.00
                i.total_expense_open_liability = expense_amount

    # @api.depends('purchase_details_ids', 'mobilization_ids')
    # def compute_total_expenses(self):
    #     for i in self:
    #         total_expense = 0.00
    #         open_liability = 0.00
    #
    #         if i.purchase_details_ids:
    #             total_expense += sum(i.purchase_details_ids.mapped('paid_amount'))
    #             total_expense += abs(sum(i.purchase_details_ids.mapped('balance_amount')))
    #
    #         if i.mobilization_ids:
    #             open_liability += sum(i.mobilization_ids.mapped('amount'))
    #             print("open_liability------------",open_liability)
    #
    #         i.total_expense = total_expense
    #         i.open_liability = open_liability
    # @api.depends('purchase_details_ids.amount_total')
    # def _compute_total_expenses(self):
    #     print("self----------")
    #     for project in self:
    #         print("project----------", project)
    #         total_expense = sum(
    #             project.purchase_details_ids.mapped('amount_total')
    #         )
    #         print("total_expense----------", total_expense)
    #         project.total_expense = total_expense

    # @api.depends('purchase_details_ids.invoice_ids.amount_residual_signed')
    # def _compute_open_liability(self):
    #     for project in self:
    #         open_liability = sum(
    #             project.purchase_details_ids.mapped('invoice_ids.amount_residual_signed')
    #         )
    #         project.open_liability = open_liability
    @api.depends('purchase_details_ids')
    def _compute_open_liability(self):
        for record in self:
            if record.purchase_details_ids:
                balance_amount = sum(record.purchase_details_ids.mapped('balance_amount'))
            else:
                balance_amount = 0.0

            record.open_liability = abs(balance_amount)

    @api.depends('purchase_details_ids', 'mobilization_ids')
    def _compute_total_expense_amount(self):
        for record in self:
            if record.purchase_details_ids:
                paid_amount = sum(record.purchase_details_ids.mapped('paid_amount'))
                balance_amount = sum(record.purchase_details_ids.mapped('balance_amount'))
            else:
                paid_amount = 0.0
                balance_amount = 0.0

            if record.mobilization_ids:
                expense_amount = sum(record.mobilization_ids.mapped('amount'))
            else:
                expense_amount = 0.0

            record.total_expense = paid_amount + abs(balance_amount) + expense_amount

    # @api.depends('purchase_details_ids.invoice_ids.amount_total')
    # def _compute_total_expense(self):
    #     print("self----------")
    #     for project in self:
    #         print("project----------",project)
    #         total_expense = sum(
    #             project.purchase_details_ids.mapped('invoice_ids.amount_total')
    #         )
    #         print("total_expense----------", total_expense)
    #         project.total_expense = total_expense

    # @api.depends('purchase_details_ids.invoice_ids.amount_residual_signed')
    # def _compute_open_liability(self):
    #     print("hhhhhhhhhhhh",self.purchase_details_ids.invoice_ids.amount_residual_signed)
    #     for project in self:
    #         open_liability = sum(
    #             project.purchase_details_ids.mapped('invoice_ids.amount_residual_signed')
    #         )
    #         project.open_liability = open_liability

    @api.depends('estimation_id')
    def compute_is_purchase(self):
        for i in self:
            if i.estimation_id:
                po = i.env['purchase.order'].search([('estimation_id', '=', i.estimation_id.id)])
                po.write({'project_rel_id': i.id})
                if po:
                    i.is_purchase = True
                else:
                    i.is_purchase = False
            else:
                i.is_purchase = False

    def _get_received_count(self):
        for rec in self:
            pick = self.env['stock.picking'].search([('project_id', '=', rec.id)])
            rec.count_received = len(pick)

    def action_view_receive_product(self):
        """view receive product"""
        action = self.env.ref("stock.action_picking_tree_ready").sudo().read()[0]
        action["domain"] = [('project_id', '=', self.id)]
        return action

    def action_receive_product(self):
        """Receive product for the project"""
        company = self.env.company.id
        dest_location_id = self.env['stock.location'].search(
            [('company_id', '=', company), ('usage', '=', 'production')], limit=1).id
        stock_picking_type = self.env['stock.picking.type'].search(
            [('company_id', '=', company), ('code', '=', 'internal')], limit=1)
        if len(stock_picking_type) == 0:
            raise ValidationError(("Please Enable location from settings"))
        return {
            'name': _('Internal Transfer'),
            'view_mode': 'form',
            'res_model': 'stock.picking',
            'view_id': self.env.ref('stock.view_picking_form').id,
            'context': {'default_location_dest_id': dest_location_id, 'default_picking_type_id': stock_picking_type.id,
                        'project_transfer': True, 'default_origin': 'Project:' + self.name,
                        'default_project_id': self.id},
            'type': 'ir.actions.act_window',
        }

    def project_update_view_action(self):
        return {
            'name': _('Project'),
            'view_mode': 'form',
            'res_model': 'project.project',
            'view_id': self.env.ref('project.edit_project').id,
            'type': 'ir.actions.act_window',
            'res_id': self.id,
        }

    def _get_stat_buttons(self):
        buttons = super(Project, self)._get_stat_buttons()
        all_purchase_orders = self.env['purchase.order'].search([('estimation_id', '=', self.estimation_id.id)])
        buttons.append({
            'icon': 'dollar',
            'text': _lt('Purchase Orders'),
            'number': len(all_purchase_orders),
            'action_type': 'object',
            'action': 'action_view_pos',
            'show': len(all_purchase_orders) > 0,
            'sequence': 1,
        })
        invoice = []
        for po in all_purchase_orders:
            invoice += po.invoice_ids.ids
        buttons.append({
            'icon': 'dollar',
            'text': _lt('Vendor Bill'),
            'number': len(invoice),
            'action_type': 'object',
            'action': 'action_view_vendor_bill',
            'show': len(invoice) > 0,
            'sequence': 1,
        })
        return buttons

    def _get_stat_buttons(self):
        buttons = super(Project, self)._get_stat_buttons()
        all_sale_orders = self.env['sale.order'].search([('estimation_id', '=', self.estimation_id.id)])
        buttons.append({
            'icon': 'dollar',
            'text': _lt('Sale Orders'),
            'number': len(all_sale_orders),
            'action_type': 'object',
            'action': 'action_view_so',
            'show': len(all_sale_orders) > 0,
            'sequence': 1,
        })
        invoice = []
        for so in all_sale_orders:
            inv= so.invoice_ids.ids
            print(inv)
            invoice += so.invoice_ids.ids
            print(invoice,"invcesssssssssssssss")
        buttons.append({
            'icon': 'dollar',
            'text': _lt('Invoices'),
            'number': len(invoice),
            'action_type': 'object',
            'action': 'action_view_invoice',
            'show': len(invoice) > 0,
            'sequence': 1,
        })
        return buttons

    def action_view_invoice(self):
        self.ensure_one()
        all_sale_orders = self.env['sale.order'].search([('estimation_id', '=', self.estimation_id.id),('partner_id', '=', self.partner_id.id)])
        print(all_sale_orders)
        action_window = {
            "type": "ir.actions.act_window",
            "res_model": 'account.move',
            'name': _("%(name)s's Invoice", name=self.name),
            "context": {"create": False,"show_sale": True,'default_move_type': 'out_invoice',},
        }
        invoice = []
        for so in all_sale_orders:
            print(so,"sale order")
            inv= so.invoice_ids.ids
            print(inv,"invvvvvv")
            invoice += so.invoice_ids.ids
            print(invoice,"invoice created")


        if len(invoice) == 1:
            action_window.update({
                "res_id": invoice[0],
                "views": [[False, "form"]],
            })
        else:
            action_window.update({
                "domain": [('id', 'in', invoice)],
                "views": [[False, "tree"], [False, "kanban"], [False, "pivot"],
                          [False, "graph"], [False, "activity"], [False, "form"]],
            })
        return action_window

    def action_view_vendor_bill(self):
        self.ensure_one()
        all_purchase_orders = self.env['purchase.order'].search([('estimation_id', '=', self.estimation_id.id)])
        action_window = {
            "type": "ir.actions.act_window",
            "res_model": 'account.move',
            'name': _("%(name)s's Vendor Bill", name=self.name),
            "context": {"create": False, "show_sale": True},
        }
        invoice = []
        for po in all_purchase_orders:
            invoice += po.invoice_ids.ids
        if len(invoice) == 1:
            action_window.update({
                "res_id": invoice[0],
                "views": [[False, "form"]],
            })
        else:
            action_window.update({
                "domain": [('id', 'in', invoice)],
                "views": [[False, "tree"], [False, "kanban"], [False, "pivot"],
                          [False, "graph"], [False, "activity"], [False, "form"]],
            })
        return action_window

    def action_view_so(self):
        self.ensure_one()
        all_sale_orders = self.env['sale.order'].search(
            [('estimation_id', '=', self.estimation_id.id)])
        action_window = {
            "type": "ir.actions.act_window",
            "res_model": "sale.order",
            'name': _("%(name)s's Sale Order", name=self.name),
            'search_view_id': [self.env.ref('sale.sale_order_view_search_inherit_sale').id],
            "context": {"create": True, "show_sale": True},

        }
        print("act0", action_window)

        if len(all_sale_orders) == 1:
            action_window.update({
                "res_id": all_sale_orders.id,
                "views": [[False, "form"]],
                "context": {"create": True, 'default_project_rel_id': self.id,
                            'default_estimation_id': self.estimation_id.id},
                # "views": [["form",False]],
            })

        else:
            action_window.update({
                "domain": [('id', 'in', all_sale_orders.ids)],
                "context": {'default_project_rel_id': self.id, 'default_estimation_id': self.estimation_id.id},
                "views": [[False, "tree"], [False, "kanban"], [False, "calendar"], [False, "pivot"],
                          [False, "graph"], [False, "activity"], [False, "form"]],

            })
        return action_window

    def action_view_pos(self):
        self.ensure_one()
        all_purchase_orders = self.env['purchase.order'].search(
            [('estimation_id', '=', self.estimation_id.id)])
        action_window = {
            "type": "ir.actions.act_window",
            "res_model": "purchase.order",
            'name': _("%(name)s's Purchase Order", name=self.name),
            'search_view_id': [self.env.ref('purchase.purchase_order_view_search').id],
            "context": {"create": True, "show_sale": True, 'search_default_vendor': 1},

        }
        print("act0", action_window)

        if len(all_purchase_orders) == 1:
            action_window.update({
                "res_id": all_purchase_orders.id,
                "views": [[False, "form"]],
                "context": {"create": True,'default_project_rel_id': self.id,'default_estimation_id':self.estimation_id.id},
                # "views": [["form",False]],
            })

        else:
            action_window.update({
                "domain": [('id', 'in', all_purchase_orders.ids)],
                "context": {'default_project_rel_id': self.id,'default_estimation_id':self.estimation_id.id},
                "views": [[False, "tree"], [False, "kanban"], [False, "calendar"], [False, "pivot"],
                          [False, "graph"], [False, "activity"], [False, "form"]],

            })
        return action_window


    def action_view_purchase_milestone(self):
        return {
            'name': 'Purchase Milestone',
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'res_model': 'purchase.milestone',
            'context': {'search_default_partner_new_id': 1},
            # 'search_default_partner_id': self.partner_id.id,
            'domain': [('project_id', '=', self.id)],
            'target': 'current'
        }

    def generate_xlsx_report(self, workbook, data=None, objs=None):
        print("HHH")
        sheet = workbook.add_worksheet('PAYMENT STATUS (PROJECT)')
        format0 = workbook.add_format({'font_size': 20, 'align': 'center', 'bold': True})
        format1 = workbook.add_format({'font_size': 10, 'align': 'vcenter'})
        format2 = workbook.add_format({'font_size': 10, 'align': 'vcenter', 'bold': True})
        format11 = workbook.add_format({'font_size': 12, 'align': 'center', 'bold': True})
        date_style = workbook.add_format({'text_wrap': True, 'num_format': 'dd-mm-yyyy'})
        border_text_centr = workbook.add_format(
            {'border': 1, 'align': 'center', 'font_size': 14, 'bold': True})

        row = 0
        v_sum = 0.00
        # print(self.id, "IDDDDD")
        # sheet.write(count, 0, '', format0)
        company_logo = io.BytesIO(base64.b64decode(self.env.user.company_id.logo))
        sheet.merge_range(row, 0, row, 6, 'PAYMENT STATUS (PROJECT)', border_text_centr)
        # sheet.insert_image(row, 7, "image.png", {'image_data': company_logo})

        row += 1
        sheet.set_column(0, 8, 15)
        # sheet.set_column(6, 7, 15)
        sheet.merge_range(row, 0, row, 4, self.name, format2)
        sheet.merge_range(row, 5, row, 8, '', format1)

        vendors = self.purchase_details_ids.mapped('partner_id')
        for vend in vendors:
            row += 1
            sheet.merge_range(row, 0, row, 3, 'Vendor : ' + str(vend.name), format2)
            for i in self.purchase_details_ids:
                purchase = self.env['purchase.order'].search([('name', '=', i.name)])
                for purch in purchase:
                    row += 1
                    sheet.write(row, 0, 'PO No', format2)
                    sheet.write(row, 1, 'Amount', format2)
                    sheet.write(row, 2, 'Balance Amount', format2)
                    sheet.write(row, 3, 'Total Amount', format2)
                    sheet.write(row, 4, 'Payment Status', format2)

                    payment = self.env['account.payment'].search([('purchase_id', '=', purch.id)])

                    row + 1
                    sheet.write(row, 0, purch.name, format2)
                    sheet.write(row, 1, purch.amount_total, format2)
                    # sheet.write(row, 2, purch., format2)
                    sheet.write(row, 3, 'Total Amount', format2)
                    sheet.write(row, 4, 'Payment Status', format2)

    def print_xlsx(self):
        active_ids_tmp = self.env.context.get('active_ids')
        active_model = self.env.context.get('active_model')
        data = {
            # 'output_type': self.read()[0]['output_type'][0],
            'ids': active_ids_tmp,
            'context': {'active_model': active_model},
        }
        file_io = BytesIO()
        workbook = xlsxwriter.Workbook(file_io)

        self.generate_xlsx_report(workbook, data=data)

        workbook.close()
        fout = encodebytes(file_io.getvalue())

        datetime_string = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_name = 'PAYMENT STATUS (PROJECT)'
        filename = '%s_%s' % (report_name, datetime_string)
        self.write({'fileout': fout, 'fileout_filename': filename})
        file_io.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model=' + self._name + '&id=' + str(
                self.id) + '&field=fileout&download=true&filename=' + filename,
        }

    def name_get(self):
        result = []
        for rec in self:
            name =  rec.name +'[' + str(rec.estimation_id.name) + '] '
            result.append((rec.id, name))
        return result

class MobilizationExpense(models.Model):
    _name = 'mobilization.expense.line'
    _description = "Mobilization Expense"

    name = fields.Char(string="Description")
    amount = fields.Float(string="Amount")
    parent_id = fields.Many2one('project.project', "Project Id")
