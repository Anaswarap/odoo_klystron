from odoo import api, fields, models, _
from odoo.addons.web_approval.models.approval_mixin import _APPROVAL_STATES

from odoo.exceptions import UserError


class AccountPayment(models.Model):
    _name = "account.payment"
    _inherit = ['account.payment', 'approval.mixin']

    job_no = fields.Char(string="Job No")
    job_no_id = fields.Many2one('project.project', string="Job No")
    job_name = fields.Char(string="Job Name")
    lpo_amount = fields.Monetary(string="LPO Amount")
    lpo_no_id = fields.Many2one('purchase.order', string="LPO NO")
    lpo_no = fields.Char(string="LPO Number")
    approval_state = fields.Selection(string='Approval Status', selection=_APPROVAL_STATES, required=False, copy=False,
                                      is_approval_state=True, tracking=True)
    is_approver = fields.Boolean(compute='compute_is_approver')

    @api.onchange('job_no_id')
    def onchange_job_no_id(self):
        if self.job_no_id:
            self.job_name = self.job_no_id.name

    @api.onchange('lpo_no_id')
    def onchange_lpo_no_id(self):
        if self.lpo_no_id:
            self.lpo_amount = self.lpo_no_id.amount_total

    def action_post(self):
        res = super(AccountPayment, self).action_post()
        if self.payment_type == 'outbound':
            if self.approval_state != 'approve':
                raise UserError(_("You cannot do this action without approval"))
        return res

    def compute_is_approver(self):
        for rec in self:
            print("rec.show_approval_buttons()--->>", rec.show_approval_buttons())
            rec.is_approver = rec.show_approval_buttons()
