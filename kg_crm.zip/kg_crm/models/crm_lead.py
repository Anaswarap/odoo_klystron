# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models,_


class CrmLead(models.Model):
    _inherit = 'crm.lead'


    code = fields.Char(string="Lead Number", required=True, default=_('New'), readonly=True, copy=False)


    is_estimated = fields.Boolean(copy=False,default=False,compute='_compute_is_estimated')
    name = fields.Char(
        'Opportunity', index='trigram', required=True,
        compute='_compute_name', readonly=False, store=True,placeholder='Deal Description')
    kg_amount = fields.Float(
        string='Amount', 
        required=False)
    kg_project_value = fields.Float(
        string='Project Value',
        required=False)

    @api.depends('type')
    def _compute_is_estimated(self):
        est = self.env['crm.estimation'].search([('crm_id','=',self.id)])
        if len(est)>0:
            self.is_estimated =True
        else:
            self.is_estimated = False

    @api.depends(lambda self: ['stage_id', 'team_id'] + self._pls_get_safe_fields())
    def _compute_probabilities(self):
        """removing automated probability"""
        res = super(CrmLead, self)._compute_probabilities()
        print("self._origin-->>",len(self._origin))
        for rec in self:
            if rec.probability == 0.00 or len(rec._origin)==0:
                rec.probability = 0.00
        return res

    def action_create_estimation(self):
        """redirecting to estimation form"""
        action = self.env.ref("kg_crm.action_crm_estimation").sudo().read()[0]
        action["context"] = {'default_crm_id':self.id,'search_default_filter_state':1}
        action["domain"] = [('crm_id','=',self.id)]
        return action

    def action_view_estimations(self):
        action = self.env.ref("kg_crm.action_crm_estimation").sudo().read()[0]
        estimation = self.env['crm.estimation'].search([('crm_id','=',self.id)])
        if len(estimation) > 0:
            action["domain"] = [("id", "in", estimation.ids)]
        return action

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('code', _('New')) == _('New'):
                # if vals.get('type') == 'opportunity':
                    vals["code"] = self.env['ir.sequence'].next_by_code('crm.lead') or _('New')

        return super(CrmLead, self).create(vals_list)

