# -*- coding: utf-8 -*-
import base64
import io
from datetime import datetime, date

# from pkg_resources import _

from odoo import api, fields, models, tools, Command
from odoo.exceptions import UserError, ValidationError
import json
from odoo.tools import date_utils

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter
from io import BytesIO

try:
    from base64 import encodebytes
except ImportError:
    from base64 import encodestring as encodebytes


class SaleOrderInh(models.Model):
    _inherit = 'sale.order'

    estimation_id = fields.Many2one('crm.estimation', readonly=True, store=True)
    earlier_revisions_summ_sale_ids = fields.One2many('earlier.revision.summary', 'earlier_revisions_obj_sale')
    revision_number = fields.Char(string='Revision Number', readonly=1)
    milestone_line_ids = fields.One2many('sale.milestone', 'sale_id')
    fileout = fields.Binary('File', readonly=True)
    fileout_filename = fields.Char('Filename', readonly=True)

    # def _prepare_invoice(self):
    #     self.ensure_one()
    #
    #     return {
    #         'ref': self.client_order_ref or '',
    #         'move_type': 'out_invoice',
    #         'narration': self.note,
    #         'currency_id': self.currency_id.id,
    #         'campaign_id': self.campaign_id.id,
    #         'medium_id': self.medium_id.id,
    #         'source_id': self.source_id.id,
    #         'team_id': self.team_id.id,
    #         'partner_id': self.partner_invoice_id.id,
    #         'partner_shipping_id': self.partner_shipping_id.id,
    #         'fiscal_position_id': (self.fiscal_position_id or self.fiscal_position_id._get_fiscal_position(
    #             self.partner_invoice_id)).id,
    #         'invoice_origin': self.name,
    #         'invoice_payment_term_id': self.payment_term_id.id,
    #         'invoice_user_id': self.user_id.id,
    #         'payment_reference': self.reference,
    #         'transaction_ids': [Command.set(self.transaction_ids.ids)],
    #         'company_id': self.company_id.id,
    #         'invoice_line_ids': [],
    #         'user_id': self.user_id.id,
    #     }

    # def _prepare_invoice(self):
    #     invoice_vals = super(SaleOrderInh, self)._prepare_invoice()
    #     invoice_line_vals = []
    #     for line in self.order_line:
    #         print("line--------",line)
    # invoice_line_vals.append(fields.Command.create({
    #     'quantity': line.product_uom_qty * 0.01,
    #     'account_id': line.product_id.property_account_income_id.id,
    # }))
    # print("invoice_line_vals-",invoice_line_vals)
    # vals = self.invoice_ids.update({
    #     'invoice_line_ids': invoice_line_vals
    # })
    # print("vals-----------",vals)
    # lines = ()
    # invoice_line_vals = self.env['account.move.line'](fields.Command.update(line, {
    #     'quantity': line.product_uom_qty * 0.01,
    # }))

    # self.update({
    #     'invoice_line_ids': [(fields.Command.update(line, {
    #         'quantity': line.product_uom_qty * 0.01,
    #     }
    #                                                 ))]
    # })
    #     invoice_line_vals.append((0,0,{
    #     'product_id': line.product_id.id,
    #     'name': line.name,
    #     'quantity': line.product_uom_qty * 0.01,
    #     'price_unit': line.price_unit,
    #     'account_id': line.product_id.property_account_income_id.id,
    #     }))
    # invoice_vals['invoice_line_ids'] = invoice_line_vals
    # print("invoice_vals---------", invoice_vals)
    # print("invoice_vals---------", invoice_line_vals)
    # return invoice_vals

    def _action_confirm(self):
        """ On SO confirmation, some lines should generate a task or a project. """
        result = super(SaleOrderInh, self)._action_confirm()
        print(self.project_ids, "Proooo")
        for user in self.project_ids:
            params = self.env['ir.config_parameter'].sudo()
            project_manager_id = params.get_param('project_manager_id')
            if project_manager_id:

                user.user_id = int(project_manager_id)
                self.activity_schedule('kg_crm.project_manager_act_approval', note=user.name,
                                       user_id=int(project_manager_id))
            else:
                raise ValidationError(('Configure Senior Project Manager'))

        if self.estimation_id.is_variation:
            for i in self.project_ids:
                i.unlink()
        # print(asdasd)
        if not self.estimation_id.is_variation:
            if len(self.project_ids) > 0 and len(self.estimation_id) > 0:
                project = self.project_ids[0]
                task_list = project.task_ids
                project.estimation_id = self.estimation_id.id
                self.estimation_id.project_id = project.id
                for task in task_list:
                    line = self.order_line.filtered(lambda l: l.id == task.sale_line_id.id)
                    if len(line) > 0:
                        sale_line = line[0]
                        serial = 1
                        for item in sale_line.category_line_id.item_line_ids:
                            planned_hours = sale_line._convert_qty_company_hours(self.company_id)
                            sale_line_name_parts = sale_line.name.split('\n')
                            title = sale_line_name_parts[0] or self.product_id.name
                            title = title + "-" + str(serial)
                            description = item.description
                            values = {
                                'name': title if project.sale_line_id else '%s - %s' % (
                                    self.order_id.name or '', title),
                                'analytic_account_id': project.analytic_account_id.id,
                                'planned_hours': planned_hours,
                                'parent_id': task.id,
                                'partner_id': sale_line.order_id.partner_id.id,
                                'email_from': sale_line.order_id.partner_id.email,
                                'description': description,
                                'project_id': project.id,
                                'display_project_id': project.id,
                                'sale_line_id': sale_line.id,
                                'sale_order_id': sale_line.order_id.id,
                                'company_id': project.company_id.id,
                                'user_ids': False,  # force non assigned task, as created as sudo()
                                'estimation_item_line_id': item.id
                            }
                            serial += 1
                            self.env['project.task'].sudo().create(values)
                # if len(self.milestone_line_ids) == 0:
                #     raise ValidationError(('Set Payment milestone before confirmation'))
                if self.milestone_count != 0:
                    mile_stone = self.env['project.milestone'].search([('sale_line_id', 'in', self.order_line.ids)])
                    sale_line_ids = self.milestone_line_ids.mapped('sale_line_id').ids
                    for m_line in mile_stone:
                        if m_line.sale_line_id.id in sale_line_ids:
                            m_line.unlink()
                    for miles in self.milestone_line_ids:
                        milestone = self.env['project.milestone'].create({
                            'name': miles.milestone,
                            'project_id': project.id,
                            'sale_line_id': miles.sale_line_id.id,
                            'quantity_percentage': miles.percentage,
                            'deadline': miles.deadline,
                        })
                for line in self.order_line:
                    line.category_line_id.project_id = project.id
                self.project_id = project.id
        else:
            self.project_id = self.estimation_id.project_id.id
            variation_value = self.estimation_id.project_id.total_variation_value
            self.estimation_id.project_id.total_variation_value = variation_value + self.amount_untaxed

        return result

    def action_view_task(self):
        result = super(SaleOrderInh, self).action_view_task()
        result['domain'].append(('parent_id', '=', False))
        return result

    @api.constrains('milestone_line_ids')
    def check_uniq_seq(self):
        for rec in self.order_line:
            if len(rec.order_id.project_ids) > 0:
                lines = self.milestone_line_ids
                item_lines = lines.filtered(lambda l: l.sale_line_id.id == rec.id)
                t_perc = sum(item_lines.mapped('percentage')) * 100
                if t_perc != 100:
                    raise ValidationError(('%s total milestones  must be 100 percenatge.' % (rec.name)))

    def generate_xlsx_report(self, workbook, data=None, objs=None):
        print("HHH")
        sheet = workbook.add_worksheet('PROJECT REGISTRATION FORM')
        format0 = workbook.add_format({'font_size': 20, 'align': 'center', 'bold': True, 'border': 1})
        format1 = workbook.add_format({'font_size': 10, 'align': 'vcenter', 'border': 1, })
        format2 = workbook.add_format({'font_size': 10, 'align': 'vcenter', 'bold': True, 'border': 1})
        format11 = workbook.add_format({'font_size': 12, 'align': 'center', 'bold': True})
        date_style = workbook.add_format({'text_wrap': True, 'num_format': 'dd-mm-yyyy', 'border': 1})
        border_text_centr = workbook.add_format(
            {'border': 1, 'align': 'center', 'font_size': 14, 'bold': True})

        row = 0
        v_sum = 0.00
        # print(self.id, "IDDDDD")
        # sheet.write(count, 0, '', format0)
        company_logo = io.BytesIO(base64.b64decode(self.env.user.company_id.logo))
        sheet.merge_range(row, 0, row, 8, 'PROJECT REGISTRATION FORM', border_text_centr)
        # sheet.insert_image(row, 7, "image.png", {'image_data': company_logo})

        row += 1
        sheet.set_column(0, 8, 15)
        # sheet.set_column(6, 7, 15)
        sheet.merge_range(row, 0, row, 4, self.partner_id.contact_address, format2)
        sheet.merge_range(row, 5, row, 8, '', format1)

        row += 1
        sheet.merge_range(row, 0, row, 4, 'Contact Person :' + self.partner_id.name, format2)
        sheet.merge_range(row, 5, row, 8, 'Email/Telephone :' + str(self.partner_id.email), format2)

        row += 1
        sheet.merge_range(row, 0, row, 2, '', format1)
        sheet.merge_range(row, 3, row, 4, 'DIrham', format1)
        sheet.merge_range(row, 5, row, 6, 'Commencement Date', format1)
        sheet.merge_range(row, 7, row, 8, self.date_order, date_style)

        row += 1
        sheet.merge_range(row, 0, row, 2, '', format1)
        sheet.merge_range(row, 3, row, 4, '', format1)
        sheet.merge_range(row, 5, row + 1, 6, 'Completion Date', format1)
        sheet.merge_range(row, 7, row + 1, 8, self.validity_date or '', date_style)

        row += 1
        sheet.merge_range(row, 0, row, 2, '', format1)
        sheet.merge_range(row, 3, row, 4, '', format1)

        row += 1
        sheet.merge_range(row, 0, row + 1, 2, 'Total Project Value', format2)
        sheet.merge_range(row, 3, row + 1, 4, self.amount_total, format2)
        sheet.merge_range(row, 5, row, 8, 'INVOICING & PAYMENT SCHEDULE', format2)
        row += 1
        sheet.write(row, 5, 'Payment Type', format1)
        sheet.write(row, 6, 'Invoice Date', format1)
        sheet.write(row, 7, 'Amount-Dh', format1)
        sheet.write(row, 8, 'Due On', format1)

        row += 1
        sheet.merge_range(row, 0, row, 2, 'Project Manager', format2)
        sheet.merge_range(row, 3, row, 4, 'KP/MM', format2)
        row += 1
        sheet.merge_range(row, 0, row, 2, 'Remarks', format1)
        sheet.merge_range(row, 3, row, 4, '', format1)
        for i in self.milestone_line_ids:
            print(i, "IIIIII")
            perc = i.percentage * 100
            sheet.write(row, 5, str(perc) + '%' + ' ' + str(i.milestone), format1)
            sheet.write(row, 7, str(i.sale_line_id.price_subtotal), format1)
            v_sum += i.sale_line_id.price_subtotal
            row += 1
        row += 1
        sheet.merge_range(row, 0, row, 2, 'Sales', format1)
        sheet.merge_range(row, 3, row, 4, str(self.user_id.name), format1)
        sheet.merge_range(row, 5, row, 6, '5% VAT', format1)
        vat = (v_sum * 5) / 100
        sheet.merge_range(row, 5, row, 6, str(vat), format1)

        row += 1
        sheet.merge_range(row, 0, row, 2, '', format1)
        sheet.merge_range(row, 3, row, 4, '', format1)
        sheet.merge_range(row, 5, row, 6, 'TOTAL', format2)
        sheet.merge_range(row, 7, row, 8, str(v_sum), format2)

        row += 1
        sheet.merge_range(row, 0, row, 4, 'Remarks', format1)
        sheet.merge_range(row, 5, row, 8, 'Purchase Order Ref', format1)

        row += 1
        sheet.merge_range(row, 0, row, 4, str(self.client_order_ref), format1)
        sheet.merge_range(row, 0, row, 4, '', format1)

        row += 1
        sheet.merge_range(row, 0, row, 2, 'G.M', format1)
        sheet.merge_range(row, 3, row, 4, 'Finance & HR Admin', format1)
        sheet.write(row, 5, 'Project Engineer : ', format1)
        sheet.write(row, 6, 'Q.S', format1)
        sheet.write(row, 7, 'Architect:', format1)
        sheet.write(row, 7, 'Accountant:', format1)

        row += 1
        sheet.merge_range(row, 0, row, 2, '', format1)
        sheet.merge_range(row, 2, row, 4, 'SS', format1)
        sheet.write(row, 5, 'KP/MM', format1)
        sheet.write(row, 6, 'MT', format1)
        sheet.write(row, 7, 'MA', format1)
        sheet.write(row, 7, 'JJG', format1)

        row += 1
        sheet.merge_range(row, 0, row, 4,
                          'Project NO:' + str(self.project_id.name) or '' + '\n' + 'Date:' + str(date.today()),
                          format2)
        sheet.merge_range(row, 5, row, 8, 'Approved By' + '\n' + 'JC',
                          format2)

    def print_xlsx(self):
        active_ids_tmp = self.env.context.get('active_ids')
        active_model = self.env.context.get('active_model')
        data = {
            # 'output_type': self.read()[0]['output_type'][0],
            'ids': active_ids_tmp,
            'context': {'active_model': active_model},
        }
        file_io = BytesIO()
        workbook = xlsxwriter.Workbook(file_io)

        self.generate_xlsx_report(workbook, data=data)

        workbook.close()
        fout = encodebytes(file_io.getvalue())

        datetime_string = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_name = 'PROJECT REGISTRATION FORM'
        filename = '%s_%s' % (report_name, datetime_string)
        self.write({'fileout': fout, 'fileout_filename': filename})
        file_io.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model=' + self._name + '&id=' + str(
                self.id) + '&field=fileout&download=true&filename=' + filename,
        }


class SaleOrderLineInh(models.Model):
    _inherit = 'sale.order.line'

    estimation_id = fields.Many2one('crm.estimation', readonly=True, store=True)
    category_id = fields.Many2one('work.categories', readonly=True, store=True)
    category_line_id = fields.Many2one('estimation.category.line')
    desc = fields.Html(readonly=True, store=True)
    budget = fields.Float(string="Budget Estimated")
    budget_utilized = fields.Float(string="Budget Utilized")
    budget_balance = fields.Float(string="Budget Balance")

    line_task_completion = fields.Float("Task Status", compute='compute_task_completion', store=True)
    invoice_percentage = fields.Float(string="Invoice Percentage")
    percentage_check = fields.Float(string="Percentage check")
    percentage_qty = fields.Float(string='Qty Percentage')

    @api.onchange('percentage_qty')
    def _onchange_percentage_qty(self):
        for rec in self:
            if rec.percentage_qty:
                rec.product_uom_qty = rec.percentage_qty
            else:
                self.percentage_qty = 0.0

    # invoice_project_wiz = fields.Many2one('invoice.project')

    @api.depends('order_id.project_id.task_ids', 'order_id.project_id.task_ids.task_weightage',
                 'order_id.project_id.task_ids.task_completion')
    def compute_task_completion(self):
        for line in self:

            for task in line.order_id.project_id.task_ids:
                task_com = task.task_completion
                print(task.task_completion, "task compltion")
                task.sale_line_id.line_task_completion = task_com * 100
            # if task.subtask_count == 0:
            #     task_com = task.task_completion
            #     print(task.task_completion,"task compltion")
            #     task.sale_line_id.line_task_completion = task_com * 100
            # else:
            #     subtask_lenth = len(task._get_all_subtasks())
            #     print(subtask_lenth, 'lngthhhhhhhhhhh')
            #     sub_tasks = self.env['project.task'].sudo().search([('parent_id', '=', task.id)])
            #     print(sub_tasks,"subtasks............")
            #     task_com = 0
            #     no_of_task = subtask_lenth + 1
            #     print(no_of_task)
            #     task_com +=((task.task_completion/100)/no_of_task)*100 if task.task_completion != 0.0 else 0.0
            #     for tsk in sub_tasks:
            #             print(tsk,"sub...............")
            #             task_com += ((tsk.task_completion/100)/no_of_task)*100
            #             print(task_com,"ordr line vallllllllllll")
            #
            #     print(task_com,"final val....")
            #     task.sale_line_id.line_task_completion = task_com *100
            #     print("finished.................",task.sale_line_id.line_task_completion)

            # <!!!!!!!!!!!task calculation with weightage**************!!!!!!!!!!!!>
            # task_com = 0
            # for task in  line.order_id.project_id.task_ids:
            #
            #     print(task.task_weightage,"task wghtage",task.task_completion,"task compltion")
            #     task_com +=(task.task_weightage)*(task.task_completion)
            #     print(task_com, "line taskkkkk")
            #     print(task_com * 100, "status line completion")
            #     task.sale_line_id.line_task_completion = float(task_com * 100)


class MailComposer(models.TransientModel):
    _inherit = 'mail.compose.message'

    email_cc = fields.Many2many('res.partner', 'mail_partner_rel', string='Cc')

    def _action_send_mail(self, auto_commit=False):
        res = super(MailComposer, self)._action_send_mail(auto_commit=auto_commit)
        cc_list = []
        for cc in self.email_cc:
            cc_list.append(cc.email)
        if len(cc_list) != 0:
            mail_cc = ','.join(cc_list)
            for mail in res[1].mail_ids:
                mail.email_cc = mail_cc
        return res
