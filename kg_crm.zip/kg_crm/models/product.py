
from odoo import api, fields, models

class ProductInh(models.Model):
    _inherit = 'product.template'

    margin_perc = fields.Float(help="Margin percenatage for estimation")
    crm_cat_id = fields.Many2one('work.categories')