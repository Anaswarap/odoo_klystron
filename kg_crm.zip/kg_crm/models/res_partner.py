# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ResPartner(models.Model):
    _inherit = 'res.partner'

    # _sql_constraints = [
    #     ('unique_email', 'unique (email)', 'Email address already exists!'),
    #     ('code_company_uniq', 'unique (name,is_company)', 'Name must be unique per company !')
    # ]
    purchase_type = fields.Selection([('local','Local'),('import','Import')],default='local')
    catgory_ser_id = fields.Many2many('res.partner.industry',string="Category/Service")
    vendor_id = fields.Char(string='Vendor ID')

    @api.constrains('email','name','is_company')
    def _check_mail_unique(self):
        # if self.email:
        #     partnr = self.env['res.partner'].search([('email','=',self.email),('id','!=',self.id)])
        #     if len(partnr) > 0:
        #         raise ValidationError(("Email id already exist"))
        for rec in self:
            if rec.name and rec.is_company:
                partnr = self.env['res.partner'].search([('name', '=', rec.name), ('id', '!=', rec.id),('is_company', '=',True)])
                if len(partnr) > 0:
                    raise ValidationError(("Name must be unique per company"))


