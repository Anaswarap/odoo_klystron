from odoo import api, fields, models, _, _lt
from odoo.exceptions import ValidationError, AccessError


class ProjectUpdate(models.Model):
    _inherit = "project.update"

    template_id = fields.Many2one('project.update.template', string="Template")

    @api.onchange('template_id')
    def onchange_template_id(self):
        if self.template_id:
            if self.template_id.template:
                self.description = self.template_id.template

