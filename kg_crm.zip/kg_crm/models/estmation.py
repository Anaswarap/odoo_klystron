from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.addons.web_approval.models.approval_mixin import _APPROVAL_STATES
from datetime import date, datetime
import xlsxwriter
from io import BytesIO
from odoo.addons.website.tools import text_from_html
from bs4 import BeautifulSoup as BS
from urllib.request import urlopen

try:
    from base64 import encodebytes
except ImportError:
    from base64 import encodestring as encodebytes


class CrmEstimation(models.Model):
    _name = "crm.estimation"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'approval.mixin']
    _description = "crm estimation"

    name = fields.Char(copy=False, index=True)
    description = fields.Char()
    note = fields.Text(string='Note', help="Designer and project manager can input their notes")
    remarks = fields.Text(string='Remarks', help="Estimation team can put their remarks")
    crm_id = fields.Many2one('crm.lead', copy=False)
    partner_id = fields.Many2one('res.partner', related='crm_id.partner_id')
    category_line_ids = fields.One2many('estimation.category.line', 'estimation_id', copy=True)
    summary_line_ids = fields.One2many('estimation.summary.line', 'estimation_id')
    template_id = fields.Many2one('estimation.template')
    state = fields.Selection(
        [('draft', 'Draft'), ('confirmed', 'Confirmed'), ('cancel', 'Cancel')],
        default='draft', readonly=True, track_visibility='onchange', copy=False)
    company_id = fields.Many2one('res.company', string="Company", index=True, default=lambda self: self.env.company,
                                 readonly=True)
    approval_state = fields.Selection(string='Approval Status', selection=_APPROVAL_STATES, required=False, copy=False,
                                      is_approval_state=True, tracking=True)
    is_approver = fields.Boolean(compute='compute_is_approver')
    rfq_created = fields.Boolean(copy=False, default=False)
    sale_id = fields.Many2one('sale.order', readonly=True, store=True)
    org_est_id = fields.Many2one('crm.estimation', 'Original Estimation')
    rev = fields.Boolean('Revision')
    date = fields.Date(default=fields.Date.to_string(date.today()))
    revision_number = fields.Char(string='Revision Number')
    earlier_revisions_summ_ids = fields.One2many('earlier.revision.summary', 'earlier_revisions_obj')
    purchase_order_count = fields.Integer(
        "Number of Purchase Order Generated",
        compute='_compute_purchase_order_count')
    sale_order_count = fields.Integer(
        "Number of Sale Order Generated",
        compute='_compute_sale_order_count')
    fileout = fields.Binary('File', readonly=True)
    fileout_filename = fields.Char('Filename', readonly=True)
    is_variation = fields.Boolean("Is Variation")

    revision_order_count = fields.Integer(
        "Number of revisions Generated",
        compute='_compute_prv_revision_count')
    project_id = fields.Many2one('project.project', "Project")
    variation_count = fields.Integer("Number of Variation Generated")
    est_margin = fields.Float(string='Total Margin' , compute='compute_total_margin',store=True )
    est_budget = fields.Float(string='Total Estimated Budget',compute='compute_est_budget',store=True)
    est_budget_utilized = fields.Float(string='Total  Budget Utilized',compute='compute_est_budget_utilized',store=True)
    manual_sequence = fields.Boolean(default=False,copy=False)

    @api.depends('category_line_ids.margin')
    def compute_total_margin(self):

        for rec in self:
            total_margin = 0
            for line in rec.category_line_ids:
                    total_margin += line.margin
            rec.est_margin = total_margin


    @api.depends('category_line_ids.budget')
    def compute_est_budget(self):

        for rec in self:
            total_budget = 0
            for line in rec.category_line_ids:
                    total_budget += line.budget
            rec.est_budget = total_budget

    @api.depends('category_line_ids.budget_utilized')
    def compute_est_budget_utilized(self ):

        for rec in self:
            total_budget_utilized = 0
            for line in rec.category_line_ids:
                total_budget_utilized += line.budget_utilized
            rec.est_budget_utilized = total_budget_utilized

    def reject(self):

        result = super(CrmEstimation, self).reject()

        approval_dict = self.approvals
        activities = self.env['mail.activity'].search(
            [('res_model', '=', self._name)])
        activities.unlink()
        return result
    @api.depends('org_est_id')
    def _compute_prv_revision_count(self):
        for est in self:
            if len(est.org_est_id) == 0:
                est.revision_order_count = 0
            else:
                prv = self.env['crm.estimation'].search(
                    [('org_est_id', '=', est.org_est_id.id), ('id', '!=', est.id)]).ids
                prv.append(est.org_est_id.id)
                est.revision_order_count = len(prv)

    @api.depends('category_line_ids.po_id')
    def _compute_purchase_order_count(self):
        for est in self:
            po = self.env['purchase.order'].search([('estimation_id', '=', self.id)])
            self.purchase_order_count = len(po)

    @api.depends('sale_id')
    def _compute_sale_order_count(self):
        for est in self:
            so = self.env['sale.order'].search([('estimation_id', '=', self.id)])
            self.sale_order_count = len(so)

    # @api.onchange('manual_sequence')
    # def onchange_manual_sequence(self):
    #     self.load_summary_lines()


    def print_xlsx(self):
        active_ids_tmp = self.env.context.get('active_ids')
        active_model = self.env.context.get('active_model')
        data = {
            # 'output_type': self.read()[0]['output_type'][0],
            'ids': active_ids_tmp,
            'context': {'active_model': active_model},
        }
        file_io = BytesIO()
        workbook = xlsxwriter.Workbook(file_io)

        self.generate_xlsx_report(workbook, data=data)

        workbook.close()
        fout = encodebytes(file_io.getvalue())

        datetime_string = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_name = 'BUDGETARY PROPOSAL'
        filename = '%s_%s' % (report_name, datetime_string)
        self.write({'fileout': fout, 'fileout_filename': filename})
        file_io.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model=' + self._name + '&id=' + str(
                self.id) + '&field=fileout&download=true&filename=' + filename,
        }

    def generate_xlsx_report(self, workbook, data=None, objs=None):
        bold = workbook.add_format({'bold': True})
        border_text_centr = workbook.add_format(
            {'border': 1, 'bg_color': '#afcaf3', 'align': 'center', 'font_size': 14})
        text_bold = workbook.add_format({'border': 1, 'align': 'left', 'bold': True, 'valign': 'top'})
        text_content = workbook.add_format({'border': 1, 'align': 'left', 'valign': 'top'})
        text_bold_heading = workbook.add_format(
            {'border': 1, 'align': 'left', 'bold': True, 'valign': 'top', 'bg_color': '#eec9ef'})
        text_bold_section = workbook.add_format(
            {'border': 1, 'align': 'left', 'bold': True, 'valign': 'top', 'font_size': 14, 'color': 'green'})
        text_bold_note = workbook.add_format(
            {'border': 1, 'align': 'left', 'bold': True, 'valign': 'top', 'font_size': 12, 'color': 'red'})
        text_content_right = workbook.add_format({'border': 1, 'align': 'right', 'valign': 'top', })

        text_content_wrap = workbook.add_format(
            {'font_size': 11, 'valign': 'top', 'left': True, 'right': True, 'text_wrap': True,
             'border': 1})
        text_border_none = workbook.add_format({
            'top': 0, 'bottom': 0, 'right': 1})
        text_border_none_top = workbook.add_format({
            'top': 1, 'bottom': 0, 'right': 1})
        text_border_bottom = workbook.add_format({
            'top': 1, 'bottom': 1, 'right': 1})
        text_border_none_bottom = workbook.add_format({
            'top': 0, 'bottom': 1, 'right': 1})
        overtime_sheet = workbook.add_worksheet("BUDGETARY PROPOSAL")
        row = 0
        format_label1 = workbook.add_format(
            {'font_size': 14, 'valign': 'top', 'bold': True, 'left': True, 'right': True})
        overtime_sheet.merge_range(row, 0, row, 5, 'BUDGETARY PROPOSAL', border_text_centr)
        row += 1
        col = 0
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "SINO", text_bold_heading)
        col += 1
        overtime_sheet.set_column(col, col, 70)
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "DESCRIPTION", text_bold_heading)
        col += 1
        overtime_sheet.set_column(col, col, 20)
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "ITEM", text_bold_heading)
        col += 1
        overtime_sheet.set_column(col, col, 20)
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "QTY", text_bold_heading)
        col += 1
        overtime_sheet.set_column(col, col, 20)
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "UNIT RATE", text_bold_heading)
        col += 1
        overtime_sheet.set_column(col, col, 20)
        overtime_sheet.merge_range(row, col, row + 1, col, '', text_bold)
        overtime_sheet.write(row, col, "AMOUNT", text_bold_heading)
        row += 1
        col = 0
        data_list = self.get_summary_line_ids()
        lp = 1
        for line in data_list:
            row += 1
            if not line['display_type']:
                if line['grp'] == True:
                    overtime_sheet.write(row, col, line['sino'], text_content)
                    col += 1
                    text = text_from_html(line['description'], True)
                    overtime_sheet.write(row, col, text, text_content_wrap)
                    col += 1
                    overtime_sheet.write(row, col, line['item'], text_content)
                    col += 1
                    overtime_sheet.write(row, col, line['qty'], text_content_right)
                    col += 1
                    overtime_sheet.write(row, col, line['rate'], text_content_right)
                    col += 1
                    if len(data_list) == lp:
                        # print("ifff------------>>>", line['amount'])
                        overtime_sheet.write(row, col, line['amount'], text_border_bottom)
                    else:
                        # print("else------------>>>", line['amount'])
                        overtime_sheet.write(row, col, line['amount'], text_border_none_top)
                    col += 1
                else:
                    overtime_sheet.write(row, col, line['sino'], text_content)
                    col += 1
                    text = text_from_html(line['description'], True)
                    overtime_sheet.write(row, col, text, text_content_wrap)
                    col += 1
                    overtime_sheet.write(row, col, line['item'], text_content)
                    col += 1
                    overtime_sheet.write(row, col, line['qty'], text_content_right)
                    col += 1
                    overtime_sheet.write(row, col, line['rate'], text_content_right)
                    col += 1
                    if len(data_list) == lp:
                        overtime_sheet.write(row, col, '', text_border_none_bottom)
                    else:
                        overtime_sheet.write(row, col, '', text_border_none)
                    col += 1
            if line['display_type'] == 'line_section':
                # overtime_sheet.merge_range(row, 0, row, 5, line.name, text_bold)
                overtime_sheet.merge_range(row, 0, row, 5, line['name'], text_bold_section)
            if line['display_type'] == 'line_note':
                # overtime_sheet.merge_range(row, 0, row, 5, line.name, text_bold)
                overtime_sheet.merge_range(row, 0, row, 5, "  " + line['name'], text_bold_note)
            col = 0
            lp += 1

    def create_revision(self, default=False):
        default = dict(default or {})
        for revs in self:
            if len(revs.org_est_id) == 0:
                rev_count = 0
            else:

                rev_count = self.search_count([('org_est_id', '=', revs.org_est_id.id)])

            if len(revs.sale_id):
                if revs.sale_id.state in ['sale', 'done']:
                    raise UserError(_("You cannot create revision.Sale order for this estimation is confirmed"))
                else:
                    revs.sale_id.state = 'cancel'
            if self.is_variation:
                default.update({
                    'org_est_id': revs.id if len(revs.org_est_id) == 0 else revs.org_est_id.id,
                    'name': revs.name + "_V" + str(rev_count) if len(revs.org_est_id) == 0
                    else revs.org_est_id.name + "_V" + str(rev_count),
                    'rev': False,
                    'revision_number': 'REV' + str(rev_count),
                    'crm_id': revs.crm_id.id,
                    'partner_id': revs.partner_id.id,
                    'description': revs.description,
                    'note': revs.note,
                    'remarks': revs.remarks,
                })
                revs.state = 'cancel'
                revs.rev = True
            else:
                default.update({
                    'org_est_id': revs.id if len(revs.org_est_id) == 0 else revs.org_est_id.id,
                    'name': revs.name + "_R" + str(rev_count) if len(revs.org_est_id) == 0
                    else revs.org_est_id.name + "_R" + str(rev_count),
                    'rev': False,
                    'revision_number': 'REV' + str(rev_count),
                    'crm_id': revs.crm_id.id,
                    'partner_id': revs.partner_id.id,
                    'description': revs.description,
                    'note': revs.note,
                    'remarks': revs.remarks,
                })
                revs.state = 'cancel'
                revs.rev = True

        rev_id = super(CrmEstimation, self).copy(default)
        notification = {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': ('Revision'),
                'message': 'Revised Estimation Created:' + default.get('name'),
                'type': 'success',  # types: success,warning,danger,info
                'sticky': False,  # True/False will display for few seconds if false
            },
        }
        return notification

    def compute_is_approver(self):
        for rec in self:
            rec.is_approver = rec.show_approval_buttons()

    def action_confirm(self):
        if self.approval_state != 'approve':
            raise UserError(_("You cannot do this action without approval"))
        self.state = 'confirmed'

    def action_view_purchase(self):
        """view purchase"""
        action = self.env.ref("purchase.purchase_form_action").sudo().read()[0]
        action["domain"] = [('estimation_id', '=', self.id)]
        return action

    def action_view_sale(self):
        """view sale"""
        action = self.env.ref("sale.action_orders").sudo().read()[0]
        action["domain"] = [('estimation_id', '=', self.id)]
        return action

    def action_view_revisions(self):
        action = self.env.ref("kg_crm.action_crm_estimation").sudo().read()[0]
        prv = self.env['crm.estimation'].search([('org_est_id', '=', self.org_est_id.id), ('id', '!=', self.id)]).ids
        prv.append(self.org_est_id.id)
        action["domain"] = [('id', 'in', prv)]
        action["context"] = {'default_filter_state': 0}
        return action

    @api.model
    def create(self, vals):
        """Creating sequence"""
        # if vals.get('is_variation'):
        #     if vals.get('name') or not vals['name'] == _('New'):
        # vals['name'] = vals['name'] + self.env['ir.sequence'].next_by_code('crm.variation.estimation')
        if not vals.get('is_variation'):
            if not vals.get('name') or vals['name'] == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('crm.estimation') or _('New')
        else:
            if not vals.get('name') or vals['name'] == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('crm.estimation') or _('New')

        # else:
        #
        #         var_count = self.search_count([('org_est_id', '=', self.org_est_id.id)])
        #         if not vals.get('name') or not vals['name'] == _('New'):
        #             vals['name'] = self.env['ir.sequence'].next_by_code('crm.estimation')+ str(var_count )

        res = super(CrmEstimation, self).create(vals)
        # getting attachments from crm log
        if vals.get('crm_id'):
            attach = []
            messages_crm = self.env["mail.message"].search(
                ["&", ("res_id", "=", vals.get('crm_id')), ("model", "=", "crm.lead")], order='create_date asc')
            for ms in messages_crm:
                for att in ms.attachment_ids:
                    attach.append(att.id)
            if len(attach) > 0:
                estimation_ms = self.env["mail.message"].create({'res_id': res.id, 'model': 'crm.estimation',
                                                                 'attachment_ids': [
                                                                     (6, 0, attach)]})
        user_list = []
        users = self.env['res.users'].search([])
        body = _(
            ' Estimation: "%(mag)s assigned for the users:',
            mag=res.name)
        for user in users:
            if user.has_group('kg_crm.group_design_teams'):
                user_list.append(user)
        for design_user in user_list:
            res.activity_schedule('kg_crm.assign_estimation', note=body, user_id=design_user.id)
        res.load_summary_lines()
        if not vals.get('org_est_id'):
            vals['name'] = self.env['ir.sequence'].next_by_code('crm.estimation') or '/'
            vals['revision_number'] = 'REV0'
        if vals.get('org_est_id'):
            estimation_obj = self.env['crm.estimation'].search([('id', '>', '0')])
            for each in estimation_obj:
                if each.name and each.name.split("_", 1)[0] == vals['name'].split("_", 1)[0]:
                    earlier_rev_count = self.env['earlier.revision.summary'].search(
                        [('name', '=', each.revision_number)])
                    if len(earlier_rev_count) == 0 and each.revision_number != res.revision_number:
                        rev_obj = self.env['earlier.revision.summary'].create(
                            {'earlier_revisions_obj': res.id, 'earlier_revisions_obj_prev': vals.get('org_est_id'),
                             'name': each.revision_number,
                             'earlier_revisions': 'Gross Margin'})
                        if len(each.sale_id) != 0:
                            for quot in each.sale_id:
                                rev_obj.earlier_revisions_obj_sale = quot.id
        return res

    def action_view_preliminaries(self):
        """Creating Preliminaries"""
        action = self.env.ref("kg_crm.action_crm_estimation_preliminaries").sudo().read()[0]
        action["context"] = {'default_estimation_id': self.id}
        action["domain"] = [('estimation_id', '=', self.id)]
        return action

    def action_view_itemlines(self):
        """View item lines"""
        action = self.env.ref("kg_crm.action_crm_estimation_preliminaries").sudo().read()[0]
        line_ids = []
        for line in self.category_line_ids:
            line_ids += line.item_line_ids.ids
        if len(line_ids) == 0:
            raise ValidationError(('No Item are linked yet...'))
        action["context"] = {'is_button_visible': True}
        action["domain"] = [('id', 'in', line_ids)]
        return action

    def load_summary_lines(self):
        """loading summary details"""
        # print("load summary--------------->>>",self.id)
        if self.id:
            lines = self.env['crm.estimation.category.line'].search([('estimation_id', '=', self.id)],
                                                                    order='seq asc,category_id asc,tag_ids asc')
            # print("lines---->>",lines)
            self.summary_line_ids = False
            for rec in self.summary_line_ids:
                rec.unlink()
            details_list = []
            if len(lines) > 0:
                category_id = lines[0].category_id
                seqnc = lines[0].seq
                if lines[0].category_id.parent_id:
                    parent = lines[0].category_id.parent_id
                    details_list.append((0, 0, {'display_type': 'line_section',
                                                'name': lines[0].seq + "." + lines[0].category_id.parent_id.name,
                                                'item': False}))
                    details_list.append(
                        (0, 0, {'display_type': 'line_note', 'name': lines[0].category_id.name, 'item': False}))
                else:
                    details_list.append((0, 0, {'display_type': 'line_section',
                                                'name': lines[0].seq + "." + lines[0].category_id.name,
                                                'item': False}))

                seq = 1
                # print("line--------->>",lines)
                for line in lines:
                    # print("line.tag_ids.id----->>", line.tag_ids)
                    if line.seq == seqnc:
                        new_seq = line.seq + "." + str(seq)
                        if line.category_id == category_id:
                            details_list.append((0, 0, {'group_id': line.tag_ids.id, 'display_type': False,
                                                        'name': line.item.name, 'item': line.item.id, 'qty': line.qty,
                                                        'rate': line.rate, 'amount': line.amount,
                                                        'estimation_id': line.estimation_id.id,
                                                        'category_id': line.category_id.id, 'description': line.description,
                                                        'sino': new_seq if not line.manual_sequence else line.line_no, 'budget': line.budget,'cat_line':line.id}))
                        else:
                            details_list.append(
                                (0, 0, {'display_type': 'line_note', 'name': line.category_id.name, 'item': False}))
                            details_list.append((0, 0, {'group_id': line.tag_ids.id, 'display_type': False,
                                                        'name': line.item.name, 'item': line.item.id, 'qty': line.qty,
                                                        'rate': line.rate, 'amount': line.amount,
                                                        'estimation_id': line.estimation_id.id,
                                                        'category_id': line.category_id.id, 'description': line.description,
                                                        'sino': new_seq if not line.manual_sequence else line.line_no, 'budget': line.budget,'cat_line':line.id}))
                            category_id = line.category_id
                        seq += 1
                    else:
                        if line.category_id.parent_id:
                            parent = line.category_id.parent_id
                            details_list.append((0, 0, {'display_type': 'line_section',
                                                        'name': line.seq + "." + line.category_id.parent_id.name,
                                                        'item': False}))
                            details_list.append(
                                (0, 0, {'display_type': 'line_note', 'name': line.category_id.name, 'item': False}))
                        else:
                            # print("cat-->",line.category_id.name)
                            # print("seq-->", line.seq)
                            # print("line---->>",line)
                            details_list.append((0, 0, {'display_type': 'line_section',
                                                        'name': line.seq + "." + line.category_id.name,
                                                        'item': False}))
                        details_list.append((0, 0,
                                             {'group_id': line.tag_ids.id, 'display_type': False, 'name': line.item.name,
                                              'item': line.item.id,
                                              'qty': line.qty, 'rate': line.rate, 'amount': line.amount,
                                              'estimation_id': line.estimation_id.id,
                                              'category_id': line.category_id.id, 'description': line.description,
                                              'sino': line.seq + "." + str(1) if not line.manual_sequence else line.line_no, 'budget': line.budget,'cat_line':line.id}))
                        category_id = line.category_id
                        seq = 2
                        seqnc = line.seq

                self.summary_line_ids = details_list
        #     sl_no = 1
        #     for rec in self.category_line_ids:
        #         for line in rec.item_line_ids:
        #             su = self.env['estimation.summary.line'].search([('cat_line', '=', line.id)], order="id desc",
        #                                                             limit=1, )

    def load_template(self):
        """Loading template details in case of estimation is created using template"""
        if self.template_id:
            # cat_line = self.env['estimation.category.line.template'].search([('template_id','=',self.template_id.id)])
            category_lines = []
            self.category_line_ids = False
            for line in self.template_id.category_tmp_line_ids:
                category_vals = {
                    'sequence': line.sequence,
                    'category_id': line.category_id.id,
                    'item_line_ids': [],
                    'estimation_id': self.id,
                    'budget': line.budget,
                }
                for item_line in line.item_line_ids:
                    res = item_line._prepare_item_line()
                    res['estimation_id'] = self.id
                    category_vals['item_line_ids'].append(
                        (0, 0, res))
                category_lines.append((0, 0, category_vals))
                # print("category_vals--->>",category_vals)
            self.category_line_ids = category_lines
        else:
            raise ValidationError(('Select template to load details'))

    def get_span(self, group_id):
        if group_id == False:
            length = 0
        else:
            summary = self.env['estimation.summary.line'].search(
                [('group_id', '=', group_id), ('estimation_id', '=', self.id)])
            length = len(summary)
        # print("group_id-------->>", group_id)
        # print("length-------->>", length)
        return length

    def get_summary_line_ids(self):
        data_list = []
        grp_id = False
        for line in self.summary_line_ids:
            if not line.display_type and line.group_id:
                grp_id = line.group_id.id
                break
        fl = False
        for line in self.summary_line_ids:
            # line.sino = False
            if not line.display_type:
                if grp_id != False and grp_id == line.group_id.id:
                    if fl == False:
                        data_list.append(
                            {'display_type': line.display_type, 'sino': line.sino, 'description': line.description,
                             'item': line.item.name, 'qty': line.qty, 'rate': line.rate, 'amount': line.amount,
                             'grp': True, 'group_id': line.group_id.id})
                        fl = True
                    else:
                        data_list.append(
                            {'display_type': line.display_type, 'sino': line.sino, 'description': line.description,
                             'item': line.item.name, 'qty': line.qty, 'rate': line.rate, 'amount': line.amount,
                             'grp': False, 'group_id': line.group_id.id})
                    grp_id = line.group_id.id
                else:
                    # ex_list = data_list[: -1]
                    # for ls in ex_list:
                    #     if ls.get('group_id') == data_list[-1].get('group_id'):
                    #         data_list[-1].update({'grp':False})
                    if len(line.group_id) == 0:
                        data_list.append(
                            {'display_type': line.display_type, 'sino': line.sino, 'description': line.description,
                             'item': line.item.name, 'qty': line.qty, 'rate': line.rate, 'amount': line.amount,
                             'grp': True, 'group_id': line.group_id.id})
                    else:
                        data_list.append(
                            {'display_type': line.display_type, 'sino': line.sino, 'description': line.description,
                             'item': line.item.name, 'qty': line.qty, 'rate': line.rate, 'amount': line.amount,
                             'grp': True, 'group_id': line.group_id.id})
                    grp_id = line.group_id.id
                    fl = True
            elif line.display_type == 'line_section':
                data_list.append({'display_type': line.display_type, 'name': line.name, })
                fl = False
            elif line.display_type == 'line_note':
                data_list.append({'display_type': line.display_type, 'name': line.name, })
                fl = False
        # print("data_list---->>", data_list)
        return data_list

    # @api.onchange('category_line_ids')
    # def onchange_category_line_ids(self):
    #     for rec in self:
    #         origin = rec._origin
    #         origin.load_summary_lines()


class CrmEstimationCat(models.Model):
    _name = "work.categories"
    _rec_name = 'complete_name'

    parent_id = fields.Many2one('work.categories')
    name = fields.Char(required=True)
    code = fields.Char()
    complete_name = fields.Char(
        'Complete Name', compute='_compute_complete_name', recursive=True,
        store=True)
    is_parent = fields.Boolean(default=False, store=True, readonly=False)
    product_id = fields.Many2one('product.product', readonly=True, store=True)
    uom_id = fields.Many2one('uom.uom', help='Working time', string="Unit of Measure")

    @api.model
    def create(self, vals):
        """Setting parent"""
        if vals.get('parent_id'):
            parent = self.env['work.categories'].search([('id', '=', vals.get('parent_id'))])
            if len(parent) > 0:
                parent.is_parent = True
        product_tmpl = self.env['product.template']
        tmpl = product_tmpl.create({
            'detailed_type': 'service',
            'name': vals.get('name'),
            'service_policy': 'delivered_milestones',
            'service_tracking': 'task_in_project',
            'display_name': vals.get('name'),
            'description': vals.get('name'),
            'uom_po_id': vals.get('uom_id'),
            'uom_id': vals.get('uom_id'),
            'sale_ok': True,
            'purchase_ok': True,
            'create_uid': self.env.user.id,
            'company_id': self.env.company.id,
            'currency_id': self.env.company.currency_id.id,
        })
        prd = self.env['product.product'].search([('product_tmpl_id', '=', tmpl.id)])
        vals['product_id'] = prd.id
        res = super(CrmEstimationCat, self).create(vals)
        product_tmpl.crm_cat_id = res.id
        return res

    def write(self, vals):
        if vals.get('name'):
            self.product_id.product_tmpl_id.name = vals.get('name')
        if vals.get('uom_id'):
            self.product_id.product_tmpl_id.uom_po_id = vals.get('uom_id')
            self.product_id.product_tmpl_id.uom_id = vals.get('uom_id')
        res = super(CrmEstimationCat, self).write(vals)
        return res

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for category in self:
            if category.parent_id:
                category.complete_name = '%s / %s' % (category.parent_id.complete_name, category.name)
            else:
                category.complete_name = category.name


class EstimationCatLine(models.Model):
    _name = "estimation.category.line"

    estimation_id = fields.Many2one('crm.estimation', copy=False)
    sequence = fields.Char(size=1, required=True)
    category_id = fields.Many2one('work.categories', required=True)
    item_line_ids = fields.One2many('crm.estimation.category.line', 'category_line_id', copy=True)
    po_id = fields.Many2many('purchase.order')
    margin = fields.Float()
    discount = fields.Float()
    budget = fields.Float(String='Estimated Budget',compute='get_total_details')
    # budget_utilized = fields.Float(String='Utilized Budget')
    total_amount = fields.Float(String='Total Amount',compute='get_total_details')
    budget_utilized = fields.Float(String='Utilized Budget')
    budget_balance = fields.Float(String='Balance Budget', compute='get_balance_budget')
    seq = fields.Integer(string="Sequence", default=10)
    project_id = fields.Many2one('project.project', copy=False)
    vari_project_id = fields.Many2one('project.project', copy=False,related='estimation_id.project_id')
    tag_no = fields.Integer(default=0)
    percentage = fields.Float(string='Percentage', compute='_compute_percentage')
    budget_tot = fields.Float(compute='compute_total_budget',string="Total Budget")


    @api.depends('item_line_ids')
    def get_total_details(self):
        for rec in self:
            amt = 0
            amt = sum(rec.item_line_ids.mapped('amount'))
            rec.total_amount = amt
            budget = sum(rec.item_line_ids.mapped('budget'))
            rec.budget = budget
            # sl_no = 1
            # for line in rec.item_line_ids:
            #     su = self.env['estimation.summary.line'].search([('cat_line', '=', line.id)],limit=1,)
            #     if len(su) == 1:
            #         line.line_no = su.sino




    @api.depends('item_line_ids')
    def compute_total_budget(self):
        for line in self:
            line.budget_tot= sum(line.item_line_ids.mapped('budget'))

    @api.depends('budget', 'budget_utilized')
    def _compute_percentage(self):
        for record in self:
            if record.budget == 0:
                record.percentage = 0.0
            else:
                record.percentage = (record.budget_utilized / record.budget) * 100.0

    @api.depends('budget', 'budget_utilized')
    def get_balance_budget(self):
        for rec in self:
            budget_balance = rec.budget - rec.budget_utilized
            if budget_balance < 0:
                rec.budget_balance = 0
            else:
                rec.budget_balance = budget_balance
            # @api.depends('budget', 'budget_utilized')
            # def get_balance_budget(self):
            #     for rec in self:
            #         budget_balance = rec.budget - rec.budget_utilized
            #         if budget_balance < 0:
            #             rec.budget_balance = 0
            #         else:
            #             rec.budget_balance = budget_balance

    @api.depends('budget','po_id')
    def get_budget_utilized(self):
        for rec in self:
            rec.budget_utilized = 0.00
            amt = 0
            for po in self.po_id:
                if po.state in ['purchase', 'done']:
                    order_line = po.order_line.filtered(lambda l: l.product_id.id == rec.category_id.product_id.id)
                    for line in order_line:
                        amt += line.budget_utilized
                        rec.budget_utilized = amt

    # @api.constrains('budget')
    # def estmated_bug(self):
    #     for rec in self:
    #         if rec.budget == 0.00:
    #             raise ValidationError('Specify Budget Amount')

    def write(self, vals):
        res = super(EstimationCatLine, self).write(vals)
        self.estimation_id.load_summary_lines()
        return res

    def unlink(self):
        est_id = self.estimation_id
        res = super(EstimationCatLine, self).unlink()
        est_id.load_summary_lines()
        return res

    def create_category_lines(self):
        """Creating category lines"""
        action = self.env.ref("kg_crm.action_crm_estimation_preliminaries").sudo().read()[0]
        action["context"] = {'default_estimation_id': self.estimation_id.id, 'default_category_id': self.category_id.id,
                             'default_seq': self.sequence, 'default_category_line_id': self.id}
        action["domain"] = [('category_line_id', '=', self.id)]
        return action

    def view_category_lines(self):
        return {
            'name': _('Item Lines'),
            'view_type': 'tree',
            'view_mode': 'tree',
            'view_id': self.env.ref('kg_crm.estimation_item_line_tree').id,
            # 'context':{'default_estimation_id':self.estimation_id.id,'default_category_id':self.category_id.id,'default_seq':self.sequence,'default_category_line_id':self.id},
            'res_model': 'crm.estimation.category.line',
            'type': 'ir.actions.act_window',
            'domain': [('category_line_id', '=', self.id)]
        }

    @api.constrains('sequence')
    def check_uniq_seq(self):
        for rec in self:
            for line in self.estimation_id.category_line_ids:
                if rec.category_id.parent_id and rec.category_id.parent_id == line.category_id:
                    raise ValidationError(('Parent Category already selected'))
                if line.category_id.parent_id and rec.category_id == line.category_id.parent_id:
                    raise ValidationError(('Child  Category already selected'))
                # if rec.category_id.parent_id and rec.category_id.parent_id == line.category_id:
                #     raise ValidationError(('Parent Category already selected'))
                if rec.sequence == line.sequence and rec.category_id != line.category_id and rec != line:
                    if not rec.category_id.parent_id:
                        raise ValidationError(('This sequence already selected'))
                elif rec.category_id == line.category_id and rec != line:
                    raise ValidationError(('This category already selected'))
                elif rec.category_id.parent_id and rec != line:
                    if rec.category_id.parent_id == line.category_id.parent_id and rec.sequence != line.sequence:
                        raise ValidationError(
                            ('Sequence should be %s for category %s' % (line.sequence, line.category_id.name)))


class EstimationSummaryLine(models.Model):
    _name = "estimation.summary.line"

    sino = fields.Char()
    description = fields.Html(translate=True, store=True, readonly=True)
    item = fields.Many2one('uom.uom', store=True, readonly=True)
    qty = fields.Float(store=True, readonly=True, default=1.00)
    rate = fields.Float(store=True, readonly=True)
    amount = fields.Float(store=True, readonly=True)
    estimation_id = fields.Many2one('crm.estimation')
    category_id = fields.Many2one('work.categories')
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False, help="Technical field for UX purpose.")
    name = fields.Char()
    margin = fields.Float(store=True, readonly=True)
    discount = fields.Float(store=True, readonly=True)
    budget = fields.Float(store=True, readonly=True)
    make_visible = fields.Boolean(string="User", compute='get_user')
    group_id = fields.Many2one('group.tag')
    cat_line = fields.Many2one('crm.estimation.category.line')

    @api.depends('make_visible')
    def get_user(self, ):
        user_crnt = self.env.user
        res_user = self.env['res.users'].search([('id', '=', user_crnt.id)])
        if res_user.has_group('kg_crm.group_project_teams'):
            self.make_visible = False
        else:
            self.make_visible = True


class CrmEstimationTemplate(models.Model):
    _name = "estimation.template"
    _inherit = 'crm.estimation'
    estimation_id = fields.Many2one("crm.estimation")
    category_tmp_line_ids = fields.One2many('estimation.category.line.template', 'category_line_template_id')


class EstimationCatLineTemp(models.Model):
    _name = "estimation.category.line.template"
    _inherit = 'estimation.category.line'

    category_line_template_id = fields.Many2one('estimation.template')
    template_id = fields.Many2one("estimation.template")
    item_line_ids = fields.One2many('crm.estimation.category.line.template', 'category_template_id')

    def create_template_category_lines(self):
        """Creating category lines"""
        action = self.env.ref("kg_crm.action_crm_estimation_line_template").sudo().read()[0]
        action["context"] = {'default_estimation_id': self.estimation_id.id, 'default_category_id': self.category_id.id,
                             'default_seq': self.sequence, 'default_category_template_id': self.id}
        action["domain"] = [('id', 'in', self.item_line_ids.ids)]
        return action


class EarlierRevisionSummary(models.Model):
    _name = 'earlier.revision.summary'
    _description = 'Earlier Revision Summary'

    name = fields.Char('Revisions')
    earlier_revisions = fields.Char('Earlier Revisions')
    remarks = fields.Char('Remarks')
    earlier_revisions_obj_sale = fields.Many2one('sale.order')
    earlier_revisions_obj = fields.Many2one('crm.estimation', ondelete="cascade")
    earlier_revisions_obj_prev = fields.Many2one('crm.estimation')
