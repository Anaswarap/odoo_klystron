from odoo import api, fields, models, _, _lt
from odoo.exceptions import ValidationError, AccessError


class StockPicking(models.Model):
    _inherit = "stock.picking"
    project_id = fields.Many2one('project.project')


    @api.depends('picking_type_id', 'partner_id')
    def _compute_location_id(self):
        res = super(StockPicking, self)._compute_location_id()
        if self._context.get('project_transfer'):
            company = self.env.company.id
            dest_location_id = self.env['stock.location'].search(
                [('company_id', '=', company), ('usage', '=', 'production')], limit=1).id
            self.location_dest_id = dest_location_id
        return res

