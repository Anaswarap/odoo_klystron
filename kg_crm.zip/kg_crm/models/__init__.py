# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import milestone
from . import stock_picking
from . import project
from . import product
from . import purchase
from . import res_partner
from . import crm_lead
from . import sale_order
from . import estmation
from . import estimation_sub_tables
from . import update_template
from . import project_update
from . import sales_return_form
from . import payment
from . import res_company
