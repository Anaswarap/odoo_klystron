from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class SaleMilestone(models.Model):
    _name = "sale.milestone"

    milestone = fields.Char(required=True)
    percentage = fields.Float(required=True)
    sale_line_id = fields.Many2one('sale.order.line', required=True)
    deadline = fields.Date()
    sale_id = fields.Many2one('sale.order')


class PurchaseMilestone(models.Model):
    _name = "purchase.milestone"

    milestone_dist = fields.Char(string="Description")
    purchase_id = fields.Many2one('purchase.order', 'Purchase')
    project_id = fields.Many2one(related='purchase_id.project_rel_id', string="Project")
    milestone_percentage = fields.Float('Percentage')
    partner_id = fields.Many2one(related='purchase_id.partner_id', string="Vendor")
    partner_bool = fields.Boolean(compute='compute_partner_change')
    partner_new_id = fields.Many2one('res.partner', string="Partner")

    @api.depends('partner_id')
    def compute_partner_change(self):
        for i in self:
            if i.partner_id:
                i.partner_bool = True
                i.partner_new_id = i.partner_id.id
            else:
                i.partner_bool = False

    @api.constrains('milestone_percentage')
    def constrain_percentage(self):
        for i in self:
            if i.milestone_percentage > 100:
                raise UserError("You cannot enter morethan 100%")
