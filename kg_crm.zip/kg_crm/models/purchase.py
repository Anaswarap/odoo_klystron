# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.addons.web_approval.models.approval_mixin import _APPROVAL_STATES
from odoo.exceptions import UserError, ValidationError


class PurchaseOrderInh(models.Model):
    _name = "purchase.order"
    _inherit = ['purchase.order','mail.activity.mixin', 'approval.mixin','approval.template']

    def get_cmp_terms_and_conditions(self):
        return self.env.company.terms_and_conditions

    estimation_id = fields.Many2one('crm.estimation')
    remarks = fields.Text(help="Estimation remarks")
    include_terms = fields.Boolean(string='Include Terms and Conditions',store=True)
    terms_and_conditions = fields.Html(string='Terms and Conditions',default=get_cmp_terms_and_conditions, readonly=False)

    # APPROVAL
    approval_state = fields.Selection(string='Approval Status', selection=_APPROVAL_STATES, required=False, copy=False,
                                      is_approval_state=True, tracking=True)
    is_approver = fields.Boolean(compute='compute_is_approver')
    purchase_type = fields.Selection([('local', 'Local'), ('import', 'Import')], default='local')
    # picking_type_id = fields.Many2one('stock.picking.type',required=True)
    project_rel_id = fields.Many2one('project.project')
    due_amount = fields.Float(string="Due Amount", compute='compute_invoice_amounts')
    paid_amount = fields.Float(string="Paid Amount", compute='compute_invoice_amounts')
    balance_amount = fields.Float(string="Balance Amount", compute='compute_invoice_amounts')
    milestone_line_ids = fields.One2many('purchase.milestone', 'purchase_id', string="Purchase Milestone lines")
    fiscal_position_id = fields.Many2one('account.fiscal.position', string='Fiscal Position', domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    state = fields.Selection([
        ('draft', 'LPO'),
        ('sent', 'LPO Sent'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)
    app_level_id = fields.Many2one('approval.template.line',string="Approval Level")
    checklist = fields.Html(string="Checklist", tracking=True)
    attention_id = fields.Many2one('res.partner', string='Attention')

    @api.onchange('partner_id', 'attention_id')
    def onchange_attention_id(self):
        return {
            'domain': {'attention_id': [('id', 'in', self.partner_id.child_ids.ids)]}}

    @api.depends('invoice_ids')
    def compute_invoice_amounts(self):
        for i in self:
            if i.invoice_ids:
                print(i.invoice_ids)
                due_amount = 0
                paid_amt = 0
                balance = 0
                for inv in i.invoice_ids:
                    due_amount += inv.amount_total
                    paid_amount = inv.amount_total - inv.amount_residual
                    paid_amt += paid_amount
                    balance += inv.amount_residual_signed
                i.due_amount = due_amount
                i.paid_amount = paid_amt
                i.balance_amount = balance
            else:
                i.due_amount = 0.00
                i.paid_amount = 0.00
                i.balance_amount = 0.00

    def compute_is_approver(self):
        for rec in self:
            print("rec.show_approval_buttons()--->>", rec.show_approval_buttons())
            rec.is_approver = rec.show_approval_buttons()

    # CHECKLIST
    def request(self):
        result = super(PurchaseOrderInh, self).request()
        approval_dict = self.approvals
        nxt_aprvl = approval_dict.get('next_approval')[0]
        nxt_aprvl_level = nxt_aprvl.get('approval_line_id')
        check_lst = self.env['kg.purchase.checklist'].search([('approval_level_id','=',nxt_aprvl_level)],limit=1)
        if len(check_lst) == 1:
            self.app_level_id = nxt_aprvl_level
            self.checklist = check_lst.checklist
        return result

    def approve(self):
        result = super(PurchaseOrderInh, self).approve()
        approval_dict = self.approvals
        if len(approval_dict.get('next_approval')) != 0:
            nxt_aprvl = approval_dict.get('next_approval')[0]
            nxt_aprvl_level = nxt_aprvl.get('approval_line_id')
            check_lst = self.env['kg.purchase.checklist'].search([('approval_level_id','=',nxt_aprvl_level)],limit=1)
            self.message_post(body=self.app_level_id.name + " Check List" + self.checklist)
            if len(check_lst) == 1:
                self.checklist = check_lst.checklist
                self.app_level_id = nxt_aprvl_level
        return result

    def button_confirm(self):
        result = super(PurchaseOrderInh, self).button_confirm()
        if self.approval_state != 'approve':
            raise ValidationError(_("You cannot do this action without approval"))
        if not self.milestone_line_ids:
            raise ValidationError('Please add a line in Milestone')
        if self.estimation_id:
            for line in self.estimation_id.category_line_ids:
                amt = 0
                for po in line.po_id:
                    if po.state in ['purchase', 'done'] or po == self:
                        order_line = po.order_line.filtered(lambda l: l.product_id.id == line.category_id.product_id.id)
                        for pline in order_line:
                            amt += pline.price_subtotal
                line.budget_utilized = amt
                line.budget_balance = line.budget - line.budget_utilized
        # else:
        #     for i in self.milestone_line_ids:
        #         milestone_id = self.env['purchase.milestone'].create({
        #             'purchase_id': i.purchase_id.id,
        #             'vendor_id': i.vendor_id.id,
        #             'milestone_dist': i.mile
        #         })
        return result

    @api.onchange('partner_id')
    def partner_po_type(self):
        if self.partner_id:
            self.purchase_type = self.partner_id.purchase_type
            self.attention_id = False





class PurchaseOrderLineInh(models.Model):
    _inherit = 'purchase.order.line'

    estimation_item_line_id = fields.Many2one('crm.estimation.category.line')
    budget = fields.Float(related='estimation_item_line_id.budget')
    budget_utilized = fields.Float()
    budget_balance = fields.Float(related='estimation_item_line_id.budget_balance')


class PurchaseChecklist(models.Model):
    _name = "kg.purchase.checklist"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'approval.mixin']
    _description = "Purchase Checklist"

    name = fields.Char('Reference',copy=False,readonly=True,default=lambda x: _('New'),required=True)
    approval_level_id = fields.Many2one('approval.template.line',string="Approval Level",
                                        domain="[('approval_id.type_id', '=', 'Purchase')]")
    checklist = fields.Html(string="Checklist")

    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('rejected', 'Rejected')], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')
    #
    def action_confirm(self):
        self.write(
            {
                "state": "confirm",
            }
        )

    @api.constrains('approval_level_id')
    def approval_level_id_constrains(self):
        if self.approval_level_id:
            lvl_id = self.env['kg.purchase.checklist'].search([('approval_level_id', '=', self.approval_level_id.id)])
            if len(lvl_id) > 1:
                raise UserError(_("Check list is already added for this approval level"))

    # def action_reject(self):
    #     self.write(
    #         {
    #             "state": "rejected",
    #         }
    #     )
    #
    # def action_reset(self):
    #     self.write(
    #         {
    #             "state": "draft",
    #         }
    #     )
    #
    # @api.model
    # def create(self, vals):
    #     if vals.get('name', _('New')) == _('New'):
    #         vals['name'] = self.env['ir.sequence'].next_by_code('kg.purchase.checklist') or _('New')
    #
    #     res = super(PurchaseChecklist, self).create(vals)
    #     return res


