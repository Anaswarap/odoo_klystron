from odoo import api, fields, models


class ProjectTemplate(models.Model):
    _name = "project.update.template"
    _description = "Project Template"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(string="Name")
    template = fields.Html(string="Template")

