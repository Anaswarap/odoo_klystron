from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class TagGroup(models.Model):
    _name = 'group.tag'
    name = fields.Char()
    code = fields.Char()


class CrmEstimation(models.Model):
    _name = "crm.estimation.category.line"
    _description = "crm estimation"
    _rec_name = 'category_id'

    sino = fields.Char()
    line_no = fields.Char(string="SI.No")
    # se_no = fields.Char()
    seq = fields.Char()
    description = fields.Html(translate=True)
    item = fields.Many2one('uom.uom', required=True,domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='category_id.product_id.uom_id.category_id')
    qty = fields.Float(required=True, default=1.00)
    rate = fields.Float(required=True)
    amount = fields.Float(store=True, readonly=True)
    # compute = '_get_total_amount'
    # discount = fields.Float()
    budget = fields.Float(compute='_compute_budget', store=True)
    category_id = fields.Many2one('work.categories', store=True)
    category_line_id = fields.Many2one('estimation.category.line', copy=False)
    estimation_id = fields.Many2one('crm.estimation', store=True, readonly=True, copy=False,
                                    related='category_line_id.estimation_id')
    manual_sequence = fields.Boolean(copy=False,related='category_line_id.estimation_id.manual_sequence')
    margin_perc = fields.Float()
    margin = fields.Float()
    is_button_visible = fields.Boolean(default=True, copy=False)
    po_created = fields.Boolean(default=False, copy=False)
    po_ref = fields.Many2many('purchase.order')
    make_visible = fields.Boolean(string="User", compute='get_user')
    actual_qty = fields.Float(required=True, default=1.00, string="Actual Qty")
    actual_rate = fields.Float(string="Actual Rate")
    actual_amount = fields.Float(compute='_get_actual_total_amount', store=True, readonly=True, string="Actual Amount")
    tag_ids = fields.Many2one('group.tag')

    budget_utilized = fields.Float(String='Utilized Budget')
    # budget_utilized = fields.Float(String='Utilized Budget', compute='get_budget_utilized')
    budget_balance = fields.Float(String='Balance Budget', compute='get_balance_budget')

    cost = fields.Float(string="Cost", compute='_get_total_rate')
    cost_rate = fields.Float(string="Rate")
    percent = fields.Float()

    is_amount_set = fields.Boolean(default=False)
    color = fields.Char(
        string="Color",
        help="Choose your color",
        size=7
    )

    @api.depends('amount', 'percent')
    def _compute_budget(self):
        for record in self:
            record.budget = record.amount - ((record.amount /100)* record.percent)


    @api.depends('budget', 'budget_utilized')
    def get_balance_budget(self):
        for rec in self:
            budget_balance = rec.budget - rec.budget_utilized
            if budget_balance < 0:
                rec.budget_balance = 0
            else:
                rec.budget_balance = budget_balance

    @api.depends('budget')
    def get_budget_utilized(self):
        for rec in self:
            rec.budget_utilized = 0.00
            amt = 0
            for po in self.po_ref:
                if po.state in ['purchase', 'done']:
                    order_line = po.order_line.filtered(lambda
                                                            l: l.product_id.id == rec.category_id.product_id.id and l.estimation_item_line_id.id == rec.id)
                    print("order_line--->>", order_line)
                    for line in order_line:
                        amt += line.price_unit
                        rec.budget_utilized = amt

    # @api.constrains('budget')
    # def check_total_budget(self):
    #     for rec in self:
    #         cat_line = rec.category_line_id.item_line_ids
    #         total_bdj = sum(cat_line.mapped('budget'))
    #         print("total_bdj--->>", total_bdj)
    #         print("rec.category_line_id.budget-->>", rec.category_line_id.budget)
    #         if total_bdj > rec.category_line_id.budget:
    #             raise ValidationError(('Total lines bugdet should be less than category budget'))

    @api.model
    def create(self, vals):
        res = super(CrmEstimation, self).create(vals)
        res.estimation_id.load_summary_lines()
        if res.estimation_id.state != 'draft' and len(res.estimation_id) != 0:
            raise ValidationError(('You can create entries for draft estimation only'))
        return res

    def write(self, vals):
        res = super(CrmEstimation, self).write(vals)
        self.estimation_id.load_summary_lines()
        print("vals--->>", vals)
        if self.estimation_id.state != 'draft' and len(self.estimation_id) != 0:
            if not 'po_ref' in vals and not 'actual_qty' in vals and not 'actual_rate' in vals and not 'actual_amount' in vals and not 'line_no' in vals :
                raise ValidationError(('You can edit entries of draft estimation only'))
        return res

    def unlink(self):
        est_id = self.estimation_id
        res = super(CrmEstimation, self).unlink()
        est_id.load_summary_lines()
        if est_id.state != 'draft' and len(est_id) != 0:
            raise ValidationError(('You can only delete entries of draft estimation'))
        return res

    @api.depends('make_visible')
    def get_user(self, ):
        user_crnt = self.env.user
        res_user = self.env['res.users'].search([('id', '=', user_crnt.id)])
        if res_user.has_group('kg_crm.group_project_teams'):
            self.make_visible = False
        else:
            self.make_visible = True

    def _prepare_item_line(self):
        res = {
            'seq': self.seq,
            'line_no':self.line_no,
            'description': self.description,
            'item': self.item.id,
            'qty': self.qty,
            'rate': self.rate,
            'amount': self.amount,
            'category_id': self.category_id.id,
            'margin': self.margin,
            'margin_perc': self.margin_perc,
            'cost': self.margin,
            'cost_rate': self.cost_rate,
            # 'discount':self.discount,

            'budget': self.budget,
        }
        print("res----------->>", res)
        return res

    @api.onchange('item')
    def onchange_item(self):
        if self.item:
            # self.rate = self.category_id.product_id.product_tmpl_id.list_price
            self.cost = self.category_id.product_id.product_tmpl_id.standard_price

    # @api.constrains('budget')
    # def check_uniq_seq(self):
    #     for rec in self:
    #         if not self.category_line_id.project_id:
    #             if rec.cost < rec.budget:
    #                 raise ValidationError(('Budget should be less than rate'))

    # @api.onchange('budget')
    # def onchange_budget(self):
    #     if self.cost and self.cost < self.budget:
    #         raise ValidationError(('Budget should be less than rate!'))

    # @api.depends('estimation_id')
    # def _get_sino(self):
    #     for rec in self:
    #         line = self.env['crm.estimation.category.line'].search([('estimation_id','=',rec.estimation_id.id),('category_id','=',rec.category_id.id)])
    #         seq = 1
    #         for l in line:
    #             l.sino = self.env.context.get('seq')+str(seq)
    #             seq+=1
    #         else:
    #             rec.sino = self.env.context.get('seq')+str(len(line)+1)

    @api.onchange('qty', 'rate')
    def _get_total_amount(self):
        for rec in self:
            if not rec.tag_ids:
                rec.amount = rec.qty * rec.rate
            # else:
            #     cat_line = self.env['crm.estimation.category.line'].search([('category_line_id','=',self.category_line_id.id),('amount','=',self.amount),('color','=',self.color),('id','!=',self._origin.id)])
            #     total = 0
            #     for line in cat_line:
            #         total  += (line.qty * line.rate)
            #     total += (self.qty * self.rate)
            #     if total != 0 and total > self.amount:
            #         self.rate = self._origin.rate
            #         self.qty = self._origin.qty
            #         raise ValidationError(('Lines total amount Exceeded the total value set'))

    # @api.constrains('qty','rate')
    # def check_amount(self):
    #     for rec in self:
    #         if rec.tag_ids:
    #             cat_line = self.env['crm.estimation.category.line'].search([('category_line_id','=',rec.category_line_id.id),('amount','=',rec.amount),('tag_ids','=',rec.tag_ids[0].id),('id','!=',rec.id)])
    #             total = 0
    #             for line in cat_line:
    #                 total  += (line.qty * line.rate)
    #             total += (self.qty * self.rate)
    #             if total != 0 and total > self.amount:
    #                 raise ValidationError(('Lines total amount Exceeded the total value set'))

    @api.depends('qty', 'cost_rate')
    def _get_total_rate(self):
        for rec in self:
            rec.cost = rec.qty * rec.cost_rate

    @api.depends('actual_qty', 'actual_rate')
    def _get_actual_total_amount(self):
        for rec in self:
            rec.actual_amount = rec.actual_qty * rec.actual_rate

    @api.onchange('margin_perc', 'cost', 'qty')
    def _get_margin(self):
        for rec in self:
            if rec.cost:
                margin_amt = rec.margin_perc * rec.cost
                rec.margin = rec.cost + margin_amt

    def add_description(self):
        return {
            'res_model': 'crm.estimation.category.line',
            'type': 'ir.actions.act_window',
            'context': {},
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.id,
            'view_id': self.env.ref("kg_crm.view_crm_estimation_description_form").id,
            'target': 'new'
        }

    def remove_amount_slab(self):
        self.amount = 0
        self.tag_ids = False
        self.is_amount_set = False


class EstimationCrmLineTemp(models.Model):
    _name = "crm.estimation.category.line.template"
    _inherit = 'crm.estimation.category.line'

    category_template_id = fields.Many2one("estimation.category.line.template")

    def add_description_tmpl(self):
        return {
            'res_model': 'crm.estimation.category.line.template',
            'type': 'ir.actions.act_window',
            'context': {},
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.id,
            'view_id': self.env.ref("kg_crm.view_crm_estimation_description_tmpl_form").id,
            'target': 'new'
        }
