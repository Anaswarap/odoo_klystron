{
    'name': 'Invoice Multiple SO',
    'version': '16.0.1.0.0',
    'depends': ['sale'],
    'data': [

        'views/invoice_mul_so_view.xml',





    ],

    'installable': True,
    'application': True
}