from odoo import fields, models, api



class InvoiceMulSo(models.Model):

    _inherit = 'account.move'



    related_sale_ids = fields.Many2many(comodel_name='sale.order',string='Related Sale Orders',domain="[('invoice_status', '=','to invoice','no')]")

    @api.onchange('related_sale_ids')
    def onchange_related_sale(self):
        rec = []
        for line_vals in self.related_sale_ids:
            for line in line_vals.order_line:
                vals = {
                    'product_id': line.product_id.id,
                    'name': line.name,
                    'quantity': line.product_uom_qty,
                    'price_unit': line.price_unit
                    }
                rec.append((0,0,vals))

        # print(rec)
        self.invoice_line_ids = rec

