# -*- coding: utf-8 -*-
{
    'name': "KG Brook Marine Purchase",

    "summary": "Customization for Purchase Module",
    "version": "16.0.1.0.0",
    'category': 'Purchase',
    'author': "Klystron Global",
    'maintainer': "SHARMI SV",
    "license": "OPL-1",
    'website': 'https://www.klystronglobal.com',
    # any module necessary for this one to work correctly
    'depends': ['base', 'sale_management', 'purchase', 'stock', 'product', 'project'],
    # always loaded
    'data': [
        'security/ir.model.access.csv',

        'data/server_action.xml',

        'report/report.xml',
        'report/purchase_order_report.xml',

        'views/purchase_order_views.xml',
        'views/enquiry_views.xml',

        'wizard/create_rfq_wizard.xml',

    ],

}
