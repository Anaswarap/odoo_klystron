from odoo import fields, models, _, api


class KGSaleOrderInherit(models.Model):
    _inherit = "sale.order"

    def kg_action_create_rfq(self):
        action = {
            'name': 'Create RFQ',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'kg.create.rfq.wizard',
            'target': 'new'
        }
        return action
