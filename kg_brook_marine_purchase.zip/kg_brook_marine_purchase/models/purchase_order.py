from odoo import fields, models, _, api
# from odoo.addons.web_approval.models.approval_mixin import _APPROVAL_STATES

from odoo.exceptions import ValidationError, UserError


class KGPurchaseOrderInherit(models.Model):
    _inherit = 'purchase.order'
    # _inherit = ['purchase.order', 'approval.mixin']

    vendor_quotation_ref = fields.Date(string="Vendor/Quotation Ref")
    ref_date = fields.Date(string="Ref Date")
    order_type = fields.Selection(([('local', 'Local'), ('import', 'Import')]), string="Order Type", default="local")
    sale_order_id = fields.Many2one('sale.order', string="Sale Order")
    enquiry_ref = fields.Many2one("kg.enquiry", string="Enquiry Ref")
    revision_no = fields.Char(string="Revision No")
    # project = fields.Many2one("project.project", string="Project")
    # estimation_no = fields.Many2one("crm.estimation", string="Estimation No")

    # approval_state = fields.Selection(string='Approval Status', selection=_APPROVAL_STATES, required=False, copy=False,
    #                                   is_approval_state=True, tracking=True)
    # is_approver = fields.Boolean(compute='compute_is_approver')

    # def compute_is_approver(self):
    #     for rec in self:
            # rec.is_approver = rec.show_approval_buttons()

    # def button_confirm(self):
    #     print("self", self)
        # result = super(KGPurchaseOrderInherit, self).button_confirm()
        # if self.approval_state != 'approve':
        #     raise ValidationError(_("You cannot do this action without approval"))

    # def kg_create_revision(self):
    #     self.ensure_one()
    #     active_id = self.env.context.get('active_id')
    #     view_id = self.env.ref('purchase.purchase_order_form').id,
    #     po_id = self.env['purchase.order'].search([('id', '=', active_id)])
    #     po_id.write({
    #         'state': 'draft',
    #     })
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'name': _('Purchase Order'),
    #         'res_model': 'purchase.order',
    #         'res_id': active_id,
    #         'view_type': 'form',
    #         'view_mode': 'form',
    #         'view_id': view_id,
    #         'target': 'current',
    #         'nodestroy': True,
    #     }


class KGPurchaseOrderLineInherit(models.Model):
    _inherit = 'purchase.order.line'

    product_code = fields.Char(string="Product Code")

    @api.onchange('product_id')
    def _get_product_code(self):
        for rec in self:
            if rec.product_id:
                rec.product_code = rec.product_id.default_code

    @api.constrains('product_qty', 'price_unit')
    def _check_values(self):
        for rec in self:
            if rec.product_qty == 0.00:
                raise UserError(_("The operation cannot be completed: Orderline require a Quantity"))
            if rec.price_unit == 0.00:
                raise UserError(_("The operation cannot be completed: Orderline require a Unit Price"))
