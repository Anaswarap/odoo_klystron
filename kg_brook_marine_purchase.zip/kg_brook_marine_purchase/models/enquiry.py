from odoo import api, fields, models, _


class KGEnquiry(models.Model):
    _name = 'kg.enquiry'
    _description = "Purchase Enquiry"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name')
    company_id = fields.Many2one("res.company", string="Company")
