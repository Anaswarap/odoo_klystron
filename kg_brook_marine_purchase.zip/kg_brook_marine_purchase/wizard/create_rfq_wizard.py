from odoo import models, fields, api


class KGCreateRfqWizard(models.Model):
    _name = "kg.create.rfq.wizard"
    _description = "Create RFQ from SO"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    vendor_id = fields.Many2one('res.partner', string="Vendor")

    def kg_create_rfq_button(self):
        orderline = []
        po_id = self.env['purchase.order'].search([('partner_id', '=', self.vendor_id.id), ('state', '=', 'draft')],
                                                  limit=1)
        if self.env['sale.order'].browse(self._context.get('active_ids')):
            for sale in self.env['sale.order'].browse(self._context.get('active_ids')):
                for line in sale.order_line:
                    line_vals = (0, 0, {
                        'product_id': line.product_id.id,
                        'product_code': line.product_id.default_code,
                        'name': line.name,
                        'product_qty': line.product_uom_qty,
                        'price_unit': line.price_unit,
                        'taxes_id': line.tax_id,
                        'price_subtotal': line.price_subtotal,
                    })
                    orderline.append(line_vals)
            vals = {
                'partner_id': self.vendor_id.id,
                'order_line': orderline
            }
            if not po_id:
                self.env['purchase.order'].create(vals)
            if po_id:
                po_id.write({'order_line': orderline})
