from odoo import fields, models


class AutomaticPoWizard(models.TransientModel):
    _name = 'automatic.po.wizard'

    product_id = fields.Many2one('product.product', string="Product Name", readonly=True)
    product_qty = fields.Float(string='Product Quantity')
    price_unit = fields.Float(string='Product Price')
    partner_id = fields.Many2one('res.partner', string="Vendor", domain="[('supplier_rank', '!=', 0)]")

    def automatic_po_details(self):
        record = self.env['purchase.order'].search([('partner_id', '=', self.partner_id.id), ('state', '=', 'draft')],
                                                   limit=1)
        if record:
            record.write({
                'order_line': [(0, 0, {
                    'product_id': self.product_id.id,
                    'product_qty': self.product_qty,
                    'price_unit': self.price_unit
                })],
            })
        else:
            record = self.env['purchase.order'].create({
                'partner_id': self.partner_id.id,
                'order_line': [(0, 0, {
                    'product_id': self.product_id.id,
                    'product_qty': self.product_qty,
                    'price_unit': self.price_unit
                })],
            })
            record.button_confirm()
