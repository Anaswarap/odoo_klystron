{
    'name': 'Automated Purchase Order',
    'version': '16.0.1.0.0',
    'depends': ['purchase'],
    'data': [
        'views/view.xml',
        'wizards/wizard.xml',
        'security/ir.model.access.csv'

    ],

    'installable': True,

}