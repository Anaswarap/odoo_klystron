from odoo import api, fields, models, _


class ProductForm(models.Model):
    _inherit = 'product.product'

    def automatic_po(self):

        return {
            'name': _('Automatic PO Details'),
            'type': 'ir.actions.act_window',
            'res_model': 'automatic.po.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_product_id':self.id}

        }
