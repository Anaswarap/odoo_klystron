# -*- encoding: utf-8 -*-

from . import reject_comment
