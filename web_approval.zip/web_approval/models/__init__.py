# -*- encoding: utf-8 -*-

from . import approval_mixin
from . import approval_template
from . import approval_type
from . import mail_activity_type
