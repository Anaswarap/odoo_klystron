{
    'name': 'Document Expiry',
    'version': '16.0.1.0.0',
    'depends': ['base','web','documents','hr','sale'],
    'data': [
                'views/email_template_views.xml',
                'views/documents_views.xml',
                'views/cron_jobs_view.xml',


    ],
    'assets': {
        'web.assets_backend': [
            'kg_document_expiry/static/src/xml/document_inspector_view.xml'
        ],
    },

    'installable': True,
    'application': True
}
