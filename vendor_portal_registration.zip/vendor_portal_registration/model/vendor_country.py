from odoo import fields, models, api


class ResCountry(models.Model):
    _inherit = 'res.country.state'

    @api.model
    def vendor_form_successfully(self, state_id):
        if state_id:
            state = self.env['res.country.state'].sudo().search([('id', '=', state_id)])
            return {
                'country_id': state.country_id.id

            }
