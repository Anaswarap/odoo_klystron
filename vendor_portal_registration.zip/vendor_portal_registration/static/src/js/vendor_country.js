odoo.define('vendor_portal_registration.vendor_registration_form_page', function (require) {
    "use strict";

    var core = require('web.core');
    var session = require('web.session');
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var _t = core._t;


         $(document).on("change", "#vendor_registration", function() {
                    var state_id = document.getElementById("state").value;
                    var country = document.getElementById("country")
                    rpc.query({
                    model: 'res.country.state',
                    method: 'vendor_form_successfully',
                    args: [state_id],
                }).then(function(result) {
                country.value= result['country_id'];

                    });
                    });




    });


