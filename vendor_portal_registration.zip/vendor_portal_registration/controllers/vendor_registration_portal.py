from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo import http
from odoo.http import request
import base64



class VendorRegistrationPortal(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'vendor_reg_count' in counters:
            values['vendor_reg_count'] = request.env['res.partner'].search_count([])
        return values


class WebsitePage(http.Controller):
    @http.route('/my/registration', type='http', auth='public', website=True)
    def vendor_list_view(self):
        partner_obj = request.env['res.partner'].sudo().search([], order='create_date desc')
        # print(partner_obj,"jjj")
        return request.render('vendor_portal_registration.portal_my_vendor_registration',{'partner_obj':partner_obj})

    @http.route('/my/registration/form', type='http', auth='public', website=True)
    def vendor_form_view(self):
        state_obj = request.env['res.country.state']
        states = state_obj.search([])
        country_obj = request.env['res.country']
        country = country_obj.search([])
        return request.render('vendor_portal_registration.vendor_registration_form_page', {'states': states, 'country': country})




    @http.route('/my/registration/form/successfully', type='http', auth='public', website=True)
    def vendor_form_successfully(self, **post):
        partner = request.env['res.partner'].sudo().create({
            'name' : post.get('name'),
            'email': post.get('email'),
            'phone': post.get('phone'),
            'street': post.get('address'),
            'state_id': post.get('state'),
            'city': post.get('city'),
            'zip': post.get('zip'),
            'image_1920': base64.b64encode(post.get('imageUpload').read())


        })
        rec = {
            'partner': partner,
        }






        return request.render('vendor_portal_registration.vendor_registration_form_success',rec)
