{
    'name': 'Vendor Portal Registration',
    'version': '16.0.1.0.0',
    'sequence': 1,
    'depends':[
        'base','portal','website'
    ],
    'data':[

            'views/vendor_registration_portal_view.xml',
    ],
    'assets': {
        'web.assets_frontend': ['vendor_portal_registration/static/src/js/vendor_country.js']

    },


    'installable': True,


}