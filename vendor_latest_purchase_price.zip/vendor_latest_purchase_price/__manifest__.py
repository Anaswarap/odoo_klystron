{
    'name': 'Vendor Latest Price',
    'version': '16.0.1.0.0',
    'depends': ['base','purchase'],
    'data': [





    ],

    'installable': True,
    'application': True
}