from odoo import fields, models


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def button_confirm(self):

        res = super(PurchaseOrder, self).button_confirm()

        for line in self.order_line:
            price = line.price_unit

        for vendor in line.product_id.seller_ids:
            print(vendor.partner_id.id)
            # print(line.partner_id.id)
            if vendor.partner_id.id == line.partner_id.id:
                vendor.price = price

        return res
