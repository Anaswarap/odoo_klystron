{
    'name': 'External Layout Footer',
    'version': '16.0.1.0.0',
    'category': 'Report',
    'author': 'Klystron Global',
    'company': 'Klystron Global',
    'maintainer': 'Klystron Global',
    'website': 'https://www.klystronglobal.com',
    'depends': ['base',],
    'data': [
                'report/custom_footer_view.xml',
    ],


    'installable': True,
    'application': True
}
