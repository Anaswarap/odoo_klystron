{
    'name': 'Attendance Everyday',
    'version': '16.0.1.0.0',
    'depends': ['base','hr_attendance','hr'],
    'data': [

        'security/ir.model.access.csv',
        'data/cron.xml',
       'views/everyday_absence_views.xml',


    ],








    'installable': True,
    'application': True
}