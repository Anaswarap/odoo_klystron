from odoo import api, fields, models


class AttendanceEveryday(models.Model):
    _name = 'attendance.everyday'

    employee_id = fields.Many2one('hr.employee', string='Employee')
    date = fields.Date(string='Date')

    def absence_employee(self):
        today = fields.Date.today()

        attendance = self.env['hr.attendance'].search([])

        rec = []

        for vals in attendance:
            check_in = vals.check_in
            date_only_check_in = check_in.date()

            if today == date_only_check_in:
                rec.append(vals.employee_id.id)

        employee = self.env['hr.employee'].search([])
        for vals in employee:
            if vals.id not in rec:
                absent_employee = self.env['attendance.everyday'].create({
                    'date': today,
                    'employee_id': vals.id,
                })
                print(absent_employee)
