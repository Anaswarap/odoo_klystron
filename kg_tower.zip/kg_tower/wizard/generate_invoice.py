from odoo import models, fields, _
from odoo.exceptions import UserError
from odoo.tools import float_compare


class GenerateInvoice(models.Model):
    _name = 'generate.invoice'
    _description = 'Generate Invoice'
    """This model using for generate invoice for completed milestone"""

    project_id = fields.Many2one('project.project', string="Project")
    date = fields.Date(string="Date")
    # mislestone_id =

    def action_generate_invoice(self):
        print("action_generate_invoice")
