from odoo import fields, models, api


class SearchTowerStock(models.TransientModel):
    _name = 'search.tower.stock'
    _description = 'Search Tower Stock'

    tower_id = fields.Many2one('product.product', 'Tower', domain="[('is_tower','=',True)]")
    partner_id = fields.Many2one('res.partner', 'Contractor')
    quant_ids = fields.One2many(
        comodel_name='search.stock.quant',
        inverse_name='search_tower_stock_id',
        string='Stock On Hand',
        required=False)


    def select(self):
        pass

    def search(self):
        products = [('is_tower','=',True)]
        locations = [('usage','=','internal')]
        if self.tower_id:
            products.append(('id','=',self.tower_id.id))
        if self.partner_id and self.partner_id.vendor_contractor_location_id:
            locations.append(('id','=',self.partner_id.vendor_contractor_location_id.id))
        print(products)
        print(locations)
        prod_ids = self.env['product.product'].search(products).ids
        loc_ids = self.env['stock.location'].search(locations).ids
        print('prod_ids',prod_ids,'loc_ids',loc_ids)
        res = self.env['stock.quant'].search([('product_id','in',prod_ids),('location_id','in',loc_ids)])
        print(res)
        self.env['search.stock.quant'].search([('search_tower_stock_id','=',self.id)]).unlink()
        self.env['search.stock.quant'].create({
            'product_id':res.product_id.id,
        })
        return True

class Stock(models.TransientModel):
    _name = 'search.stock.quant'
    _description = 'Lines'

    search_tower_stock_id = fields.Many2one('search.tower.stock', string='Search Tower Stock')
    product_id = fields.Many2one(
        comodel_name='product.product',
        string='Product',
        required=False)