from odoo import fields, models, api
import ast

class SrrSendBack(models.TransientModel):
    _name = 'srr.sendback'
    _description = 'SRR Send Back'

    srr_id = fields.Many2one(
        comodel_name='ring.request',
        string='SRR',
        )
    name = fields.Text('Remark')
    dept = fields.Selection(
        string='Department',
        selection=[('saq', 'SAQ'),
                   ('operations', 'Operations'), ],)
    model_id = fields.Many2one('ir.model', 'Models', store=True)
    approval_config_id = fields.Many2one('kg.approval.config', string="Approval Config")
    approval_state = fields.Many2one('kg.approval.config.line',
                                     domain="[('approval_config_id', '=', approval_config_id)]")

    
    def send(self):
        model = self.model_id
        obj_record = self.env[self._context.get('active_model')].browse(self._context.get('active_ids', []))
        obj_record.next_approval = self.approval_state.id
        list = ast.literal_eval(obj_record.approved_list)
        new_list = []
        for ls in list:
            if ls.get('approval_level_id'):
                if ls.get('approval_level_id') < self.approval_state.id:
                    new_list.append(ls)
            else:
                new_list.append(ls)
        obj_record.approved_list = str(new_list)
        for user in self.approval_state.user_ids:
            obj_record.activity_schedule('kg_approval_14.kg_approval',
                                         note="Rejected Approval Request " + obj_record.name + " Reason:" + self.name,
                                         user_id=user.id)

        # message = ''
        # # if self.srr_id.state == 'approved_saq':
        # if self.dept == 'saq':
        #     self.srr_id.state = 'saq_assigned'
        #     self.srr_id.notify_users('kg_tower.group_saq_user', note="Review and get back." + self.name or '')
        #     message = str("Commercial Team Sent Back : " + self.name or '')
        #     self.srr_id.saq_coordinate_status = 'back'
        # # elif self.srr_id.state == 'approved_opr':
        # elif self.dept == 'operations':
        #     self.srr_id.state = 'approved_saq'
        #     self.srr_id.notify_users('kg_tower.group_oper_rollout', note="Review and get back." + self.name or '')
        #     message = str("Commercial Team Sent Back : " + self.name or '')
        # self.srr_id.message_post(body = message)