# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import xlwt
import base64
from io import StringIO
from odoo import api, fields, models, _
import platform

class PurchaseReportOut(models.Model):
    _name = 'tower.report.out'
    _description = 'tower invoice report'

    tower_data = fields.Char('Name', size=256)
    file_name = fields.Binary('Tower Invoice Excel Report', readonly=True)
    # purchase_work = fields.Char('Name', size=256)
    # file_names = fields.Binary('Purchase CSV Report', readonly=True)


class WizardWizards(models.Model):
    _name = 'towerwizard.reports'
    _description = 'tower invoice excel wizard'

#tower invoice excel report button actions
#     @api.multi
    def action_tower_report(self):
#XLS report
        custom_value = {}
        # label_lists=['OTC Site ID','Actual  Height (m)','Applicable pricing Table Height (m)','EPA Allowance (m2)','Ground Space Allow. (m2)','Base monthly Rent','Tenancy Discount','Actual EPA (m2)','EPA Add. Fee', 'Vertical Space used (m)', 'Ground Space used (m2)', 'Ground Space Add. Fee', 'AWL Fee', 'Total monthly Rent', 'RFI Notice Date',
        #              'Tenant install. date before 45 days (Y/N)', 'Site Commencement Date', 'Last day of such month', 'Quarter', 'End of ending quarter date', 'Nb of full months due', 'Nb of days due (partial month)', 'Nb days in that month', 'Amount due']
        order = self.env['tower.invoice'].browse(self._context.get('active_ids', list()))
        workbook = xlwt.Workbook()
        for rec in order:
            invoice = []
            for line in rec.greenfield_a1_lines:
                item = {}
                item ['site_id'] = line.site_id.name
                item ['actual_max_height'] = line.actual_max_height
                item ['invoiced_height'] = line.invoiced_height
                item ['epa_allowance'] = line.epa_allowance
                item ['ground_space_allow'] = line.ground_space_allow
                item ['base_rent'] = line.base_rent
                item ['tenancy_discount'] = line.tenancy_discount
                item ['actual_epa'] = line.actual_epa
                item ['epa_add_fee'] = line.epa_add_fee
                item ['vertical_space_used'] = line.vertical_space_used
                item ['vertical_space_add_fee'] = line.vertical_space_add_fee
                item ['ground_space_used'] = line.ground_space_used
                item ['ground_space_add_fee'] = line.ground_space_add_fee
                item ['total_rent'] = line.total_rent
                item ['rfi_notice'] = line.rfi_notice
                item ['tenant_commen_before_30days'] = line.tenant_commen_before_30days
                item ['site_commen_date'] = line.site_commen_date
                item ['last_date'] = line.last_date
                item ['quarter'] = line.quarter
                item ['end_of_quarter_date'] = line.end_of_quarter_date
                item ['nb_full_months_due'] = line.nb_full_months_due
                item ['nb_days_due'] = line.nb_days_due
                item ['nb_days_in_month'] = line.nb_days_in_month
                item ['amount_due'] = line.amount_due
                invoice.append(item)

            custom_value['item'] = invoice
            custom_value ['partner_id'] = rec.partner_id.name
            custom_value ['invoice_date'] = rec.invoice_date
            # custom_value ['payment_term_id'] = rec.payment_term_id.name
            # custom_value ['date_order'] = rec.date_order
            # custom_value ['partner_no'] = rec.name
            # custom_value ['amount_total'] = str(rec.amount_total)+' '+rec.currency_id.symbol
            # custom_value ['amount_untaxed'] = str(rec.amount_untaxed)+' '+rec.currency_id.symbol
            # custom_value ['amount_total'] = str(rec.amount_due)+' '+rec.currency_id.symbol

            style0 = xlwt.easyxf('font: name Times New Roman bold on;border:left thin, right thin, top thin, bottom thin;align: horiz center;', num_format_str='#,##0.00')
            style1 = xlwt.easyxf('font:bold True;font:name Times New Roman bold on;border:left thick, right thick, top thick, bottom thick;align: horiz center;', num_format_str='#,##0.00')
            style2 = xlwt.easyxf('font:height 200,bold on;borders:left thick, right thick, top thick, bottom thick;', num_format_str='#,##0.00')
            style3 = xlwt.easyxf('font:bold True;border:left thick, right thick, top thick, bottom thick;', num_format_str='#,##0.00')
            style4 = xlwt.easyxf('font:bold True;  borders:top double,right thin;align: horiz right;', num_format_str='#,##0.00')
            style5 = xlwt.easyxf('font: name Times New Roman bold on;align: horiz center;', num_format_str='#,##0')
            style6 = xlwt.easyxf('font: name Times New Roman bold on;borders:left thin, right thin, top thin, bottom thin;', num_format_str='#,##0.00')
            style7 = xlwt.easyxf('font:bold True;  borders:top double;', num_format_str='#,##0.00')
            style8 = xlwt.easyxf('font: name Times New Roman bold on;borders:left thin, right thin, top thin, bottom thin;align: horiz right;', num_format_str='DD-MM-YYYY')
            style3_1 = xlwt.easyxf('font: name Times New Roman bold on;borders:left thin;align: horiz right;', num_format_str='#,##0.00')
            style4_1 = xlwt.easyxf('borders:top thin;', num_format_str='#,##0.00')
            style5_1 = xlwt.easyxf('borders:left thin;', num_format_str='#,##0.00')
            style6_1 = xlwt.easyxf('font:bold True;  borders:top double;', num_format_str='#,##0.00')
            style7_1 = xlwt.easyxf('borders:left thin,bottom thin,right thin;', num_format_str='#,##0.00')
            style8_1 = xlwt.easyxf('borders:right thin;', num_format_str='#,##0.00')
            sheet = workbook.add_sheet(rec.name)
            
            sheet.write_merge(0, 0, 0, 8, 'Oman Tower Company - Quarterly Invoice - '+rec.name, style2)
            sheet.write_merge(1, 1, 0, 2, 'Client:', style3)

            sheet.write(5, 0, '#', style1)
            sheet.write(5, 1, 'OTC Site ID', style1)
            sheet.write(5, 2, 'Actual Height (m)', style1)
            sheet.write(5, 3, 'Applicable pricing Table Height (m)', style1)
            sheet.write(5, 4, 'EPA Allowance (m2)', style1)
            sheet.write(5, 5, 'Ground Space Allow. (m2)', style1)
            sheet.write(5, 6, 'Base monthly Rent', style1)
            sheet.write(5, 7, 'Tenancy Discount', style1)
            sheet.write(5, 8, 'Actual EPA (m2)', style1)
            sheet.write(5, 9, 'EPA Add. Fee', style1)
            sheet.write(5, 10, 'Vertical Space used (m)', style1)
            sheet.write(5, 11, 'Vertical Space Add. Fee', style1)
            sheet.write(5, 12, 'Ground Space used (m2)', style1)
            sheet.write(5, 13, 'Ground Space Add. Fee', style1)
            sheet.write(5, 14, 'AWL Fee', style1)
            sheet.write(5, 15, 'Total monthly Rent', style1)
            sheet.write(5, 16, 'Equipment Installation Date', style1)
            sheet.write(5, 17, 'Tenant install date before 45 days(Y/N)', style1)
            sheet.write(5, 18, 'Site Commencement Date', style1)
            sheet.write(5, 19, 'Last day of such month', style1)
            sheet.write(5, 20, 'Quarter', style1)
            sheet.write(5, 21, 'End of ending quarter date', style1)
            sheet.write(5, 22, 'Nb of full months due', style1)
            sheet.write(5, 23, 'Nb of days due (partial month)', style1)
            sheet.write(5, 24, 'Nb days in that month', style1)
            sheet.write(5, 25, 'Amount due', style1)
            
            n = 7; m=0; i = 1
            for item in custom_value['item']:
                sheet.write(n, m, i, style5)
                sheet.write(n, m+1, item['site_id'], style5)
                sheet.write(n, m+2, item['actual_max_height'], style5)
                sheet.write(n, m+3, item['invoiced_height'], style5)
                sheet.write(n, m+4, item['epa_allowance'], style5)
                sheet.write(n, m+5, item['ground_space_allow'], style5)
                sheet.write(n, m+6, item['base_rent'], style5)
                sheet.write(n, m+7, item['tenancy_discount'], style5)
                sheet.write(n, m+8, item['actual_epa'], style5)
                sheet.write(n, m+9, item['epa_add_fee'], style5)
                sheet.write(n, m+10, item['vertical_space_used'], style5)
                sheet.write(n, m+11, item['vertical_space_add_fee'], style5)
                sheet.write(n, m+12, item['ground_space_used'] , style5)
                sheet.write(n, m+13, item['ground_space_add_fee'], style5)
                sheet.write(n, m+14, item['total_rent'], style5)
                sheet.write(n, m+15, item['rfi_notice'], style5)
                sheet.write(n, m+16, item['tenant_commen_before_30days'], style5)
                sheet.write(n, m+17, item['site_commen_date'], style5)
                sheet.write(n, m+18, item['last_date'], style5)
                sheet.write(n, m+19, item['quarter'], style5)
                sheet.write(n, m+20, item['end_of_quarter_date'], style5)
                sheet.write(n, m+21, item['nb_full_months_due'], style5)
                sheet.write(n, m+22, item['nb_days_due'], style5)
                sheet.write(n, m+23, item['nb_days_in_month'], style5)
                sheet.write(n, m+24, item['amount_due'], style5)
                n += 1; i += 1

            for line in rec.greenfield_a1_lines:
                item = {}
                item['site_id'] = line.site_id.name
                item['actual_max_height'] = line.actual_max_height
                item['invoiced_height'] = line.invoiced_height
                item['epa_allowance'] = line.epa_allowance
                item['ground_space_allow'] = line.ground_space_allow
                item['base_rent'] = line.base_rent
                item['tenancy_discount'] = line.tenancy_discount
                item['actual_epa'] = line.actual_epa
                item['epa_add_fee'] = line.epa_add_fee
                item['vertical_space_used'] = line.vertical_space_used
                item['vertical_space_add_fee'] = line.vertical_space_add_fee
                item['ground_space_used'] = line.ground_space_used
                item['ground_space_add_fee'] = line.ground_space_add_fee
                item['total_rent'] = line.total_rent
                item['rfi_notice'] = line.rfi_notice
                item['tenant_commen_before_30days'] = line.tenant_commen_before_30days
                item['site_commen_date'] = line.site_commen_date
                item['last_date'] = line.last_date
                item['quarter'] = line.quarter
                item['end_of_quarter_date'] = line.end_of_quarter_date
                item['nb_full_months_due'] = line.nb_full_months_due
                item['nb_days_due'] = line.nb_days_due
                item['nb_days_in_month'] = line.nb_days_in_month
                item['amount_due'] = line.amount_due
                invoice.append(item)

            custom_value['item'] = invoice
            custom_value['partner_id'] = rec.partner_id.name
            custom_value['invoice_date'] = rec.invoice_date
            # custom_value ['payment_term_id'] = rec.payment_term_id.name
            # custom_value ['date_order'] = rec.date_order
            # custom_value ['partner_no'] = rec.name
            # custom_value ['amount_total'] = str(rec.amount_total)+' '+rec.currency_id.symbol
            # custom_value ['amount_untaxed'] = str(rec.amount_untaxed)+' '+rec.currency_id.symbol
            # custom_value ['amount_total'] = str(rec.amount_due)+' '+rec.currency_id.symbol

            style0 = xlwt.easyxf(
                'font: name Times New Roman bold on;border:left thin, right thin, top thin, bottom thin;align: horiz center;',
                num_format_str='#,##0.00')
            style1 = xlwt.easyxf(
                'font:bold True;font:name Times New Roman bold on;border:left thick, right thick, top thick, bottom thick;align: horiz center;',
                num_format_str='#,##0.00')
            style2 = xlwt.easyxf('font:height 200,bold on;borders:left thick, right thick, top thick, bottom thick;',
                                 num_format_str='#,##0.00')
            style3 = xlwt.easyxf('font:bold True;border:left thick, right thick, top thick, bottom thick;',
                                 num_format_str='#,##0.00')
            style4 = xlwt.easyxf('font:bold True;  borders:top double,right thin;align: horiz right;',
                                 num_format_str='#,##0.00')
            style5 = xlwt.easyxf('font: name Times New Roman bold on;align: horiz center;', num_format_str='#,##0')
            style6 = xlwt.easyxf(
                'font: name Times New Roman bold on;borders:left thin, right thin, top thin, bottom thin;',
                num_format_str='#,##0.00')
            style7 = xlwt.easyxf('font:bold True;  borders:top double;', num_format_str='#,##0.00')
            style8 = xlwt.easyxf(
                'font: name Times New Roman bold on;borders:left thin, right thin, top thin, bottom thin;align: horiz right;',
                num_format_str='DD-MM-YYYY')
            style3_1 = xlwt.easyxf('font: name Times New Roman bold on;borders:left thin;align: horiz right;',
                                   num_format_str='#,##0.00')
            style4_1 = xlwt.easyxf('borders:top thin;', num_format_str='#,##0.00')
            style5_1 = xlwt.easyxf('borders:left thin;', num_format_str='#,##0.00')
            style6_1 = xlwt.easyxf('font:bold True;  borders:top double;', num_format_str='#,##0.00')
            style7_1 = xlwt.easyxf('borders:left thin,bottom thin,right thin;', num_format_str='#,##0.00')
            style8_1 = xlwt.easyxf('borders:right thin;', num_format_str='#,##0.00')
            sheet = workbook.add_sheet(rec.name)

            sheet.write_merge(0, 0, 0, 8, 'Oman Tower Company - Quarterly Invoice - ' + rec.name, style2)
            sheet.write_merge(1, 1, 0, 2, 'Client:', style3)

            sheet.write(5, 0, '#', style1)
            sheet.write(5, 1, 'OTC Site ID', style1)
            sheet.write(5, 2, 'Actual Height (m)', style1)
            sheet.write(5, 3, 'Applicable pricing Table Height (m)', style1)
            sheet.write(5, 4, 'EPA Allowance (m2)', style1)
            sheet.write(5, 5, 'Ground Space Allow. (m2)', style1)
            sheet.write(5, 6, 'Base monthly Rent', style1)
            sheet.write(5, 7, 'Tenancy Discount', style1)
            sheet.write(5, 8, 'Actual EPA (m2)', style1)
            sheet.write(5, 9, 'EPA Add. Fee', style1)
            sheet.write(5, 10, 'Vertical Space used (m)', style1)
            sheet.write(5, 11, 'Vertical Space Add. Fee', style1)
            sheet.write(5, 12, 'Ground Space used (m2)', style1)
            sheet.write(5, 13, 'Ground Space Add. Fee', style1)
            sheet.write(5, 14, 'AWL Fee', style1)
            sheet.write(5, 15, 'Total monthly Rent', style1)
            sheet.write(5, 16, 'Equipment Installation Date', style1)
            sheet.write(5, 17, 'Tenant install date before 45 days(Y/N)', style1)
            sheet.write(5, 18, 'Site Commencement Date', style1)
            sheet.write(5, 19, 'Last day of such month', style1)
            sheet.write(5, 20, 'Quarter', style1)
            sheet.write(5, 21, 'End of ending quarter date', style1)
            sheet.write(5, 22, 'Nb of full months due', style1)
            sheet.write(5, 23, 'Nb of days due (partial month)', style1)
            sheet.write(5, 24, 'Nb days in that month', style1)
            sheet.write(5, 25, 'Amount due', style1)

            n = 7;
            m = 0;
            i = 1
            for item in custom_value['item']:
                sheet.write(n, m, i, style5)
                sheet.write(n, m + 1, item['site_id'], style5)
                sheet.write(n, m + 2, item['actual_max_height'], style5)
                sheet.write(n, m + 3, item['invoiced_height'], style5)
                sheet.write(n, m + 4, item['epa_allowance'], style5)
                sheet.write(n, m + 5, item['ground_space_allow'], style5)
                sheet.write(n, m + 6, item['base_rent'], style5)
                sheet.write(n, m + 7, item['tenancy_discount'], style5)
                sheet.write(n, m + 8, item['actual_epa'], style5)
                sheet.write(n, m + 9, item['epa_add_fee'], style5)
                sheet.write(n, m + 10, item['vertical_space_used'], style5)
                sheet.write(n, m + 11, item['vertical_space_add_fee'], style5)
                sheet.write(n, m + 12, item['ground_space_used'], style5)
                sheet.write(n, m + 13, item['ground_space_add_fee'], style5)
                sheet.write(n, m + 14, item['total_rent'], style5)
                sheet.write(n, m + 15, item['rfi_notice'], style5)
                sheet.write(n, m + 16, item['tenant_commen_before_30days'], style5)
                sheet.write(n, m + 17, item['site_commen_date'], style5)
                sheet.write(n, m + 18, item['last_date'], style5)
                sheet.write(n, m + 19, item['quarter'], style5)
                sheet.write(n, m + 20, item['end_of_quarter_date'], style5)
                sheet.write(n, m + 21, item['nb_full_months_due'], style5)
                sheet.write(n, m + 22, item['nb_days_due'], style5)
                sheet.write(n, m + 23, item['nb_days_in_month'], style5)
                sheet.write(n, m + 24, item['amount_due'], style5)
                n += 1;
                i += 1
            # sheet.write_merge(n+1, n+1, 9, 10, 'Untaxed Amount', style7)
            # sheet.write(n+1, 11, custom_value['amount_untaxed'], style4)
            # sheet.write_merge(n+2, n+2, 9, 10, 'Taxes', style7)
            # sheet.write(n+2, 11, custom_value['amount_tax'], style4)
            # sheet.write_merge(n+3, n+3, 9, 10, 'Total', style6_1)
            # sheet.write(n+3, 11, custom_value['amount_total'], style4)
            # sheet.write(m+1, 1, '', style3_1)
            # sheet.write(m+1, 11, '', style8_1)
            # sheet.write(n+1, 1, '', style3_1)
            # sheet.write(n+2, 1, '', style3_1)
            # sheet.write(n+3, 1, '', style3_1)
            # sheet.write_merge(n+4,n+4,1, 11, '', style7_1)
# #CSV report
#         datas = []
#         for values in order:
#             for value in values.order_line:
#                 if value.product_id.seller_ids:
#                     item = [
#                             str(value.order_id.name or ''),
#                             str(''),
#                             str(''),
#                             str(value.product_id.barcode or ''),
#                             str(value.product_id.default_code or ''),
#                             str(value.product_id.name or ''),
#                             str(value.product_qty or ''),
#                             str(value.product_id.seller_ids[0].product_code or ''),
#                             str(value.partner_id.title or ''),
#                             str(value.partner_id.name or ''),
#                             str(value.partner_id.email or ''),
#                             str(value.partner_id.phone or ''),
#                             str(value.partner_id.mobile or ''),
#                             str(value.partner_id.street or ''),
#                             str(value.partner_id.street2 or ''),
#                             str(value.partner_id.zip or ''),
#                             str(value.partner_id.city or ''),
#                             str(value.partner_id.country_id.name or ' '),
#                             ]
#                     datas.append(item)
#
#         output = StringIO()
#         label = ';'.join(label_lists)
#         output.write(label)
#         output.write("\n")
#
#         for data in datas:
#             record = ';'.join(data)
#             output.write(record)
#             output.write("\n")
#         data = base64.b64encode(bytes(output.getvalue(),"utf-8"))
#
#         if platform.system() == 'Linux':
#             filename = ('/tmp/Purchase Report' +'.xls')
#         else:
        filename = ('Tower Invoice Report' +'.xls')

        workbook.save(filename)
        fp = open(filename, "rb")
        file_data = fp.read()
        out = base64.encodestring(file_data)

        # Files actions
        attach_vals = {
                'purchase_data': 'Tower Invoice Report'+ '.xls',
                'file_name': out,
                'purchase_work':'Tower'+ '.csv',
                # 'file_names':data,
            }

        act_id = self.env['purchase.report.out'].create(attach_vals)
        fp.close()
        return {
        'type': 'ir.actions.act_window',
        'res_model': 'purchase.report.out',
        'res_id': act_id.id,
        'view_type': 'form',
        'view_mode': 'form',
        'context': self.env.context,
        'target': 'new',
        }

































