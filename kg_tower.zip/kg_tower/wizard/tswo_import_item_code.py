import binascii
import tempfile
import xlrd
from odoo import models, fields, _
from odoo.exceptions import UserError


class ImportFile(models.Model):
    _name = 'import.file'
    _description = 'Import File'

    xls_file = fields.Binary(string='Excel File')
    tswo_id = fields.Many2one('kg.tswo')

    def import_order_lines(self):
        try:
            file_string = tempfile.NamedTemporaryFile(suffix=".xlsx")
            file_string.write(binascii.a2b_base64(self.xls_file))
            book = xlrd.open_workbook(file_string.name)


        except:
            raise UserError(_("Please choose the .xlsx file"))

        for sheet in book.sheets():
            print("sheet-------",sheet)
            try:
                line_vals = []
                if sheet.name == 'Sheet1':
                    for row in range(sheet.nrows):
                        print("row---------",row)
                        if row >= 1:
                            row_values = sheet.row_values(row)
                            print("row_values-------------",row_values)
                            val = int(row_values[0])
                            val_str = str(val)
                            contract = self.env['kg.tswo'].search([('id', '=', self.tswo_id.id)])
                            for rec in contract.contract_no.pricelist_line_ids:
                                if val_str == rec.name:
                                    line_vals.append((0, 0, {
                                        'contract_line_id': rec.id,
                                        'product_id': rec.product_id.id,
                                        'product_uom_id': rec.product_id.uom_id.id,
                                        'regional_coefficient_id': self.tswo_id.regional_coefficient_id.id,
                                        'reg_coefficient': self.tswo_id.regional_coefficient_id.reg_coefficient,
                                        'equipment_cost': rec.equipment_cost,
                                        'service_cost': rec.service_cost,
                                        'product_qty' : row_values[1]

                                    }))
                    line = self.tswo_id.write({
                        'tswo_line_ids': line_vals,
                    })
                    print("line---------",line)
            except IndexError:
                pass
