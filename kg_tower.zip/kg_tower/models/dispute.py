from odoo import models, fields, api, _
from odoo.exceptions import UserError


class Dispute(models.Model):
    _name = 'kg.dispute'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Dispute Resolutions'

    name = fields.Char('Description', tracking=True)
    move_id = fields.Many2one('account.move', 'Move')
    dispute_date = fields.Date('Date', tracking=True)
    resolved = fields.Boolean('Resolved', default=False, tracking=True)
    unpaid_amount = fields.Float('Unpaid Amount', tracking=True)
    just_client = fields.Text('Client Justification', tracking=True)
    actions_taken = fields.Text('Actions Taken', tracking=True)

    def action_resolve(self):
        self.resolved = True
    def action_unresolve(self):
        self.resolved  = False
