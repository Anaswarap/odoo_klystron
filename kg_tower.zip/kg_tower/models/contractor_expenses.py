from datetime import date

from odoo import api, models, fields, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta


class ProjectExpenseLines(models.Model):
    _name = 'project.expense.lines'
    _description = 'Project Expense Lines'

    name = fields.Char('Description', required=True)
    expense_type = fields.Many2one('expense.type', 'Expense Type')
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    fees = fields.Float('Monthly Fees', copy=False, digits="OTC Decimal")
    project_id = fields.Many2one('project.project', 'Project')
    task_id = fields.Many2one('project.task', 'Task')
    tower_invoice_id = fields.Many2one('tower.invoice', 'Tower Invoice')
    invoice_id = fields.Many2one('account.move', string="Bill")

    @api.onchange('type')
    def _onchange_type(self):
        if self.type:
            self.expense_type = False

    def action_create_expense(self):
        """Action raise a vendor bill for expenses in project"""
        print("Bill for expense")
        invoice = self.env['account.move']
        for rec in self:
            if rec:
                if rec.invoice_id:
                    raise ValidationError("Sorry this expense already invoiced")

                label = 'Expense: ' + rec.name + ' project: ' + rec.project_id.name
                mole_line = (0, 0, {
                    'name': label,
                    'quantity': 1,
                    'price_unit': rec.fees,
                    'analytic_account_id': rec.project_id and rec.project_id.analytic_account_id and rec.project_id.analytic_account_id.id or False,
                })
                invoice_values = {
                    'partner_id': rec.project_id.partner_id.id,
                    'invoice_date': rec.start_date if rec.start_date else date.today(),
                    'move_type': 'in_invoice',
                    'invoice_line_ids': mole_line,
                }

                create_invoice = invoice.create(invoice_values)
                create_invoice.action_post()
                create_invoice.project_id = rec.project_id.id
                rec.invoice_id = create_invoice.id
                # expense_line = (0, 0, {
                #     'id': create_invoice
                # })
                # rec.project_id.addt_exp_value += create_invoice.amount_total


class ExpenseType(models.Model):
    _name = 'expense.type'
    _description = 'Expense Type'

    name = fields.Char('Expense Type', required=True)

    bill_type = fields.Selection([('B', 'B'), ('C', 'C')], string='Bill Type', required=True, help="""Part B covers additional services that may be provided at the sites: Shelter Rental, various types of power supply, etc.
Part C covers one-off (non-recurring) invoicing amounts that may occur, for example Search Ring Fees, contributions to grid connection cost in excess of RO 6,000, etc.""", )


class ProjectContractorExpense(models.Model):
    _name = 'project.contractor.expense'
    _description = 'Contractor Expense'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'documents.mixin']
    # ****MINI****
    # removed required of name,desc for data import
    name = fields.Char('Name', default=lambda x: _('New'), )
    desc = fields.Char('Description')
    # additional field as per excel
    structure_type = fields.Many2one('structure.type', string='Structure Type')
    # removed related property for data import
    # site_id = fields.Many2one('account.asset.site', 'OTC Site', related='project_id.site_id')
    site_id = fields.Many2one('account.asset.site', 'OTC Site')

    partner_id = fields.Many2one('res.partner', 'Partner')
    expense_type = fields.Many2one('contractor.expense.type', 'Expense Type', domain="[('non_recover', '=', False)]")
    # start_date = fields.Date('Start Date')
    # end_date = fields.Date('End Date')
    invoice_date = fields.Date('Invoice Date')
    invoice_date_imp = fields.Char('Invoice Date Imp')
    amount = fields.Float('Amount', digits="OTC Decimal")
    project_id = fields.Many2one('project.project', 'Project')
    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('confirm', 'Confirmed'),
                   ('invoiced', 'Invoiced'), ],
        default='draft', required=False, )
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    contractor_id = fields.Many2one('res.partner', string="Contractor",
                                    domain="[('contractor','=',True)]")
    card_account_id = fields.Many2one('account.account', string="Card Account", )
    journal_id = fields.Many2one('account.journal', string="Journal", required=True)
    is_penalty = fields.Boolean(default=False)

    @api.model
    def create(self, values):
        if values.get('name', _('New')) == _('New'):
            values['name'] = self.env['ir.sequence'].next_by_code('project.contractor.expense') or _('New')
        if 'expense_type' in values and values.get('expense_type'):
            expense_type = self.env['contractor.expense.type'].browse(values['expense_type'])
            if expense_type.penalty:
                values['amount'] += expense_type.penalty_amnt
                values['is_penalty'] = True
            else:
                values['is_penalty'] = False
        return super(ProjectContractorExpense, self).create(values)


    def write(self, values):
        if 'expense_type' in values or 'amount' in values:
            for expense in self:
                if 'expense_type' in values:
                    expense_type = self.env['contractor.expense.type'].browse(values['expense_type'])
                    if expense_type.penalty:
                        values['amount'] = values.get('amount', expense.amount) + expense_type.penalty_amnt
                        values['is_penalty'] = True
                    else:
                        values['is_penalty'] = False
                elif 'amount' in values:
                    if expense.expense_type and expense.expense_type.penalty:
                        values['amount'] = values['amount'] + expense.expense_type.penalty_amnt
        return super(ProjectContractorExpense, self).write(values)


    def action_confirm(self):
        self.state = 'confirm'

    def create_invoice(self):

        if not self.expense_type.product_id:
            raise ValidationError('Please add a product to the expense type!')
        if not self.expense_type.recoverable_account_id:
            raise ValidationError('Please add Recoverable Account in the expense type!')
        if not self.contractor_id.property_account_receivable_id:
            raise ValidationError('Please add Receivable account in the Contractor!')
        move_obj = self.env['account.move'].with_context(default_move_type='entry')
        entries = []
        recoverable_dr_line = (0, 0, {
            'account_id': self.expense_type.recoverable_account_id.id,
            # 'partner_id': self.partner_id.id,
            'name': "Recover " + self.expense_type.name,
            'debit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(recoverable_dr_line)
        card_line = (0, 0, {
            'account_id': self.card_account_id.id,
            # 'partner_id': self.partner_id.id,
            'name': "Card Line",
            'credit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(card_line)
        contractor_line = (0, 0, {
            'account_id': self.contractor_id.property_account_receivable_id.id,
            'partner_id': self.contractor_id.id,
            'name': "Contractor " + self.contractor_id.name,
            'debit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(contractor_line)
        recoverable_cr_line = (0, 0, {
            'account_id': self.expense_type.recoverable_account_id.id,
            # 'partner_id': self.partner_id.id,
            'name': "Recover " + self.expense_type.name,
            'credit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(recoverable_cr_line)
        create_entry = move_obj.create({
            'ref': self.name,
            'invoice_origin': self.name,
            'partner_id': self.partner_id.id,
            'invoice_date': date.today(),
            'journal_id': self.journal_id.id,
            'project_contractor_expense_id': self.id,
            'line_ids': entries})

        action = self.env["ir.actions.actions"]._for_xml_id("account.action_move_in_invoice_type")
        if len(create_entry) == 1:
            form_view = [(self.env.ref('account.view_move_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = create_entry.id
        context = {
            'default_move_type': 'entry',
        }
        if len(self) == 1:
            context.update({
                'default_partner_id': self.partner_id.id,
                'default_invoice_origin': self.name,
                'default_user_id': self.env.uid,
            })
        action['context'] = context
        create_entry.action_post()
        self.state = 'invoiced'
        return action

    def action_view_invoice(self):
        action = self.env.ref('account.action_move_in_invoice_type').read()[0]
        action['domain'] = [('project_contractor_expense_id', '=', self.id)]
        return action

    @api.onchange('expense_type')
    def onchange_expense_type(self):
        if self.expense_type:
            self.journal_id = self.expense_type.journal_id


class ContractorExpenseType(models.Model):
    _name = 'contractor.expense.type'
    _description = 'Contractor Expense Type'

    name = fields.Char('Expense Type', required=True)
    product_id = fields.Many2one('product.product', string='Product', domain="[('type', '=', 'service')]")
    refundable = fields.Boolean(default=True)
    recoverable_account_id = fields.Many2one('account.account', string="Recoverable Account")
    non_recover = fields.Boolean(string='Non-Recoverable', default=False)
    penalty = fields.Boolean(string='Have Penalty', default=False)
    penalty_amnt = fields.Float(string='Penalty Amount')
    journal_id = fields.Many2one('account.journal', string="Journal", required=True)


class ProjectContractorExpenseNonRecoverable(models.Model):
    _name = 'project.contractor.expense.nonrecover'
    _description = 'Non Recoverable Contractor Expense'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'documents.mixin']

    name = fields.Char('Name', default=lambda x: _('New'), )
    desc = fields.Char('Description')
    structure_type = fields.Many2one('structure.type', string='Structure Type')

    partner_id = fields.Many2one('res.partner', 'Partner')
    expense_type = fields.Many2one('contractor.expense.type', 'Expense Type', domain="[('non_recover', '=', True)]")
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    amount = fields.Float('Amount')
    project_id = fields.Many2one('project.project', 'Project')
    site_id = fields.Many2one('account.asset.site', 'OTC Site')
    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('confirm', 'Confirmed'),
                   ('invoiced', 'Invoiced'), ],
        default='draft', required=False, )
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    contractor_id = fields.Many2one('res.partner', string="Contractor", domain="[('contractor','=',True)]")
    card_account_id = fields.Many2one('account.account', string="Card Account")
    journal_id = fields.Many2one('account.journal', string="Journal", required=True)
    invoice_date = fields.Date(string="Invoice Date")

    @api.model
    def create(self, values):
        if values.get('name', _('New')) == _('New'):
            values['name'] = self.env['ir.sequence'].next_by_code('project.contractor.expense.nonreco') or _('New')
        return super(ProjectContractorExpenseNonRecoverable, self).create(values)

    def action_confirm(self):
        self.state = 'confirm'

    def create_invoice(self):

        if not self.expense_type.product_id:
            raise ValidationError('Please add a product to the expense type!')
        if not self.expense_type.product_id.property_account_expense_id:
            raise ValidationError('Please add an expense account under expense type product!')
        if not self.contractor_id.property_account_receivable_id:
            raise ValidationError('Please add Receivable account in the Contractor!')
        move_obj = self.env['account.move'].with_context(default_move_type='entry')
        entries = []
        card_line = (0, 0, {
            'account_id': self.card_account_id.id,
            # 'partner_id': self.partner_id.id,
            'name': "Card Line",
            'credit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(card_line)
        contractor_line = (0, 0, {
            'account_id': self.expense_type.product_id.property_account_expense_id.id,
            'partner_id': self.contractor_id.id,
            'name': "Contractor " + self.contractor_id.name,
            'debit': self.amount if self.amount else self.expense_type.product_id.product_tmpl_id.list_price,
        })
        entries.append(contractor_line)
        create_entry = move_obj.create({
            'ref': self.name,
            'invoice_origin': self.name,
            'partner_id': self.partner_id.id,
            'invoice_date': date.today(),
            'journal_id': self.journal_id.id,
            'project_contractor_nonreco_expense_id': self.id,
            'line_ids': entries})

        action = self.env["ir.actions.actions"]._for_xml_id("account.action_move_in_invoice_type")
        if len(create_entry) == 1:
            form_view = [(self.env.ref('account.view_move_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = create_entry.id
        context = {
            'default_move_type': 'entry',
        }
        if len(self) == 1:
            context.update({
                'default_partner_id': self.partner_id.id,
                'default_invoice_origin': self.name,
                'default_user_id': self.env.uid,
            })
        action['context'] = context
        create_entry.action_post()
        self.state = 'invoiced'
        return action

    def action_view_invoice(self):
        action = self.env.ref('account.action_move_in_invoice_type').read()[0]
        action['domain'] = [('project_contractor_nonreco_expense_id', '=', self.id)]
        return action
