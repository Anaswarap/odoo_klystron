import math
from datetime import date, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class WorkOrder(models.Model):
    _name = 'work.order'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'kg.approval.transaction']
    _description = 'Work Order'

    active = fields.Boolean(string='Active', default=True)
    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    partner_id = fields.Many2one('res.partner',
                                 string='Operator Contact',
                                 required=True,
                                 tracking=True, domain=[('operator', '=', True)])
    operator_id = fields.Many2one('res.partner',
                                  string='Operator',
                                  required=True,
                                  tracking=True, domain=[('operator', '=', True)])
    work_order_date = fields.Date('Date', default=fields.Date.context_today, tracking=True, required=True)
    revision_date = fields.Date('Revision Date', tracking=True)
    attachment_sign = fields.Binary(
        string="Signature",
        copy=False, tracking=True)
    client_work_order_no = fields.Char(
        string='Client Work Order No',
        tracking=True, store=True)
    existing_site = fields.Boolean(
        string='Existing Site',
        default=False,
        tracking=True)
    srr_id = fields.Many2one(
        comodel_name='ring.request',
        string='SRR Id',
        required=False)
    site_type = fields.Selection(
        string='Site Type',
        selection=[('bts', 'BTS Site'),
                   ('existing', 'Existing Site'), ],
        required=True, tracking=True, default='bts')
    tower_tenants = fields.Selection(
        string='Tower Tenants',
        selection=[('0', '0'),
                   ('1', '1'),
                   ('2', '2'), ],
        required=False, tracking=True)  # [aks]
    structure_type_id = fields.Many2one('structure.type', 'Structure', store=True)
    current_task_id = fields.Many2one('project.task', 'Current Task')
    current_task_status = fields.Char('Current Status')

    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'),
    #                ('mosaic', 'Mosaic tower'), ],
    #     required=True)

    uso_site = fields.Selection(
        string='Uso Site',
        selection=[('yes', 'Yes'),
                   ('no', 'No'), ],
        required=False, tracking=True)
    ring_work_order = fields.Char(
        string='Ring Work Order No.',
        required=False, tracking=True, related='srr_id.client_work_order_no')
    location_no = fields.Char(
        string='Candidate Location No',
        required=False, tracking=True)
    # two_g = fields.Boolean(
    #     string='2G',
    #     required=False, tracking=True)
    # three_g = fields.Boolean(
    #     string='3G',
    #     required=False, tracking=True)
    # four_g = fields.Boolean(
    #     string='4G',
    #     required=False, tracking=True)
    # five_g = fields.Boolean(
    #     string='5G',
    #     required=False, tracking=True)
    # none = fields.Boolean(
    #     string='None',
    #     required=False, tracking=True)
    planned_radio_technology_ids = fields.Many2many('radio.technology', tracking=True)
    others = fields.Boolean(
        string='Others',
        required=False, tracking=True)
    radio_technology_note = fields.Text(
        string="Radio Technology Note",
        required=False, tracking=True)
    # transmission_type = fields.Selection(
    #     string='Transmission Type',
    #     selection=[('micro', 'Microwave'),
    #                ('fiber', 'Fiber Optic'),
    #                ('satellite', 'Satellite'), ],
    #     required=False, tracking=True)
    transmission_type_id = fields.Many2one('transmission.type', 'Transmission Type', required=False, tracking=True)
    no_of_antennas = fields.Selection(
        string='No Of Antennas',
        selection=[('0', '0'),
                   ('1', '1'), ],
        required=False, tracking=True)  # [aks]
    """required changed as false for excel importing NSWO by ****sha"""
    antenna_height = fields.Float(
        string='Antenna Height', digits=(16, 3),
        required=True, tracking=True)
    antenna_width = fields.Float(
        string='Antenna Width', digits=(16, 3),
        required=True, tracking=True)
    antenna_diameter = fields.Float(
        string='Antenna Diameter', digits=(16, 3),
        required=True, tracking=True)
    sector_height = fields.Float(
        string='Sector Height', digits=(16, 3),
        required=True, tracking=True)
    sector_azimuth = fields.Float(
        string='Sector_azimuth', digits=(16, 3),
        required=True, tracking=True)
    microwave_dishes = fields.Many2one(
        comodel_name='micro.dishes',
        string='Microwave Dishes',
        required=False, tracking=True)  # [aks]
    rru = fields.Many2one(
        comodel_name='rru.antenna',
        string='RRUs for each Antenna',
        required=False, tracking=True)  # [aks]
    latitude = fields.Char(
        string='Latitude',
        required=False, tracking=True)
    longitude = fields.Char(
        string='Longitude',
        required=False, tracking=True)
    governorate = fields.Many2one(
        comodel_name='kg.governorate',
        string='Governorate',
        required=True, tracking=True)
    wilayat = fields.Many2one('kg.wilayat',
                              string='Wilayat',
                              required=True, tracking=True)
    tower_height = fields.Many2one(
        comodel_name='tower.height',
        string='Tower Height',
        required=True, tracking=True)
    # requested_height = fields.Float(
    #     string='Requested Height',
    #     required=False)
    epa_allowance = fields.Many2one(
        comodel_name='epa.allowance', string='EPA Allowance', tracking=True)
    rent = fields.Float(
        string='Monthly Rent', digits=(16, 3),
        required=False)
    with_cable = fields.Boolean(
        string='With Grounded',
        required=False)
    shelter_space = fields.Many2one(
        comodel_name='shelter.space',
        string='Shelter Space',
        required=False, tracking=True)
    equipment_housing = fields.Many2one(
        comodel_name='equipment.housing',
        string='Equipment Housing', tracking=True)
    housing_width = fields.Char(
        string='Housing Width', digits=(16, 3), tracking=True)
    housing_height = fields.Char(
        string='Housing Height', digits=(16, 3), tracking=True)
    housing_diameter = fields.Char(
        string='Housing Diameter', digits=(16, 3), tracking=True)
    extra_space_request = fields.Selection(
        string='Extra Space Request',
        selection=[('none', 'None'),
                   ('yes', 'Yes'), ], tracking=True, digits=(16, 3))
    extra_space_meter = fields.Float(
        string='Extra Space', tracking=True, digits=(16, 3))
    extra_space_rent = fields.Float(
        string='Extra Space Rent', tracking=True, digits=(16, 3))

    terms_conditions = fields.Text(
        string="Terms & Conditions",
        required=False, tracking=True)
    signed_user = fields.Many2one(
        comodel_name='res.users',
        string='Signed User',
        required=False, tracking=True)
    user_id = fields.Many2one('res.users', default=lambda self: self.env.user)
    email = fields.Char(
        string='Email',
        required=False, tracking=True)
    submission_type = fields.Selection(
        string='Submission Type',
        selection=[('draft', 'First Draft'),
                   ('submit', 'Submit'), ],
        required=False, tracking=True)
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('confirm', 'Confirm'),
        ('on_hold', 'On Hold'),
        ('rejected', 'Rejected'),

    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    edit_state = fields.Selection(selection=[
        ('request', 'Requested to Modify'),
        ('edit', 'Open to Modify'),
        ('close', 'Closed Modification'),
    ], string='Modification Status', copy=False, tracking=True, default='edit')
    shelter_rent = fields.Float(
        string='Shelter Rent', digits=(16, 3),
        required=False)
    publish = fields.Boolean(
        string='Publish',
        required=False, default=False, tracking=True, readonly=True)

    ### edited by ashish
    task_status = fields.Char('Task Status', compute='comp_task_status')
    task_count = fields.Integer('Task Count', compute='comp_task_count')
    """***sha***...clinte_site_id changed as readonly false for excl import"""
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    project_id = fields.Many2one('project.project', 'Project', tracking=True)
    cabinet_space_id = fields.Many2one('cabinet.space', 'Cabinet Space', tracking=True, readonly=True)
    extra_ground_space_id = fields.Many2one('ground.space', 'Extra Ground Space', tracking=True, readonly=True)

    ## revision fields

    is_revision = fields.Boolean(string='Is Revision', default=False)
    orginal_wo_id = fields.Many2one('work.order', 'Revision ID')
    revision_count = fields.Integer('Revision Count', compute='comp_revision_count')
    mail_body = fields.Text('Mail Body')

    antenna_lines = fields.One2many('work.order.antenna.lines', 'work_order_id', copy=True)
    rru_lines = fields.One2many('work.order.rru.lines', 'work_order_id', copy=True)
    micro_lines = fields.One2many('work.order.microwave.lines', 'work_order_id', copy=True)
    total_countable_epa = fields.Float('Total Epa', compute='compute_total_countable_epa', digits=(16, 3))

    no_srr = fields.Boolean('No SRR', default=True, tracking=True)
    load_category = fields.Many2one('power.load.category', 'Power Load Category')
    off_grid_power_supply = fields.Boolean('Off Grid Power Supply', default=False)
    tower_height_input = fields.Float('Required Tower Height', help="Tower height entered from portal", store=True)

    """fields added for excel import"""
    ###***sha***
    client_site = fields.Char(string='Client Site ID:', required=False)
    # otc_site_id = fields.Char(string='OTC Site ID', required=False)
    status = fields.Selection(selection=[('Applied', 'Applied'), ('Not Applied', 'Not Applied')],
                              string='Status(Applied/Not applied)')
    type_of_site = fields.Char(string='Type of Site')
    commercial_type = fields.Char(string='Commercial Type')
    nswo_applctn = fields.Char(string='Date of NSWO Application')
    nswo_acceptance = fields.Char(string='NSWO Acceptance Date')
    rfi = fields.Char(string='RFI Date')
    tower_height_new = fields.Float("Tower Height-import")
    latest_otc_update = fields.Char(string='Latest OTC Update')
    vf_snags = fields.Text(string='VF Notification of Snags')
    vf_first_snags = fields.Text(string='VF first notification of snags')
    otc_snags_cleared = fields.Text(string='OTC Notification of Snags Cleared')
    otc_1st_snags_cleared = fields.Text(string='OTC 1st snag clearance notice')
    size = fields.Text(string='Size')
    vf_acceptance = fields.Text(string='VF Acceptance Date')
    final_rfi = fields.Text(string='Final RFI Date')
    ericson_instaltn = fields.Text(string='Ericsson Installation Date')
    actual_site_commncmnt = fields.Text(string='Actual Site Commencement Date')
    remarks = fields.Char(string='Remarks')
    depth = fields.Char(string='Depth')
    # shelter_space = fields.Char(string='Shelter Space')

    oo_colo_submisn_status = fields.Char(string='If Oo-colo submission status')
    oredeoo_colo_status = fields.Char(string='If Ooredoo Colo (status)')
    layout_reqst_date = fields.Char(string="Layout Request Date to OO")
    retrn_date_oo = fields.Char(string="Return Date From OO")
    submission_date_oo = fields.Char(string="Submission Date to OO")
    approval_date_oo = fields.Char(string="Approval Date From OO")

    """fields altered for excel import"""

    structure_type = fields.Selection(
        string='Structure Type',
        selection=[('0', '0'), ('greenfield', 'Greenfield'),
                   ('rooftop', 'Rooftop'),
                   ('ccollocation', 'Co-Location OO'), ('OO_collocation', 'Oo-Colocation'),
                   ('otc_collocation', 'OTC-Collocation'), ('Co-Location OTP', 'Co-Location OTP'),
                   ('Co-Location MOD', 'Co-Location MOD')
                   ],
        required=False)
    expected_grid_connection = fields.Selection(
        string='Expected Grid Connection',
        selection=[('yes', 'Yes'),
                   ('no', 'No'), ('Grid', 'Grid'), ('Off-Grid', 'Off-Grid'), ('TBD', 'TBD'),
                   ('to_be_confirm', 'To be Confirmed'), ],
        required=False, tracking=True)

    # field added by Nafi
    project_type = fields.Selection(
        string='Project Type',
        selection=[('new_project', 'New Project'),
                   ('link_to_existing', 'Link To Existing Project')],
        required=True, tracking=True, default='new_project')
    type_equipment_housing = fields.Selection(
        string='Equipment Housing',
        selection=[('shelter', 'Shelter'),
                   ('cabinet', 'Outdoor Cabinet')], tracking=True)

    # for data import only
    epa_allowance_import = fields.Float(string="EPA Allowance(Import)")

    '''
        ----------------------Approval Module Changes----------------------
        Approval Section field override to mentioned corresponding model.
        '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='work.order')

    @api.depends('antenna_lines', 'rru_lines', 'micro_lines')
    def compute_total_countable_epa(self):
        for data in self:
            antenna_total = 0
            rru_total = 0
            micro_total = 0
            for rec in data.antenna_lines:
                antenna_total += rec.countable_epa
            for rec in data.rru_lines:
                rru_total += rec.countable_epa
            for rec in data.micro_lines:
                micro_total += rec.countable_epa
            data.total_countable_epa = antenna_total + rru_total + micro_total

    @api.model
    def get_existing_tenants(self, client_site_id):
        work_order = self.sudo().env['work.order'].search(
            [('client_site_id.name', '=', client_site_id)],
            limit=1, order='create_date desc').tower_tenants
        if not work_order:
            return False
        return work_order

    @api.onchange('epa_allowance', 'tower_height', 'with_cable', 'structure_type_id')
    def find_rent(self):
        for rec in self:
            if rec.epa_allowance and rec.tower_height:
                rent_id = self.env['rent.calculation'].sudo().search(
                    [('epa_allowance', '=', rec.epa_allowance.id), ('tower_height_id', '=', rec.tower_height.id),
                     ('partner_id', '=', rec.operator_id.id), ('structure_type_id', '=', rec.structure_type_id.id)],
                    limit=1)
                rec.rent = rent_id.rent_with_cable if rec.with_cable else rent_id.rent_without_cable
            else:
                rec.rent = 0

    @api.onchange('tower_height_input')
    def onchange_tower_height_input(self):
        tower_height = self.tower_height_input
        exact_tower_height = self.env['tower.height'].search([('name', '>=', tower_height)], limit=1)
        if exact_tower_height:
            self.tower_height = exact_tower_height.id

    def send_back(self):
        res = super(WorkOrder, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res

    def create_revision(self):
        for rec in self:
            tasks = self.env['project.task'].search([('work_order_id', '=', rec.id)])
            for task in tasks:
                task.stage_id = self.env.ref('kg_tower.task_stage_draft').id
                activities = self.env['mail.activity'].sudo().search(
                    [('res_id', '=', task.id), ('res_model_id', '=', self.env.ref('project.model_project_task').id)])
                activities.unlink()
            task_schedule = self.env['project.task'].search(
                [('work_order_id', '=', rec.id), ('stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)],
                limit=1,
                order="sequence asc")
            if task_schedule:
                activity = self.env['mail.activity'].sudo().create({
                    'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                    'res_id': task_schedule.id,
                    'user_id': task_schedule.user_id.id,
                    # 'date_deadline':deadline,
                    'res_model_id': self.env.ref('project.model_project_task').id,
                })
                activity._onchange_activity_type_id()
            count_old_revision = self.search_count([('orginal_wo_id', '=', rec.id), ('active', '!=', True)])
            new_revision_name = rec.name + '_' + str(count_old_revision + 1)
            rec.copy(default={'is_revision': True, 'orginal_wo_id': rec.id, 'name': new_revision_name, 'active': False,
                              'revision_date': date.today()})

    def comp_revision_count(self):
        for record in self:
            record.revision_count = self.search_count(
                [('orginal_wo_id', '=', record.id), ('active', '!=', True)])

    def show_revisions(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Revisions',
                'view_mode': 'tree,form',
                'res_model': 'work.order',
                'domain': [('orginal_wo_id', '=', rec.id), ('active', '!=', True)],
                'context': "{'create': False,'edit': False}"
            }

    def comp_task_count(self):
        for record in self:
            record.task_count = self.env['project.task'].search_count(
                [('work_order_id', '=', record.id)])

    def show_tasks(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Tasks',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.task',
                'domain': [('work_order_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>
                             
                                <th scope="col">Status</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                
                """
            count = 1
            for task in self.env['project.task'].search([('work_order_id', '=', rec.id)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info
            print('info : ', info, rec.id)

    # create site acquistiom.construction,rfi notice on confirm nswo
    def create_site_acq(self):
        project_id = False
        existing_srr = self.srr_id
        if existing_srr:
            project_id = self.env['project.task'].search([('ring_request_id', '=', existing_srr.id)],
                                                         limit=1) and self.env['project.task'].search(
                [('ring_request_id', '=', existing_srr.id)], limit=1).project_id
            project_id = project_id and project_id.id
            self.project_id = project_id
        else:
            project_id = self.project_id.id
        site_acq = self.env['site.acquisition'].create({'partner_id': self.partner_id.get_operator_id() or False,
                                                        'client_work_order_no': self.client_work_order_no,
                                                        'project_id': project_id,
                                                        'client_site_id': self.client_site_id.id or False,
                                                        'existing_site': self.existing_site,
                                                        'structure_type_id': self.structure_type_id.id or False,
                                                        'wilayat_id': self.wilayat.id or False,
                                                        'governorate': self.governorate.id or False,
                                                        'client_site': self.client_site,
                                                        'nswo_id': self.id, })
        return site_acq

    def create_construction(self, site_acq):
        self.env['site.construction'].create({'partner_id': self.partner_id.get_operator_id() or False,
                                              'client_work_order_no': self.client_work_order_no,
                                              'project_id': self.project_id.id or False,
                                              'client_site_id': self.client_site_id.id or False,
                                              'existing_site': self.existing_site,
                                              'structure_type_id': self.structure_type_id.id or False,
                                              'work_order_id': self.id,
                                              'site_acq_id': site_acq.id,
                                              'client_id': self.client_site})

    def create_rfi_notice(self):
        self.env['rfi.notice'].create({'partner_id': self.partner_id.get_operator_id() or False,
                                       'client_work_order_no': self.client_work_order_no,
                                       'project_id': self.project_id.id or False,
                                       'client_site_id': self.client_site_id.id or False,
                                       'existing_site': self.existing_site,
                                       'structure_type_id': self.structure_type_id.id or False,
                                       'work_order_id': self.id,
                                       'client_site':self.client_site,
                                       # 'rfi_notice_date': fields.Date.today()
                                       })

    def show_create_site_acq(self):
        action = self.env["ir.actions.actions"]._for_xml_id("kg_tower.site_acquisition_action")

        site_ids = self.env['site.acquisition'].search(
            [('project_id', '=', self.project_id.id),
             ('client_site_id', '=', self.client_site_id.id)])
        new_cxt = {}
        if self.site_type == 'existing':
            site_type = 'Existing Site'
        elif self.site_type == 'bts':
            site_type = 'BTS Site'
        cxt = dict(self._context, )
        if len(site_ids) > 1:
            action['domain'] = [('id', 'in', site_ids.ids)]
            new_cxt.update({'create': False})
        elif site_ids:
            form_view = [(self.env.ref('kg_tower.site_acquisition_view_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = site_ids.id
            new_cxt.update({
                'default_partner_id': self.partner_id.id,
                'default_client_work_order_no': self.client_work_order_no,
                'default_project_id': self.project_id.id,
                'default_client_site_id': self.client_site_id.id,
                'default_existing_site': self.existing_site,
                'default_structure_type_id': self.structure_type_id.id or False,
                'default_wilayat_id': self.wilayat.id or False,
                'default_nswo_id': self.id,
                'default_site_type': site_type,
                'default_governorate': self.governorate.id
            })
        else:
            print("else------------>>")
            new_cxt.update({
                'default_partner_id': self.partner_id.id,
                'default_client_work_order_no': self.client_work_order_no,
                'default_project_id': self.project_id.id,
                'default_client_site_id': self.client_site_id.id,
                'default_existing_site': self.existing_site,
                'default_structure_type_id': self.structure_type_id.id or False,
                'default_wilayat_id': self.wilayat.id or False,
                'default_nswo_id': self.id,
                'default_site_type':site_type,
                'default_governorate':self.governorate.id
            })
            action['domain'] = [('id', '=', False)]
        if new_cxt:
            cxt.update(new_cxt)
        action['context'] = cxt
        return action

    def notify_users(self, allowed_group):
        self.activity_unlink(['kg_tower.nswo_created'])
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.nswo_created', note=user.name, user_id=user.id)
        return True

    def send_mail(self):
        template_id = self.env.ref('kg_tower.email_template_nswo')
        print(template_id, 'template_id')
        template_id.send_mail(self.id, force_send=True)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('work.order') or _('New')
        gov_obj = self.env['kg.governorate'].browse([vals.get('governorate')])
        site_id = self.env['structure.type'].browse([vals.get('structure_type_id')])
        if 'project_type' in vals and vals['project_type'] == 'link_to_existing':
            if 'client_site_id' not in vals or vals['client_site_id'] == False:
                raise UserError('Existing site not linked!')
            # print('vals2', vals)
        """commented for import"""""
        """***sha***"""

        if 'project_type' in vals and vals[
            'project_type'] != 'link_to_existing' and gov_obj.site_sequence and not site_id.is_restrict_site:
            site_name = gov_obj.site_sequence.next_by_id()
            client_site_id = self.env['account.asset.site'].create({'name': site_name})
            vals['client_site_id'] = client_site_id.id
        if not 'project_type' in vals and vals['no_srr'] == False and not site_id.is_restrict_site:
            site_name = gov_obj.site_sequence.next_by_id()
            client_site_id = self.env['account.asset.site'].create({'name': site_name})
            vals['client_site_id'] = client_site_id.id
        if not 'project_type' in vals and vals['no_srr'] == True and not site_id.is_restrict_site:
            site_name = gov_obj.site_sequence.next_by_id()
            client_site_id = self.env['account.asset.site'].create({'name': site_name})
            vals['client_site_id'] = client_site_id.id

        partner = self.env['res.partner'].search([('id', '=', vals.get('partner_id'))]).get_operator_id()
        vals['operator_id'] = partner
        res = super(WorkOrder, self).create(vals)
        """commented for import"""""
        """***sha***"""
        res.notify_users('kg_tower.group_nswo')
        """commented for operator_id creation while excel importing"""
        # res.operator_id = res.partner_id.get_operator_id()

        all_epa_allowance = self.env['epa.allowance'].search([])
        max_epa_allowance_id = False
        max_epa_allowance = 0
        print(res.total_countable_epa)
        try:
            for i in all_epa_allowance:
                if float(i.name) >= self.total_countable_epa:
                    if float(i.name) < max_epa_allowance:
                        max_epa_allowance = float(i.name)
                        max_epa_allowance_id = i.id
                    elif max_epa_allowance == 0:
                        max_epa_allowance = float(i.name)
                        max_epa_allowance_id = i.id
            # res.epa_allowance = max_epa_allowance_id
        except:
            print("inside exception")
        if not res.is_revision:
            res.send_mail()  # *Aks
        return res

    def action_generate_site_id(self):
        if not self:
            raise UserError('Save The Record')
        if not self.structure_type_id:
            raise UserError('Structure Type is Missing')
        gov_obj = self.env['kg.governorate'].browse(self.governorate.id)
        site_name = gov_obj.site_sequence.next_by_id()
        client_site_id = self.env['account.asset.site'].create({'name': site_name})
        self.client_site_id = client_site_id.id

    def compute_epa_allowance(self):
        all_epa_allowance = self.env['epa.allowance'].search([])
        max_epa_allowance_id = False
        max_epa_allowance = 0
        for i in all_epa_allowance:
            if float(i.name) >= self.total_countable_epa:
                if float(i.name) < max_epa_allowance:
                    max_epa_allowance = float(i.name)
                    max_epa_allowance_id = i.id
                elif max_epa_allowance == 0:
                    max_epa_allowance = float(i.name)
                    max_epa_allowance_id = i.id
        self.epa_allowance = max_epa_allowance_id

    def create_each_task(self, task_list_obj, project_id, users):
        prev_task = False
        task = self.env['project.task']
        for lines in task_list_obj.sorted('sequence'):
            if lines.progress == 'nswo_received':
                if not prev_task:
                    current_date = fields.Date.today()
                    additional_days = lines.completion_days + 2
                    deadline = current_date + timedelta(days=additional_days)
                else:
                    current_date = prev_task.date_deadline
                    additional_days = lines.completion_days + 2
                    deadline = current_date + timedelta(days=additional_days)
                allowed_user_ids = False
                if users:
                    allowed_user_ids = [[6, 0, [users.id]]]

                vals = {
                    'project_id': project_id.id,
                    'name': lines.kg_task_id,
                    'department_id': lines.department_id.id,
                    'work_flow': lines.work_flow,
                    'progress_level': lines.progress,
                    'weight': lines.weight,
                    'completion_task': lines.completion_task,
                    'gf_construction': lines.gf_construction,
                    'collacation': lines.collacation,
                    'roof_top': lines.roof_top,
                    'sequence': lines.sequence,
                    'partner_id': self.partner_id.id,
                    'work_order_id': self.id,
                    'user_id': lines.user_id.id or False,
                    'allowed_user_ids': allowed_user_ids,
                    'override_sequence': lines.override_sequence,
                    'milestone_task': lines.milestone_task,
                    'date_deadline': deadline,
                    'proposed_date_deadline': deadline,
                    'attach_mandatory': lines.attach_mandatory

                }
                prev_task = task.create(vals)
        task_schedule = self.env['project.task'].search(
            [('project_id', '=', project_id.id), ('work_order_id', '=', self.id), (
                'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1,
            order="sequence asc")
        if task_schedule:
            self.current_task_id = task_schedule.id
            self.current_task_status = task_schedule.name

            activity = self.env['mail.activity'].sudo().create({
                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                'res_id': task_schedule.id,
                'user_id': task_schedule.user_id.id,
                # 'date_deadline':deadline,
                'res_model_id': self.env.ref('project.model_project_task').id,
            })
            activity._onchange_activity_type_id()


    def action_create_tasks(self):
        project = self.env['project.project']
        task = self.env['project.task']
        no_srr = self.no_srr
        if no_srr:
            existing_srr = False
            existing_srr = self.env['ring.request'].search(
                [('client_work_order_no', '=', self.client_work_order_no),('client_work_order_no', '!=', False)], limit=1)
            print('existing_srr',existing_srr)
            if existing_srr and existing_srr.id:
                raise UserError(_('An SRR with same work order exist!'))
        else:
            if not self.srr_id:
                raise UserError(_('Please link SRR!'))
            existing_srr = self.srr_id
            if existing_srr.structure_type_id:
                self.structure_type_id = existing_srr.structure_type_id.id
        if not self.structure_type_id:
            raise UserError(_('Please link Structure Type!'))

        partner = self.partner_id.parent_id and self.partner_id.parent_id.id or self.partner_id.id
        task_lists = self.env['task.list'].search(
            [('partner_id', '=', partner), ('structure_type_id', '=', self.structure_type_id.id)],
            limit=1)
        if task_lists:
            users = self.env['res.users'].search([('partner_id', '=', self.partner_id.id)], limit=1)
            allowed_portal_user_ids = False
            if users:
                allowed_portal_user_ids = [[6, 0, [users.id]]]
            # if not users:
            #     raise ValidationError(_(
            #         "No User found for Operator Contact %s", self.partner_id.name))
            for rec in task_lists:
                # Check open tasks in SRR
                if existing_srr:
                    project_id = self.env['project.task'].search([('ring_request_id', '=', existing_srr.id)],
                                                                 limit=1) and self.env['project.task'].search(
                        [('ring_request_id', '=', existing_srr.id)], limit=1).project_id
                    # self.client_site_id = existing_srr.client_site_id.id
                    open_tasks = self.env['project.task'].search([('ring_request_id', '=', existing_srr.id), (
                        'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)])
                    if open_tasks:
                        raise UserError(_('Please complete Ring Request Stage Tasks.'))
                    #Check open tasks in SRR End

                    if project_id:
                        inventory_location_id = self.env['stock.location'].search([('usage','=', 'production')], limit=1)
                        project_id.inventory_location = inventory_location_id.id
                        project_id.work_order_id = self.id
                        project_id.site_id = self.client_site_id.id

                        # fix this project number
                        if project_id.number == 'New':
                            project_id.number = self.client_site_id.name or self.env['ir.sequence'].next_by_code('project.project') or _('New')
                        if self.project_type == 'new_project':
                            self.project_id = project_id.id
                        if self.existing_site:
                            task_list_obj = rec.existing_list_lines
                        else:
                            task_list_obj = rec.list_lines

                        self.create_each_task(task_list_obj, project_id, users)
                    else:
                        raise UserError(_('Project not found in existing SRR!'))

                if no_srr:
                    project_id = self.project_id or False
                    if not project_id:
                        if not self.client_site_id:
                            # client_site_id = self.env['account.asset.site'].create(
                            #     {'name': self.governorate.site_sequence.next_by_id()})
                            # self.client_site_id = client_site_id.id
                            raise UserError(_('Cannot find OTC Site ID!'))
                        else:
                            client_site_id = self.client_site_id
                        if self.project_type == 'new_project':
                            client_site_id_name = client_site_id.name
                        else:
                            client_site_id_name = client_site_id.name + ' - SS'
                        val = {
                            'site_id': self.client_site_id.id,
                            'partner_id': self.partner_id.id,
                            'name': client_site_id_name,
                            'number': client_site_id_name,
                            'structure_type_id': self.structure_type_id.id,
                            'allowed_portal_user_ids': allowed_portal_user_ids,
                        }
                        project_id = project.create(val)
                        self.project_id = project_id.id

                    # if project_id:
                    if project_id.number == 'New':
                        project_id.number = self.client_site_id.name or self.env['ir.sequence'].next_by_code('project.project') or _('New')
                        inventory_location_id = self.env['stock.location'].search([('usage', '=', 'production')], limit=1)
                        project_id.inventory_location = inventory_location_id.id

                    project_id.site_id = self.client_site_id.id
                    project_id.work_order_id = self.id
                    if self.existing_site:
                        task_list_obj = rec.existing_list_lines
                    else:
                        task_list_obj = rec.list_lines
                    self.create_each_task(task_list_obj, project_id, users)
        else:
            raise UserError(_('Please set Task Lists First'))

    def action_approve(self):
        # moved certain code into confirm action like task, SAQ and RFI creation.
        # if not self.project_id:
        #     raise UserError(_('Please link project before approval.'))
        self.state = 'approved'

    def action_reject(self):
        self.state = 'rejected'

    def action_on_hold(self):
        self.state = 'on_hold'

    def action_confirm(self):
        self.action_create_tasks()
        # self.compute_epa_allowance()
        site_acq = self.create_site_acq()
        self.create_construction(site_acq)
        self.create_rfi_notice()
        self.state = 'confirm'

    def kg_final_approval(self):
        """Supering method which is defined in the kg approval to confirm NSWO if it is final approval"""
        res = super(WorkOrder, self).kg_final_approval()
        self.action_confirm()
        return res

    def request_modifications(self):
        for rec in self:
            rec.edit_state = 'request'
            allowed_group_obj = self.env.ref("kg_tower.group_comm_dept")
            email_list = allowed_group_obj.users.mapped('partner_id.email')
            email_list = [e for e in email_list if e]
            email_list = ",".join(email_list)
            email_values = {'email_to': email_list}
            template_id = self.env.ref('kg_tower.nswo_modification_mail')
            if not rec.is_revision:
                template_id.send_mail(self.id, email_values=email_values, force_send=True)
            users = rec.operator_id.team_id and rec.operator_id.team_id.sale_person_ids
            for user in users:
                self.activity_schedule('kg_tower.nswo_edit_notification', note='Operator requested to modify the NSWO.', user_id=user.id)

    @api.model
    def request_modifications_from_front_end(self, rec_id):
        if rec_id:
            self.browse(int(rec_id)).sudo().request_modifications()

    def publish_work_order(self):
        for rec in self:
            rec.publish = True

    @api.model
    def request_action_publish_frontend(self, rec_id):
        if rec_id:
            self.browse(int(rec_id)).sudo().publish_work_order()

    def open_modification(self):
        for rec in self:
            rec.edit_state = 'edit'
            body = ""
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            body += "Dear " + rec.operator_id.name + ",<br/><br/>Modification Request Approved.<br/>You can access the NSWO using the below link<br/><a style='color: #FFFFFF; text-decoration: none !important; font-weight: 400; background-color: #875A7B; border: 0px solid #875A7B; border-radius:3px' class='btn btn-sm btn-link' href=" + str(
                base_url) + "/my/work_order/" + str(
                self.id) + "><i class=fa fa-fw o_button_icon fa-download></i>View Site Work Order</a>"
            if not rec.is_revision:
                rec.message_post(body=body, message_type='notification', mail_auto_delete=False,
                                 subtype_xmlid='mail.mt_comment', partner_ids=[rec.partner_id.id]
                                 )

                rec.create_revision()

    def close_modification(self):
        for rec in self:
            rec.edit_state = 'close'
            rec.send_mail()


    # fields = ['srr_id','client_site_id','structure_type_id','microwave_dishes','rru','governorate','tower_height','epa_allowance': '8','shelter_space','equipment_housing']
    def write(self, vals):
        if self:
            if vals.get('tower_height_input'):
                tower_height = vals.get('tower_height_input')
                exact_tower_height = self.env['tower.height'].search([('name', '>=', tower_height)], limit=1)
                if exact_tower_height and self.tower_height != exact_tower_height:
                    self.tower_height = exact_tower_height.id
        field_list = ['no_ssr', 'partner_id', 'client_work_order_no', 'existing_site', 'site_type', 'structure_type_id',
                  'uso_site', 'location_no', 'planned_radio_technology_ids', 'radio_technology_note',
                  'transmission_type_id', 'latitude'
            , 'longitude', 'governorate', 'wilayat', 'tower_height_input', 'epa_allowance', 'with_cable', 'rent',
                  'equipment_housing', 'shelter_space', 'terms_conditions',
                  'expected_grid_connection', 'micro_id', 'azimuth', 'tower_height', 'rru_id', 'antenna_id', 'azimuth',
                  'tower_height', 'extra_space_request','antenna_lines','rru_lines','micro_lines']
        # if 'edit_state' not in vals:
        #     if self.edit_state == 'edit':
        #         vals['edit_state'] = 'close'
        for val in vals:
            try:
                if vals[val].isnumeric():
                    print('inside', val, vals[val])
                    vals[val] = int(vals[val])
            except:
                pass
        mail_content = ''
        count = 1
        for key in vals:
            if key in field_list:
                field_description = self.env['ir.model.fields'].search(
                    [('name', '=', key), ('model_id.model', '=', 'work.order')]).field_description
                mail_content += "\n" + str(count) + ". " + field_description
                count += 1
        vals['mail_body'] = mail_content
        res = super().write(vals)
        # for data in self:
        #     all_epa_allowance = self.env['epa.allowance'].search([])
        #     max_epa_allowance_id = False
        #     max_epa_allowance = 0
        #     print(data.total_countable_epa)
        #     try:
        #         for i in all_epa_allowance:
        #             if float(i.name) >= data.total_countable_epa:
        #                 if float(i.name) < max_epa_allowance:
        #                     max_epa_allowance = float(i.name)
        #                     max_epa_allowance_id = i.id
        #                 elif max_epa_allowance == 0:
        #                     max_epa_allowance = float(i.name)
        #                     max_epa_allowance_id = i.id
        #         data.epa_allowance = max_epa_allowance_id
        #     except:
        #         print("inside exception")
        template_id = self.env.ref('kg_portal.notify_nswo_edited')
        """comment for import by sha"""
        """***sha***"""

        # users_mail = self.env['res.users'].search([('share', '=', False)]).mapped('login')
        users_mail = self.env['res.users'].search([]).filtered(lambda x: x.has_group('kg_tower.group_nswo')).mapped(
            'login')
        split_users_mail = ",".join(users_mail)
        email_to = self.partner_id.email
        email_values = {
            'email_to': email_to,
            'email_cc': split_users_mail
        }
        if self.id and count>1:
            print("commented for importing")
            # commented for importing
            # template_id.send_mail(self.id, force_send=True, email_values=email_values)
        return res

    @api.model
    def get_wilayat(self, gov):
        """rpc call from NSWO"""
        print('gov', gov)
        wilayat = self.env['kg.wilayat'].sudo().search([('governorate_id', '=', int(gov) if gov else gov)])
        print(wilayat.read(['id', 'name']))
        return wilayat.read(['id', 'name'])

    @api.model
    def create_microwave_model(self, model, height, diameter, shape):
        """rpc call from NSWO"""
        microwave_model_obj = self.env['micro.dishes'].sudo()
        microwave_model_obj.create({
            'name': model,
            'height': height,
            'diameter': diameter,
            'shape': shape,
        })
        microwave_search = microwave_model_obj.search([])
        return microwave_search.read(['id', 'display_name'])

    @api.model
    def create_rru_model(self, model, height, width, depth):
        """rpc call from NSWO"""
        rru_model_obj = self.env['rru.antenna'].sudo()
        rru_model_obj.create({
            'name': model,
            'height': height,
            'width': width,
            'depth': depth,
        })
        rru_search = rru_model_obj.search([])
        return rru_search.read(['id', 'complete_name'])

    @api.model
    def check_equipment_housing(self, equip_id):
        """rpc call from NSWO"""
        print(equip_id)
        if equip_id:
            equipment_housing = self.env['equipment.housing'].sudo().search([('id', '=', equip_id)])
            return equipment_housing.read(['type'])
        return False

    def action_open_documents(self):
        self.ensure_one()
        project_name = self.project_id.name
        saq_project_folder = self.env['documents.folder'].search(
            [('name', '=', project_name), ('model', '=', 'work.order'), ('res_id', '=', self.id)])
        action = self.env['ir.actions.act_window']._for_xml_id('documents.document_action')
        action['context'] = {
            'searchpanel_default_folder_id': saq_project_folder and saq_project_folder.id,
        }
        return action

    @api.onchange('shelter_space')
    def onchange_shelter_space(self):
        for rec in self:
            if rec.shelter_space:
                shelter_rent = self.env['shelter.rent'].search([('shelter_space_id', '=', rec.shelter_space.id)])
                if shelter_rent:
                    rec.shelter_rent = shelter_rent.rent


class WorkOrderAntennaLines(models.Model):
    _name = 'work.order.antenna.lines'
    _description = 'Radio Antenna Lines'

    work_order_id = fields.Many2one('work.order', 'Work Order')
    antenna_id = fields.Many2one('radio.antenna', 'Antenna Model')
    sector = fields.Selection([('3', '3'), ('4', '4')], 'Sector')
    height = fields.Float(string='Height', related='antenna_id.height', digits=(12, 3))
    width = fields.Float(string='Width', related='antenna_id.width', digits=(12, 3))
    depth = fields.Float(string='Depth', related='antenna_id.depth', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)', digits=(16, 3))
    tower_height = fields.Float(string='Height on the Tower', digits=(16, 3))
    azimuth = fields.Float(string='Azimuth (degree)', digits=(16, 3))
    hw = fields.Float(string='H/W', compute='compute_values', digits=(16, 3))
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values', digits=(16, 3))
    epa = fields.Float(string='EPA(no shielding)', compute='compute_values', digits=(16, 3))
    hd = fields.Float(string='H/D', compute='compute_values', digits=(12, 3))
    side_drag_coef = fields.Float(string='Side drag coef.', compute='compute_values', digits=(16, 3))
    epa_t = fields.Float(string='EPA (T) (side face)', compute='compute_values', digits=(12, 3))
    epa_antenna2 = fields.Float(string='EPA(A) antenna 2', compute='compute_values', digits=(12, 3))
    epa_antenna3 = fields.Float(string='EPA(A) antenna 3', compute='compute_values', digits=(12, 3))
    shielding_factor = fields.Float(string='shielding factor', compute='compute_values', digits=(12, 3))
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', related='tower_height', digits=(16, 3))
    lowest_point = fields.Float(string='Lowest antenna point', digits=(16, 3))
    construction_id = fields.Many2one('site.construction', 'Construction')

    @api.onchange('height', 'width', 'depth', 'tower_height', 'azimuth', 'sector')
    @api.depends('height', 'width', 'depth', 'weight', 'tower_height', 'azimuth', 'sector')
    def compute_values(self):
        for data in self:
            print(data.antenna_id.degree, 'degree')
            if data.sector == '4':
                print('haiiii1')
                # compute hw
                if data.height != 0 and data.width != 0:
                    data.hw = data.height / data.width
                else:
                    data.hw = 0.00

                # compute Drag coef.
                if data.hw < 1:
                    data.drag_coef = 0.00
                if data.hw >= 1 and data.hw <= 7:
                    data.drag_coef = 1.40
                if data.hw > 7 and data.hw < 25:
                    data.drag_coef = (data.hw + 35) / 30
                else:
                    data.drag_coef = 2

                # compute epa
                data.epa = data.height * data.width * data.drag_coef

                # compute hd
                if data.height != 0 and data.depth != 0:
                    data.hd = data.height / data.depth
                else:
                    data.hd = 0.00

                # compute side_drag_coef
                if data.hd <= 7:
                    data.side_drag_coef = 1.4
                if data.hd > 7 and data.hd < 25:
                    data.side_drag_coef = (data.hd + 35) / 30
                else:
                    data.side_drag_coef = 2

                # compute epa_t
                data.epa_t = data.height * data.depth * data.side_drag_coef

                # compute epa_antenna2
                data.epa_antenna2 = (data.epa * ((math.cos(math.radians(120))) ** 2)) + (
                        data.epa_t * ((math.sin(math.radians(120))) ** 2))

                # compute epa_antenna3
                data.epa_antenna3 = (data.epa * ((math.cos(math.radians(240))) ** 2)) + (
                        data.epa_t * ((math.sin(math.radians(240))) ** 2))

                # compute countable_epa
                if (data.epa + data.epa_antenna2 + data.epa_antenna3) != 0:
                    data.countable_epa = (data.epa + data.epa_antenna2 + data.epa_antenna3) / 3
                else:
                    data.countable_epa = 0.00

                # compute shielding_factor
                if data.countable_epa != 0 and data.epa != 0:
                    data.shielding_factor = data.countable_epa / data.epa
                else:
                    data.shielding_factor = 0.00
            elif data.sector == '3':
                print('haiiii2')
                # compute hw
                if data.height != 0 and data.width != 0:
                    data.hw = data.height / data.width
                else:
                    data.hw = 0.00
                # compute Drag coef.
                if data.hw < 1:
                    data.drag_coef = 0.00
                if data.hw >= 1 and data.hw <= 7:
                    data.drag_coef = 1.40
                if data.hw > 7 and data.hw < 25:
                    data.drag_coef = (data.hw + 35) / 30
                else:
                    data.drag_coef = 2
                # compute epa
                data.epa = data.height * data.width * data.drag_coef
                # compute hd
                if data.height != 0 and data.depth != 0:
                    data.hd = data.height / data.depth
                else:
                    data.hd = 0.00
                # compute side_drag_coef
                if data.hd <= 7:
                    data.side_drag_coef = 1.4
                if data.hd > 7 and data.hd < 25:
                    data.side_drag_coef = (data.hd + 35) / 30
                else:
                    data.side_drag_coef = 2
                # compute epa_t
                data.epa_t = data.height * data.depth * data.side_drag_coef
                data.epa_antenna2 = 0.00
                data.epa_antenna3 = 0.00
                # compute countable_epa
                if (data.epa + data.epa_t) != 0:
                    data.countable_epa = (data.epa + data.epa_t) / 2
                else:
                    data.countable_epa = 0.00
                # compute shielding_factor
                if data.countable_epa != 0 and data.epa != 0:
                    data.shielding_factor = data.countable_epa / data.epa
                else:
                    data.shielding_factor = 0.00
            else:
                print('hjnudfhvux')
                # compute hw
                if data.height != 0 and data.width != 0:
                    data.hw = data.height / data.width
                else:
                    data.hw = 0.00
                # compute Drag coef.
                if data.hw == 0:
                    data.drag_coef = 0.00
                elif data.hw >= 1 and data.hw <= 7:
                    data.drag_coef = 1.40
                elif data.hw > 7 and data.hw < 25:
                    data.drag_coef = (data.hw + 35) / 30
                else:
                    data.drag_coef = 2
                # compute epa
                data.epa = data.height * data.width * data.drag_coef
                data.countable_epa = data.epa
                data.hd = data.side_drag_coef = data.epa_t = data.epa_antenna2 = data.epa_antenna3 = data.shielding_factor = 0.00



class WorkOrderRRULines(models.Model):
    _name = 'work.order.rru.lines'
    _description = 'RRU Lines'

    work_order_id = fields.Many2one('work.order', 'Work Order')
    rru_id = fields.Many2one('rru.antenna', 'RRU Model')
    rru_position = fields.Selection(
        string='RRU Position',
        selection=[('behind_antenna', 'RRU Behind Antenna'),
                   ('separate_pole', 'RRU on separate pole'), ],
        required=False, )  # [aks]
    height = fields.Float(string='Height', related='rru_id.height', digits=(12, 3))
    width = fields.Float(string='Width', related='rru_id.width', digits=(12, 3))
    depth = fields.Float(string='Depth', related='rru_id.depth', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)', digits=(16, 3))
    tower_height = fields.Float(string='Height on the Tower', digits=(16, 3))
    epa_discount = fields.Float(string='EPA discount(%)', digits=(16, 3))
    hw = fields.Float(string='H/W', compute='compute_values', digits=(16, 3))
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values', digits=(16, 3))
    epa = fields.Float(string='EPA(no shielding)', compute='compute_values', digits=(16, 3))
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', digits=(16, 3))
    lowest_point = fields.Float(string='Lowest antenna point', digits=(16, 3))
    construction_id = fields.Many2one('site.construction', 'Construction')

    @api.onchange('height', 'width', 'depth', 'tower_height', 'azimuth')
    @api.depends('height', 'width', 'depth', 'weight', 'tower_height', 'epa_discount', 'rru_id')
    def compute_values(self):
        for data in self:
            # compute hw
            if data.height != 0 and data.width != 0:
                data.hw = data.height / data.width
            else:
                data.hw = 0.00

            # compute Drag coef.
            if data.hw <= 7:
                data.drag_coef = 1.40
            elif data.hw < 25 and data.hw > 7:
                print(data.hw)
                data.drag_coef = ((data.hw + 35) / 30)
            else:
                data.drag_coef = 2

            # compute epa
            data.epa = data.height * data.width * data.drag_coef

            # compute countable_epa
            if (1 - (data.epa_discount / 100)) != 0:
                data.countable_epa = (data.epa * (1 - (data.epa_discount / 100)))
            else:
                data.countable_epa = 0.00


class WorkOrderMicrowaveLines(models.Model):
    _name = 'work.order.microwave.lines'
    _description = 'Microwaves Lines'

    work_order_id = fields.Many2one('work.order', 'Work Order')
    micro_id = fields.Many2one('micro.dishes', 'Microwave Model', )
    diameter = fields.Float(string='Diameter', related='micro_id.diameter', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)', digits=(16, 3))
    azimuth = fields.Float(string='Azimuth (degree)', digits=(16, 3))
    tower_height = fields.Float(string='Height on the Tower', digits=(16, 3))
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values', digits=(16, 3))
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', digits=(16, 3))
    lowest_point = fields.Float(string='Lowest antenna point', digits=(16, 3))
    construction_id = fields.Many2one('site.construction', 'Construction')

    @api.onchange('micro_id', 'width', 'diameter')
    @api.depends('micro_id', 'diameter')
    def compute_values(self):
        for rec in self:  # avoiding singleton error [aks]
            # compute Drag coef.
            if rec.micro_id.shape == 'shroud':
                rec.drag_coef = 1.26
            elif rec.micro_id.shape == 'radome':
                rec.drag_coef = 0.86
            elif rec.micro_id.shape == 'grid':
                rec.drag_coef = 0.54
            else:
                rec.drag_coef = 1.55

            # compute countable_epa
            if rec.drag_coef != 0:
                rec.countable_epa = (rec.drag_coef * 3.14 * (rec.diameter * rec.diameter) / 4)
            else:
                rec.countable_epa = 0.00


class CabinetSpace(models.Model):
    _name = 'cabinet.space'
    _description = 'Cabinet Space'

    name = fields.Char(
        string='Cabinet Space',
        required=True)
    height = fields.Float(string='Height', digits=(16, 3))
    width = fields.Float(string='Width', digits=(16, 3))
    depth = fields.Float(string='Depth', digits=(16, 3))

    def name_get(self):
        res = []
        for record in self:
            name = "%s [Height = %s] [Width = %s] [Depth = %s]" % (
                record.name, record.height, record.width, record.depth)
            res.append((record.id, name))
        return res


class ExtraGroundSpace(models.Model):
    _name = 'ground.space'
    _description = 'Extra Ground Space'

    name = fields.Char(
        string='Ground Space',
        required=True)

    def name_get(self):
        res = []
        for record in self:
            name = "%s " % (record.name,)
            res.append((record.id, name))
        return res
