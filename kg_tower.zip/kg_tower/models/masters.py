import math
from datetime import date, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError




class MicrowaveDishes(models.Model):
    _name = 'micro.dishes'
    _description = 'Microwave Dishes'

    name = fields.Char(
        string='Name',
        required=True)
    shape = fields.Selection(string='Shape', required=False,
                             selection=[('shroud', 'Shroud'),
                                        ('radome', 'With Radome'),
                                        ('open', 'Open Parabole'),
                                        ('grid', 'Grid')])  # [aks]
    height = fields.Float(
        string='Height',
        required=False)
    width = fields.Float(
        string='Width',
        required=False)  # [aks]
    diameter = fields.Float(
        string='Diameter',
        required=True)
    azimuth = fields.Float(
        string='Azimuth',
        required=False)

    operator_id = fields.Many2one(
        comodel_name='res.partner',
        string='Operator',
        domain="[('operator','=',True)]")

    def name_get(self):
        res = []
        for record in self:
            name = "%s [Diameter = %s] [Shape = %s]" % (
                record.name, record.diameter, record.shape)
            res.append((record.id, name))
        return res


class RRUAntenna(models.Model):
    _name = 'rru.antenna'
    _description = 'RRU'
    _rec_name = 'complete_name'

    name = fields.Char(
        string='Name',
        required=True)
    complete_name = fields.Char('Complete Name', compute='_compute_complete_name', store=True)

    height = fields.Float(
        string='Height',
        required=True)
    width = fields.Float(
        string='Width',
        required=True)
    depth = fields.Float(
        string='Depth',
        required=True)
    weight = fields.Float(
        string='Weight(KG)',
        required=True)
    theight = fields.Float(
        string='Height on the Tower',
        required=True)

    operator_id = fields.Many2one(
        comodel_name='res.partner',
        string='Operator',
        domain="[('operator','=',True)]")

    @api.depends('name', 'height', 'width', 'depth')
    def _compute_complete_name(self):
        for each in self:
            each.complete_name = each.name + ' [Height =' + str(each.height) + ']   [Width =' + str(
                each.width) + ']  [Depth =' + str(each.depth) + ']'


class RegionalCoefficient(models.Model):
    _name = 'kg.regional.coefficient'
    _description = 'Regional Coefficient'

    name = fields.Char(
        string='Region',
        required=True)

    reg_coefficient = fields.Float('Coefficient', )


class Governorate(models.Model):
    _name = 'kg.governorate'
    _description = 'Governorate'

    name = fields.Char(
        string='Name',
        required=True)

    reg_coefficient = fields.Float('Regional Coefficient', )
    code = fields.Char(string='Code')
    site_sequence = fields.Many2one('ir.sequence', 'Site Sequence')
    active = fields.Boolean(string='Active', default=True)

    # Section Removed
    # <<<<Start----
    # parent_id = fields.Many2one(
    #     comodel_name='kg.governorate',
    #     string='Parent', )
    #
    # @api.constrains('parent_id')
    # def _check_parent_id(self):
    #     if not self._check_recursion():
    #         raise ValidationError(_('You cannot create recursive governorates.'))
    # ----End>>>>

    @api.model
    def create(self, vals):
        if vals.get('code'):
            sequence = self.env['ir.sequence'].create({
                'name': _('SiteID Sequence ') + ' ' + vals['code'],
                'padding': 3,
                'prefix': vals['code'],
            })
            vals['site_sequence'] = sequence.id
        return super(Governorate, self).create(vals)


    def write(self, vals):
        for rec in self:
            if rec.code:
                if not vals.get('site_sequence') and not rec.site_sequence:
                    code = vals.get('code') or rec.code or 'OTC'
                    sequence = self.env['ir.sequence'].create({
                        'name': _('SiteID Sequence') + vals['code'],
                        'padding': 3,
                        'prefix': vals['code'],
                    })
                    vals['site_sequence'] = sequence.id
        return super(Governorate, self).write(vals)



class ShelterSpace(models.Model):
    _name = 'shelter.space'
    _description = 'Shelter Space'

    name = fields.Char(
        string='Name',
        required=True)
    height = fields.Float(
        string='Height')
    width = fields.Float(
        string='Width')
    diameter = fields.Float(
        string='Diameter')
    extra_space = fields.Boolean('Extra space required', default=False)


class Wilayat(models.Model):
    _name = 'kg.wilayat'
    _description = 'Wilayat'
    # _rec_name = 'complete_name'

    name = fields.Char(
        string='Name',
        required=True)
    parent_id = fields.Many2one(
        comodel_name='kg.wilayat',
        string='Parent', )
    governorate_id = fields.Many2one('kg.governorate', 'Governorate')
    complete_name = fields.Char(
        'Complete Name', compute='_compute_complete_name',
        store=True)

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for wilayat in self:
            if wilayat.parent_id:
                wilayat.complete_name = '%s / %s' % (wilayat.parent_id.complete_name, wilayat.name)
            else:
                wilayat.complete_name = wilayat.name


class EquipmentHousing(models.Model):
    _name = 'equipment.housing'
    _description = 'Equipment Housing'

    name = fields.Char(
        string='Name',
        required=True)
    cabinet_type = fields.Many2one(
        'cabinet.type',
        string='Cabinet Type',
        required=True)
    cabinet_model = fields.Char(
        string='Cabinet Model',
        required=True)
    height = fields.Float(
        string='Height',
        required=False)
    width = fields.Float(
        string='Width',
        required=False)
    depth = fields.Float(
        string='Depth',
        required=False)
    is_shelter = fields.Boolean('shelter', default=False, help='For portal selection')
    is_outdoor_cabin = fields.Boolean('Outdoor Cabin', default=False, help='For portal selection')
    type = fields.Selection([('shelter', 'Shelter'),
                             ('cabinet', 'Cabinet')], string='Type', required=True)


class CabinetType(models.Model):
    _name = 'cabinet.type'
    _description = 'Cabinet Type'

    name = fields.Char(
        string='Cabinet Type',
        required=True)


class TowerHeight(models.Model):
    _name = 'tower.height'
    _description = 'Tower Height'

    name = fields.Char(
        string='Name',
        required=True)


class RadioTechnology(models.Model):
    _name = 'radio.technology'
    _description = 'Radio Technology'

    name = fields.Char(
        string='Name',
        required=True)


class EPAAllowance(models.Model):
    _name = 'epa.allowance'
    _description = 'EPA Allowance'

    name = fields.Char(
        string='Name',
        required=True)


class RentCalculation(models.Model):
    _name = 'rent.calculation'
    _description = 'Monthly Calculation'

    partner_id = fields.Many2one(
        'res.partner',
        string='Partner',
        required=True,
        tracking=True, domain=[('operator', '=', True)])
    tower_height_id = fields.Many2one(
        comodel_name='tower.height',
        string='Tower Height',
        required=True)
    epa_allowance = fields.Many2one(
        comodel_name='epa.allowance',
        string='EPA Allowance',
        required=True)
    rent_with_cable = fields.Float(
        string='Rent With Extra Cable',
        required=True)
    rent_without_cable = fields.Float(
        string='Rent Without Extra Cable',
        required=True)
    '''Add structure type field in rent calculation table.'''
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')

    @api.model
    def get_monthly_rent(self, epa_allowance, tower_height, with_cable, structure_type_id):
        if epa_allowance and tower_height and structure_type_id:
            print("epa_allowance", epa_allowance)
            print("tower_height", tower_height)
            epa_allowance_id = self.sudo().env['epa.allowance'].browse(int(epa_allowance))
            height_id = self.sudo().env['tower.height'].browse(int(tower_height))
            partner = self.env.user.partner_id.parent_id and self.env.user.partner_id.parent_id.id or self.env.user.partner_id.id
            structure_type_id = self.sudo().env['structure.type'].browse(int(structure_type_id))
            rent_id = self.sudo().search(
                [('partner_id', '=', partner), ('epa_allowance', '=', epa_allowance_id.id),
                 ('tower_height_id', '=', height_id.id), ('structure_type_id', '=', structure_type_id.id)], limit=1)
            if not rent_id or not epa_allowance_id or not height_id:
                return False
            return rent_id.rent_with_cable if with_cable else rent_id.rent_without_cable
        else:
            return False


class ShelterRentCalculation(models.Model):
    _name = 'shelter.rent'
    _description = 'Shelter Rent Calculation'

    shelter_space_id = fields.Many2one(
        comodel_name='shelter.space',
        string='Shelter Space',
        required=True)
    rent = fields.Float(
        string='Rent With Extra Cable',
        required=True)

    @api.model
    def get_shelter_rent(self, shelter_space):
        print('shelter_space', shelter_space)
        shelter_space = self.sudo().env['shelter.space'].browse(int(shelter_space) if shelter_space else '')
        rent_id = self.sudo().search(
            [('shelter_space_id', '=', shelter_space.id)],
            limit=1, order='create_date desc')
        if not rent_id or not shelter_space:
            return False
        return [rent_id.rent, shelter_space.extra_space]


class PowerLoadCategory(models.Model):
    _name = 'power.load.category'
    _description = 'Power Load Category'

    name = fields.Char(
        string='Category',
        required=True)
    avg_load = fields.Float(
        string='Avg Load (<=kW)',
    )
    peak_load = fields.Float(
        string='Peak Load (<=kW)')
    rent = fields.Float(
        string='Monthly rent (OMR)')

    operator_id = fields.Many2one(
        comodel_name='res.partner',
        string='Operator',
        domain="[('operator','=',True)]")

    def name_get(self):
        res = []
        for record in self:
            name = "%s (Average load <= %s & Peak load <= %s) [Rent = %s]" % (
                record.name, record.avg_load, record.peak_load, record.rent)
            res.append((record.id, name))
        return res


class RadioAntenna(models.Model):
    _name = 'radio.antenna'
    _description = 'Radio Antenna'
    _rec_name = 'complete_name'

    name = fields.Char(
        string='Antenna type'
    )
    complete_name = fields.Char('Complete Name', compute='_compute_complete_name', store=True)

    operator_id = fields.Many2one(
        comodel_name='res.partner',
        string='Operator',
        domain="[('operator','=',True)]")
    model = fields.Char(
        string='Model')
    height = fields.Float(string='Height', digits="OTC Decimal")
    width = fields.Float(string='Width', digits="OTC Decimal")
    depth = fields.Float(string='Depth', digits="OTC Decimal")
    degree = fields.Float(string='Degree', digits="OTC Decimal")

    @api.depends('name', 'model', 'height', 'width', 'depth')
    def _compute_complete_name(self):
        for each in self:
            each.complete_name = each.name + '  ' + each.model + ' [Height =' + str(each.height) + ']   [Width =' + str(
                each.width) + ']  [Depth =' + str(each.depth) + ']'

    # @api.model
    # def name_get(self):
    #     result = []
    #     for each in self:
    #         name = each.name + '   [Height =' + str(each.height) + ']   [Width =' + str(each.width) + ']  [Depth =' + str(each.depth) + ']'
    #         result.append((each.id, name))
    #     return result
