import datetime
import math
from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class PreventiveMaintenance(models.Model):
    _name = 'kg.preventive.maintenance'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Preventive Maintenance'

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    governorate = fields.Many2one(
        comodel_name='kg.governorate',
        string='Governorate', store=True,
        required=True, tracking=True)
    wilayat = fields.Many2one('kg.wilayat',
                              string='Wilayat',
                              required=True, tracking=True)
    structure_type_id = fields.Many2one('structure.type', 'Structure', store=True)
    latitude = fields.Char(
        string='Latitude',
        required=False, tracking=True)
    longitude = fields.Char(
        string='Longitude',
        required=False, tracking=True)
    prev_maintenance_type = fields.Selection(
        string='Preventive Maintenance Type',
        selection=[('full_prev_maint', 'Full Preventive Maintenance'),
                   ('light_prev_maint', 'Light Preventive Maintenance'),
                   ],
        required=True, tracking=True)
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('rejected', 'Rejected')], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')
    preventive_scheduler = fields.Selection(selection=[
        ('12 months', '12 Months'),
        ('18 months', '18 Months'),
        ('24 months', '24 Months')], string='Preventive Maintenance Scheduler')
    date_last_pm = fields.Date(string="Last Preventive Maintenance")
    date_next_pm = fields.Date(string="Next Preventive Maintenance")
    checklist_ids = fields.One2many('pm.checklist.line', 'pm_id', string="Check List Line")

    def action_generate_checklist(self):
        for rec in self:
            list_data = []
            check_list = self.env['pm.checklist'].search([('maintenance_type', '=', rec.prev_maintenance_type)])
            if rec.checklist_ids:
                rec.checklist_ids.unlink()
            for data in check_list:
                dict_data = {'description': data.description,
                             'category': data.category}
                list_data.append(dict_data)
                rec.update({'checklist_ids': [(0, 0, dict_data)]})



    def action_confirm(self):
        self.write(
            {
                "state": "confirm",
            }
        )
        preventive_maintenance_notification_activity = self.env.ref('kg_tower.preventive_maintenance_notification')
        activity_1 = self.activity_ids.filtered(
            lambda l: l.activity_type_id == preventive_maintenance_notification_activity)
        not_current_user_confirm = activity_1.filtered(lambda l: l.user_id != self.env.user)
        for data in not_current_user_confirm:
            data.unlink()
        activity_2 = self.activity_ids.filtered(
            lambda l: l.activity_type_id == preventive_maintenance_notification_activity)
        activity_2.action_done()

    def action_reject(self):
        self.write(
            {
                "state": "rejected",
            }
        )

    def action_reset(self):
        self.write(
            {
                "state": "draft",
            }
        )

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('kg.preventive.maintenance') or _('New')

        res = super(PreventiveMaintenance, self).create(vals)
        return res

    @api.onchange('client_site_id')
    def onchange_client_site_id(self):
        for rec in self:
            if rec.client_site_id:
                work_order = self.env['work.order'].search(
                    [('client_site_id', '=', rec.client_site_id.id)], limit=1)
                if work_order:
                    rec.latitude = work_order.latitude
                    rec.longitude = work_order.longitude
                    rec.structure_type_id = work_order.structure_type_id
                    rec.governorate = work_order.governorate
                    rec.wilayat = work_order.wilayat

    @api.onchange('date_last_pm', 'preventive_scheduler')
    def onchange_date_next_pm(self):
        if self.date_last_pm:
            if self.preventive_scheduler == '12 months':
                period = 12
                days = period * 30.417
                new_due_date = self.date_last_pm + datetime.timedelta(days=int(days))
                self.date_next_pm = new_due_date
                today = fields.Date.today()
                if self.date_next_pm <= today:
                    raise ValidationError(_('preventive maintenance is due'))
            elif self.preventive_scheduler == '18 months':
                period = 18
                days = period * 30.417
                new_due_date = self.date_last_pm + datetime.timedelta(days=int(days))
                self.date_next_pm = new_due_date
                today = fields.Date.today()
                if self.date_next_pm <= today:
                    raise ValidationError(_('preventive maintenance is due'))
            elif self.preventive_scheduler == '24 months':
                period = 24
                days = period * 30.417
                new_due_date = self.date_last_pm + datetime.timedelta(days=int(days))
                self.date_next_pm = new_due_date
                today = fields.Date.today()
                if self.date_next_pm <= today:
                    raise ValidationError(_('preventive maintenance is due'))
            else:
                self.date_next_pm = False

    def preventive_maintenance_notification(self):
        draft_records = self.search([('state', '=', 'draft')])
        for rec in draft_records:
            date_next_pm = rec.date_next_pm
            if rec.date_next_pm:
                days_15_before = date_next_pm + datetime.timedelta(days=-15)
                if days_15_before:
                    receiver = self.env.ref('kg_tower.group_preventive_maintenances')
                    for user in receiver.users:
                        body = _(
                            'This site is ' + rec.client_site_id.name + ' reaching to maintain on ' + str(
                                rec.date_next_pm) + ', Please check and confirm, Ref: ' + rec.name)
                        rec.activity_schedule('kg_tower.preventive_maintenance_notification', note=body,
                                              user_id=user.id)

    def print_preventive_maintenance_report(self):
        if self:
            return self.env.ref('kg_tower.action_preventive_maintenance_report').report_action(self)


class CheckListPreventiveMaintenance(models.Model):
    _name = 'pm.checklist'
    _rec_name = 'description'

    description = fields.Char(string="Description")
    maintenance_type = fields.Selection([('full_prev_maint', 'Full Preventive Maintenance'),
                                         ('light_prev_maint', 'Light Preventive Maintenance')],
                                        string='Maintenance Type')
    category = fields.Selection([('tower', 'Tower'), ('earthing', 'Earthing'),
                                 ('ground', 'Ground'), ('Foundation', 'Foundation'),
                                 ('hse', 'HSE'), ('boundary', 'Boundary'),
                                 ('power', 'Power'), ('access_road', 'Access Road'),
                                 ('rooftop', 'Rooftop'), ('others', 'Others')],
                                string='Category')
    status = fields.Selection([('cleared', 'Cleared'),
                               ('pending', 'Pending')],
                              string='Status')
    check = fields.Selection([('pass', 'Pass'),
                              ('Fail', 'Fail'), ('na', 'NA')],
                             string='Check')


class PmCheckListLine(models.Model):
    _name = 'pm.checklist.line'


    pm_id = fields.Many2one('kg.preventive.maintenance', string="PM Check List")
    description = fields.Char(string="Description", readonly=True)
    category = fields.Selection([('tower', 'Tower'), ('earthing', 'Earthing'),
                                 ('ground', 'Ground'), ('Foundation', 'Foundation'),
                                 ('hse', 'HSE'), ('boundary', 'Boundary'),
                                 ('power', 'Power'), ('access_road', 'Access Road'),
                                 ('rooftop', 'Rooftop'), ('others', 'Others')],
                                string='Category', readonly=True)
    remark = fields.Char(string="Remark")
    check = fields.Selection([('pass', 'Pass'),
                              ('Fail', 'Fail'), ('na', 'NA')],
                             string='Check')
    status = fields.Selection([('cleared', 'Cleared'),
                               ('pending', 'Pending')],
                              string='Status')
    attachment_fail = fields.Binary(string="Fail Attachment")
    attachment_clear = fields.Binary(string="Clear Attachment")
    client_site_id = fields.Many2one(string="OTC Site ID", related='pm_id.client_site_id')
    governorate = fields.Many2one(string='Governorate', related='pm_id.governorate')
    wilayat = fields.Many2one(string='Wilayat', related='pm_id.wilayat')
    structure_type_id = fields.Many2one(string='Structure', related='pm_id.structure_type_id')
    latitude = fields.Char(string='Latitude', related='pm_id.latitude')
    longitude = fields.Char(string='Longitude', related='pm_id.longitude')
    prev_maintenance_type = fields.Selection(string='Preventive Maintenance Type', related='pm_id.prev_maintenance_type')
    preventive_scheduler = fields.Selection(string='Preventive Maintenance Scheduler', related='pm_id.preventive_scheduler')
    date_last_pm = fields.Date(string="Last Preventive Maintenance", related='pm_id.date_last_pm')
    date_next_pm = fields.Date(string="Next Preventive Maintenance", related='pm_id.date_next_pm')






