from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ProductDevelopment(models.Model):

    _name = 'product.dev'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Product Developement'

    name = fields.Char('Reference',required=True,tracking=True)
    date = fields.Date('Date',required=True,default=fields.Date.today(),tracking=True)
    note = fields.Text('Description',tracking=True)
    state = fields.Selection([('draft','Draft'),('internal','Internal Presentation'),('final','Final Presentation')],default='draft',string="Status",required=True,tracking=True)

    def action_internal(self):
        self.state = 'internal'

    def action_final(self):
        self.state = 'final'

    def action_reset(self):
        self.state = 'draft'