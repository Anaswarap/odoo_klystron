from odoo import models, fields, api, _
from odoo.exceptions import UserError

class NDA(models.Model):
    _name = 'kg.nda'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Non-Declaration Aggrement'

    name = fields.Char('Description')
    partner_id = fields.Many2one('res.partner','Customer')
    date = fields.Date('Date')
    note = fields.Text('Note')
    lead_id = fields.Many2one('crm.lead', 'Associated Lead', required=True)
