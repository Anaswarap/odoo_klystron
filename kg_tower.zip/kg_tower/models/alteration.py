from odoo import models, api, fields, _


class AlterationForm(models.Model):
    _name = "alteration.form"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Alteration Form"
    _order = 'name desc'

    name = fields.Char('Reference', copy=False, readonly=True, default=lambda x: _('New'), required=True)

    partner_id = fields.Many2one('res.partner',
                                 string='Client',
                                 required=True,
                                 tracking=True)
    client_site_id = fields.Many2one('account.asset.site', string='Client Site ID', tracking=True)
    otc_site_id = fields.Many2one('account.asset.site', string='OTC Site ID', tracking=True)
    governorate_id = fields.Many2one('kg.governorate', string='Governorate')
    alteration_datetime = fields.Datetime(string='Date & Time')

    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    type_of_alteration = fields.Selection(selection=[
        ('equipment_addition', 'Equipment Addition'),
        ('equipment_relocation', 'Equipment Relocation'),
        ('equipment_removal', 'Equipment Removal'),
        ('others', 'Others'),
    ], string='Type ', required=True, copy=False, tracking=True,
        default='equipment_addition')
    description = fields.Text(string='Description')

    type_of_equipment_addition = fields.Selection(selection=[
        ('anteena_addition', 'Antenna Addition'),
        ('microwave_addition', 'Microwave Addition'),
        ('rru_addition', 'RRU Addition'),
        ('satellite_addition', 'Satellite Addition'),
        ('equipment_housing_addition', 'Equipment Housing Addition'),
        ('genset_addition', 'Genset Addition'),
    ], string='Equipment Addition Type', required=True, copy=False, tracking=True,
        default='anteena_addition')

    type_of_equipment_relocation = fields.Selection(selection=[
        ('anteena_relocation', 'Antenna Relocation'),
        ('microwave_relocation', 'Microwave Relocation'),
        ('rru_relocation', 'RRU relocation'),
    ], string='Equipment Relocation Type', required=True, copy=False, tracking=True,
        default='anteena_relocation')

    type_of_equipment_removal = fields.Selection(selection=[
        ('anteena_removal', 'Antenna Removal'),
        ('microwave_removal', 'Microwave Removal'),
        ('rru_removal', 'RRU Removal'),
        ('satellite_removal', 'Satellite Removal'),
        ('equipment_housing_removal', 'Equipment Housing Removal'),
        ('genset_removal', 'Genset Removal'),
    ], string='Equipment Removal Type', required=True, copy=False, tracking=True,
        default='anteena_removal')

    agreed_site_date = fields.Date(string="Agreed Site Readiness Date")
    agreed_site_employee = fields.Many2one('hr.employee',string="Full Name")
    agreed_site_employee_position = fields.Many2one('hr.job',string="Position of the Authorized Person")
    agreed_site_employee_email = fields.Char(string="Email")
    agreed_site_employee_signature = fields.Binary(string="Signature")

