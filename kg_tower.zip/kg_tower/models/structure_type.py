from odoo import models, fields, api, _


class StructureType(models.Model):
    _name = 'structure.type'
    _description = 'Structure Type'

    name = fields.Char('Description',required=True)
    validity = fields.Integer('Validity in Years',required=True)
    sequence = fields.Integer('Seqence',default=20,required=True)
    checklist_line_ids = fields.One2many('doc.checklist','structure_type_id','Check List')
    sub_folder_ids = fields.One2many('sub.folder', 'relation_id', string="Sub Folder Lines")
    is_main_structure = fields.Boolean(string="Main structure")
    is_restrict_site = fields.Boolean(string="Restrict Site ID")


class DocChecklist(models.Model):
    _name = 'doc.checklist'
    _description = 'Checklist'

    name = fields.Char(string='Name')
    description = fields.Char(string='Description')
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')


class SubFolder(models.Model):
    _name = 'sub.folder'
    _description = 'Sub Folder'

    relation_id = fields.Many2one('structure.type', 'Sub Folder Lines')
    seq = fields.Char(string="Sequence")
    folder_name = fields.Char(string="Folder Name")
