from datetime import date

from odoo import api, models, fields, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
from datetime import date, datetime


class ProjectExpenseLines(models.Model):
    _name = 'project.expense.lines'
    _description = 'Project Expense Lines'

    name = fields.Char('Description', required=True)
    expense_type = fields.Many2one('expense.type', 'Expense Type')
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    fees = fields.Float('Monthly Fees', copy=False, digits="OTC Decimal")
    project_id = fields.Many2one('project.project', 'Project')
    task_id = fields.Many2one('project.task', 'Task')
    tower_invoice_id = fields.Many2one('tower.invoice', 'Tower Invoice')
    invoice_id = fields.Many2one('account.move', string="Bill")

    @api.onchange('type')
    def _onchange_type(self):
        if self.type:
            self.expense_type = False

    def action_create_expense(self):
        """Action raise a vendor bill for expenses in project"""
        print("Bill for expense")
        invoice = self.env['account.move']
        for rec in self:
            if rec:
                if rec.invoice_id:
                    raise ValidationError("Sorry this expense already invoiced")

                label = 'Expense: ' + rec.name + ' project: ' + rec.project_id.name
                mole_line = (0, 0, {
                    'name': label,
                    'quantity': 1,
                    'price_unit': rec.fees,
                    'analytic_account_id': rec.project_id and rec.project_id.analytic_account_id and rec.project_id.analytic_account_id.id or False,
                })
                invoice_values = {
                    'partner_id': rec.project_id.partner_id.id,
                    'invoice_date': rec.start_date if rec.start_date else date.today(),
                    'move_type': 'in_invoice',
                    'invoice_line_ids': mole_line,
                }

                create_invoice = invoice.create(invoice_values)
                create_invoice.action_post()
                create_invoice.project_id = rec.project_id.id
                rec.invoice_id = create_invoice.id
                # expense_line = (0, 0, {
                #     'id': create_invoice
                # })
                # rec.project_id.addt_exp_value += create_invoice.amount_total


class ExpenseType(models.Model):
    _name = 'expense.type'
    _description = 'Expense Type'

    name = fields.Char('Expense Type', required=True)

    bill_type = fields.Selection([('B', 'B'), ('C', 'C')], string='Bill Type', required=True, help="""Part B covers additional services that may be provided at the sites: Shelter Rental, various types of power supply, etc.
Part C covers one-off (non-recurring) invoicing amounts that may occur, for example Search Ring Fees, contributions to grid connection cost in excess of RO 6,000, etc.""", )


'''
OWNER RENT & LEASE AGREEMENT
'''


class ProjectOwnerRentExpense(models.Model):
    _name = 'project.owner.rent.expense'
    _description = 'Project Owner Rent Expense'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'documents.mixin','kg.approval.transaction']


    # **** MINI ******
    # REMOVED REQUIRED ATTR OF THE TWO FIELD FOR DATA IMPORT
    name = fields.Char('Name', default=lambda x: _('New'), required=1)
    desc = fields.Text('Description',)
    # removed related property for data import
    site_acq_id = fields.Many2one('site.acquisition', 'Site Acquisition')
    # site_id = fields.Many2one('account.asset.site', 'OTC Site', related='project_id.site_id')
    project_id = fields.Many2one('project.project', 'Project')
    site_id = fields.Many2one('account.asset.site', 'OTC Site')
    # additional fields as per excel
    lease_type = fields.Selection(string='Lease Type',
                                  selection=[('ROA', 'ROA'), ('lease_agreement', 'Lease Agreement')], required=False)
    gov_type = fields.Selection(string='Owner Type',
                                selection=[('Govt', 'Govt'), ('private', 'Private')], required=False)
    saq_status = fields.Selection(string='SAQ Status',
                                  selection=[('Handover', 'Handover')], required=False)
    # Remove "every 5 year" and "5"
    payment_frequency = fields.Selection(string='Payment Frequency',
                                         selection=[('advance', 'Advance'), ('post', 'Post Paid'),
                                                    ('every_5_years', 'Every 5 years'), ('5', '5'),
                                                    ('subscription', 'Subscription')],
                                         default='advance', required=False)
    advance_years = fields.Integer(string="Years", default=5)
    payment_date = fields.Date('Payment Date', default=fields.Date.today())
    start_date = fields.Date('Rent Start Date', default=fields.Date.today())
    end_date = fields.Date('Rent End Date')
    lease_start_date = fields.Date('Lease Start Date', tracking=True)
    lease_end_date = fields.Date('Lease End Date', tracking=True)
    card_account_id = fields.Many2one('account.account', string="Card Account")
    recover = fields.Selection(
        string='Recover From',
        selection=[('owner', 'Owner'),
                   ('operator', 'Operator'), ], default='owner')

    plot_size = fields.Float()
    roa_auth_date = fields.Date(string='Autherised Date')
    next_paymnt_start_date = fields.Date(string='Next Payment Start Date')
    ref_no = fields.Char(string='Reference Number')
    currency_id = fields.Many2one('res.currency')
    governorate_id = fields.Many2one('kg.governorate', related='site_acq_id.governorate', readonly=False)
    wilayat = fields.Many2one('kg.wilayat', related='site_acq_id.wilayat_id', readonly=False)

    lease_partner_id = fields.Many2one('res.partner', 'Lease Partner', )
    partner_id = fields.Many2one('res.partner', 'Owner')
    amount = fields.Float('Monthly Amount', digits="OTC Decimal")
    penalty = fields.Float('Penalty', digits="OTC Decimal")
    other_charges = fields.Float('Registration Fee', digits="OTC Decimal")
    state = fields.Selection(string='State',
                             selection=[('draft', 'Draft'), ('confirm', 'Confirmed'), ('invoiced', 'Invoiced'), ],
                             default='draft', required=False, )
    site_acq_id = fields.Many2one(comodel_name='site.acquisition', string='Site Acquisition', required=False)
    site_type = fields.Char(string="Site Type", related='site_acq_id.site_type')
    subscription_tmpl_id = fields.Many2one('sale.subscription.template', string="Subscription Template")
    journal_id = fields.Many2one('account.journal', string="Journal")
    product_id = fields.Many2one('product.product', string="Expense Type",
                                 domain="[('can_be_expensed','=',True)]")
    subscription_id = fields.Many2one('sale.subscription', string="Subscription", copy=False)
    subscription_product_id = fields.Many2one('product.product', string="Subscription Type",
                                              domain="[('recurring_invoice','=',True)]", )
    service_invoice_created = fields.Boolean(string='Service Invoice Created', default=False, Copy=False)
    advance_invoice_created = fields.Boolean(string='Advance Invoice Created', default=False, Copy=False)
    payment_id = fields.Many2one('account.payment', string='Linked Payment')
    invoicing_period = fields.Integer(string="Invoicing Period", readonly=True, store=True)
    rule_type = fields.Char(readonly=True, store=True)
    # **Field For Data Import**
    paid_by = fields.Char(string="Paid By")
    vat_required = fields.Char(string="Vat Required")
    roa_validity = fields.Char(string="Validity")
    # lease_status = fields.Char(string="Lease Status")
    client_work_order_no = fields.Char(string="Client Work Order No", related='site_acq_id.client_work_order_no',
                                       readonly=True)
    client_site = fields.Char(string="Client Site ID:", related='site_acq_id.client_site', readonly=True)
    to_generate_subscription = fields.Boolean(string="To Generate Subscription", deafault=False)

    '''
          ----------------------Approval Module Changes----------------------
          Approval Section field override to mentioned corresponding model.
          '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='project.owner.rent.expense')

    def send_back(self):
        res = super(ProjectOwnerRentExpense, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res

    def approve_tran_do_approve(self):
        res = super(ProjectOwnerRentExpense, self).approve_tran_do_approve()
        if not self.next_approval :
            self.state='confirm'
        return res

    @api.constrains('lease_type', 'gov_type')
    def _check_work_order_id(self):
        for rec in self:
            if rec.lease_type and rec.gov_type:
                if rec.lease_type == 'ROA' and rec.gov_type == 'private':
                    raise ValidationError("Lease Type 'ROA' cannot have  private Owner.\n "
                                          "Change Owner type to Government!")

                if rec.lease_type == 'lease_agreement' and rec.gov_type == 'Govt':
                    raise ValidationError("Lease Type 'Lease Agreement' cannot have  Government Owner.\n "
                                          "Change Owner type to Private!")

    @api.model
    def create(self, values):
        if values.get('name', _('New')) == _('New'):
            values['name'] = self.env['ir.sequence'].next_by_code('project.owner.rent.expense') or _('New')
        return super(ProjectOwnerRentExpense, self).create(values)

    def write(self, vals):
        for rec in self:
            if 'start_date' in vals:
                start_date = datetime.strptime(vals['start_date'], "%Y-%m-%d").strftime('%d/%m/%Y')
                rec.message_post(body = "Start Date : %s"% start_date)
            if 'end_date' in vals:
                end_date = datetime.strptime(vals['end_date'], "%Y-%m-%d").strftime('%d/%m/%Y')
                rec.message_post(body = "End Date : %s"% end_date)
        return super(ProjectOwnerRentExpense, self).write(vals)

    @api.onchange('project_id')
    def _onchange_project(self):
        if self.project_id:
            if self.project_id.site_id:
                self.site_id = self.project_id.site_id.id
            saq = self.env['site.acquisition'].search([('project_id', '=', self.project_id.id)], limit=1)
            self.site_acq_id = saq and saq.id

    @api.onchange('advance_years', 'start_date')
    def _onchange_advance_years(self):
        if self.start_date:
            if self.payment_frequency == 'subscription':
                self.end_date = self.start_date + relativedelta(years=1) - relativedelta(days=1)
                self.next_paymnt_start_date = self.start_date + relativedelta(years=1)
            elif self.payment_frequency == 'advance' and self.advance_years > 0:
                self.end_date = self.start_date + relativedelta(years=self.advance_years) - relativedelta(days=1)
                self.next_paymnt_start_date = self.start_date + relativedelta(years=self.advance_years)

    def action_confirm(self):
        self.state = 'confirm'

    # def create_invoice_charge(self):
    #     # temporally fetching journal to avoid invoice creation error
    #     journal_id = self.journal_id
    #     if self.service_invoice_created:
    #         raise UserError("This Lease Agreement already have a service invoice Created.")
    #     invoice = self.env['account.move'].sudo().create({
    #         'ref': self.name,
    #         'move_type': 'out_invoice',
    #         'invoice_origin': self.name,
    #         'partner_id': self.partner_id.id,
    #         'journal_id': journal_id.id,
    #         'owner_rent_expense_id': self.id,
    #     }).with_user(self.env.uid)
    #     item_list = []
    #
    #     item_list.append((0, 0, {
    #         'name': 'Govt. Service Charge',
    #         'price_unit': self.other_charges,
    #         'quantity': 1,
    #         # 'account_id': account_id.id,
    #     }))
    #
    #     invoice.update({'invoice_line_ids': item_list})
    #     action = self.env["ir.actions.actions"]._for_xml_id("account.action_move_out_invoice_type")
    #     if len(invoice) == 1:
    #         form_view = [(self.env.ref('account.view_move_form').id, 'form')]
    #         if 'views' in action:
    #             action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
    #         else:
    #             action['views'] = form_view
    #         action['res_id'] = invoice.id
    #     context = {
    #         'default_move_type': 'out_invoice',
    #     }
    #     if len(self) == 1:
    #         context.update({
    #             'default_partner_id': self.partner_id.id,
    #             'default_invoice_origin': self.name,
    #             'default_user_id': self.env.uid,
    #         })
    #     action['context'] = context
    #     self.service_invoice_created = True
    #     if self.payment_frequency == 'subscription' and self.subscription_id:
    #         self.state = 'invoiced'
    #     if self.payment_frequency == 'advance' and self.advance_invoice_created:
    #         self.state = 'invoiced'
    #     return action

    def create_invoice(self):
        if self.lease_type == 'ROA':
            raise UserError('ROA Invoice creation is temporarily unavailable!')
        if self.advance_invoice_created:
            raise UserError("Record already have a service invoice Created.")
        expense_product_obj = self.product_id

        if len(expense_product_obj) == 0:
            raise ValidationError('Please add an expense product in the settings!')

        invoice = self.env['account.move'].sudo().create({
            'ref': self.name,
            'move_type': 'in_invoice',
            'invoice_origin': self.name,
            'partner_id': self.lease_partner_id.id,
            'owner_rent_expense_id': self.id,
            'invoice_date': self.payment_date,
        }).with_user(self.env.uid)
        item_list = []
        if expense_product_obj:
            item_list.append((0, 0, {
                'name': expense_product_obj.product_tmpl_id.name,
                'price_unit': self.other_charges,
                'quantity': 1,
                'product_id': expense_product_obj.id,
                'product_uom_id': expense_product_obj.uom_id.id,
            }))

        invoice.update({'invoice_line_ids': item_list})
        # creating payment for registration then, this payment will match after posting bill
        invoice.action_post()
        partner_payment = self.env['account.payment'].create({
            'payment_type': 'outbound',
            'partner_type': 'supplier',
            'partner_id': self.lease_partner_id.id,
            'amount': self.other_charges,
            'journal_id': self.journal_id.id,
            'lease_bill_id': invoice.id
        })
        partner_payment.action_post()
        self.payment_id = partner_payment.id
        # <<<<<<<<<<end>>>>>>>>>>>>>
        action = self.env["ir.actions.actions"]._for_xml_id("account.action_move_in_invoice_type")
        if len(invoice) == 1:
            form_view = [(self.env.ref('account.view_move_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = invoice.id
        context = {
            'default_move_type': 'in_invoice',
        }
        if len(self) == 1:
            context.update({
                'default_partner_id': self.partner_id.id,
                'default_invoice_origin': self.name,
                'default_user_id': self.env.uid,
            })
        action['context'] = context
        self.advance_invoice_created = True
        if self.service_invoice_created == True:
            self.state = 'invoiced'
        return action

    def action_view_invoice(self):
        action = self.env.ref('account.action_move_in_invoice_type').read()[0]
        action['domain'] = [('owner_rent_expense_id', '=', self.id), ('move_type', '=', 'in_invoice')]
        return action

    def action_view_service_invoice(self):
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]
        action['domain'] = [('owner_rent_expense_id', '=', self.id), ('move_type', '=', 'out_invoice')]
        return action

    def action_create_subscription(self):
        template_id = self.subscription_tmpl_id
        inv_start_date = False
        amount = False
        if self.subscription_id:
            print("self.subscription_id-----------",self.subscription_id)
            raise ValidationError("Subscription already created.")
        if self.payment_frequency == 'post':
            if template_id.recurring_rule_type == 'monthly':
                amount = template_id.recurring_interval * self.amount
                inv_start_date = self.start_date + relativedelta(months=template_id.recurring_interval)
            if template_id.recurring_rule_type == 'yearly':
                amount = (template_id.recurring_interval * 12) * self.amount
                inv_start_date = self.start_date + relativedelta(years=template_id.recurring_interval)
        if self.payment_frequency == 'advance':
            inv_start_date = self.start_date
            if template_id.recurring_rule_type == 'monthly':
                amount = template_id.recurring_interval * self.amount
            if template_id.recurring_rule_type == 'yearly':
                amount = (template_id.recurring_interval * 12) * self.amount

        subscription_obj = self.env['sale.subscription']
        subscription_line = []
        unit_price = self.amount + self.penalty + self.other_charges
        subscription_dict = (0, 0, {
            'product_id': self.subscription_product_id.id,
            'name': self.desc,
            'quantity': 1,
            'uom_id': self.product_id.uom_id.id,
            'price_unit': amount
        })
        print("subscription_dict------",subscription_dict)
        subscription_line.append(subscription_dict)
        if self.subscription_tmpl_id and not self.subscription_tmpl_id.journal_id.id:
            raise ValidationError('Please specify journal in subscription template !')
        create_subscription = subscription_obj.create({
            'partner_id': self.partner_id.id,
            'pricelist_id': self.partner_id.property_product_pricelist.id,
            'template_id': self.subscription_tmpl_id.id,
            'journal_id': self.subscription_tmpl_id.journal_id.id,
            'site_id': self.site_id.id,
            'recurring_next_date': inv_start_date,
            'date_start': self.start_date,
            'recurring_invoice_line_ids': subscription_line,
        })
        print("create_subscription-----------",create_subscription)
        self.subscription_id = create_subscription.id
        print("self.subscription_id-------", self.subscription_id.name)
        if self.service_invoice_created == True:
            self.state = 'invoiced'

    def action_view_subscription(self):

        view_subscription = {
            'res_model': 'sale.subscription',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.subscription_id.id,
        }
        return view_subscription

    @api.onchange('subscription_tmpl_id')
    def onchange_subscription_tmpl_id(self):
        self.invoicing_period = self.subscription_tmpl_id.recurring_interval
        self.rule_type = self.subscription_tmpl_id.recurring_rule_type


'''
OWNER RENT & LEASE AGREEMENT END
'''


class SubscriptionTemplateInherit(models.Model):
    _inherit = 'sale.subscription.template'

    journal_id = fields.Many2one(
        'account.journal', string="Accounting Journal",
        domain="[('type', '=', 'purchase')]", company_dependent=True, check_company=True,
        help="If set, subscriptions with this template will invoice in this journal; "
             "otherwise the sales journal with the lowest sequence is used.")
