from odoo import models, fields, api


class ProductBrand(models.Model):
    _inherit = 'product.template'

    @api.depends('default_code', 'categ_id')
    def update_item_serial_no(self):
        if self.default_code and self.categ_id.code_prefix:
            self.item_serial_no = self.categ_id.code_prefix + self.default_code
        else:
            self.item_serial_no =''


    brand_id = fields.Many2one('product.brand', string='Brand')
    model_no = fields.Char(
        string='Model No',
        required=False)
    item_serial_no = fields.Char(
        string='Item Serial No', compute='update_item_serial_no')

    equipment_cost = fields.Float('Equipment Cost',tracking=True)
    service_cost = fields.Float('Service Cost',tracking=True)

    is_tower = fields.Boolean('Is Tower',default=False)

    tower_height = fields.Float('Tower Height(m)')

    epa_capacity = fields.Float('EPA Capacity(m2)')

    basic_wind_speed = fields.Float('Basic Wind Speed(km/h)')

    expos_cat = fields.Selection([('C','C'),('D','D'),('B','B')],'Expos CAT',default='C')

    tower_legs = fields.Integer('Tower Legs',default=3)

    three_m_exten = fields.Boolean('3m Extension', default=False, tracking=True)

    epa_load_applied = fields.Char('EPA Load Applied at')

    is_penalty = fields.Boolean('Penalty',default=False)


class BrandProduct(models.Model):
    _name = 'product.brand'

    name = fields.Char(String="Name")
    brand_image = fields.Binary()
    member_ids = fields.One2many('product.template', 'brand_id')
    product_count = fields.Char(String='Product Count', compute='get_count_products', store=True)

    @api.depends('member_ids')
    def get_count_products(self):
        self.product_count = len(self.member_ids)


class BrandReportStock(models.Model):
    _inherit = 'stock.quant'

    brand_id = fields.Many2one(related='product_id.brand_id',
                               string='Brand', store=True, readonly=True)


class ProductCategory(models.Model):
    _inherit = 'product.category'

    code_prefix = fields.Char()
