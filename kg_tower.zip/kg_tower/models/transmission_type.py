from odoo import models, fields, api, _


class transmissionType(models.Model):
    _name = 'transmission.type'
    _description = 'Transmission Type'

    name = fields.Char('Description',required=True)
