# -*- coding: utf-8 -*-

from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError

FIELDS_TO_TRACK = ['create_partner_id', 'partner_id', 'latitude', 'longitude', 'search_radius', 'notes',
                   'tower_height_id', 'epa_id']


class RingRequest(models.Model):
    _name = 'ring.request'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin', 'kg.approval.transaction']
    _description = 'Search Ring Request'

    @api.model
    def _company_get(self):
        company_id = self.env['res.company']._company_default_get(self._name)
        return self.env['res.company'].browse(company_id.id)

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    priority = fields.Selection(
        string='Priority',
        selection=[('0', 'Low'),
                   ('1', 'Normal'), ('2', 'High')],
        required=False, tracking=True)
    create_partner_id = fields.Many2one('res.partner',
                                        string='Created By',
                                        required=True, domain=[('operator', '=', True)])
    partner_id = fields.Many2one('res.partner',
                                 string='Partner',
                                 required=True, domain=[('operator', '=', True)])
    company_id = fields.Many2one('res.company',
                                 required=True,
                                 default=_company_get)
    date = fields.Date(
        string='Submission Date',
        required=False, tracking=True)
    client_work_order_no = fields.Char(
        string='Client Work Order No',
        required=False, tracking=True)
    latitude = fields.Char(
        string='Latitude',
        required=False, tracking=True)
    longitude = fields.Char(
        string='Longitude',
        required=False, tracking=True)
    notes = fields.Text(
        string="Technical Constraints",
        required=False, tracking=True)
    expected_completion_days = fields.Char(
        string='Expected Completion Days',
        required=False, tracking=True)
    attachment = fields.Binary(
        string="Attachments",
        copy=False, tracking=True)
    attachment_sign = fields.Binary(
        string="Signature",
        copy=False, tracking=True)
    search_radius = fields.Float(
        string='Search Radius or Polygon (M)',
        required=False, tracking=True)
    micro_wave = fields.Float(
        string='Microwave Antenna Height',
        required=False, tracking=True)
    radio_wave = fields.Float(
        string='Radio Antenna Height',
        required=False, tracking=True)
    state = fields.Selection(selection=[
        ('new', 'New'),
        ('review', 'Operator Submitted the Request'),
        # ('resubmit', 'Commercial Team Verified'),
        # ('approved', 'Approved by Commercial Manager'),
        # ('saq_assigned', 'Assign to Site Acquisition'),
        # ('approved_saq', 'Approved by SAQ'),
        # ('approved_opr', 'Approved by Operations'),
        ('completed', 'Completed / Commercial Confirmed'),
        ('sent_to_client', 'Sent to Client'),
        ('rejected', 'Rejected'),
        ('dropped', 'Dropped'),
    ], string='Status', readonly=False, copy=False, tracking=True,
        default='new')
    edit_state = fields.Selection(selection=[
        ('request', 'Requested to Modify'),
        ('edit', 'Open to Modify'),
        ('close', 'Closed Modification'),
    ], string='Modification Status', readonly=True, copy=False, tracking=True)

    task_status = fields.Char('Task Status', compute='comp_task_status')
    task_count = fields.Integer('Task Count', compute='comp_task_count')

    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, )
    project_id = fields.Many2one('project.project', 'Project', tracking=True, readonly=True)

    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'), ])

    proposed_completion_date = fields.Date('Proposed Completion Date')

    upload = fields.Boolean(
        string='Upload',
        required=False)
    saq_user = fields.Many2one('res.users', string='SAQ User', tracking=True,domain=lambda self: [('groups_id', 'in', self.env.ref('kg_tower.group_saq_user').id)])
    saq_coordinate_status = fields.Selection(
        string='Saq_coordinate_status',
        selection=[('assigned', 'Assigned'),
                   ('submitted', 'Submitted'), ('back', 'Send Back'),
                   ('resubmit', 'Resubmitted'), ('completed', 'Completed')],
        required=False, tracking=True)


    ### new fields ###
    report_date = fields.Date(string='Report Submission Date', required=False, tracking=True)
    other_requirement = fields.Text(string="Other Client requirement", required=False, tracking=True)
    ges_a = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_b = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_c = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_d = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_e = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_f = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)
    ges_g = fields.Binary(string="Google Earth Snapshot", copy=False, tracking=True)

    photo_a = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_b = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_c = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_d = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_e = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_f = fields.Binary(string="Photo", copy=False, tracking=True)
    photo_g = fields.Binary(string="Photo", copy=False, tracking=True)

    panoramic_a = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_b = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_c = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_d = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_e = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_f = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)
    panoramic_g = fields.Binary(string="Panoramic Photo", copy=False, tracking=True)

    governorate = fields.Many2one('kg.governorate', 'Governorate', tracking=True)

    dist_nom_point = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_b = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_c = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_d = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_e = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_f = fields.Float('Distance to Nominal Point(m)', tracking=True)
    dist_nom_point_g = fields.Float('Distance to Nominal Point(m)', tracking=True)

    nominal_point_coordinates = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_b = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_c = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_d = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_e = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_f = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)
    nominal_point_coordinates_g = fields.Char('Nominal Point Coordinates(WGS 1984, decimal)', tracking=True)

    existing_site = fields.Boolean(string='Existing Site', default=False, tracking=True)
    existing_site_owner = fields.Many2one('res.partner', 'Existing Site Owner', domain=[('operator', '=', True)],
                                          tracking=True)
    existing_site_height = fields.Float('Existing Site Height', tracking=True)

    structure_type_id = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_b = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_c = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_d = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_e = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_f = fields.Many2one('structure.type', 'Structure Type', tracking=True)
    structure_type_id_g = fields.Many2one('structure.type', 'Structure Type', tracking=True)

    grid_type = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_b = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_c = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_d = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_e = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_f = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)
    grid_type_g = fields.Selection([('grid', 'Grid'), ('off_grid', 'Off Grid')], 'Grid Type', tracking=True)

    site_access_desc = fields.Text('Site Access Description', tracking=True)
    site_access_desc_b = fields.Text('Site Access Description', tracking=True)
    site_access_desc_c = fields.Text('Site Access Description', tracking=True)
    site_access_desc_d = fields.Text('Site Access Description', tracking=True)
    site_access_desc_e = fields.Text('Site Access Description', tracking=True)
    site_access_desc_f = fields.Text('Site Access Description', tracking=True)
    site_access_desc_g = fields.Text('Site Access Description', tracking=True)

    nearest_grid_tap_cord = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_b = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_c = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_d = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_e = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_f = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)
    nearest_grid_tap_cord_g = fields.Char('Nearest Grid Tapping Point Coordinates', tracking=True)

    dist_to_grid_tap_cord = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_b = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_c = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_d = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_e = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_f = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)
    dist_to_grid_tap_cord_g = fields.Char('Distance to Nearest Grid Tapping Point', tracking=True)

    issue = fields.Text('Any other comment or issue', tracking=True)
    issue_b = fields.Text('Any other comment or issue', tracking=True)
    issue_c = fields.Text('Any other comment or issue', tracking=True)
    issue_d = fields.Text('Any other comment or issue', tracking=True)
    issue_e = fields.Text('Any other comment or issue', tracking=True)
    issue_f = fields.Text('Any other comment or issue', tracking=True)
    issue_g = fields.Text('Any other comment or issue', tracking=True)

    candidate_d = fields.Boolean('Enable Candidate D', default=False, tracking=True)
    candidate_e = fields.Boolean('Enable Candidate E', default=False, tracking=True)
    candidate_f = fields.Boolean('Enable Candidate F', default=False, tracking=True)
    candidate_g = fields.Boolean('Enable Candidate G', default=False, tracking=True)

    comments = fields.Text('Comments', tracking=True)
    invoice_count = fields.Integer('Invoice Count', compute='comp_invoice_count')
    notify_fine = fields.Boolean(
        string='Fine Reminder Sent',
        required=False, default=False)
    notify_nswo = fields.Boolean(
        string='Fine Created',
        required=False, default=False)
    date_completed = fields.Date(
        string='Completion Date',
        required=False, tracking=True)
    after_sixty_days = fields.Date(
        string='Generate fine on',
        required=False, tracking=True)
    after_fifty_days = fields.Date(
        string='Send NSWO Create Warning on',
        required=False, tracking=True)

    tower_height_id = fields.Many2one('tower.height', string="Tower Height")
    epa_id = fields.Many2one('epa.allowance', string="EPA Allowance")
    tower_height = fields.Float(string="Tower Height")
    model = fields.Char('Related Document Model', index=True, readonly=True, default='ring.request')

    # def resubmit_srr(self):
    #     template_id = self.env.ref('kg_tower.srr_confirmation_mail')
    #     template_id.send_mail(self.id, force_send=True)
    #     self.notify_users('kg_tower.group_comm_dept_mgr', note='Commercial team verification.')
    #
    #     self.state = 'resubmit'

    # def approve_srr(self):
    #     self.state = 'approved'

    # def assign_to_saq(self):
    #     self.notify_users('kg_tower.group_saq_coor')

        # self.state = 'saq_assigned'
    def kg_final_approval(self):
        """" Supering method which is defined in the kg approval to approve ring request and
        """
        res = super(RingRequest, self).kg_final_approval()
        self.complete()
        return res

    def approve_tran_do_reject(self):
        res = super(RingRequest, self).approve_tran_do_reject()
        self.reject_srr()
        return res

    def send_back(self):
        res = super(RingRequest, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res

    def approve_saq(self):
        if self.saq_coordinate_status == 'assigned':
            raise UserError("Kindly ask SAQ user to update coordinates before approval.")
        self.notify_users('kg_tower.group_oper_rollout')
        self.state = 'approved_saq'
        self.saq_coordinate_status = 'completed'

    def send_back_saq(self):
        action = self.env["ir.actions.actions"]._for_xml_id("kg_tower.srr_sendback_act_window")
        action['context'] = {'default_srr_id': self.id}
        return action

    def approve_opr(self):
        self.notify_users('kg_tower.group_comm_dept_mgr')
        self.state = 'approved_opr'

    def complete(self):
        self.activity_unlink(['kg_tower.srr_created'])
        self.state = 'completed'

    def action_sent_to_client(self):
        self.state = 'sent_to_client'

    def print_srr_report(self):
        return self.env.ref('kg_tower.action_search_ring_report').report_action(self)

    def reject_srr(self):
        self.state = 'rejected'
        self.project_id.active = False

    def drop_srr(self):
        self.state = 'dropped'
        self.project_id.active = False

    def notify_users(self, allowed_group, note=False):
        self.activity_unlink(['kg_tower.srr_created'])
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.srr_created', note=note or user.name, user_id=user.id)
        return True

    def action_allocate_candidate_location(self):
        activity = self.env['mail.activity'].search(
            [('res_id', '=', self.id), ('user_id', '=', self.env.user.id), ('res_model', '=', 'ring.request')])
        activity.action_feedback(feedback='Update Done')
        note = "Kindly update candidate locations."
        if self.saq_user:
            self.activity_schedule('kg_tower.srr_update_candidate', note=note or self.saq_user.name,
                                   user_id=self.saq_user.id)
        else:
            raise UserError('Link SAQ user first')
        if self.saq_coordinate_status in ('submitted', 'resubmit'):
            self.saq_coordinate_status = 'back'
        else:
            self.saq_coordinate_status = 'assigned'
        return True

    def action_complete(self):
        activity = self.env['mail.activity'].search(
            [('res_id', '=', self.id), ('user_id', '=', self.env.user.id), ('res_model', '=', 'ring.request')])
        activity.action_feedback(feedback='Completed')
        note = "Completed."
        allowed_group_obj = self.env.ref("kg_tower.group_saq_coor")
        self.saq_coordinate_status = 'completed'
        for user in allowed_group_obj.users:
            self.activity_schedule('kg_tower.srr_update_candidate', note=note or user.name, user_id=user.id)

    def action_review_candidate_location(self):
        activity = self.env['mail.activity'].search(
            [('res_id', '=', self.id), ('user_id', '=', self.env.user.id), ('res_model', '=', 'ring.request')])
        activity.action_feedback(feedback='Review completed')
        note = "Kindly review the candidate locations."
        allowed_group_obj = self.env.ref("kg_tower.group_saq_coor")
        for user in allowed_group_obj.users:
            self.activity_schedule('kg_tower.srr_update_candidate', note=note or user.name, user_id=user.id)
        if self.saq_coordinate_status == 'back':
            self.saq_coordinate_status = 'resubmit'
        else:
            self.saq_coordinate_status = 'submitted'
        return True

    def comp_task_count(self):
        for record in self:
            record.task_count = self.env['project.task'].search_count(
                [('ring_request_id', '=', record.id)])

    def show_tasks(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Tasks',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.task',
                'domain': [('ring_request_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>

                                <th scope="col">Status</th>

                            </tr>
                        </thead>
                        <tbody>

                """
            count = 1
            for task in self.env['project.task'].search([('ring_request_id', '=', rec.id)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info

    def send_mail(self):
        allowed_group_obj = self.env.ref('kg_tower.group_srr')
        email_list = allowed_group_obj.users.mapped('partner_id.email')
        email_list = [e for e in email_list if e]
        email_list = ",".join(email_list)
        email_values = {'email_cc': email_list}
        template_id = self.env.ref('kg_tower.srr_confirmation_mail')
        print(template_id, 'template_id')
        template_id.send_mail(self.id, email_values=email_values, force_send=True)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if vals.get('partner_id'):
                partner_obj = self.env['res.partner'].browse([vals.get('partner_id')])
                if partner_obj.operator_sequence:
                    vals['name'] = partner_obj.operator_sequence.next_by_id()
                    # Moved to NSWO
                    # client_site_id = self.env['account.asset.site'].create({'name':vals['name']})
                    # vals['client_site_id'] = client_site_id.id
                elif partner_obj.parent_id and partner_obj.parent_id.operator_sequence:
                    vals['name'] = partner_obj.parent_id.operator_sequence.next_by_id()
                    # Moved to NSWO
                    # client_site_id = self.env['account.asset.site'].create({'name':vals['name']})
                    # vals['client_site_id'] = client_site_id.id
                else:
                    raise UserError(_('Please Add Partner With Sequence'))
            else:
                raise UserError(_('Please Add Partner'))

            # vals['name'] = self.env['ir.sequence'].next_by_code('ring.request') or _('New')
        res = super(RingRequest, self).create(vals)
        res.send_mail()
        res.notify_users('kg_tower.group_srr', note='SRR Verification.')

        res.action_review()
        return res

    def action_review(self):
        # if not self.client_site_id:
        #     raise UserError(_('Please Mention Site'))
        self.notify_users('kg_tower.group_comm_dept')

        project = self.env['project.project']
        task = self.env['project.task']
        task_lists = self.env['task.list'].search([('is_common', '=', True)], limit=1)
        if task_lists:
            users = self.env['res.users'].search([('partner_id', '=', self.partner_id.id)], limit=1)
            allowed_portal_user_ids = False
            if users:
                allowed_portal_user_ids = [[6, 0, [users.id]]]
            # if not users:
            #     raise UserError(_('Please Mention Portal User for Client'))

            for rec in task_lists:
                vals = {
                    # 'site_id': self.client_site_id.id,
                    'partner_id': self.partner_id.id,
                    'name': rec.name,
                    'display_name': rec.name + '[' + self.name + ']',
                    'srr_id': self.id,
                    'structure_type_id': self.structure_type_id.id,
                    'allowed_portal_user_ids': allowed_portal_user_ids,
                }
                create_project = project.create(vals)
                create_project.display_name = rec.name + '[' + self.name + ']'
                self.project_id = create_project.id
                prev_task = False
                for lines in rec.list_lines.sorted('sequence'):
                    if lines.progress == 'srr_received':
                        if not prev_task:
                            current_date = fields.Date.today()
                            additional_days = lines.completion_days + 2
                            deadline = current_date + timedelta(days=additional_days)
                        else:
                            current_date = prev_task.date_deadline
                            additional_days = lines.completion_days + 2
                            deadline = current_date + timedelta(days=additional_days)

                        vals = {
                            'project_id': create_project.id,
                            'name': lines.kg_task_id,
                            'department_id': lines.department_id.id,
                            'work_flow': lines.work_flow,
                            'progress_level': lines.progress,
                            'weight': lines.weight,
                            'completion_task': lines.completion_task,
                            'gf_construction': lines.gf_construction,
                            'collacation': lines.collacation,
                            'roof_top': lines.roof_top,
                            'sequence': lines.sequence,
                            'partner_id': self.partner_id.id,
                            'ring_request_id': self.id,
                            'user_id': lines.user_id.id or False,
                            'allowed_user_ids': allowed_portal_user_ids,
                            'override_sequence': lines.override_sequence,
                            'milestone_task': lines.milestone_task,
                            'date_deadline': deadline,
                            'proposed_date_deadline': deadline,
                            'attach_mandatory': lines.attach_mandatory

                        }
                        prev_task = task.create(vals)
            task_schedule = self.env['project.task'].search([('project_id', '=', create_project.id)], limit=1,
                                                            order="sequence asc")
            print('TaskList', task_schedule)
            if task_schedule:
                task_schedule.activity_schedule('mail.mail_activity_data_todo', note=task_schedule.user_id.name,
                                                user_id=task_schedule.user_id.id)

                # activity = self.env['mail.activity'].sudo().create({
                #     'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                #     'res_id': task_schedule.id,
                #     'user_id': task_schedule.user_id.id,
                #     # 'date_deadline':deadline,
                #     'res_model_id': self.env.ref('project.model_project_task').id,
                # })
                # print(":activity", activity)
                # activity._onchange_activity_type_id()
        else:
            raise UserError(_('Please set Task Lists First'))
        self.state = 'review'

    def create_invoices(self):
        for rec in self:
            vals_inv = {}
            vals_inv['invoice_date'] = fields.Date.today()
            vals_inv['move_type'] = 'out_invoice'
            vals_inv['srr_id'] = rec.id
            vals_inv['partner_id'] = rec.partner_id.id
            srr_charge = float(self.env['ir.config_parameter'].sudo().get_param('kg_tower.srr_charge')) or 100
            srr_product_id = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.srr_product_id'))
            print('srr_product_id', srr_product_id)

            inv_lines = []

            a = (0, 0, {
                'quantity': 1,
                'price_unit': srr_charge,
                'name': 'Survey Charge' + rec.name,
                'product_id': srr_product_id or False,
            })

            inv_lines.append(a)
            vals_inv['invoice_line_ids'] = inv_lines
            print(vals_inv)
            self.env['account.move'].create(vals_inv)

    def comp_invoice_count(self):
        for record in self:
            record.invoice_count = self.env['account.move'].search_count(
                [('srr_id', '=', record.id)])

    def show_invoices(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('srr_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def request_modification(self):
        for rec in self:
            rec.message_post(body='Request for Modify', message_type='notification',
                             subtype_xmlid='mail.mt_comment',
                             )
            rec.edit_state = 'request'
            allowed_group_obj = self.env.ref("kg_tower.group_saq_coor")
            email_list = allowed_group_obj.users.mapped('partner_id.email')
            email_list = [e for e in email_list if e]
            email_list = ",".join(email_list)
            email_values = {'email_cc': email_list}
            template_id = self.env.ref('kg_tower.srr_modification_mail')
            template_id.send_mail(self.id, email_values=email_values, force_send=True)

    @api.model
    def request_modification_from_front_end(self, rec_id):
        if rec_id:
            self.browse(int(rec_id)).sudo().request_modification()

    def open_modification(self):
        for rec in self:
            body =""
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            body += "Dear "+rec.partner_id.name+",<br/><br/>Modification Request Approved.<br/>You can access the SSR using the below link<br/><a style='color: #FFFFFF; text-decoration: none !important; font-weight: 400; background-color: #875A7B; border: 0px solid #875A7B; border-radius:3px' class='btn btn-sm btn-link' href="+str(base_url)+"/my/ring_request/"+str(self.id)+"><i class=fa fa-fw o_button_icon fa-download></i>View Search Ring Request</a>"
            rec.message_post(body=body, message_type='notification',
                             subtype_xmlid='mail.mt_comment', partner_ids=[rec.partner_id.id]
                             )
            rec.edit_state = 'edit'

    def close_modification(self):
        for rec in self:
            rec.edit_state = 'close'

    def write(self, vals):
        template_id = self.env.ref('kg_portal.notify_srr_edited')
        update_client = False
        for F in FIELDS_TO_TRACK:
            update_client = F in vals
        if update_client:
            template_id.send_mail(self.id, force_send=True)
        for rec in self:
            if 'edit_state' not in vals:
                if rec.edit_state == 'edit':
                    vals['edit_state'] = 'close'
            return super().write(vals)

    # @api.onchange('saq_user')
    # def onchange_user(self):
    #     users = self.env['res.users'].search([]).filtered(lambda x: x.has_group('kg_tower.group_saq_user'))
    #     if users:
    #         return {'domain': {'saq_user': [('id', 'in', users.ids)]}}
