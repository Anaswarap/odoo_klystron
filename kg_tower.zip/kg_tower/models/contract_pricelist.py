from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ContractPricelist(models.Model):
    _name = 'contract.pricelist'
    _description = 'Contract Pricelist'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        'Reference',
        copy=False,

    )
    contract_title = fields.Char('Contract Title')
    tender_id = fields.Many2one('kg.purchase.tender', 'Tender', tracking=True, )
    contract_start_date = fields.Date('Contract Start Date', tracking=True, )
    contract_end_date = fields.Date('Contract End Date', tracking=True, )
    service_as_separate_order = fields.Boolean('Service As Seperate Order')
    partner_id = fields.Many2one('res.partner', 'Contractor', tracking=True, )

    pricelist_line_ids = fields.One2many('contract.pricelist.line', 'contract_pricelist_id', copy=True,
                                         string='Pricelist Lines')
    contractor_line_ids = fields.One2many('contract.pricelist.contractor.sequence', 'contract_pricelist_id', copy=True,
                                          string='Contractor Seq Lines')
    contractor_line_so_ids = fields.One2many('contract.pricelist.contractor.sequence.so', 'contract_pricelist_id',
                                             copy=True,
                                             string='Contractor SO Seq Lines')
    contractor_rc_ids = fields.One2many('contract.pricelist.regional.coefficient', 'contract_pricelist_id',
                                        copy=True,
                                        string='Regional Coeffient Lines')
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done'), ('cancel', 'Cancelled')], string='Status',
                             default='draft', tracking=True, )
    purchase_id = fields.Many2one(
        comodel_name='purchase.order',
        string='Purchase',
        required=False)

    category = fields.Selection([('tower_installation', 'Tower & installation'), ('other_cw', 'OTHER CW'),
                                 ('grid_connection', 'Grid Connection'),
                                 ('access_road', 'Access Road'),
                                 ('development', 'Development(for additional tenants)')], string='Category',
                                default='tower_installation', tracking=True, )
    analytic_id = fields.Many2one('account.analytic.account', string="Analytic Account")

    def action_done(self):
        self.state = 'done'

    def action_cancel(self):
        self.state = 'cancel'


class ContractPrielistLine(models.Model):
    _name = 'contract.pricelist.line'

    @api.constrains('name', 'contract_pricelist_id')
    def check_name(self):
        for x in self:
            if x.name:
                rec = self.env['contract.pricelist.line'].search(
                    [('name', '=', x.name), ('id', '!=', x.id),
                     ('contract_pricelist_id', '=', x.contract_pricelist_id.id)])
                if rec:
                    raise UserError(_('Exists ! Item Code must be unique !'))

    # _sql_constraints = [('product_contract_unique', 'unique(product_id,contract_pricelist_id)', 'Select Different Products.')]

    name = fields.Char('Description')
    product_id = fields.Many2one('product.product', 'Product')
    product_tmpl_id = fields.Many2one('product.template', related="product_id.product_tmpl_id", readonly=True)
    equipment_cost = fields.Float('Equipment Cost', digits="OTC Decimal")
    service_cost = fields.Float('Service Cost', digits="OTC Decimal")
    service_cost_separate = fields.Float('Service Cost (as separate order)', digits="OTC Decimal")
    unit_price = fields.Float('Unit Price', digits="OTC Decimal")
    product_uom_id = fields.Many2one(
        'uom.uom', 'Unit of Measure',
    )
    contract_pricelist_id = fields.Many2one('contract.pricelist', 'Price List', ondelete='cascade', index=True)
    category = fields.Selection([('tower_installation', 'Tower & installation'), ('other_cw', 'OTHER CW'),
                                 ('grid_connection', 'Grid Connection'),
                                 ('access_road', 'Access Road'),
                                 ('development', 'Development(for additional tenants)')], string='Category',
                                default='tower_installation', tracking=True, )

    @api.onchange('product_id')
    def onchange_product_id(self):
        for rec in self:
            rec.product_uom_id = rec.product_id.uom_id.id


class ContractPrielistContractorSequence(models.Model):
    _name = 'contract.pricelist.contractor.sequence'

    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Contractor',
        required=False, domain=[('contractor', '=', True)])
    con_seq_code = fields.Char('Code')
    sequence_id = fields.Many2one('ir.sequence', 'Contractor Sequence')
    contract_pricelist_id = fields.Many2one('contract.pricelist', 'Price List', ondelete='cascade', index=True)

    @api.model
    def create(self, vals):
        if vals.get('con_seq_code'):
            sequence = self.env['ir.sequence'].create({
                'name': _('Sequence') + ' ' + vals['con_seq_code'],
                'padding': 3,
                'prefix': vals['con_seq_code'],

            })
            vals['sequence_id'] = sequence.id
        return super(ContractPrielistContractorSequence, self).create(vals)


class ContractPrielistContractorStockOrderSequence(models.Model):
    _name = 'contract.pricelist.contractor.sequence.so'

    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Contractor',
        required=False, domain=[('contractor', '=', True)])
    con_seq_code = fields.Char('Code')
    sequence_id = fields.Many2one('ir.sequence', 'Contractor Sequence')
    contract_pricelist_id = fields.Many2one('contract.pricelist', 'Price List', ondelete='cascade', index=True)

    @api.model
    def create(self, vals):
        if vals.get('con_seq_code'):
            sequence = self.env['ir.sequence'].create({
                'name': _('Sequence') + ' ' + vals['con_seq_code'],
                'padding': 3,

            })
            vals['sequence_id'] = sequence.id
            print("oiuoiuo", vals)
        return super(ContractPrielistContractorStockOrderSequence, self).create(vals)


    def write(self, values):
        if values.get('con_seq_code'):
            sequence = self.env['ir.sequence'].create({
                'name': _('Sequence') + ' ' + values['con_seq_code'],
                'padding': 3,

            })
            values['sequence_id'] = sequence.id
        return super(ContractPrielistContractorStockOrderSequence, self).write(values)


class PricelistRegionalCoefficient(models.Model):
    _name = 'contract.pricelist.regional.coefficient'
    _description = 'Pricelist Regional Coefficient'

    name = fields.Char(
        string='Region',
        required=True)

    reg_coefficient = fields.Float('Coefficient', )
    contract_pricelist_id = fields.Many2one('contract.pricelist', 'Price List', ondelete='cascade', index=True)
