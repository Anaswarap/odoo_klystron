# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


class EventGift(models.Model):
    _name = 'event.gift'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Event Gift'

    name = fields.Char('Description', required=True, tracking=True)
    date = fields.Date('Date', required=True)
    event_id = fields.Many2one('event.event', 'Event')
    employee_id = fields.Many2one('hr.employee', 'Employee', tracking=True,
                                  default=lambda self: self.env.user.employee_id.id, )
    manager_id = fields.Many2one('hr.employee', 'Line Manger')

    gift_lines = fields.One2many('event.gift.line', 'gift_id', 'Lines')
    amount_total = fields.Float('Amount Total',compute='comp_amount_total')
    inv_count  = fields.Integer('# Invoices',compute='comp_inv_count')


    state = fields.Selection(
        [('draft', 'Draft'), ('approval_line', 'Approved by Manager'), ('approve_comm', 'Approved by Comm Dept'),
         ('approve_ceo', 'Approved'), ('reject', 'Rejected')], default='draft', string='Status')



    def comp_inv_count(self):
        for record in self:
            record.inv_count = self.env['account.move'].search_count(
                [('event_gift_id', '=', record.id)])


    def show_invoices(self):

        for rec in self:

            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('event_gift_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def create_invoices(self):
        for rec in self:

            vals_inv = {}
            vals_inv['invoice_date']  = rec.date
            vals_inv['move_type'] = 'out_invoice'
            vals_inv['event_gift_id'] = rec.id

            inv_lines = []

            for item in rec.gift_lines:
                a = (0, 0, {
                    'quantity': item.qty,
                    'price_unit': item.unit_price,
                    'name': item.name,
                    'product_id':item.product_id and item.product_id.id or False,
                    'analytic_account_id': item.analytic_account_id and item.analytic_account_id.id or False,
                })

                inv_lines.append(a)
            vals_inv['invoice_line_ids'] = inv_lines
            self.env['account.move'].create(vals_inv)


    @api.depends('gift_lines.price_total')
    def comp_amount_total(self):
        for rec in self:
            total = 0
            for line in rec.gift_lines:
                total += line.price_total
            rec.amount_total = total


    def send_notification_to_group(self, group_xml_id):
        for rec in self:
            rec.activity_unlink(['kg_tower.gift_stages'])
            group = self.env.ref(group_xml_id)
            for user in group.users:
                rec.activity_schedule('kg_tower.gift_stages', note=rec.name, user_id=user.id)

    def line_mgr_approve(self):
        if self.env.user.id  != (self.manager_id and self.manager_id.user_id and self.manager_id.user_id.id or False):
            raise UserError(_('Only Line Manager Can Approve'))

        self.state = 'approval_line'
        self.send_notification_to_group('kg_tower.group_comm_dept')

    def comm_dept_approve(self):
        self.state = 'approve_comm'
        # self.send_notification_to_group('kg_tower.group_comm_dept')
        
    def ceo_approve(self):
        self.state = 'approve_ceo'
        self.create_invoices()

    def reject_gift(self):
        self.state = 'reject'

    @api.model
    def create(self, vals):
        # if vals.get('name', _('New')) == _('New'):
        #     vals['name'] = self.env['ir.sequence'].next_by_code('tower.invoice') or _('New')
        res = super(EventGift, self).create(vals)
        if res.manager_id and res.manager_id.user_id:
            res.activity_schedule('kg_tower.gift_stages', note=res.name, user_id=res.manager_id.user_id.id)
        return res

    @api.onchange('employee_id')
    def onchange_emp_id(self):
        for rec in self:
            if rec.employee_id and rec.employee_id.parent_id:
                rec.manager_id = rec.employee_id.parent_id.id


class EventGiftLine(models.Model):
    _name = 'event.gift.line'
    _description = 'Event Gift Line'

    name = fields.Char('Description', required=True)
    product_id = fields.Many2one('product.product', 'Product')
    analytic_account_id = fields.Many2one('account.analytic.account', string="Analytic Account", copy=False,
                                          ondelete='set null',
                                          help="Analytic account to which this project is linked for financial management. "
                                               "Use an analytic account to record cost and revenue on your project.")
    gift_id = fields.Many2one('event.gift', 'Gift')
    unit_price = fields.Float('Unit Price')
    qty = fields.Float('Quantity')
    price_total = fields.Float('Total', compute='comp_price_total', store=True)

    @api.depends('unit_price', 'qty')
    def comp_price_total(self):
        for rec in self:
            price_total = 0
            price_total = rec.unit_price * rec.qty
            rec.price_total = price_total
