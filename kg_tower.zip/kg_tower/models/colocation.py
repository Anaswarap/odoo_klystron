from odoo import models, api, fields, _


class CoLocation(models.Model):
    _name = "co.location"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Co-location form"
    _order = 'name desc'

    name = fields.Char('Reference', copy=False, readonly=True, default=lambda x: _('New'), required=True)
    tower_owner_id = fields.Many2one('res.partner', tracking=True, domain=[('operator', '=', True)])
    tower_owner_site_id = fields.Many2one('account.asset.site', 'Tower Owner Site ID', tracking=True)
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    # Site Location
    governorate_id = fields.Many2one('kg.governorate', 'Governorate')
    wilayat_id = fields.Many2one('kg.wilayat', string='Wilayat')
    latitude = fields.Char(string='Latitude', required=False, tracking=True)
    longitude = fields.Char(string='Longitude', required=False, tracking=True)

    # Equipment Summary Sheet
    equipment_housing_id = fields.Many2one('equipment.housing', string='Type of Equipment Housing')
    is_genset_required = fields.Boolean('Genset Deployment Required', default=False)
    genset_type = fields.Selection([('with_fuel', 'Generator with Fuel tank'),
                                    ('without_fuel', 'Generator without Fuel tank')])

    # Tower Details
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    tower_height_id = fields.Many2one('tower.height', string='Structure Height (m)')

    # Date
    scd_date = fields.Date('Site Commencement Date')
    requested_date = fields.Date('Requested Date')

    # one2many fields
    antenna_lines = fields.One2many('co.location.antenna.lines', 'co_location_id')
    rru_lines = fields.One2many('co.location.rru.lines', 'co_location_id')
    micro_lines = fields.One2many('co.location.microwave.lines', 'co_location_id')

    tower_type = fields.Selection(selection=[
        ('lattice_tower', 'Lattice Tower'),
        ('normal_monopole', 'Normal Monopole'),
        ('camouflage_monopole', 'Camouflage Monopole'),
        ('gi_pole', 'GI - Pole'),
    ], string='Tower Type', required=True, copy=False, tracking=True,
        default='lattice_tower')
    no_of_anteena = fields.Integer(string='Number of Antenna')
    anteena_type_id = fields.Many2one('anteena.type', 'Antenna Type')
    transmission_type_id = fields.Many2one('transmission.type', 'Transmission Type')
    no_of_rru = fields.Char(string="Number of RRU's per sector")

    is_vsat_required = fields.Boolean('V-SAT Required', default=False)
    vsat_width = fields.Float(string='V-SAT Width')
    vsat_depth = fields.Float(string='V-SAT Depth')

    is_microwave_required = fields.Boolean('Microwave Required', default=False)
    microwave_height = fields.Float(string='Microwave Height')
    microwave_diameter = fields.Float(string='Microwave Diameter')
    microwave_azimuth = fields.Float(string='Microwave Azimuth')
    microwave_azimuth = fields.Float(string='Microwave Azimuth')

    otc_authorized_person_id = fields.Many2one('hr.employee', 'OTC Authorized Person')
    otc_authorized_person_position_id = fields.Many2one('hr.job', string='Position',related='otc_authorized_person_id.job_id')
    otc_authorized_person_email = fields.Char(string='Email',related='otc_authorized_person_id.work_email')
    otc_authorized_person_signature = fields.Binary(string='Signature',related='otc_authorized_person_id.user_id.sign_signature')

    is_client_person_required = fields.Boolean('Client Authorized Person Required', default=False)
    client_person_person_id = fields.Many2one('hr.employee', 'Client Authorized Person')
    client_person_date = fields.Date(string='Date')
    client_person_signature = fields.Binary(string='Signature',related='client_person_person_id.user_id.sign_signature')

    # fields added for excel import
    # ***sha***
    ref_datetme = fields.Char(string='Ref')
    site_phase = fields.Char(string='Site Phase')
    vf_site_id = fields.Char(string='VF Site ID')
    oo_site_id = fields.Char(string='OO Site ID')
    date_nswo_applctn = fields.Char(string='Date of NSWO Application')
    layout_reqst_date_oo = fields.Char(string='Layout Request Date to OO')
    return_date_oo = fields.Char(string='Return Date From OO')
    layout_send_obc = fields.Char(string='Layout Sent to OBC')
    layout_return_frm_obc = fields.Char(string='Layout Return From OBC')
    submission_date_oo = fields.Char(string='Submission Date to OO')
    response_date_oo = fields.Char(string='Response Date from OO')
    avergae = fields.Char(string='Avergae')
    acceptance_date_oo = fields.Char(string='Acceptance Date From OO')
    return_vf = fields.Char(string='Return to VF')
    response_frm_vf = fields.Char(string='Resonse From VF')
    nswo_acceptnce = fields.Char(string='NSWO Acceptance Date')
    details = fields.Char(string='DETAILS')
    current_progress = fields.Char(string='Current Progress')
    rfi_date_frm_oo = fields.Char(string='RFI Date From OO')
    rfi_date_to_vf = fields.Char(string='RFI Date to VF')
    submission_request = fields.Char(string='Submission Request')
    approval_date_oo = fields.Char(string='Approval Date From OO')
    handover_projct = fields.Char(string='Handover To Project')
    radio_antenna_ids = fields.Many2many('radio.technology', string="Radio Antenna", tracking=True)

    sites_status = fields.Selection([('Approved', 'Approved'), ('RFI', 'RFI'), ('Dropped', 'Dropped'),
                                     ('Pending with OTC', 'Pending with OTC'), ('Rejected by OO', 'Rejected by OO'),
                                     ('Pending with OO', 'Pending with OO')], string="Sites Status")

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('co.location') or _('New')
        return super(CoLocation, self).create(vals)


class CoLocationAntennaLines(models.Model):
    _name = 'co.location.antenna.lines'
    _description = 'Radio Antenna Lines'

    co_location_id = fields.Many2one('co.location', 'CoLocation Id')
    antenna_id = fields.Many2one('radio.antenna', 'Antenna Model')
    sector = fields.Selection([('3', '3'), ('4', '4')], 'Sector')
    height = fields.Float(string='Height', related='antenna_id.height', digits=(12, 3))
    width = fields.Float(string='Width', related='antenna_id.width', digits=(12, 3))
    depth = fields.Float(string='Depth', related='antenna_id.depth', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)')
    tower_height = fields.Float(string='Height on the Tower')
    azimuth = fields.Float(string='Azimuth (degree)')
    hw = fields.Float(string='H/W', compute='compute_values')
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values')
    epa = fields.Float(string='EPA(no shielding)', compute='compute_values')
    hd = fields.Float(string='H/D', compute='compute_values', digits=(12, 1))
    side_drag_coef = fields.Float(string='Side drag coef.', compute='compute_values')
    epa_t = fields.Float(string='EPA (T) (side face)', compute='compute_values', digits=(12, 3))
    epa_antenna2 = fields.Float(string='EPA(A) antenna 2', compute='compute_values', digits=(12, 3))
    epa_antenna3 = fields.Float(string='EPA(A) antenna 3', compute='compute_values', digits=(12, 3))
    shielding_factor = fields.Float(string='shielding factor', compute='compute_values', digits=(12, 3))
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', related='height')
    lowest_point = fields.Float(string='Lowest antenna point', )


class CoLocationRRULines(models.Model):
    _name = 'co.location.rru.lines'
    _description = 'RRU Lines'

    co_location_id = fields.Many2one('co.location', 'CoLocation Id')
    rru_id = fields.Many2one('rru.antenna', 'RRU Model')
    rru_position = fields.Selection(
        string='RRU Position',
        selection=[('behind_antenna', 'RRU Behind Antenna'),
                   ('separate_pole', 'RRU on separate pole'), ],
        required=False, )  # [aks]
    height = fields.Float(string='Height', related='rru_id.height', digits=(12, 3))
    width = fields.Float(string='Width', related='rru_id.width', digits=(12, 3))
    depth = fields.Float(string='Depth', related='rru_id.depth', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)')
    tower_height = fields.Float(string='Height on the Tower')
    epa_discount = fields.Float(string='EPA discount(%)')
    hw = fields.Float(string='H/W', compute='compute_values')
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values')
    epa = fields.Float(string='EPA(no shielding)', compute='compute_values')
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', )
    lowest_point = fields.Float(string='Lowest antenna point', )


class CoLocationMicrowaveLines(models.Model):
    _name = 'co.location.microwave.lines'
    _description = 'Microwaves Lines'

    co_location_id = fields.Many2one('co.location', 'CoLocation Id')
    micro_id = fields.Many2one('micro.dishes', 'Microwave Model', )
    diameter = fields.Float(string='Diameter', related='micro_id.diameter', digits=(12, 3))
    weight = fields.Float(string='Weight (kg)')
    azimuth = fields.Float(string='Azimuth (degree)')
    tower_height = fields.Float(string='Height on the Tower')
    drag_coef = fields.Float(string='Drag coef.', compute='compute_values')
    countable_epa = fields.Float(string='Countable EPA', compute='compute_values', digits=(12, 3))
    highest_point = fields.Float(string='Highest antenna point', )
    lowest_point = fields.Float(string='Lowest antenna point', )



class Anteena_Type(models.Model):
    _name = 'anteena.type'
    _description = 'Anteena Type'

    name = fields.Char(string='Name')
