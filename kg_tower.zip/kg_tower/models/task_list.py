from odoo import fields, models


class TaskList(models.Model):
    _name = 'task.list'
    _description = 'Task List'

    name = fields.Char()
    partner_id = fields.Many2one('res.partner',
                                 string='Partner',
                                 domain=[('operator', '=', True)])
    # structure_type = fields.Selection(
    #       string='Structure Type',
    #       selection=[('greenfield', 'Greenfield'),
    #                  ('rooftop', 'Rooftop'),
    #                  ('collocation', 'Collocation'), ])
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    is_common = fields.Boolean('Common', default=False)

    list_lines = fields.One2many(
        comodel_name='task.list.lines',
        inverse_name='task_list',
        string='List Lines', copy=True,
        required=False, domain=[('existing_site_task', '=', False)])

    existing_list_lines = fields.One2many(
        comodel_name='task.list.lines',
        inverse_name='task_list',
        string='Existing List Lines', copy=True,
        required=False, domain=[('existing_site_task', '=', True)])


class TaskListLines(models.Model):
    _name = 'task.list.lines'
    _description = 'Task List Lines'
    _order = 'sequence ASC'

    sequence = fields.Char("Sequence")
    existing_site_task = fields.Boolean('Existing Site Task', default=False)
    task_list = fields.Many2one(
        comodel_name='task.list',
        string='Task List',
        required=True)
    kg_task_id = fields.Char(
        string='Task',
        required=True)
    department_id = fields.Many2one(
        comodel_name='hr.department',
        string='Department',
        required=True)
    user_id = fields.Many2one(
        comodel_name='res.users',
        string='User',
        required=True)
    work_flow = fields.Selection(
        string='Work Flow',
        selection=[('initial', 'Initial'),
                   ('site', 'Site Aquisition'),
                   ('tower', 'Tower Supply'),
                   ('construction', 'Construction'),
                   ('grid', 'Grid Connection'),
                   ('final', 'Final')
                   ],
        required=True, )
    progress = fields.Selection(
        string='Progress',
        selection=[('srr_received', 'SRR Received'),
                   ('nswo_received', 'NSWO Received'),
                   ('site', 'Site Aquisition'),
                   ('construction', 'Construction'),
                   ('rfi', 'RFI Notice Issued'), ],
        required=True, )
    weight = fields.Float(
        string='Weight',
        required=True)
    completion_task = fields.Float(
        string='Triggered by Completion of Task',
        required=False)
    gf_construction = fields.Float(
        string='GF Construction',
        required=False)
    collacation = fields.Float(
        string='Collacation',
        required=False)
    roof_top = fields.Float(
        string='Roof Top',
        required=False)

    completion_days = fields.Integer('Completion days', default=2)

    override_sequence = fields.Boolean('Override', default=False,
                                       help='Override task sequence to allow parellel completion')
    milestone_task = fields.Boolean('Milestone', default=False, help='Allow invoice after completion of this task')
    attach_mandatory = fields.Boolean('Attachment mandatory', default=False, )
    task_list_cat_id = fields.Many2one('task.list.category', string="Task Category")
