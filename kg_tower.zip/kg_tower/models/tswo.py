from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import ast
from datetime import date


class TSWO(models.Model):
    _name = 'kg.tswo'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'kg.approval.transaction']
    _description = 'Turn Key Site Work Order'

    @api.model
    def _company_get(self):
        company_id = self.env['res.company']._company_default_get(self._name)
        return self.env['res.company'].browse(company_id.id)

    """field added for excel importing..........***sumayya***********"""
    name = fields.Char(
        'Work Order No',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
    )
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    description = fields.Char('Description')
    project_id = fields.Many2one('project.project', 'Project', tracking=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id)
    date = fields.Date('Date', default=fields.Date.today())
    partner_id = fields.Many2one('res.partner', 'Partner', tracking=True, domain=[('contractor', '=', True)])
    # work_order_no = fields.Char('Work Order No')
    work_order_date = fields.Date('Work Order Date', default=fields.Date.today)
    work_comm_date = fields.Date('Work Commencement Date')
    governorate = fields.Many2one('kg.governorate', 'Governorate')
    regional_coefficient = fields.Many2one('kg.regional.coefficient', 'Regional Coefficient')
    regional_coefficient_id = fields.Many2one('contract.pricelist.regional.coefficient', 'Regional Coefficient',
                                              domain="[('contract_pricelist_id','=',contract_no)]", required=1)
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    amount_subtotal = fields.Monetary('Subtotal', compute='comp_total', store=True)
    grid_extension = fields.Monetary('Grid Extension')
    amount_total = fields.Monetary('Total', compute='comp_total', store=True)
    notes = fields.Text('Notes')
    special_instr = fields.Text('Special Instructions')
    tswo_line_ids = fields.One2many('kg.tswo.line', 'tswo_id', copy=True, string='TSWO Lines')
    state = fields.Selection([('draft', 'Draft'), ('approval_one', 'Approved by Senior Engg'),
                              ('approval_two', 'Approved by Project Dept'),
                              ('approval_three', 'Approved by Supply Chain'),
                              ('approval_four', 'Approved by Finance'),
                              ('approval_five', 'Approved by GM'),
                              ('done', 'Done'),
                              ('cancel', 'Cancelled')], string='Status', default='draft', tracking=True)
    stock_order_id = fields.Many2one(
        comodel_name='stock.order',
        string='Stock Order',
        required=False)
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string='Payment Terms',
        required=False)

    approval_one_user_id = fields.Many2one('res.users')
    approval_two_user_id = fields.Many2one('res.users')
    approval_three_user_id = fields.Many2one('res.users')
    approval_four_user_id = fields.Many2one('res.users')
    approval_five_user_id = fields.Many2one('res.users')

    total_amount_in_words = fields.Char(
        string="Amount in Words",
        store=True,
        compute='_compute_total_amt_in_words',
    )
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    construction_id = fields.Many2one(
        comodel_name='site.construction',
        string='Construction',
        required=False)

    wo_schedule_comp_date = fields.Date('WO Scheduled Completion Date')
    inv_count = fields.Integer('# Invoices', compute='comp_inv_count')

    company_id = fields.Many2one('res.company',
                                 required=True,
                                 default=_company_get)
    tower_install = fields.Float(string="Tower & installation", readonly=True, digits="OTC Decimal")
    other_cw = fields.Float(string="Other CW", readonly=True, digits="OTC Decimal")
    grid_connection = fields.Float(string="Grid Connection", readonly=True, digits="OTC Decimal")
    access_road = fields.Float(string="Access Road", readonly=True, digits="OTC Decimal")
    development = fields.Float(string="Development", readonly=True, digits="OTC Decimal")
    work_order_no_imp = fields.Char(string="WO No  Import")
    stock_status = fields.Char(string="Stock Status")
    tower_stock_percent = fields.Float(string="Tower Stock %")
    year = fields.Integer(string="Year")

    '''
            ----------------------Approval Module Changes----------------------
            Approval Section field override to mentioned corresponding model.
            '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='kg.tswo')

    def kg_final_approval(self):
        """Supering method which is defined in the kg approval to confirm TSWO if it is final approval"""
        res = super(TSWO, self).kg_final_approval()
        self.action_done()
        return res



    def print_tswo_report(self):
        if self:
            return self.env.ref('kg_tower.action_tswo_report').report_action(self)

    def send_mail(self):
        template_id = self.env.ref('kg_tower.email_template_tswo')
        print(template_id, 'template_id')
        template_id.send_mail(self.id, force_send=True)

    # @api.constrains('project_id')
    # def _check_max_tenant_limit_tswo_project(self):
    #     for rec in self:
    #         max_tenants = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.max_tenants'))
    #         current_tenants_tswo = self.env['kg.tswo'].search_count([('project_id', '=', rec.project_id.id)])
    #         if current_tenants_tswo > max_tenants:
    #             raise UserError(_("Only %s Tenant TSWO's Allowed", str(max_tenants)))

    # Client requested to remove restriction
    # @api.constrains('construction_id')
    # def _validate_construnction_uniqueness(self):
    #     for record in self:
    #         construction_count = self.env['kg.tswo'].search_count(
    #             [('construction_id', '=', record.construction_id.id), ('state', '!=', 'cancel')])
    #         print(construction_count, 'site_construction_count')
    #
    #         if construction_count > 1:
    #             raise UserError(
    #                 _("Only one TSWO allowed for One Site Construction."))

    @api.depends('currency_id', 'amount_total')
    def _compute_total_amt_in_words(self):
        for pay in self:
            if pay.currency_id:
                pay.total_amount_in_words = pay.currency_id.amount_to_text(pay.amount_total)
            else:
                pay.total_amount_in_words = ''

    def action_cancel(self):
        self.state = 'cancel'

    """field added for excel importing..........***sumayya***********"""

    @api.model
    def create(self, vals):
        year_today = date.today().year
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('kg.tswo') or _('New')

        res = super(TSWO, self).create(vals)
        seq = self.env['contract.pricelist.contractor.sequence'].search(
            [('contract_pricelist_id', '=', vals.get('contract_no')),
             ('partner_id', '=', vals.get('partner_id'))], limit=1)
        if not seq:
            raise UserError('Contractor not linked in UPL')
        if res.partner_id and res.contract_no:
            if res.partner_id.contractor_sequence:
                partner_seq = seq.sequence_id.next_by_id()
                sequence_part1 = partner_seq[:3]
                sequence_part2 = partner_seq[3:]
                work_order_no = 'WO' + '-' + res.contract_no.name + '-' + sequence_part1 + '-' + str(
                    year_today) + '-' + sequence_part2
                res.name = work_order_no
        return res

    @api.depends('tswo_line_ids.price_subtotal', 'grid_extension')
    def comp_total(self):
        for rec in self:
            subtot = 0
            other = rec.grid_extension
            for line in rec.tswo_line_ids:
                subtot += line.price_subtotal
            rec.amount_subtotal = subtot
            rec.amount_total = subtot + other
            filter_tower_install = self.tswo_line_ids.filtered(lambda l: l.category == 'tower_installation')
            sum_tower_install = sum(filter_tower_install.mapped('price_subtotal'))
            self.tower_install = sum_tower_install
            filter_other_cw = self.tswo_line_ids.filtered(lambda l: l.category == 'other_cw')
            sum_other_cw = sum(filter_other_cw.mapped('price_subtotal'))
            self.other_cw = sum_other_cw
            filter_grid_connection = self.tswo_line_ids.filtered(lambda l: l.category == 'grid_connection')
            sum_grid_connection = sum(filter_grid_connection.mapped('price_subtotal'))
            self.grid_connection = sum_grid_connection
            filter_access_road = self.tswo_line_ids.filtered(lambda l: l.category == 'access_road')
            sum_access_road = sum(filter_access_road.mapped('price_subtotal'))
            self.access_road = sum_access_road
            filter_development = self.tswo_line_ids.filtered(lambda l: l.category == 'development')
            sum_development = sum(filter_development.mapped('price_subtotal'))
            self.development = sum_development

    @api.onchange('project_id')
    def onchange_project(self):
        for rec in self:
            if rec.project_id:
                if rec.project_id.site_id:
                    rec.client_site_id = rec.project_id.site_id.id
                if rec.project_id.structure_type_id:
                    rec.structure_types = rec.project_id.structure_type_id.id
                    rec.structure = rec.project_id.structure_type_id.name

    @api.onchange('governorate')
    def onchange_gov(self):
        for rec in self:
            for line in rec.tswo_line_ids:
                line.governorate = rec.governorate.id

    @api.onchange('regional_coefficient_id')
    def onchange_loc(self):
        for rec in self:
            for line in rec.tswo_line_ids:
                line.regional_coefficient_id = rec.regional_coefficient_id.id
                line.onchange_regional_coefficient()

    def send_back(self):
        res = super(TSWO, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res
    @api.onchange('contract_no')
    def onchange_contract_no(self):
        # for rec in self:
        #     rec.description = rec.contract_no.contract_title
        #     for line in rec.tswo_line_ids:
        #         line.contract_no = rec.contract_no.id
        #         line.onchange_contract_no()
        for rec in self:
            print("rec", rec._origin.id)
            line = []
            rec.description = rec.contract_no.contract_title
            print("rec.description", rec.description)
            if rec.construction_id and rec.construction_id.tower_id and rec.contract_no:
                contract_line_product = rec.construction_id.tower_id
                if rec.tswo_line_ids:
                    rec.tswo_line_ids = [(5, 0, 0)]
                contract_pricelist_obj = self.env['contract.pricelist.line'].sudo()
                product = contract_pricelist_obj.search(
                    [('contract_pricelist_id', '=', rec.contract_no.id), ('product_id', '=', contract_line_product.id)])
                line.append(
                    (0, 0, {
                        'contract_line_id': product.id,
                        'product_id': product.product_id.id,
                        'name': product.product_id.name,
                        'product_uom_id': product.product_id.uom_id.id,
                        'product_qty': 1,
                        'equipment_cost': product.equipment_cost,
                        'service_cost': product.service_cost,

                    }))
                rec.update({'tswo_line_ids': line})
                rec.tswo_line_ids.onchange_regional_coefficient()

    '''New states and notification added to TSWO'''

    def notify_users(self, allowed_user_ids, allowed_group):
        self.activity_unlink(['kg_tower.tswo_approval'])
        print(allowed_user_ids, allowed_group)
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.tswo_approval', note=user.name, user_id=user.id)
        if allowed_user_ids:
            user_ids = allowed_user_ids.split(',')
            user_ids = list(map(int, user_ids))
            for user in self.env['res.users'].browse(user_ids):
                self.activity_schedule('kg_tower.tswo_approval', note=user.name, user_id=user.id)

        return True

    def action_approve_senior_engg(self):
        self.notify_users(False, 'project.group_project_manager')
        self.approval_one_user_id = self.env.user.id

        self.state = 'approval_one'

    def action_approve_project_dept(self):
        self.notify_users(False, 'stock.group_stock_manager')
        self.state = 'approval_two'
        self.approval_two_user_id = self.env.user.id

    def action_approve_supply_chain(self):
        self.notify_users(False, 'account.group_account_manager')
        self.approval_three_user_id = self.env.user.id

        self.state = 'approval_three'

    def action_approve_finance(self):
        self.notify_users(False, 'kg_tower.group_second_authoriser')
        self.approval_four_user_id = self.env.user.id

        self.state = 'approval_four'

    def action_approve_gm(self):
        self.approval_five_user_id = self.env.user.id

        self.state = 'approval_five'

    def action_done(self):
        # self.create_invoices()
        self.send_mail()
        if self.project_id:
            self.project_id.write({'tswo_ids': [(0, 0, {'tswo_id': self.id})]})
        self.state = 'done'

    def comp_inv_count(self):
        for record in self:
            record.inv_count = self.env['account.move'].search_count(
                [('tswo_id', '=', record.id)])

    def show_invoices(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Vendor/Contractor Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('tswo_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def create_invoices(self):
        inv_lines = []
        today_date = date.today()
        for rec in self:
            if not rec.project_id.company_id.work_progress_acc_id:
                raise ValidationError("Please Specify Work in Progress Account in Accounting Configuration")
            task_ids = rec.project_id.task_ids
            if any(task.stage_id.is_closed == False for task in task_ids):
                raise ValidationError("There are open tasks in the project")
            milestone_ids = rec.project_id.milestone_ids
            if milestone_ids:
                first_milestone = False
                milestone = milestone_ids.filtered(lambda l: not l.move_id)
                if milestone:
                    first_milestone = milestone.sorted('id')[0]
                else:
                    raise ValidationError(
                        'No milestone available')
                if not first_milestone.milestone_task_id:
                    raise ValidationError(
                        'This Milestone has no task assigned. Please specify corresponding task in project milestone line')
                milestone_percentage = first_milestone.milestone_per
                invoice_date = first_milestone.invoicing_date if first_milestone.invoicing_date else today_date
                label = 'TSWO : ' + rec.name + ' ' + first_milestone.milestone
                move_vals = (0, 0, {
                    'name': label,
                    'price_unit': rec.amount_total,
                    'account_id': rec.project_id.company_id.work_progress_acc_id,
                    'quantity': milestone_percentage,
                    'milestone_percentage': milestone_percentage,
                    'analytic_account_id': rec.contract_no.analytic_id.id,
                })
                inv_lines.append(move_vals)
                create_invoice = self.env['account.move'].create({
                    'partner_id': rec.partner_id.id,
                    'move_type': 'in_invoice',
                    'invoice_date': invoice_date,
                    'tswo_id': rec.id,
                    'site_id': rec.client_site_id.id,
                    'milestone': first_milestone.milestone_per,
                    'milestone_id': first_milestone.id,
                    'invoice_line_ids': inv_lines})
                # create_invoice.action_post()
                first_milestone.move_id = create_invoice.id
                first_milestone.tswo = rec.id
                first_milestone.invoicing_date = create_invoice.invoice_date
                rec.project_id.work_order_value = rec.amount_total
                rec.project_id.invoiced_amount += create_invoice.amount_total
                rec.project_id.balance_amount += rec.project_id.total_work_order_value - rec.project_id.invoiced_amount
                create_invoice.project_id = rec.project_id.id
            else:
                raise ValidationError('Please add milestone in the project')
                # vals_inv = {}
                # vals_inv['invoice_date'] = rec.date
                # vals_inv['move_type'] = 'in_invoice'
                # vals_inv['tswo_id'] = rec.id
                # vals_inv['partner_id'] = rec.partner_id.id
                #
                # # for item in rec.tswo_line_ids:
                # #     a = (0, 0, {
                # #         'quantity': item.product_qty,
                # #         'price_unit': item.price_subtotal,
                # #         'name': item.name,
                # #         'product_id': item.product_id and item.product_id.id or False,
                # #         'analytic_account_id': rec.project_id and rec.project_id.analytic_account_id and rec.project_id.analytic_account_id.id or False,
                # #     })
                # a = (0, 0, {
                #     'quantity': 0.2,
                #     'price_unit': rec.amount_total,
                #     'name': 'TSWO : ' + rec.name + ' First Milestone',
                #     'analytic_account_id': rec.project_id and rec.project_id.analytic_account_id and rec.project_id.analytic_account_id.id or False,
                # })
                #
                # inv_lines.append(a)
                # vals_inv['invoice_line_ids'] = inv_lines
                # inv = self.env['account.move'].create(vals_inv)
                # inv.action_post()

    """field added for excel importing..........***sumayya***********"""
    project_title = fields.Char(string="Project Title")
    three_m_ext = fields.Char(string="3m Ext")
    site_status = fields.Char(string="Site Status")
    stock_payment_terms = fields.Char(string="Stock Payment Terms")
    stock_order_no = fields.Char(string="Stock order NO")
    wo_status = fields.Char(string="WO Status")
    wov_status = fields.Char(string="WOV Status")
    power_status_vf = fields.Char(string="Power Status VF")
    structure_types = fields.Many2one('structure.type', string="Type")
    actual_wo_value = fields.Float(string="Actual WO Value", digits="OTC Decimal")
    variation_value = fields.Float(string="Variation Value", digits="OTC Decimal")
    final_wo_value = fields.Float(string="Final WO Value", digits="OTC Decimal")
    additional_tower_payment = fields.Char(string="Additional tower payment")
    site_value = fields.Float(string="Site Value", digits="OTC Decimal")
    structure = fields.Char(string="Structure")

    def get_approve_details(self):
        approval_list = []
        if self.approved_list:
            data = ast.literal_eval(self.approved_list)
            for ad in data:
                user = ""
                if 'user_approved' in ad:
                    user_obj = self.env['res.users'].browse(ad['user_approved'])
                    user = user_obj
                    approval_level = (ad['approval_level'])
                    if approval_level == 'Requested By':
                        approval_level = 'Project Engineer'
                    approval_dict = {'user': user,
                                     'approval_level': approval_level}
                    approval_list.append(approval_dict)

            return approval_list


    def import_xlsx_file(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Import File',
            'view_mode': 'form',
            'res_model': 'import.file',
            'target': 'new',
            'context': {'default_tswo_id': self.id},
        }


class TSWOLine(models.Model):
    _name = 'kg.tswo.line'

    _description = 'Products for TSWO'

    sequence = fields.Integer('Sequence', default=20)
    name = fields.Char('Description')
    contract_line_id = fields.Many2one('contract.pricelist.line', 'Item Code')
    product_id = fields.Many2one(
        'product.product', 'Product', store=True, readonly=True)
    product_tmpl_id = fields.Many2one('product.template', related="product_id.product_tmpl_id", readonly=True)
    product_qty = fields.Float(
        'Quantity', default=1.0,  digits="OTC Decimal")
    product_uom_id = fields.Many2one(
        'uom.uom', 'Unit of Measure', readonly=True, store=True
    )

    governorate = fields.Many2one('kg.governorate', 'Governorate')
    regional_coefficient = fields.Many2one('kg.regional.coefficient', 'Regional Coefficient')
    regional_coefficient_id = fields.Many2one('contract.pricelist.regional.coefficient', 'Regional Coefficient')
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    equipment_cost = fields.Float('Equipment Cost', digits="OTC Decimal")
    service_cost = fields.Float('Service Cost', digits="OTC Decimal")
    paid_amount = fields.Float('Paid Amount', digits="OTC Decimal")
    reg_coefficient = fields.Float('Regional Coefficient', digits="OTC Decimal")
    price_subtotal = fields.Float('Subtotal', compute='comp_total', digits="OTC Decimal")
    tswo_id = fields.Many2one('kg.tswo', string='TSWO Reference', ondelete='cascade', copy=False)
    category = fields.Selection([('tower_installation', 'Tower & installation'), ('other_cw', 'OTHER CW'),
                                 ('grid_connection', 'Grid Connection'),
                                 ('access_road', 'Access Road'),
                                 ('development', 'Development(for additional tenants)')], string='Category',
                                tracking=True, related='contract_line_id.category')
    deduct_eqp_cost = fields.Boolean(string="Deduct EQP Coast", default=False)
    deduct_service_cost = fields.Boolean(string="Deduct service Coast", default=False)



    @api.onchange('contract_line_id','product_qty')
    def onchange_contract_line_id(self):
        for rec in self:
            rec.product_id = rec.contract_line_id.product_id.id
            rec.product_uom_id = rec.contract_line_id.product_uom_id and rec.contract_line_id.product_uom_id.id or rec.product_id.uom_id.id
            rec.regional_coefficient_id = rec.tswo_id and rec.tswo_id.regional_coefficient_id and rec.tswo_id.regional_coefficient_id.id






    @api.onchange('product_id')
    def onchange_product_id(self):
        for rec in self:
            rec.name = rec.product_id.name
            rec.product_uom_id = rec.product_id.uom_id.id

    @api.onchange('contract_no', 'product_id')
    def onchange_contract_no(self):
        for rec in self:
            for line in rec.contract_no.pricelist_line_ids:
                if line.product_id == rec.product_id:
                    rec.equipment_cost = line.equipment_cost
                    rec.service_cost = line.service_cost
                    break
                else:
                    rec.equipment_cost = 0.0
                    rec.service_cost = 0.0

    @api.onchange('regional_coefficient_id')
    def onchange_regional_coefficient(self):
        for rec in self:
            print('rec.regional_coefficient_id', rec.regional_coefficient_id)
            if rec.regional_coefficient_id:
                rec.reg_coefficient = rec.regional_coefficient_id.reg_coefficient

    @api.depends('reg_coefficient', 'service_cost', 'equipment_cost', 'product_qty', 'paid_amount', 'deduct_eqp_cost',
                 'deduct_service_cost')
    def comp_total(self):
        for rec in self:
            # if not rec.tswo_id.regional_coefficient_id:
            #     raise ValidationError("Please Specify Regional Coefficient in the form")
            if rec.deduct_eqp_cost:
                rec.equipment_cost = 0.00
            else:
                for line in rec.contract_no.pricelist_line_ids:
                    if line.product_id == rec.product_id:
                        rec.equipment_cost = line.equipment_cost
            if rec.deduct_service_cost:
                rec.service_cost = 0.00
            else:
                for line in rec.contract_no.pricelist_line_ids:
                    if line.product_id == rec.product_id:
                        rec.service_cost = line.service_cost
            total = (((
                                  rec.service_cost * rec.reg_coefficient) + rec.equipment_cost) * rec.product_qty) - rec.paid_amount
            rec.price_subtotal = total
