# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ResCompanyInherit(models.Model):
    _inherit = "res.company"

    work_progress_acc_id = fields.Many2one('account.account', string="Work in Progress Account")
    project_asset_acc_id = fields.Many2one('account.account', string="Project Asset Account")
    asset_account_fixed_asset_id = fields.Many2one('account.account', string='Fixed Asset Account',
                                       help="Account used to record the purchase of the asset at its original price.",
                                       domain="[('company_id', '=', company_id), ('is_off_balance', '=', False)]")
    asset_account_depreciation_id = fields.Many2one(
        comodel_name='account.account',
        string='Depreciation Account',
        help="Account used in the depreciation entries, to decrease the asset value.")
    asset_account_depreciation_expense_id = fields.Many2one(
        comodel_name='account.account',
        string='Expense Account')
    asset_journal_id = fields.Many2one(
        'account.journal',
        string='Journal')

    account_asset_counterpart_id = fields.Many2one(comodel_name='account.account', string='Account Asset Counterpart', )
    stock_order_acc_id = fields.Many2one('account.account', string="Stock Order Account")

class ResConfigSettingsInherit(models.TransientModel):
    _inherit = 'res.config.settings'

    work_progress_acc_id = fields.Many2one(related='company_id.work_progress_acc_id', string="Work in Progress Account",
                                           readonly=False)
    project_asset_acc_id = fields.Many2one(related='company_id.project_asset_acc_id', string="Project Asset Account",
                                           readonly=False)
    asset_account_fixed_asset_id = fields.Many2one(related='company_id.asset_account_fixed_asset_id', string="Fixed Asset Account",
                                           readonly=False)
    asset_account_depreciation_id = fields.Many2one(related='company_id.asset_account_depreciation_id', string="Depreciation Account",
                                           readonly=False)
    asset_account_depreciation_expense_id = fields.Many2one(related='company_id.asset_account_depreciation_expense_id', string="Expense Account",
                                           readonly=False)
    asset_journal_id = fields.Many2one(related='company_id.asset_journal_id', string="Asset Journal",
                                       readonly=False)
    account_asset_counterpart_id = fields.Many2one(related='company_id.account_asset_counterpart_id', readonly=False,
                                                   string='Account Asset Counterpart')
    stock_order_acc_id = fields.Many2one(related='company_id.stock_order_acc_id', string="Stock Order Account",readonly=False)


class ResPartnerInherit(models.Model):
    _inherit = 'res.users'

    team_ids = fields.Many2many('crm.team', string="Sales Team", compute='compute_sales_team', store=True)

    # @api.depends('')
    def compute_sales_team(self):
        for rec in self:
            sale_team = self.env['crm.team'].search([])
            for team in sale_team:
                sale_person_ids = team.mapped('sale_person_ids')
                if rec.id and rec.id in sale_person_ids.ids:
                    rec.team_ids |= team.id
