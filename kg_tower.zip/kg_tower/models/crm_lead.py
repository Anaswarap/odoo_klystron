# -*- coding: utf-8 -*-


from odoo import models, fields


class CrmLeadInherit(models.Model):
    _inherit = 'crm.team'

    sale_person_ids = fields.Many2many('res.users', string="Team Member")

