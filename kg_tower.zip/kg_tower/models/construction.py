from odoo import models, fields, api, _
from datetime import datetime, date, timedelta
from odoo.exceptions import UserError, ValidationError


class Construction(models.Model):
    _name = 'site.construction'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Construction'

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    partner_id = fields.Many2one('res.partner',
                                 string='Client',tracking=True, domain=[('operator', '=', True)])
    client_work_order_no = fields.Char(
        string='Client Work Order No',
        required=False, readonly=True,
        tracking=True)
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    project_id = fields.Many2one('project.project', 'Project', tracking=True, )
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    existing_site = fields.Boolean(
        string='Existing Site',
        default=False,
        tracking=True)
    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'), ])
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    contractor_id = fields.Many2one('res.partner', string='Contractor', tracking=True,
                                    domain=[('contractor', '=', True)])
    draft_no_issued = fields.Boolean('Draft No Issued', default=False, tracking=True)
    kick_off = fields.Boolean('Kick Off', default=False, tracking=True)
    otc_turnkey_site_no = fields.Char('OTC Turnkey Site No', copy=False)
    tswo_issued = fields.Boolean('TSWO Issued', default=False, tracking=True)
    tswo_date = fields.Date('TSWO Date', tracking=True)
    pip_cwb_days = fields.Integer('PIP CW B.Days', tracking=True)
    cw_start_date = fields.Date('CW Starting Date', tracking=True)
    cw_eta = fields.Date('CW ETA', tracking=True)
    cw_status = fields.Selection([('saq', 'SAQ'),
                                  ('kickoff', 'kickoff'),
                                  ('excavation', 'Excavation'),
                                  ('foundation', 'Foundation'),
                                  ('erection', 'Erection'),('wo_pending', 'WO pending'),
                                  ('fence_bw', 'Fence/BW'), ('planning', 'Planning'), ('soil_test', 'Soil Test'),('access_permission', 'Access Permission'),
                                  ('fixing_snags', 'Fixing Snags'),
                                  ('cw_completed', 'CW completed'),
                                  ('power_ip', 'Power IP'),('mobilization', 'Mobilization'),
                                  ('co_cw_ip', 'CO CW IP'), ('hold', 'HOLD'),('stop', 'STOP'),
                                  ('layout_approval', 'Layout-Approval'),('ep_pending', 'EP-Pending'),
                                  ('access_road', 'Access Road'),('wo_negotiation', 'WO Negotiation'),
                                  ('site_completed', 'Site Completed')], string='CW Status', default='saq', tracking=True, copy=False)
    cw_complete_date = fields.Date('CW Completion Date', tracking=True)
    grid_site_type = fields.Selection([('on_grid', 'On-Grid'),
                                       ('temp_off_grid', 'Temporary Off-Grid'),('yes', 'Yes'),
                                  ('no', 'No'),], default='on_grid', tracking=True)
    extension_status = fields.Char('Extension Status', tracking=True)
    exten_conn_eta = fields.Date('Extension & Connection ETA', tracking=True)
    conn_status = fields.Char('Connection Status', tracking=True)
    conn_date = fields.Date('Connection Date', tracking=True)
    mds_genset_wo_no = fields.Char('MDS GenSet WO#', tracking=True)
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    pav_date = fields.Date('PAV Date')
    pac_date = fields.Date('PAC Date')
    fav_date = fields.Date('FAV Date')
    fac_date = fields.Date('FAC Date')

    task_status = fields.Char('Task Status', compute='comp_task_status')
    task_count = fields.Integer('Task Count', compute='comp_task_count')

    vo_count = fields.Integer('VO Count', compute='comp_vo_count')
    work_order_id = fields.Many2one(
        comodel_name='work.order',
        string='NSWO', readonly=True,
        required=False)
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    current_task_id = fields.Many2one('project.task', 'Current Task')
    current_task_status = fields.Char('Current Status')

    tswo_count = fields.Integer('TSWO Count', compute='comp_tswo_count')
    tower_id = fields.Many2one('product.product', 'Tower', related='site_acq_id.tower_id')

    client_id = fields.Char('Client Site ID', readonly=True,)
    project_name = fields.Char('Project Name')
    reason_of_presence = fields.Char('Reason of Presence')

    governorate = fields.Many2one(comodel_name='kg.governorate',string='Governorate')
    latitude = fields.Char(string='Latitude',tracking=True)
    longitude = fields.Char(string='Longitude',tracking=True)
    wilayat_id = fields.Many2one('kg.wilayat', string='Wilayat',tracking=True)
    power_type = fields.Selection([('power_connected', 'Power Connected'),
                                  ('genset_oo', 'Genset OO'),
                                  ('genset_vf', 'Genset VF'),('oo_power', 'OO Power'),
                                  ('genset_ot', 'Genset OT'), ('no_power', 'No Power'),
                                  ('rt_owner', 'RT owner')], string='Power Type')

    indicative_target_rfi = fields.Date('Indicative Target RFI Date')
    max_ht_required = fields.Float('Max Ht Required')
    client_height = fields.Float('Client Hight(m)')
    tenancies = fields.Integer('Tenancies')
    tower_height = fields.Float('Tower Height(m)')
    required_height = fields.Float('Required Height(m)', related='work_order_id.tower_height_input')
    actual_height = fields.Float('Actual Height(m)')
    audited_height = fields.Float('Audited Height(m)')
    required_epa = fields.Float('Required EPA')
    actual_epa = fields.Float('Actual EPA')
    audited_epa = fields.Float('Audited EPA')
    tenent_id = fields.Many2one('res.partner',
                                 string='First Tenant',domain=[('operator', '=', True)])
    nswo_date = fields.Date('NSWO Date', readonly=True)
    nswo_acceptance_date = fields.Date('NSWO Acceptance Date', readonly=True)
    handover_date = fields.Date('Handover Date')
    assignment_date = fields.Date('Assignment Date')
    handover = fields.Selection(
        selection=[('handover', 'Handover'), ('handover without ibaha', 'Handover Without Ibaha'),
                   ('handover-ep', 'Handover-EP'), ('handover-rds', 'Handover-RDS'),
                   ('special project', 'Special Project')],string='Handover', copy=False, tracking=True)
    extension_possible = fields.Selection([('yes', 'Yes'),
                                         ('no', 'No'),
                                         ('tbc', 'TBC')], string='3m Extension Possible')

    extension_installed = fields.Selection([('yes', 'Yes'),
                                           ('no', 'No')], string='3m Extension Installed')
    kick_off_date = fields.Date('Kick Off Date')
    excavation_date = fields.Date('Excavation Date')
    foundation_date = fields.Date('Foundation Date')
    erection_date = fields.Date('Erection Date')
    fence_bw_date = fields.Date('Fence/BW Date')
    rfi_date = fields.Date('RFI Date')
    first_rfi_date = fields.Date('First RFI Date')
    rfi_acceptance_date = fields.Date('RFI Acceptance Date')
    pad_lock_no = fields.Integer('Pad lock number')

    antenna_lines = fields.One2many('work.order.antenna.lines', 'construction_id',related='work_order_id.antenna_lines', copy=True)
    rru_lines = fields.One2many('work.order.rru.lines', 'construction_id',related='work_order_id.rru_lines', copy=True)
    micro_lines = fields.One2many('work.order.microwave.lines', 'construction_id',related='work_order_id.micro_lines', copy=True)

    def action_open_documents(self):
        self.ensure_one()
        project_name = self.project_id.name
        saq_project_folder = self.env['documents.folder'].search(
            [('model', '=', 'site.construction'), ('res_id', '=', self.id)])
        action = self.env['ir.actions.act_window']._for_xml_id('documents.document_action')
        action['context'] = {
            'searchpanel_default_folder_id': saq_project_folder and saq_project_folder.id,
        }
        return action




    # @api.constrains('work_order_id')
    # def _check_work_order_id(self):
    #     for rec in self:
    #         if rec.env['site.construction'].search_count([('work_order_id', '=', rec.work_order_id.id)]) > 1:
    #             raise ValidationError('An construction form has already been created with the selected work order')

    def comp_tswo_count(self):
        for record in self:
            record.tswo_count = self.env['kg.tswo'].search_count(
                [('construction_id', '=', record.id)])

    def comp_vo_count(self):
        for record in self:
            record.vo_count = self.env['kg.vo'].search_count(
                [('construction_id', '=', record.id)])

    def get_special_instr(self):
        if self.work_order_id:
            panel_antts = self.env['work.order.antenna.lines'].read_group([ ("work_order_id", "=", self.work_order_id.id) ], fields=['antenna_id.name'], groupby=['antenna_id'])
            rrus = self.env['work.order.rru.lines'].read_group([ ("work_order_id", "=", self.work_order_id.id) ], fields=['rru_id'], groupby=['rru_id'])
            micros = self.env['work.order.microwave.lines'].read_group([ ("work_order_id", "=", self.work_order_id.id) ], fields=['micro_id'], groupby=['micro_id'])
            instruction = "Panel Antenna : "
            for panel_antt in panel_antts:
                name = panel_antt['antenna_id'] and (panel_antt['antenna_id'][1])
                count = panel_antt['antenna_id_count'] and str(panel_antt['antenna_id_count'])
                instruction = ("%s %s(%s)\n" %(instruction,name,count))
            instruction = ("%s \n RRUs:" %(instruction))
            for rru in rrus:
                name = rru['rru_id'] and (rru['rru_id'][1])
                count = rru['rru_id_count'] and str(rru['rru_id_count'])
                instruction = ("%s %s(%s)\n" %(instruction,name,count))
            instruction = ("%s \n Microwaves:" %(instruction))
            for micro in micros:
                name = micro['micro_id'] and (micro['micro_id'][1])
                count = micro['micro_id_count'] and str(micro['micro_id_count'])
                instruction = ("%s %s(%s)\n" %(instruction,name,count))
            return instruction
        else:
            return ""

    def show_tswo(self):
        for rec in self:
            context = {
                        'default_date': fields.Date.today(),
                        'default_construction_id': rec.id,
                        'default_partner_id': rec.contractor_id.id or False,
                        'default_project_id': rec.project_id and rec.project_id.id or False,
                        'default_payment_term_id': rec.project_id and rec.project_id.payment_term_id and rec.project_id.payment_term_id.id or False,
                        'default_stock_order_id': rec.project_id and rec.project_id.payment_term_id and rec.project_id.stock_order_id.id or False,
                        'default_governorate': rec.site_acq_id.wilayat_id.governorate_id.id or False,
                        'default_work_order_no': rec.project_id.work_order_id.name or False,
                        'default_work_order_date': rec.project_id.work_order_id.work_order_date or False,
                        'default_client_site_id': rec.project_id.work_order_id.client_site_id.id or False,
                        'default_special_instr': rec.get_special_instr(),
                    }
            tswo = self.env['kg.tswo'].search([('construction_id', '=', rec.id), ], order='date DESC')
            if tswo:
                return {
                    'type': 'ir.actions.act_window',
                    'name': "TSWO's",
                    'view_mode': 'tree,form',
                    'res_model': 'kg.tswo',
                    'domain': [('id', 'in', tswo.ids)],
                    # 'context': "{'create': False}",
                    'context': context,

                }
            else:
                return {
                    'type': 'ir.actions.act_window',
                    'name': "TSWO's",
                    'view_mode': 'form',
                    'res_model': 'kg.tswo',
                    'context': context,
                }

    def show_vo(self):
        for rec in self:
            tswo = self.env['kg.tswo'].search([('construction_id', '=', rec.id), ('state', '=', 'done')],
                                              order='date DESC', limit=1)

            return {
                'type': 'ir.actions.act_window',
                'name': "VO's",
                'view_mode': 'tree,form',
                'res_model': 'kg.vo',
                'domain': [('construction_id', '=', rec.id)],
                'context': {
                    'default_date': fields.Date.today(),
                    'default_construction_id': rec.id,
                    'default_partner_id': rec.partner_id and rec.partner_id.id or False,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_governorate': tswo and tswo.governorate.id or False,
                    'default_tswo_id': tswo and tswo.id or False,
                    'default_contract_no': tswo and tswo.contract_no.id or False,
                    'default_description': tswo and tswo.description or False

                }
            }

    def show_create_rfi_notice(self):
        for rec in self:
            rfi_notice = self.env['rfi.notice'].search(
                [('project_id', '=', rec.project_id.id),
                 ('client_site_id', '=', rec.client_site_id.id)])

            if rfi_notice:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'RFI Notice',
                    'view_mode': 'tree,form',
                    'res_model': 'rfi.notice',
                    'domain': [('id', 'in', rfi_notice.ids)],
                    'context': "{'create': False}",

                }
            else:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'RFI Notice',
                    'view_mode': 'form',
                    'res_model': 'rfi.notice',
                    'context': {
                        'default_partner_id': rec.partner_id.id,
                        'default_client_work_order_no': rec.client_work_order_no,
                        'default_project_id': rec.project_id.id,
                        'default_client_site_id': rec.client_site_id.id,
                        'default_work_order_id': rec.work_order_id.id,
                    }
                }

    def comp_task_count(self):
        for record in self:
            record.task_count = self.env['project.task'].search_count(
                [('construction_id', '=', record.id)])

    def show_tasks(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Tasks',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.task',
                'domain': [('construction_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>

                                <th scope="col">Status</th>

                            </tr>
                        </thead>
                        <tbody>

                """
            count = 1
            for task in self.env['project.task'].search([('construction_id', '=', rec.id)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('site.construction') or _('New')
        return super(Construction, self).create(vals)

    def action_confirm(self):
        # validation for required fields
        print("partner_id",self.partner_id)
        field_list = ['work_order_id', 'partner_id', 'client_work_order_no','site_acq_id','current_task_status','project_id',
                      'structure_type_id','client_site_id','tower_id','contractor_id','client_id','tower_height','required_height','audited_height',
                      'required_epa','actual_epa']
        miss_list = []
        for fld in field_list:
            field_obj = self.env['ir.model.fields'].search(
                [('name', '=', fld), ('model_id.model', '=', 'site.construction')])
            if len(field_obj) == 1:
                if field_obj.ttype == 'char' and self.mapped(fld)[0] == False:
                    miss_list.append(field_obj.field_description)
                elif field_obj.ttype == 'many2one' and len(self.mapped(fld)) == 0:
                    miss_list.append(field_obj.field_description)
                elif field_obj.ttype == 'float' and self.mapped(fld)[0] == 0.00:
                    miss_list.append(field_obj.field_description)
        raise ValidationError(_(
                    "Please fill the following details: %s", ','.join(miss_list)))
        project = self.env['project.project']
        task = self.env['project.task']
        existing_site_acq = self.env['site.acquisition'].search(
            [('nswo_id', '=', self.work_order_id.id)], limit=1)
        if existing_site_acq:
            self.structure_type_id = existing_site_acq.structure_type_id.id
            self.contractor_id = existing_site_acq.contractor_id.id
        else:
            raise UserError(_('Please create Site Acquistion Stage'))
        partner = self.partner_id.id
        # partner = self.partner_id.get_operator_id()
        task_lists = self.env['task.list'].search([('partner_id', '=', partner),
                                                   ('structure_type_id', '=', existing_site_acq.structure_type_id.id)],
                                                  limit=1)
        if task_lists:
            users = self.env['res.users'].search([('partner_id', '=', self.partner_id.id)], limit=1)
            allowed_user_ids = False
            if users:
                allowed_user_ids = [[6, 0, [users.id]]]

            for rec in task_lists:
                # existing_site_acq = self.env['site.acquisition'].search(
                #     [('client_work_order_no', '=', self.client_work_order_no)], limit=1)
                if existing_site_acq:
                    project_id = self.env['project.task'].search([('site_acq_id', '=', existing_site_acq.id)],
                                                                 limit=1) and self.env['project.task'].search(
                        [('site_acq_id', '=', existing_site_acq.id)], limit=1).project_id or False
                    open_tasks = self.env['project.task'].search([('site_acq_id', '=', existing_site_acq.id), (
                        'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)])
                    self.client_site_id = existing_site_acq.client_site_id.id
                    self.site_acq_id = existing_site_acq.id
                    self.work_order_id = existing_site_acq.nswo_id and existing_site_acq.nswo_id.id or False
                    # if open_tasks:
                    #     raise UserError(_('Please complete Site Acquisition Stage'))
                    if project_id:
                        self.project_id = project_id.id
                        if self.existing_site:
                            task_list_obj = rec.existing_list_lines
                        else:
                            task_list_obj = rec.list_lines
                        prev_task = False

                        for lines in task_list_obj.sorted('sequence'):
                            if lines.progress == 'construction':
                                if not prev_task:
                                    current_date = fields.Date.today()
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)
                                else:
                                    current_date = prev_task.date_deadline
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)

                                vals = {
                                    'project_id': project_id.id,
                                    'name': lines.kg_task_id,
                                    'department_id': lines.department_id.id,
                                    'work_flow': lines.work_flow,
                                    'progress_level': lines.progress,
                                    'weight': lines.weight,
                                    'completion_task': lines.completion_task,
                                    'gf_construction': lines.gf_construction,
                                    'collacation': lines.collacation,
                                    'roof_top': lines.roof_top,
                                    'sequence': lines.sequence,
                                    'partner_id': self.partner_id.id,
                                    'construction_id': self.id,
                                    'user_id': lines.user_id.id or False,

                                    'allowed_user_ids': allowed_user_ids,
                                    'override_sequence': lines.override_sequence,
                                    'milestone_task': lines.milestone_task,
                                    'date_deadline': deadline,
                                    'proposed_date_deadline': deadline,
                                    'attach_mandatory': lines.attach_mandatory

                                }
                                prev_task = task.create(vals)
                        task_schedule = self.env['project.task'].search(
                            [('project_id', '=', project_id.id), ('construction_id', '=', self.id), (
                                'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1,
                            order="sequence asc")
                        print('TaskList', task_schedule)
                        if task_schedule:
                            self.current_task_id = task_schedule.id
                            self.current_task_status = task_schedule.name

                            activity = self.env['mail.activity'].sudo().create({
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'res_id': task_schedule.id,
                                'user_id': task_schedule.user_id.id,
                                # 'date_deadline':deadline,
                                'res_model_id': self.env.ref('project.model_project_task').id,
                            })
                            print(":activity", activity)
                            activity._onchange_activity_type_id()
        else:
            raise UserError(_('Please set Task Lists First'))
        self.state = 'confirm'
