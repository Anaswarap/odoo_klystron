from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ProjectClosure(models.Model):

    _name = 'project.closure'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Project Closure'

    name = fields.Char('Reference',required=True,tracking=True)
    date = fields.Date('Date',required=True,default=fields.Date.today(),tracking=True)
    note = fields.Text('Description',tracking=True)
