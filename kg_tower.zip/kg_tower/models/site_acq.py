from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, date, timedelta


class SiteAcquisition(models.Model):
    _name = 'site.acquisition'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'documents.mixin']
    _description = 'Site Acquisition'

    def notify_users(self, allowed_group):
        self.activity_unlink(['kg_tower.saq_created'])
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.saq_created', note=user.name, user_id=user.id)
        return True

    @api.model
    def _company_get(self):
        company_id = self.env['res.company']._company_default_get(self._name)
        return self.env['res.company'].browse(company_id.id)

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    company_id = fields.Many2one('res.company',
                                 required=True,
                                 default=_company_get)
    partner_id = fields.Many2one('res.partner',
                                 string='Operator',
                                 required=True, readonly=True,
                                 tracking=True, domain=[('operator', '=', True)])
    client_work_order_no = fields.Char(
        string='Client Work Order No',
        required=False,
        tracking=True, readonly=True)

    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, readonly=True)
    project_id = fields.Many2one('project.project', 'Project', tracking=True, )
    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'), ])
    wilayat_id = fields.Many2one('kg.wilayat',
                                 string='Wilayat', readonly=True,
                                 tracking=True, ondelete="cascade")
    structure_type_id = fields.Many2one('structure.type', 'Structure Type', readonly=True)
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    existing_site = fields.Boolean(
        string='Existing Site',
        default=False,
        tracking=True)

    extract_permit_actual = fields.Date('Extract Permit Actual')

    saq_eta = fields.Char('SAQ ETA')
    saq_status = fields.Selection([('early', 'Early Stage'),
                                   ('survey', 'Survey'),
                                   ('kruki', 'Kruki'),
                                   ('roa', 'ROA'),
                                   ('civil_defence', 'Civil Defence'),
                                   ('civil_aviation', 'Civil Aviation'),
                                   ('ibaha', 'Ibaha'),
                                   ('exca_permit_ip', 'Excavation Permit IP'),
                                   ('saq_complete', 'SAQ Completed'),
                                   ('commercial', 'Commercial'),
                                   ], string='SAQ Status', default='early', tracking=True, required=True, copy=False)
    remarks = fields.Text('Remarks', copy=True, )
    model = fields.Char('Model', tracking=True, )
    three_m_exten = fields.Boolean('3m Extension', default=False, tracking=True)
    supplier_id = fields.Many2one('res.partner', 'Supplier', tracking=True)
    anchor_bolt_status = fields.Selection([('not_install', 'Not Installed'), ('install', 'Installed')],
                                          string='Anchor Bolt Status', default='not_install', copy=True, tracking=True)
    tower_status = fields.Selection([('not_install', 'Not Installed'), ('install', 'Installed')], string='Tower Status',
                                    default='not_install', copy=True, tracking=True)

    task_status = fields.Char('Task Status', compute='comp_task_status')
    task_count = fields.Integer('Task Count', compute='comp_task_count')

    # tswo_count = fields.Integer('TSWO Count', compute='comp_tswo_count')

    contractor_expense_count = fields.Integer('Contractor Count', compute='comp_contractor_expense_count')
    contractor_nonreco_expense_count = fields.Integer('Contractor Count', compute='comp_contractor_nonreco_expense_count')
    owner_rent_expense_count = fields.Integer('Owner Rent Count', compute='comp_owner_rent_expense_count')
    stock_transfer_count = fields.Integer('Internal Transfer Count', compute='comp_transfer_count')
    tower_transfer_count = fields.Integer('Tower Transfer Count', compute='comp_tower_transfer_count')

    nswo_id = fields.Many2one(
        comodel_name='work.order',
        string='NSWO',
        required=False, readonly=True)
    srr_id = fields.Many2one(comodel_name='ring.request', string='SRR', related='nswo_id.srr_id')

    current_task_id = fields.Many2one('project.task', 'Current Task')
    current_task_status = fields.Char('Current Status')

    latitude = fields.Char(
        string='Latitude',
        related='nswo_id.latitude', tracking=True)
    longitude = fields.Char(
        string='Longitude',
        related='nswo_id.longitude', tracking=True)

    governorate = fields.Many2one(
        comodel_name='kg.governorate',
        string='Governorate', readonly=True)
    # related='nswo_id.governorate', tracking=True)

    tower_height = fields.Many2one(
        comodel_name='tower.height',
        string='Tower Height',
        related='nswo_id.tower_height', tracking=True)

    expected_grid_connection = fields.Selection(
        string='Expected Grid Connection',
        selection=[('yes', 'Yes'),
                   ('no', 'No'),
                   ('to_be_confirm', 'To be Confirmed'), ],
        related='nswo_id.expected_grid_connection', tracking=True)

    tower_id = fields.Many2one('product.product', 'Tower', readonly=True)
    # def comp_tswo_count(self):
    #     for record in self:
    #         record.tswo_count = self.env['kg.tswo'].search_count(
    #             [('site_acq_id', '=', record.id)])
    doc_checklist = fields.Many2many('doc.checklist', string='Check List')
    contractor_id = fields.Many2one('res.partner', 'Contractor', tracking=True, readonly=True,
                                    domain=[('contractor', '=', True)])
    owner_id = fields.Many2one('res.partner',
                                 string='Owner',
                                 tracking=True, domain=[('owner', '=', True)])

    """field added for excel importing..........***sha***********"""

    ot_id=fields.Char(string="OT ID")
    oo_id=fields.Char(string="OO ID")
    location_area=fields.Char(string="Location Area")
    site_progress=fields.Char(string="Site Progress")
    owner_type=fields.Char(string="Owner Type")
    lease_type=fields.Char(string="Lease type")
    saq_nswo_site=fields.Char(string="SAQ NSWO Site Status")
    site_secured=fields.Char(string="Site Secured Date")
    nswo_hight=fields.Char(string="NSWO Required Hight")
    nswo_date=fields.Char(string="NSWO Date")
    nswo_acceptanc_date=fields.Char(string="NSWO Acceptance Date")
    operator_id = fields.Many2one('res.partner',
                                  string='SAQ Area Managers',
                                  required=False,
                                  tracking=True)
    kruki_latitude = fields.Char(string='Kruki-Latitude',tracking=True)
    kruki_longitude = fields.Char(string='Kruki-Longitude',tracking=True)
    rdu_latitude = fields.Char(string='RDU-Latitude', tracking=True)
    rdu_longitude = fields.Char(string='RDU-Longitude', tracking=True)
    letter_tra = fields.Char(string='Letter Submitted to TRA', tracking=True)
    tra_letter_moh = fields.Char(string='TRA issued Letter to MOH', tracking=True)
    tra_letter_eng = fields.Char(string='Send the TRA Letter to Eng', tracking=True)
    tra_new_proposal_sent = fields.Char(string='sent TRA Letter for new Proposal', tracking=True)
    new_locatn_lat = fields.Char(string='New Location Latitude', tracking=True)
    new_locatn_longtd = fields.Char(string='New Location Longitude', tracking=True)
    tra_new_proposal_recvd = fields.Char(string='Recived TRA Letter for new Proposal', tracking=True)
    apprvl_from_opertr = fields.Char(string='Send new proposal to get approval from operator', tracking=True)
    apprvd_by_opertr = fields.Char(string='approved by operator', tracking=True)
    reqst_draft_krookie = fields.Char(string='Request for Draft Kruki', tracking=True)
    draft_krookie_ready = fields.Char(string='Draft Krookie Received', tracking=True)
    letter_sent_moh = fields.Char(string='Letter Sent To MOH', tracking=True)
    moh_refrnce_no = fields.Char(string='MOH Reffrenace numebr', tracking=True)
    acquired_kruki = fields.Char(string='Acquired Kruki ', tracking=True)
    stamp_kruki_frm_moh = fields.Char(string='Stamp Kruki from MOH', tracking=True)
    kruki_no = fields.Char(string='Krookie No', tracking=True)
    plot_no = fields.Char(string='Plot No', tracking=True)
    plot_size = fields.Char(string='Plot Size', tracking=True)
    acquired_mulkia = fields.Char(string='Acquired Mulkia')
    share_kruki_to_oprtr = fields.Char(string='Share kruki to operator', tracking=True)
    apprvd_kruki_by_oprtr = fields.Char(string='approved kruki by operator', tracking=True)
    roa_signedby_tra = fields.Char(string='Submitted ROA requist to be signed by TRA', tracking=True)
    roa_signed_recvd_tra = fields.Char(string='ROA Signed & Recived  from TRA', tracking=True)
    roa_authorised_regstrd = fields.Char(string='ROA Authorised \ Registered (مصدق)', tracking=True)
    amnt_paid_roa = fields.Char(string='Amount payed for ROA OMR', tracking=True)
    paca_submission = fields.Char(string='CAA Submission', tracking=True)
    paca_height = fields.Char(string='Request Hight ( m )', tracking=True)
    paca_approved_height = fields.Char(string='CAA Approved Hight ( m )', tracking=True)
    paca_modification_submisn = fields.Char(string='CAA Modification Submission', tracking=True)
    new_heght_reqsted = fields.Char(string='New Hight Requsted ?', tracking=True)
    paca_payment = fields.Char(string='CAA payment Date', tracking=True)
    amnt_caa_omr = fields.Char(string='Amount payed for CAA OMR', tracking=True)
    paca_modfctn_recvd = fields.Char(string='CAA Modification Received', tracking=True)
    new_paca_apprv = fields.Char(string='NEW CAA Approved High ( M )', tracking=True)
    paca_issued = fields.Char(string='PACA issued', tracking=True)
    paca_submited = fields.Char(string='PACD Submitted', tracking=True)
    initial_paca_issued = fields.Char(string='Initial PACD issued  المبدئي', tracking=True)
    initial_paca_omr = fields.Char(string='Initial PACD Payed OMR', tracking=True)
    final_paca_issued = fields.Char(string='Final PACD date issued النهائي', tracking=True)
    final_paca_expired = fields.Char(string='Final PACD date will expire النهائي', tracking=True)
    demarcation_eng = fields.Char(string='Demarcation Share to Eng')
    demarcation_recv = fields.Char(string='Demarcation Recived')
    pictures_provided = fields.Char(string='Picturs Provided ?')
    remarks_commnts = fields.Char(string='Remarks / Comments')
    date_demarcation = fields.Char(string='Date for payed the demarcation')
    amnt_payed_demarcation = fields.Char(string='Amount payed for demarcation OMR')
    name_demarcation_consaltnc = fields.Char(string='Name of Demarcation Consaltance')
    original_demarcation = fields.Char(string='Original demarcation with who ?')
    reqsted_planning = fields.Char(string='Requsted for Layouts from Planning for Ibaha')
    layout_recvd_planning = fields.Char(string='Layout Recived From Planning for Ibaha')
    reqsted_planning_hand = fields.Char(string='Requsted for Layouts from Planning for handover')
    layout_recvd_planning_hand = fields.Char(string='Layout Recived From Planning for handover')

    cntrctr_pleadge_lettr = fields.Char(string='Request Contractor Pledge Letter')
    revcd_pleadge_lettr = fields.Char(string='Recived Contractor Pledge Letter')
    letter_ready = fields.Char(string='Letter Ready')
    ibaha_submitd = fields.Char(string='Ibaha Submitted')
    insurence = fields.Char(string='insurance')
    amount_ibaha_omr = fields.Char(string='Amount payed for Ibaha OMR')
    ibaha_reff_no = fields.Char(string='Ibaha Reff Number')
    remarks_dherkreet = fields.Char(string='Remarks Dhekraeat')
    ibaha_issued = fields.Char(string='Ibaha issued')
    prepperd_elctrcl_drwng = fields.Char(string='Prepperd Electrical Drawing ')
    elctrcl_drwng_date_reqstd = fields.Char(string='Electrical Drawing Request Date')
    ref_number = fields.Char(string='Ref Number')
    elctrcl_drwng_date_apprvd = fields.Char(string='Electrical Drawing Approval Date')
    sent_contractr = fields.Char(string='Sent to Contractor')
    signed_from = fields.Char(string='Signed Form')
    submit_reqst = fields.Char(string='Submitt the requist')
    ref_no = fields.Char(string='Ref. Number')
    date_epdoc_sent = fields.Char(string='Date of sending the EP Documents to Project team')
    ep_payment = fields.Char(string='EP Payment')
    ep_insurnc_amnt = fields.Char(string='EP Insurance amount')
    ep_issued = fields.Char(string='EP issued')
    date_recvd_cc = fields.Char(string='Date of recived Completion Certificate ( CC ) from Projects or Contractor')
    power_connctn_noc = fields.Char(string='Power Connection NOC ( from MM to MEDC )')
    planned = fields.Char(string='Planned')
    actual = fields.Char(string='Actual')
    acceptance = fields.Char(string='Acceptance')
    doesnt_accept = fields.Char(string='why doesnt accept')
    otc_reqst_shftng = fields.Char(string='OTC requsted for shifting letter')
    tra_issued_shftng = fields.Char(string='TRA issued Letter to MOH - Shifting')
    saq_team_moh = fields.Char(string='Sent to SAQ team apply with MOH')
    saq_team_moh_remrk = fields.Char(string='SAQ team - MOH remarks')
    planing_dept = fields.Char(string='Planning department ')
    site_survey_moh = fields.Char(string='Site Surveyed by MOH ')
    kurki_drawng_dept = fields.Char(string='Kurki drowing department ')
    undear_apprvl = fields.Char(string='Undear Scurtary for approval ')
    sajal_kurki_malakia = fields.Char(string='Sajal Eiqari for kurki and Malakia')
    demarcation_renewl = fields.Char(string='Demarcation Renweal')
    no_renewl = fields.Char(string='No of Renweal')
    target_handover = fields.Char(string='Target Handover Date')
    vf_id = fields.Char(string='VF ID')
    site_phase = fields.Char(string='Site phase ')
    nswo_status = fields.Char(string='NSWO')
    vf_nswo_height = fields.Char(string='VF NSWO height (m)')
    rds = fields.Char(string='RDS')
    rds_batch = fields.Char(string='RDS Batch')
    fence_no_fnc = fields.Char(string='Fence or no fence')
    rds_perm_temp = fields.Char(string='RDS ( Permannet / Temp )')
    perm_site_remarks = fields.Text(string='Permanent Site remarks')
    perm_site_type = fields.Text(string='Permanent Site type')
    rds_handover = fields.Char(string='RDS Handover Date')
    rds_actv_remv = fields.Char(string='RDS Active or removed ?')
    rds_date_remv = fields.Char(string='RDS Removed date')
    moh_privt = fields.Char(string='MOH / Privt')
    tra_rds = fields.Char(string='TRA')
    vf_rds = fields.Char(string='Operator RDS Approval')
    rds_height = fields.Char(string='RDS Height')
    permenent_height = fields.Char(string='Permanent Height')
    rds_lat = fields.Char(string='RDS Lat')
    rds_app_lat = fields.Char(string='RDS Approved Lat')
    rds_app_lon = fields.Char(string='RDS Approved Long')
    rds_long = fields.Char(string='RDS long')
    rds_northing = fields.Char(string='Northing')
    rds_easting = fields.Char(string='Easting')
    recieved_lettr = fields.Char(string='Received Letter')
    avg_majid = fields.Char(string='Avrage with Majid')
    avg_noor = fields.Char(string='Avrage by Noor')
    moh_plot_no = fields.Char(string='Plot No - المسلسل')
    distnc_frm_nswo = fields.Char(string='Distance from NSWO')
    owner_doc_recvd = fields.Char(string='Owner Documents Received')
    otc_layout_ready = fields.Char(string='OTC Layout ready')
    otc_layout_signed = fields.Char(string='Layout Signed by owner')
    noc_signed = fields.Char(string='NOC signed by Owner')
    building_no = fields.Char(string='Building Number')
    complex_no = fields.Char(string='Complex Number')
    way_no = fields.Char(string='Way Number')
    street_no = fields.Char(string='Street Number')
    bank_info = fields.Char(string='Bank Information')
    bank_acc_car = fields.Char(string='Bank account card received')
    owner_phn = fields.Char(string='Owner Phone')
    owner_email = fields.Char(string='Owner Email')
    owner_monthly_rent = fields.Char(string='Monthly Rent agreed with owner')
    passthrough_approved = fields.Char(string='Passthrough  Approved ?')
    passthrough_approved_rent = fields.Char(string='Passthrough Approved Rent')
    passthrough_terms = fields.Char(string='Passthrough Terms')
    otc_lease_signed_owner = fields.Char(string='OTC internal Lease signed by Owner')
    otc_lease_signed_otc = fields.Char(string='OTC internal Lease signed by OTC')
    tanency_agreemnt = fields.Char(string='Tanensy agreement')
    tan_applied_date = fields.Date(string="Tan Applied Date")
    tan_ref_num = fields.Char(string="Application Reff Number")
    lease_status = fields.Char(string="Lease Status")
    tan_remark = fields.Char(string="Tan Remark")
    modifiction_payment_caa = fields.Char(string='CAA Modification payment date')
    amount_secnd_omr_paymnt = fields.Char(string='Amount (OMR ) of Second payment')
    caa_status = fields.Char(string='CAA Status')
    demarcation_submited = fields.Char(string='Demarcation Submitted')
    new_reff_no = fields.Char(string='New Reff. No')
    no_attempts = fields.Char(string='No of Attempts')
    ibha_remarks = fields.Char(string='Ibaha Remarks ( Comment from Municipality )')
    ibha_status = fields.Char(string='Ibaha Status')
    layout_modifctn = fields.Char(string='Layout Modification')
    ibha_priorty = fields.Char(string='Ibaha Priority')
    ibha_payment = fields.Char(string='Ibaha Payment ')
    ibha_insurence = fields.Char(string='Ibha Insurance')
    ibha_recieved = fields.Char(string='Ibaha Recived')
    applied_date = fields.Char(string='MOA Applied date')
    moa_received_date = fields.Date(string="Received date")
    document_handover = fields.Char(string='Date of sending the handover documents to project to optain EP')
    excavation_recvd = fields.Char(string='Excavation Permit recived date')
    saq_srr_site_status = fields.Char(string='SAQ SRR Site Status')
    special_area = fields.Char(string='Special Area ?')
    special_area_type = fields.Char(string='Special Area Type')
    selected_candidate = fields.Char(string='Selected Candidate')
    selected_candidate = fields.Char(string='Shifting Coordinates-lat')
    selected_candidate = fields.Char(string='Shifting Coordinates-long')
    meter_no = fields.Char(string='Meter number')
    progress = fields.Float("Task Progress", compute='compute_task_progress')

    # field added for importing by Nafi
    date_applied_moh = fields.Date(string="Applied in MOH")
    send_letter_to_tra = fields.Date(string="Send Letter to TRA")
    tra_dead_line_rmv = fields.Date(string="TRA Deadline to remove RDU")
    apply_omantel_apr = fields.Date(strig="Apply for Omantel Approval")
    ot_rf_number = fields.Char(srting="OT Reference Number")
    ot_recv_date = fields.Date(string="OT Received Date")
    # project_import = fields.Char(string="Project Import")
    site_type = fields.Char(string="Site Type")
    saq_status_impt = fields.Char(string="SAQ Status IMP")
    site_category = fields.Char(string="Site Category")
    send_letter_to_moh = fields.Date(string="Send Letter to MOH")
    recieved_letter_from_moh = fields.Date(string="Recieved Letter from MOH")
    caa_received_date = fields.Date(string="CAA Received Date")
    moh_status = fields.Char(string="MOH Status")
    ep_applied_date = fields.Date(string="EP Applied date")
    perm_site_action = fields.Text(string='Permanent Site Action')
    pass_applied_date = fields.Date(string='Passthrough Applied Date')
    # additional field added from new req
    client_site = fields.Char(string="Client Site ID:", readonly=True)

    # phase_id = fields.Many2many('site.acquisition', phase1='site_phase',
    #                                phase2='site_phase', string='Tags')

    @api.depends('current_task_id')
    def compute_task_progress(self):
        for record in self:
            task_weight = sum(self.env['project.task'].search([('site_acq_id', '=', record.id)]).mapped('weight'))
            completed_task_weight = sum(self.env['project.task'].search(
                [('site_acq_id', '=', record.id),
                 ('stage_id', '=', self.env.ref('kg_tower.task_stage_confirmed').id)]).mapped('weight'))
            if task_weight != 0:
                record.progress = (completed_task_weight / task_weight) * 100
            else:
                record.progress = 0

    def comp_owner_rent_expense_count(self):
        for rec in self:
            rec.owner_rent_expense_count = self.env['project.owner.rent.expense'].search_count([('site_acq_id', '=', rec.id)])

    def comp_contractor_expense_count(self):
        for rec in self:
            rec.contractor_expense_count = self.env['project.contractor.expense'].search_count([('site_acq_id', '=', rec.id)])

    def comp_contractor_nonreco_expense_count(self):
        for rec in self:
            rec.contractor_nonreco_expense_count = self.env['project.contractor.expense.nonrecover'].search_count(
                [('site_acq_id', '=', rec.id)])



    def comp_tower_transfer_count(self):
        for rec in self:
            rec.tower_transfer_count = self.env['tower.transfer'].search_count([('site_acq_id', '=', rec.id)])

    def comp_transfer_count(self):
        for rec in self:
            rec.stock_transfer_count = self.env['stock.picking'].search_count([('site_acq_id', '=', rec.id)])

    def show_tower_transfer(self):
        for rec in self:
            # if rec.project_id and rec.project_id.internal_transfer_picking_id:
            #     picking_type_id = rec.project_id.internal_transfer_picking_id
            #
            # else:
            #     picking_type_id = self.env['stock.picking.type'].create({
            #         'name': rec.project_id.number + '- Internal',
            #         'sequence_code': rec.project_id.number,
            #         'code': 'internal',
            #         # 'company_id': self.company_a.id,
            #         'warehouse_id': False,
            #         # 'default_location_src_id': self.stock_location_a.id,
            #         'default_location_dest_id': rec.project_id.inventory_location.id,
            #         'use_create_lots':False,
            #         'use_existing_lots':True
            #
            #     })
            #     rec.project_id.internal_transfer_picking_id = picking_type_id.id
            return {
                'type': 'ir.actions.act_window',
                'name': "Tower To Project Location",
                'view_mode': 'tree,form',
                'res_model': 'tower.transfer',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': {
                    'default_site_acq_id': rec.id,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_tower_id': rec.tower_id and rec.tower_id.id or False,
                    'default_partner_id': rec.contractor_id.id or False,
                    'default_site_id': rec.client_site_id.id or False
                    #     'default_picking_type_id':picking_type_id.id,
                    #     'default_location_id':rec.project_id and rec.project_id.vendor_id and rec.project_id.vendor_id.vendor_contractor_location_id and rec.project_id.vendor_id.vendor_contractor_location_id.id or False,
                    #     'default_location_dest_id':rec.project_id and rec.project_id.inventory_location and rec.project_id.inventory_location.id or False
                    #
                }
            }

    def show_owner_rent_expense(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "Lease Agreement",
                'view_mode': 'tree,form',
                'res_model': 'project.owner.rent.expense',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': {
                    'default_partner_id': rec.owner_id.id or False,
                    'default_site_id': rec.client_site_id.id or False,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_desc': rec.remarks,
                    'default_site_acq_id': rec.id,
                }
            }


    def show_contractor_expense(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "Contractor Expense",
                'view_mode': 'tree,form',
                'res_model': 'project.contractor.expense',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': {
                    'default_partner_id': rec.contractor_id.id or False,
                    'default_site_id': rec.client_site_id.id or False,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_desc': rec.remarks,
                    'default_site_acq_id': rec.id,
                }
            }

    def show_contractor_nonreco_expense(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "Non-Recoverable Contractor Expense",
                'view_mode': 'tree,form',
                'res_model': 'project.contractor.expense.nonrecover',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': {
                    'default_partner_id': rec.contractor_id.id or False,
                    'default_site_id': rec.client_site_id.id or False,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_desc': rec.remarks,
                    'default_site_acq_id': rec.id,
                }
            }

    def show_internal_transfer(self):
        for rec in self:
            if rec.project_id and rec.project_id.internal_transfer_picking_id:
                picking_type_id = rec.project_id.internal_transfer_picking_id

            else:
                picking_type_id = self.env['stock.picking.type'].create({
                    'name': rec.project_id.number + '- Internal',
                    'sequence_code': rec.project_id.number,
                    'code': 'internal',
                    # 'company_id': self.company_a.id,
                    'warehouse_id': False,
                    # 'default_location_src_id': self.stock_location_a.id,
                    'default_location_dest_id': rec.project_id.inventory_location.id,
                    'use_create_lots': False,
                    'use_existing_lots': True

                })
                rec.project_id.internal_transfer_picking_id = picking_type_id.id
            return {
                'type': 'ir.actions.act_window',
                'name': "Tower To Project Location",
                'view_mode': 'tree,form',
                'res_model': 'stock.picking',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': {
                    'default_site_acq_id': rec.id,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_picking_type_id': picking_type_id.id,
                    'default_location_id': rec.project_id and rec.project_id.vendor_id and rec.project_id.vendor_id.vendor_contractor_location_id and rec.project_id.vendor_id.vendor_contractor_location_id.id or False,
                    'default_location_dest_id': rec.project_id and rec.project_id.inventory_location and rec.project_id.inventory_location.id or False
                }
            }

    # def show_tswo(self):
    #     for rec in self:
    #         return {
    #             'type': 'ir.actions.act_window',
    #             'name': "TSWO's",
    #             'view_mode': 'tree,form',
    #             'res_model': 'kg.tswo',
    #             'domain': [('site_acq_id', '=', rec.id)],
    #             'context': {
    #                 'default_date': fields.Date.today(),
    #                 'default_site_acq_id': rec.id,
    #                 'default_partner_id': rec.project_id and rec.project_id.vendor_id and rec.project_id.vendor_id.id or False,
    #                 'default_project_id':rec.project_id and rec.project_id.id or False,
    #                 'default_governorate':rec.wilayat_id.governorate_id.id or False,
    #                 'default_work_order_no':rec.project_id.work_order_id.name or False,
    #                 'default_work_order_date':rec.project_id.work_order_id.work_order_date or False,
    #                 'default_client_site_id':rec.project_id.work_order_id.client_site_id.id or False
    #             }
    #         }

    def show_create_construction(self):
        for rec in self:
            construction = self.env['site.construction'].search(
                [('project_id', '=', rec.project_id.id),
                 ('client_site_id', '=', rec.client_site_id.id)])

            if construction:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Construction',
                    'view_mode': 'tree,form',
                    'res_model': 'site.construction',
                    'domain': [('id', 'in', construction.ids)],
                    'context': "{'create': False}",

                }
            else:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Site Construction',
                    'view_mode': 'form',
                    'res_model': 'site.construction',
                    'context': {
                        'default_partner_id': rec.partner_id.id,
                        'default_client_work_order_no': rec.client_work_order_no,
                        'default_project_id': rec.project_id.id,
                        'default_client_site_id': rec.client_site_id.id,
                        'default_tower_id': rec.tower_id.id,
                        'default_work_order_id': rec.nswo_id.id,
                        'default_site_acq_id': rec.id,
                        'default_contractor_id': rec.contractor_id.id,
                    }
                }

    def comp_task_count(self):
        for record in self:
            record.task_count = self.env['project.task'].search_count(
                [('site_acq_id', '=', record.id)])

    def show_tasks(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Tasks',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.task',
                'domain': [('site_acq_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>

                                <th scope="col">Status</th>

                            </tr>
                        </thead>
                        <tbody>

                """
            count = 1
            for task in self.env['project.task'].search([('site_acq_id', '=', rec.id)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('site.acquisition') or _('New')
        return super(SiteAcquisition, self).create(vals)

    def action_confirm(self):
        self.notify_users('kg_tower.group_saq_user')

        project = self.env['project.project']
        task = self.env['project.task']
        existing_nswo = self.nswo_id or False
        if not existing_nswo:
            raise UserError(_('NSWO not linked with site aquisition!'))
        self.structure_type_id = existing_nswo.structure_type_id.id
        partner = self.partner_id.get_operator_id()
        task_lists = self.env['task.list'].search(
            [('partner_id', '=', partner), ('structure_type_id', '=', existing_nswo.structure_type_id.id)],
            limit=1)
        if task_lists:
            users = self.env['res.users'].search([('partner_id', '=', self.partner_id.id)], limit=1)
            allowed_user_ids = False
            if users:
                allowed_user_ids = [[6, 0, [users.id]]]

            for rec in task_lists:
                # existing_nswo = self.env['work.order'].search(
                #     [('client_work_order_no', '=', self.client_work_order_no)], limit=1)
                if existing_nswo:
                    project_id = self.env['project.task'].search([('work_order_id', '=', existing_nswo.id)],
                                                                 limit=1) and self.env['project.task'].search(
                        [('work_order_id', '=', existing_nswo.id)], limit=1).project_id or False
                    open_tasks = self.env['project.task'].search([('work_order_id', '=', existing_nswo.id), (
                        'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)])
                    self.client_site_id = existing_nswo.client_site_id.id

                    # if open_tasks:
                    #     raise UserError(_('Please complete Work Order Stage'))
                    print('project_id>>>>', project_id)
                    if project_id:
                        self.project_id = project_id.id
                        if self.existing_site:
                            task_list_obj = rec.existing_list_lines
                        else:
                            task_list_obj = rec.list_lines
                        prev_task = False

                        for lines in task_list_obj.sorted('sequence'):

                            if lines.progress == 'site':
                                if not prev_task:
                                    current_date = fields.Date.today()
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)
                                else:
                                    current_date = prev_task.date_deadline
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)

                                vals = {
                                    'project_id': project_id.id,
                                    'name': lines.kg_task_id,
                                    'department_id': lines.department_id.id,
                                    'work_flow': lines.work_flow,
                                    'progress_level': lines.progress,
                                    'weight': lines.weight,
                                    'completion_task': lines.completion_task,
                                    'gf_construction': lines.gf_construction,
                                    'collacation': lines.collacation,
                                    'roof_top': lines.roof_top,
                                    'sequence': lines.sequence,
                                    'partner_id': self.partner_id.id,
                                    'site_acq_id': self.id,
                                    'user_id': lines.user_id.id or False,

                                    'allowed_user_ids': allowed_user_ids,
                                    'override_sequence': lines.override_sequence,
                                    'milestone_task': lines.milestone_task,
                                    'date_deadline': deadline,
                                    'proposed_date_deadline': deadline,
                                    'attach_mandatory': lines.attach_mandatory

                                }
                                print('vals:', vals)
                                prev_task = task.create(vals)
                        task_schedule = self.env['project.task'].search(
                            [('project_id', '=', project_id.id), ('site_acq_id', '=', self.id), (
                                'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1,
                            order="sequence asc")
                        print('TaskList', task_schedule)
                        if task_schedule:
                            self.current_task_id = task_schedule.id
                            self.current_task_status = task_schedule.name
                            activity = self.env['mail.activity'].sudo().create({
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'res_id': task_schedule.id,
                                'user_id': task_schedule.user_id.id,
                                # 'date_deadline':deadline,
                                'res_model_id': self.env.ref('project.model_project_task').id,
                            })
                            print(":activity", activity)
                            activity._onchange_activity_type_id()
        else:
            raise UserError(_('Please set Task Lists First'))
        self.state = 'confirm'

    def action_open_documents(self):
        self.ensure_one()
        project_name = self.project_id.name
        saq_project_folder = self.env['documents.folder'].search(
            [('name', '=', project_name), ('model', '=', 'site.acquisition'), ('res_id', '=', self.id)])
        action = self.env['ir.actions.act_window']._for_xml_id('documents.document_action')
        action['context'] = {
            'searchpanel_default_folder_id': saq_project_folder and saq_project_folder.id,
        }
        return action



class ProjectKg(models.Model):
    _inherit = 'project.project'

    saq_ids = fields.One2many('site.acquisition', 'project_id', string='Site Acquisition Id')
    nswo_ids = fields.One2many('work.order', 'project_id', string='Nswo Id')

    def attachment_tree_view(self):
        """OVERRIDE"""
        action = self.env['ir.actions.act_window']._for_xml_id('base.action_attachment')
        action['domain'] = str([
            '|',
            '|',
            '|',
            '&',
            ('res_model', '=', 'project.project'),
            ('res_id', 'in', self.ids),
            '&',
            ('res_model', '=', 'project.task'),
            ('res_id', 'in', self.task_ids.ids),
            '&',
            ('res_model', '=', 'site.acquisition'),
            ('res_id', 'in', self.saq_ids.ids),
            '&',
            ('res_model', '=', 'work.order'),
            ('res_id', 'in', self.nswo_ids.ids),
        ])
        action['context'] = "{'default_res_model': '%s','default_res_id': %d}" % (self._name, self.id)
        return action

    def _compute_attached_docs_count(self):
        """OVERRIDE"""
        Attachment = self.env['ir.attachment']
        for project in self:
            project.doc_count = Attachment.search_count([
                '|',
                '|',
                '|',
                '&',
                ('res_model', '=', 'project.project'), ('res_id', '=', project.id),
                '&',
                ('res_model', '=', 'project.task'), ('res_id', 'in', project.task_ids.ids),
                '&',
                ('res_model', '=', 'site.acquisition'), ('res_id', 'in', self.saq_ids.ids),
                '&',
                ('res_model', '=', 'work.order'), ('res_id', 'in', self.nswo_ids.ids),
            ])
