from odoo import fields, models


class Partner(models.Model):
    _inherit = 'res.partner'

    # vendor visibility in portal
    show_nswo = fields.Boolean('Show NSWO in Portal')
    show_srr = fields.Boolean('Show SRR in Portal')
