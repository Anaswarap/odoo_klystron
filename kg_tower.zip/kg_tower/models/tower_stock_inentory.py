from odoo import models, api, fields, _
import logging, requests, json, re

from odoo.exceptions import ValidationError
from datetime import date, datetime, timedelta
from odoo.tools.config import config
from threading import Thread
from odoo import SUPERUSER_ID
import io


class TowerStockInventory(models.Model):
    _name = 'tower.stock.inventory'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _mail_post_access = 'read'

    name = fields.Char(string='Name', copy=False, readonly=True, index=True, default=lambda self: _('New'))
    tower_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, readonly=False)
    saq_status = fields.Selection(selection=[('handover', 'Handover'),('handover without ibaha', 'Handover Without Ibaha'),
                                             ('handover-ep','Handover-EP'),('handover-rds','Handover-RDS'),('special project', 'Special Project'),('still not handed','Still not Handed')], string='SAQ Status', copy=False, tracking=True)
    supplier_id = fields.Many2one('res.partner', 'Supplier', tracking=True)
    tower_model = fields.Many2one('product.template', string='Tower Model')
    m_ext = fields.Char( string='3m Ext')
    cw_status = fields.Char( string='CW status')
    so_twr = fields.Char( string='SO #')
    order_type = fields.Char( string='Order Type')
    tower_state = fields.Selection(
        [('available', 'Available'), ('assigned', 'Assigned'), ('sold', 'Sold'), ('installed', 'Installed'),
         ('ordered', 'Ordered'),
         ('To be fabricated', 'To be fabricated'), ('To be ordered', 'To be ordered'), ('pre_assign', 'Pre-Assigned')],
        default='available', string='Status')

    payment_confirmation = fields.Char( string='Payment confirmation')
    tower_remarks = fields.Char( string='Remarks')
    portion_paid = fields.Float( string='Portion to be paid in SO (OMR)')
    amount_paid = fields.Float( string='Amount to be paid in SO (OMR)')
    tower_cost = fields.Float( string='Tower Cost')
    remainder_paid = fields.Float( string='Remainder to be paid')
    state = fields.Selection(
        selection=[('draft', 'Draft'), ('submited', 'Submited'),  ('cancel', 'Cancelled'), ],
        string='Status', required=True, readonly=True, copy=False, tracking=True, default='draft')


    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'): vals['name'] = self.env['ir.sequence'].next_by_code(
            'tower.stock.inventory') or _('New')
        request = super(TowerStockInventory, self).create(vals)
        return request

    def btn_cancel(self):
        self.write({'state': 'cancel'})

    def btn_submit(self):
        self.write({'state': 'Submited'})

