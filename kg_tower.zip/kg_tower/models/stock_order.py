from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError
import ast


class StockOrder(models.Model):
    _name = 'stock.order'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'kg.approval.transaction']
    _description = 'Stock Order'

    @api.model
    def _company_get(self):
        company_id = self.env['res.company']._company_default_get(self._name)
        return self.env['res.company'].browse(company_id.id)

    name = fields.Char(
        'Stock Order No',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
    )
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    description = fields.Char('Description')
    project_id = fields.Many2one('project.project', 'Project', tracking=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id)
    date = fields.Date('Date', default=fields.Date.today())
    vendor_id = fields.Many2one('res.partner', 'Vendor', tracking=True, domain=[('supplier_rank', '=', 1)])
    partner_id = fields.Many2one('res.partner', 'Contractor', tracking=True, domain=[('contractor', '=', True)])
    # stock_order_no = fields.Char('Work Order No')
    stock_order_date = fields.Date('Stock Order Date')
    work_comm_date = fields.Date('Work Commencement Date')
    governorate = fields.Many2one('kg.governorate', 'Governorate')
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    amount_subtotal = fields.Monetary('Subtotal', compute='comp_total', store=True)
    grid_extension = fields.Monetary('Grid Extension')
    amount_total = fields.Monetary('Total', compute='comp_total', store=True)
    notes = fields.Text('Notes')
    special_instr = fields.Text('Special Instructions')
    stock_order_line_ids = fields.One2many('stock.order.line', 'stock_order_id', copy=True, string='Stock Order Lines')
    state = fields.Selection([('draft', 'Draft'), ('approval_one', 'Approved by Senior Engg'),
                              ('approval_two', 'Approved by Project Dept'),
                              ('approval_three', 'Approved by Supply Chain'),
                              ('approval_four', 'Approved by Finance'),
                              ('approval_five', 'Approved by GM'),
                              ('done', 'Done'),
                              ('cancel', 'Cancelled')], string='Status', default='draft', tracking=True)

    approval_one_user_id = fields.Many2one('res.users')
    approval_two_user_id = fields.Many2one('res.users')
    approval_three_user_id = fields.Many2one('res.users')
    approval_four_user_id = fields.Many2one('res.users')
    approval_five_user_id = fields.Many2one('res.users')

    total_amount_in_words = fields.Char(
        string="Amount in Words",
        store=True,
        compute='_compute_total_amt_in_words',
    )
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    construction_id = fields.Many2one(
        comodel_name='site.construction',
        string='Construction',
        required=False)

    so_schedule_comp_date = fields.Date('SO Delivery Date')
    inv_count = fields.Integer('# Invoices', compute='comp_inv_count')

    company_id = fields.Many2one('res.company',
                                 required=True,
                                 default=_company_get)
    tower_transfer_id = fields.Many2one(
        comodel_name='tower.transfer',
        string='Tower Transfer',
        required=False)
    picking_type_id = fields.Many2one(
        comodel_name='stock.picking.type',
        string='Deliver To',
        required=False)
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string='Payment Terms',
        required=False)
    picking_count = fields.Integer('SO Count', compute='comp_picking_count')

    # field added by Nafi
    milestone_ids = fields.One2many(
        comodel_name='so.project.milestone',
        inverse_name='stock_order_id',
        string='Milestone', )
    project_ids = fields.Many2many('project.project', string="Projects")
    order_type = fields.Char(string="Order Type")
    stock_order_no_imp = fields.Char(string="Stock Order No")
    invoices_ids = fields.One2many('stock.invoice', 'stock_id', string="Invoices")

    def comp_picking_count(self):
        for record in self:
            record.picking_count = self.env['stock.picking'].search_count(
                [('stock_order_id', '=', record.id)])

    def print_stock_order_report(self):
        return self.env.ref('kg_tower.action_stock_order_report').report_action(self)

    #
    # def send_mail(self):
    #     template_id = self.env.ref('kg_tower.email_template_tswo')
    #     print(template_id, 'template_id')
    #     template_id.send_mail(self.id, force_send=True)

    # @api.constrains('project_id')
    # def _check_max_tenant_limit_tswo_project(self):
    #     for rec in self:
    #         max_tenants = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.max_tenants'))
    #         current_tenants_tswo = self.env['kg.tswo'].search_count([('project_id', '=', rec.project_id.id)])
    #         if current_tenants_tswo > max_tenants:
    #             raise UserError(_("Only %s Tenant TSWO's Allowed", str(max_tenants)))

    @api.depends('currency_id', 'amount_total')
    def _compute_total_amt_in_words(self):
        for pay in self:
            if pay.currency_id:
                pay.total_amount_in_words = pay.currency_id.amount_to_text(pay.amount_total)
            else:
                pay.total_amount_in_words = ''

    @api.onchange('partner_id')
    def onchange_vendor_contract(self):
        for rec in self:
            if rec.partner_id:
                rec.picking_type_id = rec.partner_id.vendor_picking_type_id and rec.partner_id.vendor_picking_type_id.id or False

    def action_cancel(self):
        self.state = 'cancel'

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('kg.stock.order') or _('New')

        res = super(StockOrder, self).create(vals)
        seq = self.env['contract.pricelist.contractor.sequence.so'].search(
            [('contract_pricelist_id', '=', vals.get('contract_no')),
             ('partner_id', '=', vals.get('partner_id'))], limit=1)
        if not seq:
            raise UserError('Contractor not linked in UPL')
        if res.partner_id and res.contract_no:
            if res.partner_id.contractor_sequence:
                stock_order_no = 'SO-' + str(res.contract_no.name) + '-' + str(res.partner_id.con_seq_code) + '-' + str(
                    fields.Date.today().year) + "-" + seq.sequence_id.next_by_id()
                res.name = stock_order_no
        return res

    @api.depends('stock_order_line_ids.price_subtotal', 'grid_extension')
    def comp_total(self):
        for rec in self:
            subtot = 0
            other = rec.grid_extension
            for line in rec.stock_order_line_ids:
                subtot += line.price_subtotal
            rec.amount_subtotal = subtot
            rec.amount_total = subtot + other

    @api.onchange('governorate')
    def onchange_gov(self):
        for rec in self:
            for line in rec.stock_order_line_ids:
                line.governorate = rec.governorate.id

    @api.onchange('contract_no')
    def onchange_contract_no(self):

        for rec in self:
            line = []
            rec.description = rec.contract_no.contract_title

    #         if rec.tower_transfer_id and rec.tower_transfer_id.tower_id and rec.contract_no:
    #             contract_line_product = rec.tower_transfer_id.tower_id
    #             if rec.stock_order_line_ids:
    #                 rec.stock_order_line_ids = [(5, 0, 0)]
    #             contract_pricelist_obj = self.env['contract.pricelist.line'].sudo()
    #             product = contract_pricelist_obj.search(
    #                 [('contract_pricelist_id', '=', rec.contract_no.id), ('product_id', '=', contract_line_product.id)])
    #             line.append(
    #                 (0, 0, {
    #                     'contract_line_id': product.id,
    #                     'product_id': product.product_id.id,
    #                     'name': product.product_id.name,
    #                     'product_uom_id': product.product_id.uom_id.id,
    #                     'product_qty': 1,
    #                     'equipment_cost': product.equipment_cost,
    #
    #                 }))
    #             rec.update({'stock_order_line_ids': line})

    '''New states and notification added to Stock Order'''

    def notify_users(self, allowed_user_ids, allowed_group):
        self.activity_unlink(['kg_tower.stock_order_approval'])
        print(allowed_user_ids, allowed_group)
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.stock_order_approval', note=user.name, user_id=user.id)
        if allowed_user_ids:
            user_ids = allowed_user_ids.split(',')
            user_ids = list(map(int, user_ids))
            for user in self.env['res.users'].browse(user_ids):
                self.activity_schedule('kg_tower.stock_order_approval', note=user.name, user_id=user.id)

        return True

    def action_approve_senior_engg(self):
        self.notify_users(False, 'project.group_project_manager')
        self.approval_one_user_id = self.env.user.id

        self.state = 'approval_one'

    def action_approve_project_dept(self):
        self.notify_users(False, 'stock.group_stock_manager')
        self.state = 'approval_two'
        self.approval_two_user_id = self.env.user.id

    def action_approve_supply_chain(self):
        self.notify_users(False, 'account.group_account_manager')
        self.approval_three_user_id = self.env.user.id

        self.state = 'approval_three'

    def action_approve_finance(self):
        self.notify_users(False, 'kg_tower.group_second_authoriser')
        self.approval_four_user_id = self.env.user.id

        self.state = 'approval_four'

    def action_approve_gm(self):
        self.approval_five_user_id = self.env.user.id

        self.state = 'approval_five'

    def action_done(self):

        for rec in self:
            self.create_invoices()
            # self.send_mail()
            vals_inv = {}
            vals_inv['stock_order_id'] = rec.id
            vals_inv['site_acq_id'] = rec.site_acq_id.id
            vals_inv['project_id'] = rec.project_id and rec.project_id.id or False
            vals_inv['partner_id'] = rec.vendor_id and rec.vendor_id.id or False
            vendor_picking_type_id = rec.partner_id.vendor_picking_type_id
            print("vendor_picking_type_id", vendor_picking_type_id)
            vals_inv['picking_type_id'] = vendor_picking_type_id and vendor_picking_type_id.id or False
            vals_inv[
                'location_id'] = vendor_picking_type_id and vendor_picking_type_id.default_location_src_id.id or False
            vals_inv[
                'location_dest_id'] = rec.partner_id and rec.partner_id.vendor_contractor_location_id and rec.partner_id.vendor_contractor_location_id.id or False

            inv_lines = []
            lot_count = 1

            if not vals_inv['location_id']:
                raise UserError("Define source location in contractor receipt.")
            for line in rec.stock_order_line_ids:
                for qty_as in range(0, int(line.product_qty)):
                    create_lot = self.env['stock.production.lot'].create(
                        {
                            'name': rec.name + '-' + (line.product_id.default_code if line.product_id.default_code else line.product_id.name )+ '-' + str(
                                lot_count),
                            'product_id': line.product_id.id,
                            'company_id': self.env.company.id,
                            'product_qty': 1,
                            'stock_order_id': rec.id,
                            'payment_term_id': rec.payment_term_id and rec.payment_term_id.id or False,
                            })
                    create_lot.order_type = self.order_type
                    a = (0, 0, {
                        'description_picking': line.product_id.name,
                        'product_id': line.product_id.id,
                        'location_id': vals_inv['location_id'],
                        'location_dest_id': vals_inv['location_dest_id'],
                        'qty_done': 1,
                        'lot_id': create_lot.id,
                        'product_uom_id': line.product_id.uom_id.id
                    })
                    inv_lines.append(a)
                    lot_count += 1
            vals_inv['move_line_ids_without_package'] = inv_lines
            milestone_percentage = sum(self.milestone_ids.mapped('milestone_per'))
            if self.milestone_ids:
                if milestone_percentage != 100.0:
                    raise ValidationError("Milestone Should be 100 %")
            self.env['stock.picking'].create(vals_inv)
            for record in self.milestone_ids:
                milestone_per = (record.milestone_per / 100)
                milestone = {'milestone_no': record.milestone_no,
                             'milestone': record.milestone,
                             'milestone_per': milestone_per}
                for project in self.project_ids:
                    project.sudo().update({'milestone_ids': [(0, 0, milestone)]})
            self.state = 'done'
            return {
                'type': 'ir.actions.act_window',
                'name': "Stock Order Receipt",
                'view_mode': 'tree,form',
                'res_model': 'stock.picking',
                'domain': [('stock_order_id', '=', rec.id)],
                'context': {

                    'default_tower_transfer_id': rec.id,
                    'default_site_acq_id': rec.site_acq_id.id,
                    'default_stock_order_id': rec.id,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_picking_type_id': vals_inv['picking_type_id'],
                    'default_location_id': vals_inv['location_id'],
                    'default_location_dest_id': vals_inv['location_dest_id'],
                }
            }

    def show_pickings(self):
        for rec in self:
            vendor_picking_type_id = rec.partner_id.vendor_picking_type_id
            return {
                'type': 'ir.actions.act_window',
                'name': "Stock Order Receipt",
                'view_mode': 'tree,form',
                'res_model': 'stock.picking',
                'domain': [('stock_order_id', '=', rec.id)],
                'context': {

                    'default_tower_transfer_id': rec.id,
                    'default_site_acq_id': rec.site_acq_id.id,
                    'default_stock_order_id': rec.id,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_picking_type_id': vendor_picking_type_id and vendor_picking_type_id.id or False,
                    'default_location_id': vendor_picking_type_id and vendor_picking_type_id.default_location_src_id.id or False,
                    'default_location_dest_id': rec.partner_id and rec.partner_id.vendor_contractor_location_id and rec.partner_id.vendor_contractor_location_id.id or False,
                }
            }

    def comp_inv_count(self):
        for record in self:
            record.inv_count = self.env['account.move'].search_count(
                [('stock_order_id', '=', record.id)])

    def show_invoices(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Vendor/Contractor Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('stock_order_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def create_invoices(self):
        for rec in self:

            vals_inv = {}
            vals_inv['invoice_date'] = rec.date
            vals_inv['move_type'] = 'in_invoice'
            vals_inv['stock_order_id'] = rec.id
            vals_inv['partner_id'] = rec.partner_id.id

            inv_lines = []
            if not rec.company_id.stock_order_acc_id:
                raise ValidationError("Please Specify Stock Order Account in Accounting Configuration")
            for item in rec.stock_order_line_ids:
                a = (0, 0, {
                    'quantity': item.product_qty,
                    'price_unit': item.price_subtotal,
                    'name': item.name,
                    'product_id': item.product_id and item.product_id.id or False,
                    'analytic_account_id': rec.contract_no.analytic_id.id,
                    'account_id':rec.company_id.stock_order_acc_id.id,
                })

                inv_lines.append(a)
            print("inv_lines", inv_lines)
            # dkfjhewjfwelhfj
            vals_inv['invoice_line_ids'] = inv_lines
            inv = self.env['account.move'].create(vals_inv)
            inv.action_post()

    '''
        ----------------------Approval Module Changes----------------------
        Approval Section field override to mentioned corresponding model.
        '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='stock.order')

    '''
    Inherit final approve and post payment. 
    '''

    def send_back(self):
        res = super(StockOrder, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res
    def kg_final_approval(self):
        """" Supering method which is defined in the kg approval to approve stock order and
        rise invoice if it is final approval"""
        res = super(StockOrder, self).kg_final_approval()
        self.action_done()
        return res

    '''
    Get approval details for print.
    '''

    def get_approve_details(self):
        approval_list = []
        if self.approved_list:
            data = ast.literal_eval(self.approved_list)
            for ad in data:
                user = ""
                if 'user_approved' in ad:
                    user_obj = self.env['res.users'].browse(ad['user_approved'])
                    user = user_obj
                    approval_level = (ad['approval_level'])
                    approval_dict = {'user': user,
                                     'approval_level': approval_level}
                    approval_list.append(approval_dict)

            return approval_list


class StockOrderLine(models.Model):
    _name = 'stock.order.line'

    _description = 'Stock Order Line'

    sequence = fields.Integer('Sequence', default=20)
    name = fields.Char('Description')
    contract_line_id = fields.Many2one('contract.pricelist.line', 'Item Code')
    product_id = fields.Many2one(
        'product.product', 'Product')
    product_tmpl_id = fields.Many2one('product.template', related="product_id.product_tmpl_id", readonly=True)
    product_qty = fields.Float(
        'Quantity', default=1.0, )
    product_uom_id = fields.Many2one(
        'uom.uom', 'Unit of Measure',
    )

    governorate = fields.Many2one('kg.governorate', 'Governorate')
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    equipment_cost = fields.Float('Equipment Cost', digits="OTC Decimal")
    price_subtotal = fields.Float('Subtotal', compute='comp_total', digits="OTC Decimal")
    stock_order_id = fields.Many2one('stock.order', string='Stock Order Reference', ondelete='cascade', copy=False)

    @api.onchange('contract_line_id')
    def onchange_contract_line_id(self):
        for rec in self:
            rec.product_id = rec.contract_line_id.product_id.id
            rec.product_uom_id = rec.contract_line_id.product_uom_id and rec.contract_line_id.product_uom_id.id or rec.product_id.uom_id.id

    @api.onchange('product_id')
    def onchange_product_id(self):
        for rec in self:
            rec.name = rec.product_id.name
            # rec.product_uom_id = rec.product_id.uom_id.id

    @api.onchange('contract_no', 'product_id')
    def onchange_contract_no(self):
        for rec in self:
            for line in rec.contract_no.pricelist_line_ids:
                if line.product_id == rec.product_id:
                    rec.equipment_cost = line.equipment_cost
                    break
                else:
                    rec.equipment_cost = 0.0

    @api.depends('equipment_cost', 'product_qty')
    def comp_total(self):
        for rec in self:
            total = rec.equipment_cost * rec.product_qty
            rec.price_subtotal = total


class SOProjectMilestone(models.Model):
    _name = 'so.project.milestone'
    _description = 'SO Project Milestone'
    _rec_name = 'milestone'

    stock_order_id = fields.Many2one('stock.order', string="Stock Order")
    milestone_no = fields.Char(string="Milestone No", readonly=True, required=True, copy=False, default='New')
    milestone_per = fields.Float()
    milestone = fields.Char()

    @api.model
    def create(self, vals):
        if vals.get('milestone_no', 'New') == 'New':
            vals['milestone_no'] = self.env['ir.sequence'].next_by_code('so.project.milestone') or 'New'

        res = super(SOProjectMilestone, self).create(vals)
        return res


class StockOrderInvoice(models.Model):
    _name = 'stock.invoice'
    _description = 'Stock Order Invoice'

    stock_id = fields.Many2one('stock.order', string="Stock Order")
    serial_number = fields.Char(string="SR No:", copy=False, readonly=True, default=lambda x: _('New'), required=True)
    invoice_percentage = fields.Float(string="Invoice percentage %")
    date_of_invoice = fields.Date(string="Invoice Date")
    invoice_id = fields.Many2one('account.move', string="invoice", readonly=True)

    @api.model
    def create(self, vals):
        if vals.get('serial_number', _('New')) == _('New'):
            vals['serial_number'] = self.env['ir.sequence'].next_by_code('stock.invoice') or _('New')
        res = super(StockOrderInvoice, self).create(vals)
        return res
