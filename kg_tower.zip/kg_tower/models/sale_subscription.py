# -*- coding: utf-8 -*-


from dateutil.relativedelta import relativedelta
from odoo import fields, models, _
from odoo.exceptions import UserError
from odoo.tools import format_date


class SaleSubscriptionInherit(models.Model):
    _inherit = 'sale.subscription'

    journal_id = fields.Many2one('account.journal', string="Journal", required=True)
    partner_id = fields.Many2one('res.partner', string='Partner', required=True, auto_join=True,
                                 domain="['|',('company_id', '=', False), ('company_id', '=', company_id), ('owner', '=', True)]")
    site_id = fields.Many2one('account.asset.site', string="Site")
    tax_ids = fields.Many2many('account.tax', string="Tax")

    """overwrite existing subscription create action switch to vendor bill """

    def _prepare_invoice_data(self):
        self.ensure_one()

        if not self.partner_id:
            raise UserError(_("You must first select a Customer for Subscription %s!", self.name))

        company = self.env.company or self.company_id

        journal = self.template_id.journal_id or self.env['account.journal'].search(
            [('type', '=', 'sale'), ('company_id', '=', company.id)], limit=1)
        if not journal:
            raise UserError(_('Please define a sale journal for the company "%s".') % (company.name or '',))

        next_date = self.recurring_next_date
        if not next_date:
            raise UserError(_('Please define Date of Next Invoice of "%s".') % (self.display_name,))
        recurring_next_date = self._get_recurring_next_date(self.recurring_rule_type, self.recurring_interval,
                                                            next_date, self.recurring_invoice_day)
        end_date = fields.Date.from_string(recurring_next_date) - relativedelta(
            days=1)  # remove 1 day as normal people thinks in term of inclusive ranges.
        addr = self.partner_id.address_get(['delivery', 'invoice'])
        sale_order = self.env['sale.order'].search([('order_line.subscription_id', 'in', self.ids)], order="id desc",
                                                   limit=1)
        use_sale_order = sale_order and sale_order.partner_id == self.partner_id
        partner_id = sale_order.partner_invoice_id.id if use_sale_order else self.partner_invoice_id.id or addr[
            'invoice']
        partner_shipping_id = sale_order.partner_shipping_id.id if use_sale_order else self.partner_shipping_id.id or \
                                                                                       addr['delivery']
        fpos = self.env['account.fiscal.position'].with_company(company).get_fiscal_position(self.partner_id.id,
                                                                                             partner_shipping_id)
        narration = _("This invoice covers the following period: %s - %s") % (
            format_date(self.env, next_date), format_date(self.env, end_date))
        if self.env['ir.config_parameter'].sudo().get_param(
                'account.use_invoice_terms') and self.company_id.invoice_terms:
            narration += '\n' + self.company_id.invoice_terms
        res = {
            'move_type': 'in_invoice',
            'partner_id': partner_id,
            'partner_shipping_id': partner_shipping_id,
            'currency_id': self.pricelist_id.currency_id.id,
            'journal_id': self.journal_id.id,
            'invoice_date': self.recurring_next_date,
            'invoice_origin': self.code,
            'fiscal_position_id': fpos.id,
            'invoice_payment_term_id': self.payment_term_id.id,
            'narration': narration,
            'site_id': self.site_id.id,
            'invoice_user_id': self.user_id.id,
            'partner_bank_id': company.partner_id.bank_ids.filtered(
                lambda b: not b.company_id or b.company_id == company)[:1].id,
        }
        if self.team_id:
            res['team_id'] = self.team_id.id
        return res

    """overwrite existing subscription invoice line to specify tax from subscription form directly """

    def _prepare_invoice_line(self, line, fiscal_position, date_start=False, date_stop=False):
        company = self.env.company or line.analytic_account_id.company_id
        # default tax fetching 👇
        # tax_ids = line.product_id.taxes_id.filtered(lambda t: t.company_id == company)
        taxes = self.tax_ids
        # if fiscal_position:
        # tax_ids = self.env['account.fiscal.position'].browse(fiscal_position).map_tax(tax_ids)
        return {
            'name': line.name,
            'subscription_id': line.analytic_account_id.id,
            'price_unit': line.price_unit or 0.0,
            'discount': line.discount,
            'quantity': line.quantity,
            'product_uom_id': line.uom_id.id,
            'product_id': line.product_id.id,
            'tax_ids': [(6, 0, taxes.ids)],
            'analytic_account_id': line.analytic_account_id.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, line.analytic_account_id.tag_ids.ids)],
            'subscription_start_date': date_start,
            'subscription_end_date': date_stop,
        }
