from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class RFINotice(models.Model):
    _name = 'rfi.notice'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'RFI Notice Issued'

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    partner_id = fields.Many2one('res.partner',
                                 string='Client',
                                 required=True,
                                 tracking=True,domain=[('operator', '=', True)])
    client_work_order_no = fields.Char(
        string='Client Work Order No',
        required=False,
        tracking=True)

    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, )
    project_id = fields.Many2one('project.project', 'Project', tracking=True)
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    existing_site = fields.Boolean(
        string='Existing Site',
        default=False,
        tracking=True)
    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'), ])
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')

    indi_target_rfi_date = fields.Date('Indicative Target RFI Date', tracking=True, )
    rfi_notice_date = fields.Date('RFI Notice Date', tracking=True, )
    tenant_foi_date = fields.Date('Tenant 1st Day of Install', tracking=True, )
    tenant_oa_date = fields.Date('Tenant On-Air Date', tracking=True, )
    acceptance_date = fields.Date('Acceptance Date', tracking=True, )
    pad_lock_no = fields.Char('Pad Lock #')

    task_status = fields.Char('Task Status', compute='comp_task_status')
    task_count = fields.Integer('Task Count', compute='comp_task_count')

    initial_invoice_id = fields.Many2one('tower.invoice','Tower invoice')

    '''[FIX] Added fields for site commen,equipment and power conn date
    '''
    scd_date = fields.Date('Site Commencement Date', store=True, compute='comp_scd_date')
    equipment_date = fields.Date('Equipment Install Date')
    power_conn_date = fields.Date('Power Connection Date')

    work_order_id = fields.Many2one('work.order', 'Work Order')

    '''[IMP]Added required tower height ,audited and actual tower height
    '''

    required_tower_height = fields.Many2one(
        comodel_name='tower.height',
        related='work_order_id.tower_height', tracking=True, string='Required Height')



    audited_tower_height = fields.Float('Audited Height')
    actual_input_tower_height = fields.Float('Actual Input Height')
    actual_tower_height = fields.Float('Actual Height', store=True, compute='comp_actual_height')

    closest_tower_height = fields.Many2one('tower.height',string='Closest Tower Height',store=True,compute='comp_closest_height')

    required_epa_allowance = fields.Many2one(comodel_name='epa.allowance',
        related='work_order_id.epa_allowance', tracking=True, string='Required EPA Allowance')

    audited_epa_allowance = fields.Float('Audited EPA Allowance', digits="OTC Decimal")

    actual_input_epa_allowance = fields.Float('Actual Input EPA Allowance', digits="OTC Decimal")

    actual_epa_allowance = fields.Float('Actual EPA Allowance', store=True, compute='comp_actual_epa_allowance', digits="OTC Decimal")
    epa_allowance_difference = fields.Float('EPA Allowance difference',compute='get_difference' ,digits="OTC Decimal",help='Difference of actual and required epa allowance in case required epa less than actual epa ')


    closest_epa_allowance = fields.Many2one('epa.allowance',string='Closest EPA Allowance',store=True,compute='comp_closest_epa')

    rent = fields.Float('Monthly Rent',compute='compute_rent',store=True, digits="OTC Decimal")

    current_task_id = fields.Many2one('project.task','Current Task')

    current_task_status = fields.Char('Current Status')

    snags_date = fields.Date(string='Notification of Snags')
    first_snags_date = fields.Date(string='first notification of snags')
    otc_snags_cleared_date = fields.Date(string='OTC Notification of Snags Cleared')
    otc_1st_snags_cleared_date = fields.Date(string='OTC 1st snag clearance notice')
    acceptance_date = fields.Date(string='Acceptance Date')
    final_rfi_date = fields.Date(string='Final RFI Date')
    equipment_installation_date = fields.Date(string='Equipment Installation Date')
    actual_site_commencement_date = fields.Date(string='Actual Site Commencement Date')
    remarks = fields.Char("Remarks")
    ####imp###
    snags_date_imp = fields.Char(string='Notification of Snags Imp')
    first_snags_date_imp = fields.Char(string='first notification of snags Imp')
    otc_snags_cleared_date_imp = fields.Char(string='OTC Notification of Snags Cleared Imp')
    otc_1st_snags_cleared_date_imp = fields.Char(string='OTC 1st snag clearance notice Imp')
    # new field added by Nafi by req
    required_tower = fields.Float("Required Height", related='work_order_id.tower_height_input')
    client_site = fields.Char(string="Client Site ID:")

    @api.depends('actual_epa_allowance', 'required_epa_allowance')
    def get_difference(self):
        for rec in self:
            rec.epa_allowance_difference = 0.00
            if rec.required_epa_allowance.name:
                req_alwnce = float(rec.required_epa_allowance.name)
                if req_alwnce < rec.actual_epa_allowance:
                    rec.epa_allowance_difference = rec.actual_epa_allowance - req_alwnce

    @api.depends('required_tower_height', 'audited_tower_height','actual_input_tower_height')
    def comp_actual_height(self):
        for rec in self:
            required_tower_height = rec.required_tower_height.name or 0.0
            actual_input_tower_height = rec.actual_input_tower_height
            audited_tower_height = rec.audited_tower_height
            actual = max(float(required_tower_height), audited_tower_height, actual_input_tower_height)
            rec.actual_tower_height = actual

    @api.depends('required_epa_allowance', 'audited_epa_allowance', 'actual_input_epa_allowance')
    def comp_actual_epa_allowance(self):
        for rec in self:
            required_epa_allowance = rec.required_epa_allowance.name or 0.0
            audited_epa_allowance = rec.audited_epa_allowance
            actual_input_epa_allowance = rec.actual_input_epa_allowance
            actual = max(float(required_epa_allowance), audited_epa_allowance, actual_input_epa_allowance)
            rec.actual_epa_allowance = actual

    '''Invoice height will be captured from rent calculation table.'''

    @api.depends('actual_epa_allowance')
    def comp_closest_epa(self):
        for rec in self:
            all_epa_allowance = self.env['epa.allowance'].search([])
            print(all_epa_allowance, 'aagg')
            max_epa_allowance_id = False
            max_epa_allowance = 0
            try:
                for i in all_epa_allowance:
                    print("insideeeeeeeeeeeeeeeeeeeeeeeeee")
                    print(i.name, rec.actual_epa_allowance)
                    if float(i.name) >= rec.actual_epa_allowance:
                        if float(i.name) < max_epa_allowance:
                            max_epa_allowance = float(i.name)
                            max_epa_allowance_id = i.id
                        elif max_epa_allowance == 0:
                            max_epa_allowance = float(i.name)
                            max_epa_allowance_id = i.id
                rec.closest_epa_allowance = max_epa_allowance_id
            except:
                print("inside exception")



    @api.depends('actual_tower_height')
    def comp_closest_height(self):
        for rec in self:
            all_tower_height = self.env['tower.height'].search([])
            print (all_tower_height,'aagg')
            max_height_id = False
            max_height  = 0
            for i in all_tower_height:
                print (i.name,rec.actual_tower_height)
                if float(i.name) >= rec.actual_tower_height:
                    if float(i.name) < max_height:
                        max_height = float(i.name)
                        max_height_id = i.id
                    elif max_height == 0:
                        max_height = float(i.name)
                        max_height_id = i.id


            rec.closest_tower_height = max_height_id

    @api.depends('work_order_id','closest_epa_allowance','closest_tower_height','structure_type_id','partner_id')
    def compute_rent(self):
        for rec in self:
            if rec.work_order_id and rec.closest_epa_allowance and rec.closest_tower_height and rec.structure_type_id:
                calc_matrix = self.env['rent.calculation'].search([('partner_id','=',rec.partner_id.id),('structure_type_id','=',rec.structure_type_id.id),('tower_height_id','=',rec.closest_tower_height.id),('epa_allowance','=',rec.closest_epa_allowance.id)])

                if calc_matrix:
                    if rec.work_order_id.with_cable:
                        rec.rent = calc_matrix.rent_with_cable
                    if not rec.work_order_id.with_cable:
                        rec.rent = calc_matrix.rent_without_cable
                else:
                    rec.rent = 0.0
            else:
                rec.rent = 0.0


    @api.depends('rfi_notice_date', 'equipment_date', 'power_conn_date')
    def comp_scd_date(self):
        for rec in self:
            dates = []
            scd_days = 30
            if rec.partner_id:
                scd_days = rec.partner_id.site_comm_days
            if rec.rfi_notice_date:
                rfi_30 = rec.rfi_notice_date + timedelta(days=scd_days)
                dates.append(rfi_30)
            if rec.equipment_date:
                dates.append(rec.equipment_date)
            if rec.power_conn_date:
                dates.append(rec.power_conn_date)

            if dates:
                scd_date = min(dates)
                rec.scd_date = scd_date
            else:
                rec.scd_date = False

    def comp_task_count(self):
        for record in self:
            record.task_count = self.env['project.task'].search_count(
                [('rfi_notice_id', '=', record.id)])

    def show_tasks(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Tasks',
                'view_mode': 'kanban,tree,form',
                'res_model': 'project.task',
                'domain': [('rfi_notice_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>

                                <th scope="col">Status</th>

                            </tr>
                        </thead>
                        <tbody>

                """
            count = 1
            for task in self.env['project.task'].search([('rfi_notice_id', '=', rec.id)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('rfi.notice') or _('New')
        return super(RFINotice, self).create(vals)

    def action_confirm(self):
        project = self.env['project.project']
        task = self.env['project.task']
        if not self.work_order_id:
            raise UserError(_('Please link NSWO'))
        existing_construction = self.env['site.construction'].search(
            [('work_order_id', '=', self.work_order_id.id)], limit=1)
        if not existing_construction:
            raise UserError(_('Please create Construction Stage'))
        self.structure_type_id = existing_construction.structure_type_id.id

        partner = self.partner_id.parent_id and self.partner_id.parent_id.id or self.partner_id.id
        task_lists = self.env['task.list'].search(
            [('partner_id', '=', partner), ('structure_type_id', '=', existing_construction.structure_type_id.id)],
            limit=1)
        if task_lists:
            users = self.env['res.users'].search([('partner_id', '=', self.partner_id.id)], limit=1)

            for rec in task_lists:
                # existing_construction = self.env['site.construction'].search(
                #     [('client_work_order_no', '=', self.client_work_order_no)], limit=1)
                print('task_lists>>>>>',task_lists,existing_construction)
                if existing_construction:
                    project_id = self.env['project.task'].search([('construction_id', '=', existing_construction.id)],
                                                                 limit=1) and self.env['project.task'].search(
                        [('construction_id', '=', existing_construction.id)], limit=1).project_id or False
                    open_tasks = self.env['project.task'].search([('construction_id', '=', existing_construction.id), (
                        'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)])
                    self.client_site_id = existing_construction.client_site_id.id

                    # if open_tasks:
                    #     raise UserError(_('Please complete Construction Stage'))
                    print('project',project_id)
                    if project_id:
                        self.project_id = project_id.id
                        if self.existing_site:
                            task_list_obj = rec.existing_list_lines
                        else:
                            task_list_obj = rec.list_lines
                        prev_task = False

                        for lines in task_list_obj.sorted('sequence'):
                            if lines.progress == 'rfi':
                                if not prev_task:
                                    current_date = fields.Date.today()
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)
                                else:
                                    current_date = prev_task.date_deadline
                                    additional_days = lines.completion_days + 2
                                    deadline = current_date + timedelta(days=additional_days)
                                vals = {
                                    'project_id': project_id.id,
                                    'name': lines.kg_task_id,
                                    'department_id': lines.department_id.id,
                                    'work_flow': lines.work_flow,
                                    'progress_level': lines.progress,
                                    'weight': lines.weight,
                                    'completion_task': lines.completion_task,
                                    'gf_construction': lines.gf_construction,
                                    'collacation': lines.collacation,
                                    'roof_top': lines.roof_top,
                                    'sequence': lines.sequence,
                                    'partner_id': self.partner_id.id,
                                    'rfi_notice_id': self.id,
                                    'user_id': lines.user_id.id or False,

                                    'allowed_user_ids': [[6, 0, [users.id]]],
                                    'override_sequence': lines.override_sequence,
                                    'milestone_task': lines.milestone_task,
                                    'date_deadline': deadline,
                                    'proposed_date_deadline': deadline,
                                    'attach_mandatory': lines.attach_mandatory

                                }
                                prev_task = task.create(vals)
                        task_schedule = self.env['project.task'].search([('project_id', '=', project_id.id),('rfi_notice_id','=',self.id), (
                            'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1,
                                                                        order="sequence asc")
                        print('TaskList', task_schedule)
                        if task_schedule:
                            self.current_task_id = task_schedule.id
                            self.current_task_status = task_schedule.name

                            activity = self.env['mail.activity'].sudo().create({
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'res_id': task_schedule.id,
                                'user_id': task_schedule.user_id.id,
                                # 'date_deadline':deadline,
                                'res_model_id': self.env.ref('project.model_project_task').id,
                            })
                            print(":activity", activity)
                            activity._onchange_activity_type_id()
        else:
            raise UserError(_('Please set Task Lists First'))
        self.state = 'confirm'
