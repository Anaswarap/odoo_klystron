import calendar
import math
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
import ast
from odoo import models, fields, api, _


class TowerInvoice(models.Model):
    _name = 'tower.invoice'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'kg.approval.transaction']
    _description = 'Tower Invoice'

    def comp_inv_count(self):
        for record in self:
            record.inv_count = self.env['account.move'].search_count(
                [('tower_invoice_id', '=', record.id)])

    def show_invoices(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('tower_invoice_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def create_invoices(self):
        for rec in self:
            if rec.analytic_account_id:
                analytic_account_id = rec.analytic_account_id and rec.analytic_account_id.id or False
            vals_inv = {}
            vals_inv['partner_id'] = rec.partner_id.id
            vals_inv['invoice_date'] = rec.invoice_date
            vals_inv['move_type'] = 'out_invoice'
            vals_inv['tower_invoice_id'] = rec.id
            vals_inv['invoice_payment_term_id'] = self.env.ref('account.account_payment_term_45days').id

            inv_lines = []

            a = (0, 0, {
                'display_type': 'line_section',

                'name': 'Part A Tower Rental',
                'sequence': 1
            })
            inv_lines.append(a)

            for item in rec.a1_lines:
                if item.display_type == 'line_section':
                    a = (0, 0, {
                        'display_type': 'line_section',

                        'name': item.name,
                        'sequence': item.sequence,
                    })
                else:
                    a = (0, 0, {
                        'sequence': item.sequence,
                        'quantity': 1,
                        'price_unit': item.total_amt_due,
                        'name': item.name,
                        'analytic_account_id': item.project_id.analytic_account_id and item.project_id.analytic_account_id.id or False,
                    })

                inv_lines.append(a)

            if rec.b_lines:
                a = (0, 0, {
                    'display_type': 'line_section',

                    'name': 'Part B',
                })
                inv_lines.append(a)
                for item in rec.b_lines:
                    a = (0, 0, {
                        'quantity': 1,
                        'price_unit': item.amount_due,
                        'name': item.name,
                        'analytic_account_id': item.project_id.analytic_account_id and item.project_id.analytic_account_id.id or False,

                    })

                    inv_lines.append(a)
            if rec.c_lines:
                a = (0, 0, {
                    'display_type': 'line_section',

                    'name': 'Part C',
                })
                inv_lines.append(a)
                for item in rec.c_lines:
                    a = (0, 0, {
                        'quantity': 1,
                        'price_unit': item.amount_due,
                        'name': item.name,
                        'analytic_account_id': item.project_id.analytic_account_id and item.project_id.analytic_account_id.id or False,

                    })

                    inv_lines.append(a)
            vals_inv['invoice_line_ids'] = inv_lines
            self.env['account.move'].create(vals_inv)

    def create_quarter_invoices(self):
        current_month = date.today().month
        current_year = date.today().year
        quarter = math.ceil(current_month / 3)

        end_month = quarter * 3

        last_day = calendar.monthrange(current_year, end_month)[1]

        quarter_end_date = datetime(current_year, end_month, last_day)

        start_month = end_month - 2

        quarter_start_date = datetime(current_year, start_month, 1)

        prev_quarter = quarter - 1
        if prev_quarter == 0:
            prev_quarter = 4
            prev_year = current_year - 1
        else:
            prev_year = current_year

        prev_quarter_end_month = prev_quarter * 3
        prev_quarter_start_month = prev_quarter_end_month - 2
        prev_quarter_lastmonth_day = calendar.monthrange(prev_year, prev_quarter_end_month)[1]
        prev_quarter_end_date = datetime(prev_year, prev_quarter_end_month, prev_quarter_lastmonth_day)
        prev_quarter_start_date = datetime(prev_year, prev_quarter_start_month, 1)

        find_clients = self.env['ring.request'].search([('state', '=', 'completed')]).partner_id
        print(find_clients, '1223')
        for client in find_clients:
            inv_id = self.env['tower.invoice'].create(
                {'partner_id': client.id, 'invoice_date': date.today(), 'quarter': str(quarter), 'state': 'draft',
                 'previous_quarter': str(prev_quarter), 'quarter_end_date': quarter_end_date, 'quarter_start_date': quarter_start_date,
                 'invoice_year': current_year})
            project_id = False
            ## part c of Invoices

            c_lines = self.env['project.expense.lines'].search(
                [('start_date', '>=', quarter_start_date), ('start_date', '<=', quarter_end_date),
                 ('tower_invoice_id', '=', False),
                 ('project_id', '!=', False), ('expense_type.bill_type', '=', 'C'),
                 ('project_id.partner_id', '=', client.id)])

            for item in c_lines:
                project_id = item.project_id
                srr_obj = self.env['ring.request'].search(
                    [('project_id', '=', project_id.id), ('partner_id', '=', client.id), ('state', '=', 'approved')],
                    limit=1)
                if srr_obj:
                    self.env['tower.invoice.line'].create(
                        {'site_id': project_id.site_id.id, 'bill_type': 'C', 'srr_id': srr_obj.id,
                         'total_rent': item.fees, 'tower_invoice_id': inv_id.id, 'name': item.name})
                    item.tower_invoice_id = inv_id.id

            ## part b of incvoices

            b_lines = self.env['project.expense.lines'].search(
                [('start_date', '>=', quarter_start_date), ('start_date', '<=', quarter_end_date),
                 ('tower_invoice_id', '=', False),
                 ('project_id', '!=', False), ('expense_type.bill_type', '=', 'B'),
                 ('project_id.partner_id', '=', client.id)])

            for item in b_lines:
                project_id = item.project_id
                self.env['tower.invoice.line'].create(
                    {'site_id': project_id.site_id.id, 'bill_type': 'B', 'period_start_date': quarter_start_date,
                     'period_end_date': quarter_end_date, 'expense_type': item.expense_type.id, 'total_rent': item.fees,
                     'tower_invoice_id': inv_id.id, 'name': item.name})
                item.tower_invoice_id = inv_id.id

            ## part a3 of invoices

            work_orders = self.env['work.order'].search(
                [('partner_id', '=', client.id), ('work_order_date', '>=', quarter_start_date),
                 ('work_order_date', '<=', quarter_end_date), ('state', '=', 'confirm')])
            for nswo in work_orders:
                project_id = nswo.project_id
                rfi_tasks = self.env['project.task'].search_count(
                    [('project_id', '=', project_id.id), ('rfi_notice_id', '!=', False)])
                rfi_completed = self.env['project.task'].search_count(
                    [('project_id', '=', project_id.id), ('rfi_notice_id', '!=', False),
                     ('stage_id', '=', self.env.ref('kg_tower.task_stage_confirmed').id)])
                if rfi_tasks > 0 and rfi_completed == rfi_tasks:
                    self.env['tower.invoice.line'].create(
                        {'site_id': project_id.site_id.id, 'structure_type_id': nswo.structure_type_id.id,
                         'bill_sub_type': 'A3', 'bill_type': 'A',
                         'total_rent': nswo.rent, 'base_rent': nswo.rent, 'tower_invoice_id': inv_id.id,
                         'name': nswo.name})

            ##part a1 of invoices

            revised_work_orders = self.env['work.order'].search(
                [('partner_id', '=', client.id), ('revision_date', '>=', prev_quarter_start_date),
                 ('revision_date', '<=', prev_quarter_end_date), ('is_revision', '=', True),
                 ('orginal_wo_id', '!=', False), ('active', '!=', True)])
            print(prev_quarter_end_date, prev_quarter_start_date, revised_work_orders)
            for item in revised_work_orders:
                project_id = item.project_id
                orginal_project_id = item.orginal_wo_id.project_id
                rfi_id = self.env['rfi.notice'].search(
                    [('project_id', '=', orginal_project_id.id), ('state', '=', 'confirm')])
                rfi_first_date = rfi_id.tenant_foi_date or False
                wo_rev_date = item.revision_date
                if rfi_first_date:
                    if rfi_first_date < wo_rev_date + timedelta(days=45):
                        commen_date = rfi_first_date
                    else:
                        commen_date = wo_rev_date + timedelta(days=45)
                else:
                    commen_date = wo_rev_date
                self.env['tower.invoice.line'].create(
                    {'site_id': project_id.site_id.id, 'structure_type_id': item.structure_type_id.id,
                     'bill_sub_type': 'A1',
                     'bill_type': 'A', 'site_commen_date': commen_date, 'quarter': str(prev_quarter),
                     'total_rent': item.orginal_wo_id.rent, 'base_rent': item.orginal_wo_id.rent,
                     'tower_invoice_id': inv_id.id, 'name': item.name, })

            if project_id:
                inv_id.project_id = project_id.id
                if project_id.analytic_account_id:
                    inv_id.analytic_account_id = project_id.analytic_account_id.id

    def update_lines(self):
        for rec in self:

            quarter_end_date = rec.quarter_end_date

            quarter_start_date = rec.quarter_start_date

            quarter_start_month = quarter_start_date.month
            quarter_end_month = quarter_end_date.month
            quarter_start_year = quarter_start_date.year
            quarter = math.ceil(quarter_start_month / 3)

            prev_quarter = quarter - 1
            if prev_quarter == 0:
                prev_quarter = 4
                prev_year = quarter_start_year - 1
            else:
                prev_year = quarter_start_year

            prev_quarter_end_month = prev_quarter * 3
            prev_quarter_start_month = prev_quarter_end_month - 2
            prev_quarter_lastmonth_day = calendar.monthrange(prev_year, prev_quarter_end_month)[1]
            prev_quarter_end_date = datetime(prev_year, prev_quarter_end_month, prev_quarter_lastmonth_day)
            prev_quarter_start_date = datetime(prev_year, prev_quarter_start_month, 1)

            find_clients = rec.partner_id
            print(find_clients, '1223')
            inv_id = rec
            self.env['tower.invoice.line'].search([('tower_invoice_id', '=', rec.id)]).unlink()
            find_structures = self.env['structure.type'].search([])

            for i in find_structures:
                self.env['tower.invoice.line'].create({'display_type': 'line_section',
                                                       'name': i.name,
                                                       'sequence': i.sequence, 'tower_invoice_id': rec.id,
                                                       'bill_type': 'A','structure_type_id': i.id,
                                                       })
            find_updated_expenses = self.env['project.expense.lines'].search([('tower_invoice_id', '=', rec.id)])
            for item in find_updated_expenses:
                item.tower_invoice_id = False
            project_id = False
            for client in find_clients:

                ## part c of Invoices

                c_lines = self.env['project.expense.lines'].search(
                    [('start_date', '>=', quarter_start_date), ('start_date', '<=', quarter_end_date),
                     ('tower_invoice_id', '=', False),
                     ('project_id', '!=', False), ('expense_type.bill_type', '=', 'C'),
                     ('project_id.partner_id', '=', client.id)])

                for item in c_lines:
                    project_id = item.project_id
                    srr_obj = self.env['ring.request'].search(
                        [('project_id', '=', project_id.id), ('partner_id', '=', client.id), ('state', '=', 'confirm')],
                        limit=1)
                    if srr_obj:
                        self.env['tower.invoice.line'].create(
                            {'site_id': project_id.site_id.id, 'bill_type': 'C', 'srr_id': srr_obj.id,
                             'project_id': project_id.id,
                             'total_rent': item.fees, 'tower_invoice_id': inv_id.id, 'name': item.name})
                        item.tower_invoice_id = inv_id.id

                ## part b of incvoices

                b_lines = self.env['project.expense.lines'].search(
                    [('start_date', '>=', quarter_start_date), ('start_date', '<=', quarter_end_date),
                     ('tower_invoice_id', '=', False),
                     ('project_id', '!=', False), ('expense_type.bill_type', '=', 'B'),
                     ('project_id.partner_id', '=', client.id)])

                for item in b_lines:
                    project_id = item.project_id
                    self.env['tower.invoice.line'].create(
                        {'site_id': project_id.site_id.id, 'bill_type': 'B', 'period_start_date': quarter_start_date,
                         'period_end_date': quarter_end_date, 'expense_type': item.expense_type.id,
                         'project_id': project_id.id,
                         'total_rent': item.fees, 'tower_invoice_id': inv_id.id, 'name': item.name})
                    item.tower_invoice_id = inv_id.id

                ## part a1 of invoices
                ## recurring invoices
                rfi_notices_recurring = self.env['rfi.notice'].search(
                    [('partner_id', '=', client.id), ('state', '=', 'confirm')]).filtered(
                    lambda i: i.scd_date.year < quarter_start_year)
                for rfi in rfi_notices_recurring:
                    project_id = rfi.project_id
                    tenancy_discount = 0
                    find_tenancy_discount = self.env['project.tenant.details'].search(
                        [('project_id', '=', project_id.id), ('rfi_notice_id', '=', rfi.id),
                         ('partner_id', '=', rfi.partner_id.id)])
                    if find_tenancy_discount:
                        tenancy_discount = find_tenancy_discount.discount_percent

                    self.env['tower.invoice.line'].create(
                        {'site_id': rfi.client_site_id.id, 'structure_type_id': rfi.structure_type_id.id,
                         'bill_type': 'A',
                         'total_rent': rfi.rent, 'base_rent': rfi.rent, 'tower_invoice_id': inv_id.id,
                         'name': rfi.name, 'quarter': inv_id.quarter, 'previous_quarter': str(prev_quarter),
                         'actual_max_height': rfi.actual_tower_height,
                         'audited_height': rfi.audited_tower_height,
                         'height_from_nswo': float(rfi.required_tower_height.name),
                         'tenancy_discount': tenancy_discount,
                         'invoiced_height': float(rfi.closest_tower_height.name),
                         'actual_epa': rfi.actual_epa_allowance,
                         'project_id': project_id.id,
                         'epa_allowance': float(rfi.closest_epa_allowance.name),
                         'sequence': rfi.structure_type_id.sequence})
                ## site completed in this billing quarter
                rfi_notices = self.env['rfi.notice'].search(
                    [('partner_id', '=', client.id), ('scd_date', '=', quarter_start_date), ('state', '=', 'confirm')])
                for rfi in rfi_notices:
                    project_id = rfi.project_id
                    tenancy_discount = 0
                    find_tenancy_discount = self.env['project.tenant.details'].search(
                        [('project_id', '=', project_id.id), ('rfi_notice_id', '=', rfi.id),
                         ('partner_id', '=', rfi.partner_id.id)])
                    if find_tenancy_discount:
                        tenancy_discount = find_tenancy_discount.discount_percent


                    rfi.initial_invoice_id = inv_id.id
                    self.env['tower.invoice.line'].create(
                        {'site_id': rfi.client_site_id.id, 'structure_type_id': rfi.structure_type_id.id,
                         'bill_type': 'A', 'rfi_notice': rfi.rfi_notice_date, 'project_id': project_id.id,
                         'total_rent': rfi.rent, 'base_rent': rfi.rent, 'tower_invoice_id': inv_id.id, 'name': rfi.name,
                         'site_commen_date': rfi.scd_date, 'quarter': inv_id.quarter, 'previous_quarter': str(prev_quarter),
                         'audited_height': rfi.audited_tower_height,
                         'height_from_nswo': float(rfi.required_tower_height.name),
                         'tenancy_discount': tenancy_discount,
                         'actual_max_height': rfi.actual_tower_height,
                         'invoiced_height': float(rfi.closest_tower_height.name),
                         'actual_epa': rfi.actual_epa_allowance, 'epa_allowance': float(rfi.closest_epa_allowance.name),
                         'sequence': rfi.structure_type_id.sequence})
                ## site completed in previous billing quarter but not billed
                rfi_notices_prev_qtr = self.env['rfi.notice'].search(
                    [('partner_id', '=', client.id), ('scd_date', '>=', prev_quarter_start_date),
                     ('scd_date', '<=', prev_quarter_end_date), ('initial_invoice_id', '=', False),
                     ('state', '=', 'confirm')])
                for rfi in rfi_notices_prev_qtr:
                    project_id = rfi.project_id
                    tenancy_discount = 0
                    find_tenancy_discount = self.env['project.tenant.details'].search(
                        [('project_id', '=', project_id.id), ('rfi_notice_id', '=', rfi.id),
                         ('partner_id', '=', rfi.partner_id.id)])
                    if find_tenancy_discount:
                        tenancy_discount = find_tenancy_discount.discount_percent

                    self.env['tower.invoice.line'].create(
                        {'site_id': rfi.client_site_id.id, 'structure_type_id': rfi.structure_type_id.id,
                         'bill_type': 'A', 'project_id': project_id.id,
                         'total_rent': rfi.rent, 'base_rent': rfi.rent, 'tower_invoice_id': inv_id.id, 'name': rfi.name,
                         'site_commen_date': rfi.scd_date, 'quarter': str(prev_quarter),
                         'audited_height': rfi.audited_tower_height,
                         'height_from_nswo': float(rfi.required_tower_height.name),
                         'actual_max_height': rfi.actual_tower_height, 'rfi_notice': rfi.rfi_notice_date,
                         'invoiced_height': float(rfi.closest_tower_height.name), 'tenancy_discount': tenancy_discount,
                         'actual_epa': rfi.actual_epa_allowance, 'epa_allowance': float(rfi.closest_epa_allowance.name),
                         'sequence': rfi.structure_type_id.sequence})

            if project_id:
                rec.project_id = project_id.id
                if project_id.analytic_account_id:
                    rec.analytic_account_id = project_id.analytic_account_id.id

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)

    quarter = fields.Selection([('1', 'Q1'), ('2', 'Q2'), ('3', 'Q3'), ('4', 'Q4')], string='Quarter')

    quarter_start_date = fields.Date('Period Start Date', tracking=True, )

    quarter_end_date = fields.Date('Period End Date', tracking=True)

    inv_count = fields.Integer('# Invoices', compute='comp_inv_count')

    invoice_date = fields.Date('Invoice Date', tracking=True)

    invoice_year = fields.Char('Invoice Year', readonly=True)

    partner_id = fields.Many2one('res.partner', 'Client', tracking=True, required=True,domain=[('operator', '=', True)])

    partner_arabic_name = fields.Char('Client(Arabic name)', related='partner_id.arabic_name')

    state = fields.Selection([('draft', 'Draft'), ('pre_com_dep', 'Prep By Commercial Department'),
                              ('technical_review', 'Reviewed By Technical Department'), ('fin_app', 'Finance Approved'),
                              ('sent_to_client', 'Sent To Client')], default='draft', tracking=True)

    a1_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', domain=[('bill_type', '=', 'A')])
    greenfield_a1_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Greenfield A1',
                                          domain=[('structure_type_id.name', '=', 'Greenfield'),
                                                  ('bill_type', '=', 'A'), ('bill_sub_type', '=', 'A1')])
    rooftop_a1_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Rooftop A1',
                                       domain=[('structure_type_id.name', '=', 'Rooftop'), ('bill_type', '=', 'A'),
                                               ('bill_sub_type', '=', 'A1')])

    greenfield_a2_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Greenfield A2',
                                          domain=[('structure_type_id.name', '=', 'Greenfield'),
                                                  ('bill_type', '=', 'A'), ('bill_sub_type', '=', 'A2')])
    rooftop_a2_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Rooftop A2',
                                       domain=[('structure_type_id.name', '=', 'Rooftop'), ('bill_type', '=', 'A'),
                                               ('bill_sub_type', '=', 'A2')])

    greenfield_a3_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Greenfield A3',
                                          domain=[('structure_type_id.name', '=', 'Greenfield'),
                                                  ('bill_type', '=', 'A'), ('bill_sub_type', '=', 'A3')])
    rooftop_a3_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Rooftop A3',
                                       domain=[('structure_type_id.name', '=', 'Rooftop'), ('bill_type', '=', 'A'),
                                               ('bill_sub_type', '=', 'A3')])

    b_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Part B',
                              domain=[('bill_type', '=', 'B')])
    c_lines = fields.One2many('tower.invoice.line', 'tower_invoice_id', string='Part C',
                              domain=[('bill_type', '=', 'C')])

    tax_id = fields.Many2one(
        comodel_name='account.tax',
        string='Tax Id',
        required=False, domain="[('type_tax_use', '=', 'sale')]")
    total_excluding_vat = fields.Float('Total Excluding VAT', compute='comp_total_due', digits="OTC Decimal", store=False)
    total_amount_vat = fields.Float('VAT', compute='comp_total_due', digits="OTC Decimal", store=False)
    total_amount_due = fields.Float('Total Amount Due', compute='comp_total_due', digits="OTC Decimal", store=False)

    narration = fields.Text('Narration')

    project_id = fields.Many2one('project.project', 'Project')
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)

    analytic_account_id = fields.Many2one('account.analytic.account', string="Analytic Account", copy=False,
                                          ondelete='set null',
                                          domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
                                          check_company=True,
                                          help="Analytic account to which this project is linked for financial management. "
                                               "Use an analytic account to record cost and revenue on your project.")
    # _________________________________________________________________________
    # --------------------------------------------------------------------------
    '''Added by Ameen for excel report purpose'''

    approval1_user_id = fields.Many2one('res.users', 'Approval 1')
    approval2_user_id = fields.Many2one('res.users', 'Approval 2')
    approval3_user_id = fields.Many2one('res.users', 'Approval 3')
    user1_designation = fields.Char('Designation 1', related='approval1_user_id.partner_id.function', readonly=False)
    user2_designation = fields.Char('Designation 2', related='approval2_user_id.partner_id.function', readonly=False)
    user3_designation = fields.Char('Designation 3', related='approval3_user_id.partner_id.function', readonly=False)
    aproval_date1 = fields.Date('Approval Date1')
    aproval_date2 = fields.Date('Approval Date2')
    aproval_date3 = fields.Date('Approval Date3')

    # _________________________________________________________________________________________________
    # ------------------------------------------------------------------------------------------------------

    def send_notification_to_group(self, group_xml_id):
        for rec in self:
            rec.activity_unlink(['kg_tower.tower_invoice_stages'])
            group = self.env.ref(group_xml_id)
            for user in group.users:
                rec.activity_schedule('kg_tower.tower_invoice_stages', note=rec.name, user_id=user.id)

    def prep_by_com_dep(self):
        self.send_notification_to_group('kg_tower.group_oper_saq_rollout')
        self.state = 'pre_com_dep'

    def technical_review(self):
        self.send_notification_to_group('account.group_account_manager')
        self.state = 'technical_review'

    def fin_app(self):
        self.activity_unlink(['kg_tower.tower_invoice_stages'])
        self.state = 'fin_app'

    def sent_to_client(self):
        self.activity_unlink(['kg_tower.tower_invoice_stages'])
        self.state = 'sent_to_client'

    @api.depends('a1_lines', 'b_lines', 'c_lines')
    def comp_total_due(self):
        for rec in self:
            amt_due = 0
            for i in rec.a1_lines:
                amt_due += i.total_amt_due
            for i in rec.b_lines:
                amt_due += i.amount_due
            for i in rec.c_lines:
                amt_due += i.amount_due
            total_included = 0
            total_excluded = 0
            if rec.tax_id:
                print('amt_due', amt_due, 'rec.tax_id.compute_all(amt_due)', rec.tax_id.compute_all(amt_due))
                result = rec.tax_id.compute_all(amt_due)
                rec.total_excluding_vat = result['total_excluded']
                rec.total_amount_vat = result['total_included'] - result['total_excluded']
                rec.total_amount_due = result['total_included']
            else:
                rec.total_excluding_vat = 0
                rec.total_amount_vat = 0
                rec.total_amount_due = amt_due

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('tower.invoice') or _('New')
        res = super(TowerInvoice, self).create(vals)
        res.send_notification_to_group('kg_tower.group_comm_dept')

        return res

    '''
        ----------------------Approval Module Changes----------------------
        Approval Section field override to mentioned corresponding model.
        '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='tower.invoice')

    '''
    Inherit final approve and post payment. 
    '''

    def kg_final_approval(self):
        """Supering method which is defined in the kg approval to rise invoice if it is final approval"""
        res = super(TowerInvoice, self).kg_final_approval()
        self.create_invoices()
        return res

    '''
    Get approval details for print.
    '''

    def get_approve_details(self):
        approval_list = []
        if self.approved_list:
            data = ast.literal_eval(self.approved_list)
            for ad in data:
                user = ""
                if 'user_approved' in ad:
                    user_obj = self.env['res.users'].browse(ad['user_approved'])
                    user = user_obj
                    approval_level = (ad['approval_level'])
                    approval_dict = {'user': user,
                                     'approval_level': approval_level}
                    approval_list.append(approval_dict)

            return approval_list


class TowerInvoiceLine(models.Model):
    _name = 'tower.invoice.line'
    _description = 'Tower Invoice Line'

    name = fields.Char('Reference', required=True, )
    sequence = fields.Integer(string='Sequence', default=10)
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False, help="Technical field for UX purpose.")

    site_id = fields.Many2one('account.asset.site', 'Site ID', )
    project_id = fields.Many2one('project.project', 'Project')
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')

    # structure_type = fields.Selection([('greenfield','Greenfield'),('rooftop','Rooftop'),('collocation', 'Collocation')],  string='Structure Type',)
    bill_type = fields.Selection([('A', 'A'), ('B', 'B'), ('C', 'C')], string='Bill Type', required=True, default='A')
    bill_sub_type = fields.Selection([('A1', 'A1'), ('A2', 'A2'), ('A3', 'A3')], string='Sub Type')

    tower_invoice_id = fields.Many2one('tower.invoice', 'Invoice')

    amount_due = fields.Float('Amount Due for Ending Quarter', compute='comp_amt_due', digits="OTC Decimal")

    amount_due_for_starting_quarter = fields.Float('Amount Due For Starting Quarter', digits="OTC Decimal",
                                                   compute='comp_amount_due_for_starting_quarter')

    total_amt_due = fields.Float('Total Amount Due Under this Invoice', compute='comp_tot_amt_due', digits="OTC Decimal" )

    ## a1 greenfield fields

    audited_height = fields.Float('Audited Height')
    height_from_nswo = fields.Float('Height From NSWO')

    actual_max_height = fields.Float('Actual Max Height(m)')
    invoiced_height = fields.Float('Invoiced Height (m)')
    epa_allowance = fields.Float('EPA Allowance (m2)', digits="OTC Decimal")
    ground_space_allow = fields.Float('Ground Space Allow. (m2)')
    base_rent = fields.Float('Base Rent (monthly)', digits="OTC Decimal")
    tenancy_discount = fields.Float('Tenancy Discount', digits="OTC Decimal")
    actual_epa = fields.Float('Actual EPA (m2)', digits="OTC Decimal")
    epa_add_fee = fields.Integer('EPA Add. Fee', compute='comp_epa_add_fee')
    vertical_space_used = fields.Float('Vertical Space used (m)')
    vertical_space_add_fee = fields.Float('Vertical Space Add. Fee')
    ground_space_used = fields.Float('Ground Space used (m2)')
    ground_space_add_fee = fields.Float('Ground Space Add. Fee', digits="OTC Decimal")
    total_rent = fields.Float('Total Rent (monthly)', digits="OTC Decimal")
    other = fields.Float('Other', digits="OTC Decimal")
    rfi_notice = fields.Date('RFI Notice')
    tenant_commen_before_30days = fields.Boolean('Tenant Commencement Date before the 30 days')
    site_commen_date = fields.Date('Site Commencement Date')
    last_date = fields.Date('Last day of such month', compute='comp_last_date')
    quarter = fields.Selection([('1', 'Q1'), ('2', 'Q2'), ('3', 'Q3'), ('4', 'Q4')], string='Quarter')
    previous_quarter = fields.Selection([('1', 'Q1'), ('2', 'Q2'), ('3', 'Q3'), ('4', 'Q4')], string='Previous Quarter')
    end_of_quarter_date = fields.Date('End of quarter date', compute='comp_quarter_date')
    nb_full_months_due = fields.Integer('Nb full months due', compute='comp_nb_full_months')
    nb_days_due = fields.Integer('Nb days due (partial month)', compute='comp_last_date')
    nb_days_in_month = fields.Integer('Nb days in that month', compute='comp_last_date')

    ##a2 fields

    period_start_date = fields.Date('Period Start Date')
    period_end_date = fields.Date('Period End Date')
    monthly_rent_previous = fields.Float('Monthly rent previously applied', digits="OTC Decimal")
    monthly_rent_current = fields.Float('Monthly rent actually applicable', digits="OTC Decimal")
    nb_od_days = fields.Integer('Nb of days concerned', compute='comp_nb_od_days')

    srr_id = fields.Many2one('ring.request', 'SRR')
    expense_type = fields.Many2one('expense.type', 'Expense Type')

    @api.depends('site_commen_date', 'end_of_quarter_date', 'period_start_date', 'period_end_date', 'last_date')
    def comp_nb_full_months(self):
        for rec in self:
            previous_quarter = False
            if rec.tower_invoice_id.quarter_start_date:
                previous_period_start = rec.tower_invoice_id.quarter_start_date - relativedelta(months=1)
                if rec.site_commen_date and rec.site_commen_date >= previous_period_start:
                    previous_quarter = True
                elif not rec.site_commen_date:
                    previous_quarter = True

            if rec.end_of_quarter_date and rec.last_date and previous_quarter:
                # site_commen_month = rec.site_commen_date.month
                last_date_month = rec.last_date.month
                last_quarter_month = rec.end_of_quarter_date.month
                due_months = last_quarter_month - last_date_month
                rec.nb_full_months_due = int(due_months)
            elif rec.period_start_date and rec.period_end_date:
                rec.nb_full_months_due = ((rec.period_end_date.year - rec.period_start_date.year) * 12 + rec.period_end_date.month - rec.period_start_date.month)
            else:
                rec.nb_full_months_due = 0

    @api.depends('previous_quarter', 'tower_invoice_id.invoice_date')
    def comp_quarter_date(self):
        for rec in self:
            invoice_year = rec.tower_invoice_id.invoice_date.year
            month = int(rec.previous_quarter) * 3
            if month > 0:
                last_day = calendar.monthrange(invoice_year, month)[1]
                quarter_last_date = datetime(invoice_year, month, last_day)
                rec.end_of_quarter_date = quarter_last_date
            else:
                rec.end_of_quarter_date = False

    @api.depends('actual_epa', 'epa_allowance')
    def comp_epa_add_fee(self):
        for rec in self:
            value = round(2 * (rec.actual_epa - rec.epa_allowance), 0) * 3.5

            rec.epa_add_fee = max(value, 0)

    @api.onchange('epa_add_fee', 'base_rent', 'tenancy_discount', 'vertical_space_add_fee', 'ground_space_add_fee')
    def onchage_epa_add_fee_base_rent(self):
        for rec in self:
            epa_add_fee = rec.epa_add_fee
            vertical_space_add_fee = rec.vertical_space_add_fee
            tenancy_discount = rec.tenancy_discount
            value = rec.base_rent * (1 - ((tenancy_discount) / 100) + ((epa_add_fee) / 100) + (
                        (vertical_space_add_fee) / 100)) + rec.ground_space_add_fee
            rec.total_rent = value

    @api.depends('site_commen_date')
    def comp_last_date(self):
        for rec in self:
            if rec.site_commen_date:
                year = rec.site_commen_date.year
                month = rec.site_commen_date.month
                day = calendar.monthrange(year, month)[1]
                last_day = date(year, month, day)
                rec.last_date = last_day
                diff = (last_day - rec.site_commen_date).days
                rec.nb_days_due = diff + 1
                rec.nb_days_in_month = day
            else:
                rec.last_date = False
                rec.nb_days_due = 0
                rec.nb_days_in_month = 0

    @api.depends('period_start_date', 'period_end_date')
    def comp_nb_od_days(self):
        for rec in self:
            diff = 0
            if rec.period_start_date and rec.period_end_date:
                diff = max((rec.period_end_date - rec.period_start_date).days, 0)
            rec.nb_od_days = diff

    @api.depends('total_rent', 'nb_full_months_due', 'nb_days_due', 'nb_days_in_month', 'nb_od_days',
                 'monthly_rent_current', 'monthly_rent_previous')
    def comp_amt_due(self):
        for rec in self:
            amt_due = 0
            previous_quarter = False
            if rec.tower_invoice_id.quarter_start_date:
                previous_period_start = rec.tower_invoice_id.quarter_start_date - relativedelta(months=1)
                if rec.site_commen_date and rec.site_commen_date >= previous_period_start:
                    previous_quarter = True
                elif not rec.site_commen_date:
                    previous_quarter = True
            if rec.bill_type == 'A' and rec.site_commen_date and previous_quarter:
                if rec.nb_days_in_month > 0:
                    factor = (rec.nb_days_due / rec.nb_days_in_month) + rec.nb_full_months_due
                else:
                    factor = 1
                amt_due = rec.total_rent * factor

            # elif rec.bill_type == 'A' and rec.bill_sub_type == 'A2':
            #     correction = max(rec.monthly_rent_current - rec.monthly_rent_previous,0)
            #     amt_due = correction
            # elif rec.bill_type == 'A' and rec.bill_sub_type == 'A3':
            #     amt_due = rec.total_rent * 3
            elif rec.bill_type == 'B':
                amt_due = rec.total_rent * rec.nb_full_months_due
            elif rec.bill_type == 'C' and rec.period_end_date and rec.period_start_date:
                amt_due = rec.total_rent * ((rec.period_end_date.year - rec.period_start_date.year) * 12 + rec.period_end_date.month - rec.period_start_date.month)

            rec.amount_due = amt_due

    @api.depends('total_rent', 'quarter', 'tower_invoice_id.quarter', 'site_commen_date')
    def comp_amount_due_for_starting_quarter(self):
        for rec in self:
            if rec.quarter == rec.tower_invoice_id.quarter:
                rec.amount_due_for_starting_quarter = rec.total_rent * 3
            elif not rec.site_commen_date:
                rec.amount_due_for_starting_quarter = rec.total_rent * 3
            else:
                rec.amount_due_for_starting_quarter = 0

    @api.depends('amount_due_for_starting_quarter', 'amount_due')
    def comp_tot_amt_due(self):
        for rec in self:
            tot = 0
            tot = rec.amount_due + rec.amount_due_for_starting_quarter
            rec.total_amt_due = tot

    def calculate_quarter(self):
        for rec in self:
            if rec.quarter:
                prev_quarter = int(rec.quarter) - 1
                if prev_quarter == 0:
                    rec.previous_quarter = '4'
                else:
                    rec.previous_quarter = str(prev_quarter)
