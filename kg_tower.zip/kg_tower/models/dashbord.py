from odoo import models, fields, api
from odoo import tools



class KgDashboard(models.Model):
    _name = 'kg.dashboard'
    _auto = False
    _description = 'Dashboard Analisys'

    partner_id = fields.Many2one('res.partner', string='Partner', readonly=True)
    nswo_id = fields.Many2one('work.order', string='NSWO', readonly=True)
    user_id = fields.Many2one('res.users', string='Salesperson', readonly=True)
    work_order_date = fields.Date('Date', default=fields.Date.context_today, tracking=True)
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, readonly=True)
    project_id = fields.Many2one('project.project', 'Project', tracking=True, readonly=True)
    srr_id = fields.Many2one(comodel_name='ring.request',string='SRR Id',required=False)
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    governorate = fields.Many2one(comodel_name='kg.governorate',string='Governorate',tracking=True)
    wilayat = fields.Many2one('kg.wilayat',string='Wilayat',tracking=True)

    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], string='Status', readonly=True, copy=False, tracking=True,
        default='draft')
    shelter_rent = fields.Float(
        string='Shelter Rent')
    total_countable_epa = fields.Float('Total Epa')
    rent = fields.Float(
        string='Monthly Rent',
        required=False)
    acceptance_date = fields.Date('Acceptance Date')
    saq_id = fields.Many2one('site.acquisition','Site Acquisition')
    saq_current_task_status = fields.Char('SAQ Status')
    nswo_current_status = fields.Char('NSWO Status')
    con_current_status = fields.Char('Construction Status')
    rfi_current_status = fields.Char('RFI Status')
    con_genset_conn_date = fields.Date('Genset Connection Date')
    def init(self):
        tools.drop_view_if_exists(self.env.cr, 'kg_dashboard')
        self.env.cr.execute("""
            CREATE OR REPLACE VIEW kg_dashboard AS (
                SELECT
                    row_number() OVER () AS id,
                    line.partner_id,
                    line.nswo_id,
                    line.work_order_date,
                    line.client_site_id,
                    line.project_id,
                    line.srr_id,
                    line.structure_type_id,
                    line.governorate,
                    line.wilayat,
                    line.user_id,
                    line.shelter_rent,
                    line.rent,
                    line.acceptance_date,
                    line.saq_id,
                    line.saq_current_task_status,
                    line.con_current_status,
                    line.rfi_current_status,
                    line.nswo_current_status,
                    line.con_genset_conn_date,
                    line.state FROM (
                        SELECT
                            p.id as partner_id,
                            nswo.id as nswo_id,
                            nswo.work_order_date as work_order_date,
                            nswo.client_site_id as client_site_id,
                            nswo.project_id as project_id,
                            nswo.srr_id as srr_id,
                            nswo.structure_type_id as structure_type_id,
                            nswo.governorate as governorate,
                            nswo.wilayat as wilayat,
                            nswo.state as state,
                            nswo.user_id as user_id,
                            nswo.shelter_rent as shelter_rent,
                            nswo.rent as rent,
                            rfi.acceptance_date as acceptance_date,
                            saq.id as saq_id,
                            saq.current_task_status as saq_current_task_status,
                            nswo.current_task_status as nswo_current_status,
                            con.current_task_status as con_current_status,
                            rfi.current_task_status as rfi_current_status,
                            con.conn_date as con_genset_conn_date
                        FROM res_partner p
                        LEFT JOIN work_order nswo ON (p.id = nswo.partner_id)
                        LEFT JOIN site_acquisition saq on (saq.nswo_id = nswo.id)
                        LEFT JOIN site_construction con on (con.work_order_id = nswo.id)
                        LEFT JOIN rfi_notice rfi on (rfi.work_order_id = nswo.id)
                        LEFT JOIN project_project project on (project.id = nswo.project_id)
                        
                    ) as line
                    WHERE
                        line.state = 'confirm'
                )""")
class KgDashbord(models.Model):
    _name = 'kg.dashbord'
    _auto = False
    _description = 'Dashbord Analisys'