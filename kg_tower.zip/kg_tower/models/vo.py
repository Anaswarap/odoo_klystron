from odoo import models, fields, api, _
from odoo.exceptions import UserError
import ast


class VO(models.Model):
    _name = 'kg.vo'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'base.revision', 'kg.approval.transaction']

    _description = 'Variation Order'

    current_revision_id = fields.Many2one(
        comodel_name="kg.vo",
    )
    old_revision_ids = fields.One2many(
        comodel_name="kg.vo",
    )

    @api.model
    def _company_get(self):
        company_id = self.env['res.company']._company_default_get(self._name)
        return self.env['res.company'].browse(company_id.id)

    company_id = fields.Many2one('res.company',
                                 required=True,
                                 default=_company_get)

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
    )
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    description = fields.Char('Description')
    project_id = fields.Many2one('project.project', 'Project', tracking=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id)
    date = fields.Date('Date', default=fields.Date.today())
    partner_id = fields.Many2one('res.partner', 'Partner', tracking=True)
    notes = fields.Text('Notes')
    vo_line_ids = fields.One2many('kg.vo.line', 'vo_id', copy=True, string='VO Lines')
    state = fields.Selection([('draft', 'Draft'), ('approval_one', 'Approved by Senior Engg'),
                              ('approval_two', 'Approved by Project Dept'),
                              ('approval_three', 'Approved by Supply Chain'),
                              ('approval_four', 'Approved by Finance'),
                              ('approval_five', 'Approved by GM'),
                              ('done', 'Done'),
                              ('cancel', 'Cancelled')], string='Status', default='draft', tracking=True)

    approval_one_user_id = fields.Many2one('res.users')
    approval_two_user_id = fields.Many2one('res.users')
    approval_three_user_id = fields.Many2one('res.users')
    approval_four_user_id = fields.Many2one('res.users')
    approval_five_user_id = fields.Many2one('res.users')
    amount_subtotal = fields.Monetary('Original Order Value', compute='comp_total', store=True)
    variation_subtotal = fields.Monetary('Variaton Order Value', compute='comp_total', store=True)
    amount_total = fields.Monetary('Total', compute='comp_total', store=True, copy=False, digits="OTC Decimal")

    total_amount_in_words = fields.Char(
        string="Amount in Words",
        store=True,
        compute='_compute_total_amt_in_words',
    )
    governorate = fields.Many2one('kg.governorate', 'Governorate')

    regional_coefficient = fields.Many2one('kg.regional.coefficient', 'Regional Coefficient')
    regional_coefficient_id = fields.Many2one('contract.pricelist.regional.coefficient', 'Regional Coefficient',
                                              domain="[('contract_pricelist_id','=',contract_no)]")

    construction_id = fields.Many2one(
        comodel_name='site.construction',
        string='Construction',
        required=False)

    tswo_id = fields.Many2one(
        comodel_name='kg.tswo',
        string='TSWO',
        required=False)

    inv_count = fields.Integer('# Invoices', compute='comp_inv_count')

    '''
                ----------------------Approval Module Changes----------------------
                Approval Section field override to mentioned corresponding model.
                '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='kg.vo')

    def kg_final_approval(self):
        """Supering method which is defined in the kg approval to confirm Variation Order if it is final approval"""
        res = super(VO, self).kg_final_approval()
        self.action_done()
        return res

    def get_approve_details(self):
        approval_list = []
        if self.approved_list:
            data = ast.literal_eval(self.approved_list)
            for ad in data:
                user = ""
                if 'user_approved' in ad:
                    user_obj = self.env['res.users'].browse(ad['user_approved'])
                    user = user_obj
                    approval_level = (ad['approval_level'])
                    approval_dict = {'user': user,
                                     'approval_level': approval_level}
                    approval_list.append(approval_dict)

            return approval_list

    def print_vo_report(self):
        return self.env.ref('kg_tower.action_vo_report').report_action(self)

    @api.constrains('project_id')
    def _check_max_tenant_limit_vo_project(self):
        for rec in self:
            max_tenants = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.max_tenants'))
            current_tenants_vo = self.env['kg.vo'].search_count([('project_id', '=', rec.project_id.id)])
            if current_tenants_vo > max_tenants:
                raise UserError(_("Only %s Tenant VO Allowed", str(max_tenants)))

    # Client requested to remove restriction
    # @api.constrains('construction_id')
    # def _validate_construction_uniqueness(self):
    #     for record in self:
    #         construction_count = self.env['kg.vo'].search_count([('construction_id', '=', record.construction_id.id),('state','=','done')])
    #         print(construction_count, 'construction_count')
    #
    #         if construction_count > 1:
    #             raise UserError(
    #                 _("Only one VO allowed for One Construction."))

    @api.onchange('tswo_id')
    def onchange_tswo_id(self):
        for rec in self:
            vo_lines = []
            rec.vo_line_ids = False
            for item in rec.tswo_id.tswo_line_ids:
                a = (0, 0, {
                    'contract_line_id': item.contract_line_id and item.contract_line_id.id or False,
                    'product_qty': item.product_qty,
                    'actual_qty': item.product_qty,
                    'name': item.name,
                    'contract_no': item.contract_no and item.contract_no.id or False,
                    'governorate': item.governorate and item.governorate.id or False,

                    'product_id': item.product_id and item.product_id.id or False,
                    'product_uom_id': item.product_uom_id and item.product_uom_id.id or False,
                })

                vo_lines.append(a)
            rec.vo_line_ids = vo_lines
            rec.onchange_contract_no()
            rec.onchange_gov()

    @api.onchange('contract_no')
    def onchange_contract_no(self):
        for rec in self:
            for line in rec.vo_line_ids:
                line.contract_no = rec.contract_no.id
                line.onchange_contract_no()

    @api.onchange('governorate')
    def onchange_gov(self):
        for rec in self:
            for line in rec.vo_line_ids:
                line.governorate = rec.governorate.id

    # @api.onchange('regional_coefficient')
    # def onchange_loc(self):
    #     for rec in self:
    #         for line in rec.vo_line_ids:
    #             line.regional_coefficient = rec.regional_coefficient.id
    #             line.onchange_regional_coefficient()

    @api.onchange('regional_coefficient_id')
    def onchange_loc(self):
        for rec in self:
            for line in rec.vo_line_ids:
                line.regional_coefficient_id = rec.regional_coefficient_id.id
                line.onchange_regional_coefficient()

    @api.depends('currency_id', 'amount_total')
    def _compute_total_amt_in_words(self):
        for pay in self:
            if pay.currency_id:
                pay.total_amount_in_words = pay.currency_id.amount_to_text(pay.amount_total)
            else:
                pay.total_amount_in_words = ''

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('kg.vo') or _('New')
        res = super(VO, self).create(vals)
        return res

    @api.depends('vo_line_ids.price_subtotal')
    def comp_total(self):
        for rec in self:
            subtot = 0
            vartot = 0
            for line in rec.vo_line_ids:
                subtot += line.price_subtotal
                vartot += line.variation_value

            rec.amount_subtotal = subtot
            rec.variation_subtotal = vartot
            rec.amount_total = subtot + vartot

    def action_cancel(self):
        self.state = 'cancel'

    def notify_users(self, allowed_user_ids, allowed_group):
        self.activity_unlink(['kg_tower.vo_approval'])
        print(allowed_user_ids, allowed_group)
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.vo_approval', note=user.name, user_id=user.id)
        if allowed_user_ids:
            user_ids = allowed_user_ids.split(',')
            user_ids = list(map(int, user_ids))
            for user in self.env['res.users'].browse(user_ids):
                self.activity_schedule('kg_tower.vo_approval', note=user.name, user_id=user.id)

        return True

    def action_approve_senior_engg(self):
        self.notify_users(False, 'project.group_project_manager')
        self.approval_one_user_id = self.env.user.id

        self.state = 'approval_one'

    def action_approve_project_dept(self):
        self.notify_users(False, 'stock.group_stock_manager')
        self.state = 'approval_two'
        self.approval_two_user_id = self.env.user.id

    def action_approve_supply_chain(self):
        self.notify_users(False, 'account.group_account_manager')
        self.approval_three_user_id = self.env.user.id

        self.state = 'approval_three'

    def action_approve_finance(self):
        self.notify_users(False, 'kg_tower.group_second_authoriser')
        self.approval_four_user_id = self.env.user.id

        self.state = 'approval_four'

    def action_approve_gm(self):
        self.approval_five_user_id = self.env.user.id

        self.state = 'approval_five'

    def action_done(self):
        # self.create_invoices()
        self.state = 'done'
        self.project_id.vo_value += self.amount_total

    def comp_inv_count(self):
        for record in self:
            record.inv_count = self.env['account.move'].search_count(
                [('vo_id', '=', record.id)])

    def show_invoices(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Vendor/Contractor Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('vo_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def create_invoices(self):
        for rec in self:

            vals_inv = {}
            vals_inv['invoice_date'] = rec.date
            vals_inv['move_type'] = 'in_invoice'
            vals_inv['vo_id'] = rec.id
            vals_inv['partner_id'] = rec.partner_id.id

            inv_lines = []

            for item in rec.vo_line_ids:
                a = (0, 0, {
                    'quantity': item.actual_qty - item.product_qty,
                    'price_unit': item.variation_value,
                    'name': item.name,
                    'product_id': item.product_id and item.product_id.id or False,
                    'analytic_account_id': rec.contract_no.analytic_id.id,
                })

                inv_lines.append(a)
            vals_inv['invoice_line_ids'] = inv_lines
            inv = self.env['account.move'].create(vals_inv)
            inv.action_post()
            inv.project_id = rec.project_id.id


class VOLine(models.Model):
    _name = 'kg.vo.line'

    _description = 'Products for TSWO'

    sequence = fields.Integer('Sequence', default=20)
    contract_line_id = fields.Many2one('contract.pricelist.line', 'Item Code')

    name = fields.Char('Description')
    product_id = fields.Many2one(
        'product.product', 'Product')
    product_tmpl_id = fields.Many2one('product.template', related="product_id.product_tmpl_id", readonly=True)
    product_qty = fields.Float(
        'Orginal Quantity', default=0.0, digits=(16, 3), readonly=True)
    actual_qty = fields.Float('Actual Quantity', digits=(16, 3))
    product_uom_id = fields.Many2one(
        'uom.uom', 'Unit of Measure',
    )
    governorate = fields.Many2one('kg.governorate', 'Governorate')
    regional_coefficient = fields.Many2one('kg.regional.coefficient', 'Regional Coefficient')

    equipment_cost = fields.Float('Equipment Cost', digits=(16, 3))
    service_cost = fields.Float('Service Cost', digits=(16, 3))
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    reg_coefficient = fields.Float('Regional Coefficient', digits=(16, 3))

    price_subtotal = fields.Float('Original Value', compute='comp_total', digits=(16, 3))
    variation_value = fields.Float('Variation Value', compute='comp_total', digits=(16, 3))
    vo_id = fields.Many2one('kg.vo', string='VO Reference', ondelete='cascade', copy=False)
    regional_coefficient_id = fields.Many2one('contract.pricelist.regional.coefficient', 'Regional Coefficient',
                                              domain="[('contract_pricelist_id','=',contract_no)]")

    @api.onchange('contract_line_id')
    def onchange_contract_line_id(self):
        for rec in self:
            rec.product_id = rec.contract_line_id.product_id.id

    @api.onchange('product_id')
    def onchange_product_id(self):
        for rec in self:
            rec.name = rec.product_id.name
            rec.product_uom_id = rec.product_id.uom_id.id

    @api.onchange('contract_no', 'product_id')
    def onchange_contract_no(self):
        for rec in self:
            print(rec.contract_no.pricelist_line_ids)
            for line in rec.contract_no.pricelist_line_ids:
                if line.product_id == rec.product_id:
                    rec.equipment_cost = line.equipment_cost
                    rec.service_cost = line.service_cost
                    break
                else:
                    rec.equipment_cost = 0.0
                    rec.service_cost = 0.0

    # @api.onchange('regional_coefficient')
    # def onchange_regional_coefficient(self):
    #     for rec in self:
    #         if rec.regional_coefficient:
    #             rec.reg_coefficient = rec.regional_coefficient.reg_coefficient
    @api.onchange('regional_coefficient_id')
    def onchange_regional_coefficient(self):
        for rec in self:
            if rec.regional_coefficient_id:
                rec.reg_coefficient = rec.regional_coefficient_id.reg_coefficient

    @api.depends('reg_coefficient', 'service_cost', 'equipment_cost', 'product_qty', 'actual_qty')
    def comp_total(self):
        for rec in self:
            orginal_total = ((rec.service_cost * rec.reg_coefficient) + rec.equipment_cost) * rec.product_qty
            actual_total = ((rec.service_cost * rec.reg_coefficient) + rec.equipment_cost) * rec.actual_qty

            rec.price_subtotal = orginal_total
            if rec.actual_qty > 0:
                rec.variation_value = actual_total - orginal_total
            else:
                rec.variation_value = 0
