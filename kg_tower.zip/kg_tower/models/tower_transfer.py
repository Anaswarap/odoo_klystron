from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class TowerTransfer(models.Model):
    _name = 'tower.transfer'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name')
    tower_id = fields.Many2one('product.product', 'Tower')
    contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
    partner_ids = fields.Many2many('res.partner', string='partners', compute='_compute_partners')
    partner_id = fields.Many2one('res.partner', 'Contractor')
    project_id = fields.Many2one('project.project', 'Project')
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)

    site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)

    state = fields.Selection(
        [('new', 'New'), ('waiting', 'Waiting'), ('transfer', 'Transfer Requested'), ('confirm', 'Confirm'),
         ('cancel', 'Cancelled')], default='new')

    quant_ids = fields.One2many(
        comodel_name='search.stock.quant',
        inverse_name='tt_id',
        string='Stock On Hand',
        required=False)
    so_count = fields.Integer('SO Count', compute='comp_so_count')
    tower_selected = fields.Boolean(
        string='Tower Selected',
        required=False, default=False, copy=False)

    @api.depends('contract_no', 'contract_no.contractor_line_ids.partner_id')
    def _compute_partners(self):
        for rec in self:
            print(rec.contract_no.contractor_line_ids)
            rec.partner_ids = rec.contract_no.contractor_line_ids.mapped('partner_id').ids

    def comp_so_count(self):
        for record in self:
            record.so_count = self.env['stock.order'].search_count(
                [('tower_transfer_id', '=', record.id)])

    def action_tower_availability(self):
        action = self.env["ir.actions.actions"]._for_xml_id("stock.action_view_quants")
        action['context'] = {
            'search_default_product_id': self.tower_id.id,
            'tower_transfer_id': self.id,
        }
        action['target'] = 'new'
        return action

    def action_view_tower_availability(self):
        action = self.env["ir.actions.actions"]._for_xml_id("kg_tower.search_tower_stock_act_window")
        action['context'] = {
            'default_tower_id': self.tower_id.id,
            'default_partner_id': self.partner_id.id,
        }
        action['target'] = 'new'
        return action

    def search_stock(self):
        products = [('is_tower', '=', True)]
        locations = [('usage', '=', 'internal')]
        if self.tower_id:
            products.append(('id', '=', self.tower_id.id))
        if self.partner_id and self.partner_id.vendor_contractor_location_id:
            locations.append(('id', '=', self.partner_id.vendor_contractor_location_id.id))
        prod_ids = self.env['product.product'].search(products).ids
        loc_ids = self.env['stock.location'].search(locations).ids
        results = self.env['stock.quant'].search([('product_id', 'in', prod_ids), ('location_id', 'in', loc_ids),
                                                  ('lot_id.state', 'in', ['ordered', 'available']),
                                                  ('quantity', '>', 0),
                                                  ('lot_id.stock_order_id.contract_no', '=', self.contract_no.id)])
        val = []
        for result in results:
            val.append({
                'product_id': result.product_id and result.product_id.id,
                'tt_id': self.id,
                'location_id': result.location_id and result.location_id.id,
                'lot_id': result.lot_id and result.lot_id.id,
                'inventory_quantity': result.inventory_quantity,
                'available_quantity': result.available_quantity,

            })
        self.env['search.stock.quant'].search([('tt_id', '=', self.id)]).unlink()
        self.env['search.stock.quant'].create(val)

    def select_tower(self):
        filter_selected_product = self.quant_ids.filtered(lambda l: l.selected)
        if len(filter_selected_product) > 1:
            raise ValidationError("You Can choose only one tower in the line !")
        quant_line_obj = self.env['search.stock.quant'].search([('tt_id', '=', self.id), ('selected', '=', True)])
        if quant_line_obj:
            self.tower_id = quant_line_obj.product_id.id
            contractor = self.env['res.partner'].search(
                [('contractor', '=', True), ('vendor_contractor_location_id', '=', quant_line_obj.location_id.id)])
            self.partner_id = contractor.id
            self.tower_selected = True

        self.env['search.stock.quant'].search([('tt_id', '=', self.id), ('selected', '=', False)]).unlink()

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('tower.transfer') or _('New')
        return super(TowerTransfer, self).create(vals)

    def create_so(self):
        for rec in self:
            so = self.env['stock.order'].search([('tower_transfer_id', '=', rec.id), ], order='date DESC', limit=1)
            rec.state = 'waiting'
            if so:
                return {
                    'type': 'ir.actions.act_window',
                    'name': "Stock Order",
                    'view_mode': 'tree,form',
                    'res_model': 'stock.order',
                    'domain': [('id', 'in', so.ids)],
                    'context': "{'create': False}",

                }
            else:
                if not rec.contract_no:
                    raise UserError(_('Link contract before you create Stock Order!'))
                if not rec.tower_id:
                    raise UserError(_('Link tower before you create Stock Order!'))
                if not rec.partner_id:
                    raise UserError(_('Link contractor before you create Stock Order!'))
                line_id = self.env['contract.pricelist.line'].search(
                    [('product_id', '=', rec.tower_id.id), ('contract_pricelist_id', '=', rec.contract_no.id)])
                default_stock_order_line_ids = []
                if line_id:
                    default_stock_order_line_ids = [(0, 0, {
                        'product_qty': 1,
                        'product_id': line_id.product_id.id or False,
                        'equipment_cost': line_id.equipment_cost,
                        'contract_line_id': line_id.id,
                        'product_uom_id': line_id.product_id.uom_id.id,
                    })]

                return {
                    'type': 'ir.actions.act_window',
                    'name': "Stock Order",
                    'view_mode': 'form',
                    'res_model': 'stock.order',
                    'context': {
                        'default_tower_transfer_id': rec.id,
                        'default_site_acq_id': rec.site_acq_id.id,
                        'default_date': fields.Date.today(),
                        'default_construction_id': rec.id,
                        'default_contract_no': rec.contract_no.id,
                        'default_partner_id': rec.partner_id.id or False,
                        'default_project_id': rec.project_id and rec.project_id.id or False,
                        'default_governorate': rec.site_acq_id.wilayat_id.governorate_id.id or False,
                        'default_work_order_no': rec.project_id.work_order_id.name or False,
                        'default_work_order_date': rec.project_id.work_order_id.work_order_date or False,
                        'default_client_site_id': rec.project_id.work_order_id.client_site_id.id or False,
                        'default_stock_order_line_ids': default_stock_order_line_ids,
                    }
                }

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirm'

    def action_transfer(self):
        for rec in self:
            if not rec.partner_id or not rec.tower_id:
                raise UserError(_('Link Contractor and Tower before confirm!'))
            rec.state = 'transfer'
            filter_selected_product = rec.quant_ids.filtered(lambda l: l.selected)
            lot = filter_selected_product.lot_id
            if len(filter_selected_product) > 1:
                raise ValidationError("You Can choose only one tower in the line !")
            if not lot.state == 'available':
                raise ValidationError("You Can not choose this tower as its not available !")
            rec.site_acq_id.tower_id = rec.tower_id.id
            rec.site_acq_id.contractor_id = rec.partner_id.id
            stock_order_id = lot.stock_order_id and lot.stock_order_id.id
            payment_term_id = lot.payment_term_id and lot.payment_term_id.id
            if rec.project_id:
                rec.project_id.stock_order_id = stock_order_id
                rec.project_id.payment_term_id = payment_term_id
                # for ms in rec.stock_order_id.milestone_ids:
                milestones = [(0,0,{'milestone_no': ms.milestone_no,
                             'milestone': ms.milestone,
                             'milestone_per': ms.milestone_per / 100}) for ms in lot.stock_order_id.milestone_ids]
                rec.project_id.sudo().update({'milestone_ids': milestones})

            if rec.project_id and rec.project_id.internal_transfer_picking_id:
                picking_type_id = rec.project_id.internal_transfer_picking_id

            else:
                picking_type_id = self.env['stock.picking.type'].create({
                    'name': rec.project_id.number + '- Internal',
                    'sequence_code': rec.project_id.number,
                    'code': 'internal',
                    # 'company_id': self.company_a.id,
                    'warehouse_id': False,
                    # 'default_location_src_id': self.stock_location_a.id,
                    'default_location_dest_id': rec.project_id.inventory_location.id,
                    'use_create_lots': False,
                    'use_existing_lots': True

                })
                rec.project_id.internal_transfer_picking_id = picking_type_id.id

            vals_inv = {}
            vals_inv['tower_transfer_id'] = rec.id
            vals_inv['site_acq_id'] = rec.site_acq_id.id
            vals_inv['project_id'] = rec.project_id and rec.project_id.id or False
            vals_inv['picking_type_id'] = picking_type_id.id
            vals_inv[
                'location_id'] = rec.partner_id and rec.partner_id.vendor_contractor_location_id and rec.partner_id.vendor_contractor_location_id.id or False
            vals_inv[
                'location_dest_id'] = rec.project_id and rec.project_id.inventory_location and rec.project_id.inventory_location.id or False
            inv_lines = []
            # a = (0, 0, {
            #     'name': rec.tower_id.name,
            #     'product_id': rec.tower_id.id,
            #     'product_uom_qty': 1,
            #     'product_uom': rec.tower_id.uom_id.id
            # })
            exact_lot = self.env['stock.production.lot'].search([('id', '=', lot.id)]).id
            a = (0, 0, {
                'description_picking': filter_selected_product.product_id.name,
                'product_id': filter_selected_product.product_id.id,
                'location_id': vals_inv['location_id'],
                'location_dest_id': vals_inv['location_dest_id'],
                'qty_done': 1,
                'lot_id': exact_lot,
                'product_uom_id': filter_selected_product.product_id.uom_id.id
            })
            inv_lines.append(a)
            vals_inv['move_line_ids_without_package'] = inv_lines
            self.env['stock.picking'].create(vals_inv)
            rec.site_id.lot_id = lot.id

            return {
                'type': 'ir.actions.act_window',
                'name': "Tower Transactions",
                'view_mode': 'tree,form',
                'res_model': 'stock.picking',
                'domain': [('tower_transfer_id', '=', rec.id)],
                'context': {

                    'default_tower_transfer_id': rec.id,
                    'default_site_acq_id': rec.site_acq_id.id,
                    'default_project_id': rec.project_id and rec.project_id.id or False,
                    'default_picking_type_id': picking_type_id.id,
                    'default_location_id': rec.partner_id and rec.partner_id.vendor_contractor_location_id and rec.partner_id.vendor_contractor_location_id.id or False,
                    'default_location_dest_id': rec.project_id and rec.project_id.inventory_location and rec.project_id.inventory_location.id or False
                }
            }

    # @api.onchange('contract_no')
    # def onchange_partner_id(self):
    #     print("kkkklllmmmnnn")
    #     if self.contract_no:
    #         partner = self.contract_no.contractor_line_ids.mapped('partner_id')
    #         print("partner", partner)
    #         domain = [('partner_id', 'in', partner.ids)]
    #         print("domain", domain)
    #         return domain


class Stock(models.Model):
    _name = 'search.stock.quant'
    _description = 'Lines'

    tt_id = fields.Many2one('tower.transfer', string='Tower Transfer')
    product_id = fields.Many2one(
        comodel_name='product.product',
        string='Product',
        required=False)
    location_id = fields.Many2one(
        comodel_name='stock.location',
        string='Location',
        required=False)
    lot_id = fields.Many2one(
            comodel_name='stock.production.lot',
        string='Lot',
        required=False)
    inventory_quantity = fields.Float(
        string='Inventory Quantity',
        required=False)
    available_quantity = fields.Float(
        string='Inventory Available',
        required=False)
    selected = fields.Boolean(
        string='Select',
        required=False, default=False)

    @api.constrains('selected', 'tt_id')
    def _check_max_tenant_limit_tswo_project(self):
        for rec in self:
            count = rec.search_count([('tt_id', '=', rec.tt_id.id), ('selected', '=', True)])
            print('count', count)
            if count > 1:
                raise UserError(_("You can only select one tower!"))
