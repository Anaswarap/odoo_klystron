# -*- coding: utf-8 -*-

from odoo import http, _
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from odoo.exceptions import AccessError, MissingError
from odoo.http import request
from odoo.osv.expression import AND, OR


class CustomerPortal(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'work_order_count' in counters:
            values['work_order_count'] = request.env['work.order'].search_count(
                ['|', '|', ('operator_id', '=', request.env.user.partner_id.id),
                 ('operator_id', '=', request.env.user.partner_id.parent_id.id),
                 ('operator_id', 'in', request.env.user.partner_id.child_ids.ids)])
        return values

    def _get_nswo_search_domain(self, search_in, search):
        search_domain = []
        if search_in in ('search_ring_request', 'nswo_no'):
            search_domain = OR(
                [search_domain, ['|', '|', ('name', 'ilike', search), ('client_work_order_no', 'ilike', search),
                                 ('client_site_id', 'ilike', search)]])
        return search_domain

    def _get_nswo_searchbar_inputs(self):
        return {
            'nswo_no': {'input': 'nswo_no', 'label': _('Search NSWO No.')},
        }

    # ------------------------------------------------------------
    # My Work Order Request
    # ------------------------------------------------------------
    def _work_order_get_page_view_values(self, request_id, access_token, **kwargs):
        values = {
            'page_name': 'site_work_order',
            'work_order_request': request_id,
        }
        return self._get_page_view_values(request_id, access_token, values, 'my_work_order_history', False, **kwargs)

    @http.route(['/my/work_order', '/my/work_order/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_work_orders(self, page=1, date_begin=None, date_end=None, sortby=None, search=None,
                              search_in='nswo_no', **kw):
        values = self._prepare_portal_layout_values()
        print("portal_my_work_orders values:", values)
        WorkOrder = request.env['work.order']
        domain = ['|', '|', ('operator_id', '=', request.env.user.partner_id.id),
                  ('operator_id', '=', request.env.user.partner_id.parent_id.id),
                  ('operator_id', 'in', request.env.user.partner_id.child_ids.ids)]

        searchbar_sortings = {
            'date': {'label': _('Newest'), 'order': 'create_date desc'},
            # 'submit_date': {'label': _('Submitted Date'), 'order': 'date desc'},
            'name': {'label': _('Name'), 'order': 'name'},
        }
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        if date_begin and date_end:
            domain += [('create_date', '>', date_begin), ('create_date', '<=', date_end)]
        print(search, "SEARDCHHH", search_in)
        if search and search_in:
            domain += self._get_nswo_search_domain(search_in, search)
            print(domain,"DOMAINNN")

        searchbar_inputs = self._get_nswo_searchbar_inputs()

        # work order count
        work_order_count = WorkOrder.search_count(domain)
        # pager
        pager = portal_pager(
            url="/my/work_order",
            url_args={'date_begin': date_begin, 'date_end': date_end, 'sortby': sortby, 'search_in': search_in,
                      'search': search},
            total=work_order_count,
            page=page,
            step=self._items_per_page
        )
        print(pager, "PAGER")

        # content according to pager and archive selected
        requests = WorkOrder.search(domain, order=order, limit=self._items_per_page, offset=pager['offset'])
        request.session['my_work_order_history'] = requests.ids[:100]
        print("requesttt", requests, "SSSSSSSSS")

        values.update({
            'date': date_begin,
            'date_end': date_end,
            'requests': requests,
            'search_in': search_in,
            'search': search,
            'page_name': 'site_work_order',
            'default_url': '/my/work_order',
            'pager': pager,
            'searchbar_sortings': searchbar_sortings,
            'searchbar_inputs': searchbar_inputs,
            'sortby': sortby
        })
        return request.render("kg_tower.portal_my_work_orders", values)

    @http.route(['/my/work_order/<int:request_id>'], type='http', auth="user", website=True)
    def portal_my_work_order(self, request_id=None, access_token=None, **kw):
        try:
            work_order_sudo = self._document_check_access('work.order', request_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')

        values = self._work_order_get_page_view_values(work_order_sudo, access_token, **kw)
        print(values, "VALUES")
        partner_id = request.env.user.partner_id.id
        partner = work_order_sudo.partner_id.parent_id and work_order_sudo.partner_id.parent_id.name or work_order_sudo.partner_id.name
        technology_ids = request.env['radio.technology'].sudo().search([])
        srr_id = request.env['ring.request'].sudo().search(
            [('state', '=', 'completed'), ('partner_id', '=', request.env.user.partner_id.id)])
        cabinet_space = request.env['cabinet.space'].sudo().search([])
        shelter_space = request.env['shelter.space'].sudo().search([])
        Antenna_count = len(values['work_order_request'].mapped('antenna_lines'))
        micro_lines_count = len(values['work_order_request'].mapped('micro_lines'))
        rru_lines_count = len(values['work_order_request'].mapped('rru_lines'))
        print(Antenna_count, "Count")
        values.update({
            'page_name': 'existing_site_work_order',
            'technology_ids': technology_ids,
            'partner_id': partner_id,
            'parent_id': partner,
            'srr_id': srr_id,
            'cabinet_space': cabinet_space,
            'shelter_space': shelter_space,
            'antenna_count': Antenna_count if Antenna_count else "0",
            'micro_lines_count': micro_lines_count if micro_lines_count else "0",
            'rru_lines_count': rru_lines_count if rru_lines_count else "0"
        })
        print(values, "??????????????????????/")
        return request.render("kg_tower.portal_my_work_order", values)
