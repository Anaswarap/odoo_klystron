# -*- coding: utf-8 -*-
import base64
import logging

from odoo import http, _
from odoo.http import request

_logger = logging.getLogger('odoo')


class SearchRingRequest(http.Controller):

    def _create_attachment(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': base64.encodebytes(file.read()),
            'res_model': 'ring.request',
            'res_id': res_id
        })
        return attachment_id.datas

    def _create_attachment_nswo(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': base64.encodebytes(file.read()),
            'res_model': 'work.order',
            'res_id': res_id
        })
        return attachment_id.datas

    def _save_image(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': file.encode(),
            'res_model': 'ring.request',
            'res_id': res_id,
        })
        return attachment_id.datas

    def _save_image_nswo(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': file.encode(),
            'res_model': 'work.order',
            'res_id': res_id,
        })
        return attachment_id.datas

    @http.route('/form/ring_request', type='http', auth="user", methods=['POST', 'GET'], website=True)
    def portal_search_ring_request(self, **post):
        srr_model = request.env['ir.model'].sudo().search([('model', '=', 'work.order')])
        if post and request.httprequest.method == 'POST':
            RingRequest = request.env['ring.request'].sudo()
            vals = {
                'create_partner_id': request.env.user.partner_id.id,
                'partner_id': request.env.user.partner_id.get_operator_id(),
                # 'priority': post.get('priority'),
                'date': post.get('date'),
                'client_work_order_no': post.get('work_order_no'),
                'latitude': post.get('latitude'),
                'longitude': post.get('longitude'),
                'search_radius': post.get('radius'),
                # 'micro_wave': post.get('micro_antenna'),
                # 'radio_wave': post.get('radio_antenna'),
                'notes': post.get('technical_requirement'),
                'expected_completion_days': post.get('expected_days'),
                'epa_id': post.get('epa_allowance'),
                'tower_height': post.get('tower_height'),
                'model_id': srr_model.id,
            }
            search_ring_request_id = RingRequest.create(vals)
            attachment = post.get('attachment')
            attachment = self._create_attachment(attachment, search_ring_request_id.id)
            if not post.get('upload'):
                attachment_sign = post.get('contractdata')
                attachment_sign = self._save_image(attachment_sign, search_ring_request_id.id)
            else:
                attachment_sign = post.get('up_signature')
                attachment_sign = self._create_attachment(attachment_sign, search_ring_request_id.id)

            search_ring_request_id.sudo().write({
                'attachment': attachment,
                'attachment_sign': attachment_sign,
            })
            msg = "Your request for search ring is submitted."
            return request.render('kg_tower.form_thankyou_template',
                                  {'message': msg,
                                   'booking_ref': search_ring_request_id.name, })


        else:
            epa_allowance = request.env['epa.allowance'].sudo().search([], order='id asc')
            # tower_height = request.env['tower.height'].sudo().search([], order='id asc')
            # partner_id = request.env.user.partner_id.id
            partner = request.env.user.partner_id.parent_id and request.env.user.partner_id.parent_id.name or request.env.user.partner_id.name
            return request.render('kg_tower.portal_search_ring_request', {
                'partner_id': request.env.user.partner_id.id,
                'partner_name': partner,
                'epa_allowance': epa_allowance,
                # 'tower_height': tower_height,
            })

    @http.route('/form/work_order', type='http', auth="user", methods=['POST', 'GET'], website=True)
    def portal_work_order(self, **post):
        if post and request.httprequest.method == 'POST':
            nswo_model = request.env['ir.model'].sudo().search([('model', '=', 'work.order')])
            WorkOrder = request.env['work.order'].sudo()
            cabin_space_obj = request.env['cabinet.space'].sudo()
            shelter_space_obj = request.env['shelter.space'].sudo()
            shelter_space = ''
            ssr_id = int(post.get('srr_id')) if post.get('srr_id') else ""
            shelter = True if post.get('equipment_housing') else False
            list = []
            rru_list = []
            microwave_list = []
            rx_list = []
            search_key = 'tech_'
            list = [int(key.split("tech_", 1)[1]) for key, val in post.items() if search_key in key]

            if post.get('ignore_pan_antenna') != 'on':
                for j in range(0, int(post.get('no_of_antennas'))):
                    radio_antenna_obj = request.env['radio.antenna'].sudo().search(
                        [('id', '=', post.get('antenna_' + str(j + 1)))])
                    child = {
                        'antenna_id': radio_antenna_obj.id,
                        'sector': '3',  # post.get('sector_' + str(j + 1)),
                        'tower_height': post.get('sector_height_' + str(j + 1)),
                        'azimuth': post.get('sector_azimuth_' + str(j + 1)),
                    }
                    rx_list.append((0, 0, child))

            if post.get('ignore_microwave') != 'on':
                for i in range(0, int(post.get('no_of_microwave'))):
                    microwave_obj = request.env['micro.dishes'].sudo().search(
                        [('id', '=', post.get('microwave_' + str(i + 1)))])
                    mw_child = {
                        'micro_id': microwave_obj.id,
                        'tower_height': post.get('microwave_height_' + str(i + 1)),
                        'azimuth': post.get('microwave_azimuth_' + str(i + 1)),
                    }
                    microwave_list.append((0, 0, mw_child))

            if post.get('ignore_rru') != 'on':
                for k in range(0, int(post.get('no_of_rru'))):
                    rru_obj = request.env['rru.antenna'].sudo().search([('id', '=', post.get('rru_' + str(k + 1)))])
                    rru_child = {
                        'rru_id': rru_obj.id,
                        'rru_position': post.get('site_type_' + str(k + 1))
                    }
                    rru_list.append((0, 0, rru_child))

            if shelter and post.get('shelter_space') == 'others':
                new_shelter_space = shelter_space_obj.create({
                    'name': "Height : " + post.get('housing_height') + " Width :" + post.get(
                        'housing_width') + " Dia :" + post.get('housing_diameter'),
                    'height': post.get('housing_height'),
                    'width': post.get('housing_width'),
                    'diameter': post.get('housing_diameter'),
                })
                shelter_space = new_shelter_space.id
            elif shelter and post.get('shelter_space') != '':
                shelter_space = shelter_space_obj.search(
                    [('id', '=', int(post.get('shelter_space')))]).id
            else:
                shelter_space = False
            vals = {
                'partner_id': request.env.user.partner_id.id,
                'operator_id': request.env.user.partner_id.get_operator_id(),
                'client_work_order_no': post.get('client_work_order'),
                'existing_site': post.get('existing_site'),
                'client_site_id': post.get('client_site_id'),
                'site_type': post.get('site_type'),
                'uso_site': post.get('uso_site'),
                'location_no': post.get('location_no'),
                'antenna_lines': rx_list,
                'micro_lines': microwave_list,
                'rru_lines': rru_list,
                'radio_technology_note': post.get('radio_technology_note'),
                'planned_radio_technology_ids': list,
                'sector_azimuth': post.get('sector_azimuth'),
                'sector_height': post.get('sector_height'),
                'no_of_antennas': '1',
                'antenna_height': post.get('antenna_height'),
                'antenna_width': post.get('antenna_width'),
                'antenna_diameter': post.get('antenna_diameter'),
                # 'microwave_dishes': 1,
                'latitude': post.get('latitude'),
                'longitude': post.get('longitude'),
                'governorate': int(post.get('governorate')) if post.get('governorate') else False,
                'wilayat': int(post.get('wilayat')) if post.get('wilayat') else False,
                # 'housing_height': post.get('housing_height'),
                'tower_height': int(post.get('tower_height')) if post.get('tower_height') else False,
                'epa_allowance': int(post.get('epa_allowance')) if post.get('epa_allowance') else False,
                'with_cable': post.get('with_cable'),
                'rent': post.get('rent'),
                'no_srr': False if (post.get('is_ssr') is not None) else True,
                'srr_id': ssr_id if post.get('is_ssr') else '',
                'shelter_space': shelter_space,
                'structure_type_id': int(post.get('structure_type_id')) if post.get('structure_type_id') else "",
                # 'housing_width': post.get('housing_width'),
                # 'housing_diameter': post.get('housing_diameter'),
                'extra_space_request': post.get('extra_space_request') if shelter else '',
                'expected_grid_connection': post.get('expected_grid_connection'),
                'terms_conditions': post.get('terms_conditions'),
                'signed_user': request.env.user.id,
                'email': post.get('email'),
                'shelter_rent': post.get('shelter_rent') if shelter else '',
                'submission_type': post.get('submission_type') if post.get('is_submission_type') else 'submit',
                'transmission_type_id': int(post.get('transmission_type')) if post.get('transmission_type') else False,
                'extra_space_meter': post.get('extra_space_meter'),
                'extra_space_rent': post.get('extra_space_rent'),
                'load_category': post.get('load_category'),
                'off_grid_power_supply': post.get('off_grid_power_supply'),
                'tower_height_input': post.get('tower_height_input') if post.get('tower_height_input') else False,
                'model_id': nswo_model.id,
                'type_equipment_housing': post.get('equipment_housing')
            }
            create_work_order = WorkOrder.sudo().create(vals)
            if not post.get('upload'):
                attachment_sign = post.get('contractdata')
                attachment_sign = self._save_image_nswo(attachment_sign, create_work_order.id)
            else:
                attachment_sign = post.get('up_signature')
                attachment_sign = self._create_attachment_nswo(attachment_sign, create_work_order.id)

            cabin_space = post.get('cabinet_space')
            if cabin_space == '':
                create_work_order.cabinet_space_id = None
            elif cabin_space == 'others':
                new_cabin_space = cabin_space_obj.create({
                    'name': post.get('cabinet_space_name'),
                    'height': post.get('cabinet_space_height'),
                    'width': post.get('cabinet_space_width'),
                    'depth': post.get('cabinet_space_depth'),
                })
                create_work_order.cabinet_space_id = new_cabin_space.id
            else:
                create_work_order.cabinet_space_id = cabin_space_obj.search(
                    [('id', '=', int(cabin_space) if cabin_space else '')]).id

            create_work_order.sudo().write({
                'attachment_sign': attachment_sign,
            })

            msg = "New site work order form is submitted."
            _logger.info(_("Created New NSWO with parameters %s") % (post.items()))
            return request.render('kg_tower.form_thankyou_template',
                                  {'message': msg,
                                   'booking_ref': create_work_order.name})

        else:
            partner_id = request.env.user.partner_id.id
            partner = request.env.user.partner_id.parent_id and request.env.user.partner_id.parent_id.name or request.env.user.partner_id.name
            microwave_dishes = request.env['micro.dishes'].sudo().search([])
            rru = request.env['rru.antenna'].sudo().search([])
            governorate = request.env['kg.governorate'].sudo().search([])
            shelter_space = request.env['shelter.space'].sudo().search([])

            rents = request.env['rent.calculation'].sudo().search([('partner_id', '=', partner)])
            tower_height = rents.mapped('tower_height_id')
            tower_height = request.env['tower.height'].sudo().search([], order='name asc')
            max_tower_height = max([float(h.name) for h in tower_height])
            epa_allowance = request.env['epa.allowance'].sudo().search([],
                                                                       order='id asc')  # [AKS] not ordering by name needs to check
            # max_epa_allowance = max([float(e.name) for e in epa_allowance])
            wilayat = request.env['kg.wilayat'].sudo().search([])
            structure_type_id = request.env['structure.type'].sudo().search([('is_main_structure', '=', True)])
            srr_id = request.env['ring.request'].sudo().search(
                [('state', 'in', ('completed', 'sent_to_client')),
                 ('partner_id', '=', request.env.user.partner_id.parent_id.id)])
            technology_ids = request.env['radio.technology'].sudo().search([])
            transmission_type_id = request.env['transmission.type'].sudo().search([])
            load_category = request.env['power.load.category'].sudo().search(
                [('operator_id', '=',
                  request.env.user.partner_id.parent_id.id if request.env.user.partner_id.parent_id else partner_id)])
            cabinet_space = request.env['cabinet.space'].sudo().search([])
            extra_ground_space = request.env['ground.space'].sudo().search([])

            # print("LLLLL", tower_height, epa_allowance)
            # print("LLLLL", request.env.user.partner_id.is_submission_type)
            return request.render('kg_tower.portal_new_site_work_order',
                                  {
                                      'partner_id': partner_id,
                                      'parent_id': partner,
                                      'partner_name': request.env.user.name,
                                      'email': request.env.user.email,
                                      'micro_wave_dishes': microwave_dishes,
                                      'rru': rru,
                                      'governorate': governorate,
                                      'shelter_space': shelter_space,
                                      'tower_height': tower_height,
                                      'max_tower_height': max_tower_height,
                                      'epa_allowance': epa_allowance,
                                      # 'max_epa_allowance': max_epa_allowance,
                                      'technology_ids': technology_ids,
                                      'srr_id': srr_id,
                                      'wilayat': wilayat,
                                      'structure_type_id': structure_type_id,
                                      'transmission_type_id': transmission_type_id,
                                      'is_submission_type': request.env.user.partner_id.is_submission_type,
                                      'load_category': load_category,
                                      'cabinet_space': cabinet_space,
                                      'extra_ground_space': extra_ground_space,
                                  })

    @http.route('/request/ring_request/modify', type='http', auth="user", methods=['POST'], website=True)
    def portal_ring_request_modify(self, **post):
        RingRequest = request.env['ring.request'].sudo()
        diff_fields = {
            'work_order_no': 'client_work_order_no',
            # 'micro_antenna': 'micro_wave',
            # 'radio_antenna': 'radio_wave',
            'technical_requirement': 'notes',
            'expected_days': 'expected_completion_days',
        }
        form_keys = diff_fields.keys()
        rec_id = post.get('rec_id')
        request_id = RingRequest.browse(int(rec_id))
        exception_vals = ['rec_id', 'radius']
        new_vals = {}
        for val in post:
            if val not in exception_vals:
                rec_value = post.get(val)
                rec_field = diff_fields[val] if val in form_keys else val
                if not self._compare_request_value(request_id, rec_field, rec_value):
                    if rec_field == 'attachment':
                        # attachment_ids = request.env['ir.attachment'].sudo().search(
                        #     [('res_model', '=', 'ring.request'), ('res_id', '=', request_id.id)])
                        # attachment_ids.unlink()
                        new_attachment = self._create_attachment(rec_value, request_id.id)
                        if new_attachment:
                            new_vals.update({
                                rec_field: new_attachment
                            })
                    else:
                        if rec_field == 'epa_id' and not rec_value:
                            rec_value = False
                        if rec_field == 'tower_height_id' and not rec_value:
                            rec_value = False
                        new_vals.update({
                            rec_field: rec_value
                        })
        if new_vals:
            request_id.write(new_vals)
        values = {
            'page_name': 'search_ring_request',
            'srr_request': request_id,
        }
        return request.render("kg_tower.portal_my_srr", values)

    def _compare_request_value(self, rec_id, field_name, value):
        rec = rec_id.sudo().read([field_name])
        exists = True
        if rec:
            rec_value = rec[0].get(field_name)
            if field_name == 'attachment':
                if rec_value == base64.encodebytes(value.read()):
                    return False
            if str(rec_value) != value:
                return False
        return True

    @http.route('/request/work_order/modify', type='http', auth="user", methods=['POST'], website=True)
    def portal_work_order_modify(self, **post):
        WorkOrder = request.env['work.order'].sudo()
        shelter_space_obj = request.env['shelter.space'].sudo()
        cabin_space_obj = request.env['cabinet.space'].sudo()
        cabin_space = post.get('cabinet_space')
        diff_fields = {
            'client_work_order': 'client_work_order_no',
            'tenants': 'tower_tenants',
            'micro_wave_dishes': 'microwave_dishes',
            'other': 'others',
        }
        form_keys = diff_fields.keys()
        rec_id = post.get('rec_id')
        request_id = WorkOrder.browse(int(rec_id))
        exception_vals = ['rec_id', 'partner_id', 'signed_user', 'ring_work_order']
        new_vals = {}
        rx_list = []
        microwave_list = []
        rru_list = []
        if post.get('ignore_pan_antenna') != 'on' and not request_id.antenna_lines:
            if post.get('no_of_antennas'):
                for j in range(0, int(post.get('no_of_antennas'))):
                    radio_antenna_obj = request.env['radio.antenna'].sudo().search(
                        [('id', '=', int(post.get('antenna_' + str(j + 1))))])
                    child = {
                        'antenna_id': radio_antenna_obj.id,
                        'sector': '3',  # post.get('sector_' + str(j + 1)),
                        'tower_height': post.get('sector_height_' + str(j + 1)),
                        'azimuth': post.get('sector_azimuth_' + str(j + 1)),
                    }
                    rx_list.append((0, 0, child))
        else:
            if int(post.get('antenna_id_1')):
                length = int(post.get('ext_line_count')) if post.get('ext_line_count') else 0
                # length = len(request_id.antenna_lines)
                if length > 0:
                    antenna_ids = [int(post.get('antenna_id_' + str(k + 1))) for k in range(length)]
                    missing_antenna_ids = set(request_id.antenna_lines.ids) - set(antenna_ids)
                    if missing_antenna_ids:
                        missing_antenna_lines = request.env['work.order.antenna.lines'].sudo().browse(
                            list(missing_antenna_ids))
                        missing_antenna_lines.unlink()
                new_legth = len(request_id.antenna_lines)
                for k in range(0, new_legth):
                    antenna = int(post.get('antenna_id_' + str(k + 1)))
                    line = request.env['work.order.antenna.lines'].sudo().browse(antenna)
                    if line:
                        radio_antenna_obj = request.env['radio.antenna'].sudo().search(
                            [('id', '=', post.get('antenna_' + str(k + 1)))])
                        line.update({
                            'antenna_id': radio_antenna_obj.id,
                            'sector': '3',  # post.get('sector_' + str(j + 1)),
                            'tower_height': post.get('sector_height_' + str(k + 1)),
                            'azimuth': post.get('sector_azimuth_' + str(k + 1)),
                        })
                if int(post.get('no_of_antennas')) > length:
                    for j in range(length, int(post.get('no_of_antennas'))):
                        radio_antenna_obj = request.env['radio.antenna'].sudo().search(
                            [('id', '=', post.get('antenna_' + str(j + 1)))])
                        request.env['work.order.antenna.lines'].sudo().create({
                            'antenna_id': radio_antenna_obj.id,
                            'work_order_id': request_id.id,
                            'sector': '3',
                            'tower_height': post.get('sector_height_' + str(j + 1)),
                            'azimuth': post.get('sector_azimuth_' + str(j + 1)),
                        })
            else:
                length = len(request_id.antenna_lines)
                if int(post.get('no_of_antennas')) > length:
                    for j in range(length + 1, int(post.get('no_of_antennas'))):
                        radio_antenna_obj = request.env['radio.antenna'].sudo().search(
                            [('id', '=', post.get('antenna_' + str(j + 1)))])
                        request.env['work.order.antenna.lines'].sudo().create({
                            'antenna_id': radio_antenna_obj.id,
                            'work_order_id': request_id.id,
                            'sector': '3',  # post.get('sector_' + str(j + 1)),
                            'tower_height': post.get('sector_height_' + str(j + 1)),
                            'azimuth': post.get('sector_azimuth_' + str(j + 1)),
                        })

        if post.get('ignore_microwave') != 'on' and not request_id.micro_lines:
            if post.get('no_of_microwave'):
                for i in range(0, int(post.get('no_of_microwave'))):
                    microwave_obj = request.env['micro.dishes'].sudo().search(
                        [('id', '=', post.get('microwave_' + str(i + 1)))])
                    mw_child = {
                        'micro_id': microwave_obj.id,
                        'tower_height': post.get('microwave_height_' + str(i + 1)),
                        'azimuth': post.get('microwave_azimuth_' + str(i + 1)),
                    }
                    microwave_list.append((0, 0, mw_child))
        else:
            if post.get('microwave_id_1'):
                length = int(post.get('ext_micro_line_count')) if post.get('ext_micro_line_count') else 0
                if length > 0:
                    micro_ids = [int(post.get('microwave_id_' + str(k + 1))) for k in range(length)]
                    missing_micro_ids = set(request_id.micro_lines.ids) - set(micro_ids)
                    if missing_micro_ids:
                        missing_micro_lines = request.env['work.order.microwave.lines'].sudo().browse(
                            list(missing_micro_ids))
                        missing_micro_lines.unlink()
                new_legth = len(request_id.micro_lines)
                for k in range(0, new_legth):
                    micro = int(post.get('microwave_id_' + str(k + 1)))
                    line = request.env['work.order.microwave.lines'].sudo().browse(micro)
                    if line:
                        microwave_obj = request.env['micro.dishes'].sudo().search(
                            [('id', '=', post.get('microwave_' + str(k + 1)))])
                        line.update({
                            'micro_id': microwave_obj.id,
                            'tower_height': post.get('microwave_height_' + str(k + 1)),
                            'azimuth': post.get('microwave_azimuth_' + str(k + 1)),
                        })
                if int(post.get('no_of_microwave')) > length:
                    for j in range(length, int(post.get('no_of_microwave'))):
                        microwave_obj = request.env['micro.dishes'].sudo().search(
                            [('id', '=', post.get('microwave_' + str(j + 1)))])
                        request.env['work.order.microwave.lines'].sudo().create({
                            'micro_id': microwave_obj.id,
                            'tower_height': post.get('microwave_height_' + str(j + 1)),
                            'azimuth': post.get('microwave_azimuth_' + str(j + 1)),
                            'work_order_id': request_id.id
                        })

            else:
                length = len(request_id.micro_lines)
                if post.get('no_of_microwave'):
                    if int(post.get('no_of_microwave')) > length:
                        for j in range(length + 1, int(post.get('no_of_microwave'))):
                            microwave_obj = request.env['micro.dishes'].sudo().search(
                                [('id', '=', post.get('microwave_' + str(j + 1)))])
                            request.env['work.order.microwave.lines'].sudo().create({
                                'micro_id': microwave_obj.id,
                                'tower_height': post.get('microwave_height_' + str(j + 1)),
                                'azimuth': post.get('microwave_azimuth_' + str(j + 1)),
                                'work_order_id': request_id.id
                            })

        if post.get('ignore_rru') != 'on' and not request_id.rru_lines:
            if post.get('no_of_rru'):
                for k in range(0, int(post.get('no_of_rru'))):
                    rru_obj = request.env['rru.antenna'].sudo().search([('id', '=', post.get('rru_' + str(k + 1)))])
                    rru_child = {
                        'rru_id': rru_obj.id,
                        'rru_position': post.get('site_type_' + str(k + 1))
                    }
                    rru_list.append((0, 0, rru_child))
        else:
            if int(post.get('rru_id_1')):
                length = int(post.get('ext_rru_line_count')) if post.get('ext_rru_line_count') else 0
                if length > 0:
                    rru_ids = [int(post.get('rru_id_' + str(k + 1))) for k in range(length)]
                    missing_rru_ids = set(request_id.rru_lines.ids) - set(rru_ids)
                    if missing_rru_ids:
                        missing_rru_lines = request.env['work.order.rru.lines'].sudo().browse(
                            list(missing_rru_ids))
                        missing_rru_lines.unlink()
                new_legth = len(request_id.rru_lines)
                for k in range(0, new_legth):
                    rru = int(post.get('rru_id_' + str(k + 1)))
                    line = request.env['work.order.rru.lines'].sudo().browse(rru)
                    if line:
                        rru_obj = request.env['rru.antenna'].sudo().search(
                            [('id', '=', post.get('rru_' + str(k + 1)))])
                        line.update({
                            'rru_id': rru_obj.id,
                            'rru_position': post.get('site_type_' + str(k + 1))
                        })
                if int(post.get('no_of_rru')) > length:
                    for j in range(length, int(post.get('no_of_rru'))):
                        rru_obj = request.env['rru.antenna'].sudo().search(
                            [('id', '=', post.get('rru_' + str(j + 1)))])
                        request.env['work.order.rru.lines'].sudo().create({
                            'rru_id': rru_obj.id,
                            'rru_position': post.get('site_type_' + str(j + 1)),
                            'work_order_id': request_id.id
                        })
            else:
                length = len(request_id.rru_lines)
                if int(post.get('no_of_rru')) > length:
                    for j in range(length + 1, int(post.get('no_of_rru'))):
                        rru_obj = request.env['rru.antenna'].sudo().search(
                            [('id', '=', post.get('rru_' + str(j + 1)))])
                        request.env['work.order.rru.lines'].sudo().create({
                            'rru_id': rru_obj.id,
                            'rru_position': post.get('site_type_' + str(j + 1)),
                            'work_order_id': request_id.id
                        })

        for val in post:
            if val not in exception_vals:
                rec_value = post.get(val)
                rec_field = diff_fields[val] if val in form_keys else val
                if not self._compare_request_values(request_id, rec_field, rec_value):
                    if rec_field:
                        if rec_field == 'equipment_housing':
                            temp_val = rec_value
                            rec_value = False
                            request_id.sudo().update({
                                'type_equipment_housing': temp_val if temp_val else False
                            })
                        if rec_field == 'shelter_space' and rec_value == 'others':
                            new_shelter_space = shelter_space_obj.create({
                                'name': "Height : " + post.get('housing_height') + " Width :" + post.get(
                                    'housing_width') + " Dia :" + post.get('housing_diameter'),
                                'height': post.get('housing_height'),
                                'width': post.get('housing_width'),
                                'diameter': post.get('housing_diameter'),
                            })
                            rec_value = new_shelter_space.id
                        if rec_field == 'cabinet_space' and rec_value == 'others':
                            new_cabin_space = cabin_space_obj.create({
                                'name': post.get('cabinet_space_name'),
                                'height': post.get('cabinet_space_height'),
                                'width': post.get('cabinet_space_width'),
                                'depth': post.get('cabinet_space_depth'),
                            })
                            rec_value.cabinet_space_id = new_cabin_space.id
                        cabinet_space_id = cabin_space_obj.search(
                            [('id', '=', int(cabin_space) if cabin_space else False)])
                        request_id.sudo().update({
                            'cabinet_space_id': cabinet_space_id if cabinet_space_id else False
                        })
                        if rec_field == 'load_category' and not rec_value:
                            rec_value = False
                        if rec_field == 'srr_id' and not rec_value:
                            rec_value = False
                        if rec_field == 'equipment_housing' and not rec_value:
                            rec_value = False
                        if rec_field == 'shelter_space' and not rec_value:
                            rec_value = False
                        if rec_field == 'structure_type_id' and not rec_value:
                            rec_value = False
                        # if rec_field == 'no_of_antennas':
                        #     rec_value = '1'
                        # if rec_field in ['antenna_1', 'antenna_1', 'antenna_1', 'antenna_1', ]
                        new_vals.update({
                            rec_field: rec_value
                        })
        if new_vals:
            new_vals['no_of_antennas'] = '0'
            request_id.write(new_vals)

        if rx_list:
            request_id.sudo().write({
                'antenna_lines': rx_list
            })
        if microwave_list:
            request_id.sudo().write({
                'micro_lines': microwave_list
            })
        if rru_list:
            request_id.sudo().write({
                'rru_lines': rru_list
            })

        Antenna_count = len(request_id.mapped('antenna_lines'))
        micro_lines_count = len(request_id.mapped('micro_lines'))
        rru_lines_count = len(request_id.mapped('rru_lines'))
        values = {
            'antenna_count': Antenna_count,
            'micro_lines_count': micro_lines_count,
            'rru_lines_count': rru_lines_count,
            'page_name': 'work_order_request',
            'work_order_request': request_id,
        }

        return request.render("kg_tower.portal_my_work_order", values)

    def _compare_request_values(self, rec_id, field_name, value):
        if field_name in rec_id._fields:
            rec = rec_id.sudo().read([field_name])
            if rec:
                rec_value = rec[0].get(field_name)
                if str(rec_value) != value:
                    return False
        return True
