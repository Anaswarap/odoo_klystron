# -*- coding: utf-8 -*-

from odoo import http, _
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from odoo.exceptions import AccessError, MissingError
from odoo.http import request
from odoo.osv.expression import AND, OR


class CustomerPortal(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'srr_count' in counters:
            values['srr_count'] = request.env['ring.request'].search_count(
                ['|', '|', ('partner_id', '=', request.env.user.partner_id.id),
                 ('partner_id', '=', request.env.user.partner_id.parent_id.id),
                 ('partner_id', 'in', request.env.user.partner_id.child_ids.ids)])
        return values

    def _get_srr_search_domain(self, search_in, search):
        search_domain = []
        if search_in in ('search_ring_request', 'srr_no'):
            search_domain = OR(
                [search_domain, ['|', ('name', 'ilike', search), ('client_work_order_no', 'ilike', search)]])
        return search_domain

    def _get_srr_searchbar_inputs(self):
        return {
            'srr_no': {'input': 'srr_no', 'label': _('Search SRR No.')},
        }

    # ------------------------------------------------------------
    # My Search Ring Request
    # ------------------------------------------------------------
    def _srr_get_page_view_values(self, request_id, access_token, **kwargs):
        values = {
            'page_name': 'search_ring_request',
            'srr_request': request_id,
        }
        return self._get_page_view_values(request_id, access_token, values, 'my_srr_history', False, **kwargs)

    @http.route(['/my/ring_request', '/my/ring_request/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_srrs(self, page=1, date_begin=None, date_end=None, sortby=None,search=None,
                       search_in='srr_no', **kw):
        values = self._prepare_portal_layout_values()
        RingRequest = request.env['ring.request']
        domain = ['|', '|', ('partner_id', '=', request.env.user.partner_id.id),
                  ('partner_id', '=', request.env.user.partner_id.parent_id.id),
                  ('partner_id', 'in', request.env.user.partner_id.child_ids.ids)]

        searchbar_sortings = {
            'date': {'label': _('Newest'), 'order': 'create_date desc'},
            'submit_date': {'label': _('Submitted Date'), 'order': 'date desc'},
            'name': {'label': _('Name'), 'order': 'name'},
        }
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        if date_begin and date_end:
            domain += [('create_date', '>', date_begin), ('create_date', '<=', date_end)]

        if search and search_in:
            domain += self._get_srr_search_domain(search_in, search)

        searchbar_inputs = self._get_srr_searchbar_inputs()

        # srr count
        srr_count = RingRequest.search_count(domain)
        # pager
        pager = portal_pager(
            url="/my/ring_request",
            url_args={'date_begin': date_begin, 'date_end': date_end, 'sortby': sortby, 'search_in': search_in,
                      'search': search},
            total=srr_count,
            page=page,
            step=self._items_per_page
        )

        # content according to pager and archive selected
        requests = RingRequest.search(domain, order=order, limit=self._items_per_page, offset=pager['offset'])
        request.session['my_srr_history'] = requests.ids[:100]

        values.update({
            'date': date_begin,
            'date_end': date_end,
            'requests': requests,
            'search_in': search_in,
            'search': search,
            'page_name': 'search_ring_request',
            'default_url': '/my/ring_request',
            'pager': pager,
            'searchbar_sortings': searchbar_sortings,
            'searchbar_inputs': searchbar_inputs,
            'sortby': sortby
        })
        return request.render("kg_tower.portal_my_srrs", values)

    @http.route(['/my/ring_request/<int:request_id>'], type='http', auth="user", website=True)
    def portal_my_srr(self, request_id=None, access_token=None, **kw):
        try:
            srr_sudo = self._document_check_access('ring.request', request_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my');

        values = self._srr_get_page_view_values(srr_sudo, access_token, **kw)
        partner_id = srr_sudo.partner_id.parent_id if srr_sudo.partner_id.parent_id else srr_sudo.partner_id
        partner_name = request.env.user.partner_id.parent_id and request.env.user.partner_id.parent_id.name or request.env.user.partner_id.name
        values.update({
            'partner_id': partner_id,
            'partner_name': partner_name,
        })
        return request.render("kg_tower.portal_my_srr", values)
