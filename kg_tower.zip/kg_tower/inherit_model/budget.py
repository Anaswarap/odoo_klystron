# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models

class CrossoveredBudgetInh(models.Model):
    _inherit = "crossovered.budget"
    state = fields.Selection([
        ('draft', 'Draft'),
        ('cancel', 'Cancelled'),
        ('confirm', 'Confirmed'),
        ('approved_by_board','approved by board'),
        ('validate', 'Validated'),
        ('done', 'Done')
        ], 'Status', default='draft', index=True, required=True, readonly=False, copy=False, tracking=True)

class CrossoveredBudgetLinesInh(models.Model):
    _inherit = "crossovered.budget.lines"

    line_type = fields.Selection([('Opex', 'Opex'), ('Capex', 'Capex')], string="Type",
                                  default="Opex")
    import_achivement = fields.Float()
    import_available = fields.Float()
    import_variance= fields.Float()
    import_ydt=fields.Float()
    user_id = fields.Many2one('res.users',string="Responsible",readonly=False)
    analytic_group = fields.Many2one('account.analytic.group')