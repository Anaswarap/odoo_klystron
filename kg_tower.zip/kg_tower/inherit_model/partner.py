from odoo import api, models, fields, _
import werkzeug.urls

class ResPartnerBank(models.Model):
    _inherit = 'res.partner.bank'

    nature = fields.Char(
        string='Nature of Account')



class ResPartner(models.Model):
    _inherit = 'res.partner'

    invoice_policy = fields.Selection([
        ('1', '1'), ('2', '2'),
        ('3', '3'), ('4', '4'),
        ('5', '5'), ('6', '6'),
        ('7', '7'), ('8', '8'),
        ('9', '9'), ('10', '10'),
        ('11', '11'), ('12', '12')
    ], string='Invoiced every', default='4', required=True,
        help="Client will be invoiced every .", tracking=True)
    site_comm_days = fields.Integer(
        string='Site Commencement Days',
        required=False, default=45)

    arabic_name = fields.Char('Arabic Name')

    operator = fields.Boolean('Operator', default=False)

    vendor_contractor_location_id = fields.Many2one('stock.location', 'Vendor/Contractor Location')

    vendor_picking_type_id = fields.Many2one('stock.picking.type','Vendor Picking Type', store=True)

    op_seq_code = fields.Char('Code')

    contractor = fields.Boolean('Contractor', default=False)
    owner = fields.Boolean('Owner', default=False)

    con_seq_code = fields.Char('Code')

    operator_sequence = fields.Many2one('ir.sequence', 'Sequence')
    contractor_sequence = fields.Many2one('ir.sequence', 'Contractor Sequence')

    # vendor visibility in portal
    show_nswo = fields.Boolean('Show NSWO in Portal')
    show_srr = fields.Boolean('Show SRR in Portal')
    is_omantel = fields.Boolean('Omantel', default=False)
    is_submission_type = fields.Boolean('Submission Type', default=False, help='To show submission type in NSWO')

    @api.model
    def create(self, vals):
        if vals.get('operator') and vals.get('op_seq_code') and vals.get('company_type') == 'company':
            sequence = self.env['ir.sequence'].create({
                'name': _('Sequence') + ' ' + vals['op_seq_code'],
                'padding': 5,
                'prefix': vals['op_seq_code'],

            })
            vals['operator_sequence'] = sequence.id

        if vals.get('contractor') and vals.get('con_seq_code'):
            sequence = self.env['ir.sequence'].create({
                'name': _('Sequence') + ' ' + vals['con_seq_code'],
                'padding': 5,
                'prefix': vals['con_seq_code']+'-%(year)s-',

            })
            vals['contractor_sequence'] = sequence.id


        res = super().create(vals)
        if res.contractor:
            wh_location = self.env['stock.location'].search([('name', '=', 'WH'), ('usage', '=', 'view')], limit=1)
            if wh_location:
                inventory_location_id = self.env['stock.location'].create({

                    'name': res.name,
                    'location_id': wh_location.id,
                    'usage': 'internal'
                })

                picking_type_id = self.env['stock.picking.type'].create({
                    'name': res.name + '- Receipts',
                    'sequence_code': res.name,
                    'code': 'incoming',
                    # 'company_id': self.company_a.id,
                    'warehouse_id': False,
                    # 'default_location_src_id': self.stock_location_a.id,
                    'default_location_dest_id':inventory_location_id.id,

                })


                res.vendor_picking_type_id = picking_type_id.id
                res.vendor_contractor_location_id = inventory_location_id.id
        return res

    def get_operator_id(self):
        id = self.parent_id and self.parent_id.id or self.id
        return id

    def get_operator_name(self):
        name = self.parent_id and self.parent_id.name or self.name
        return name

    def write(self, vals):
        for rec in self:
            if not rec.operator_sequence:
                if rec.operator or vals.get('operator'):
                    seq_code = vals.get('op_seq_code') or rec.op_seq_code or rec.name
                    sequence = self.env['ir.sequence'].create({
                        'name': _('Sequence') + ' ' + seq_code,
                        'padding': 5,
                        'prefix': seq_code,

                })
                    vals['operator_sequence'] = sequence.id

            if not rec.contractor_sequence:
                if rec.contractor or vals.get('contractor'):
                    seq_code = vals.get('con_seq_code') or rec.con_seq_code or rec.name
                    sequence = self.env['ir.sequence'].create({
                        'name': _('Sequence') + ' ' + seq_code,
                        'padding': 5,
                        'prefix': seq_code+'-%(year)s-',
                    })
                    vals['contractor_sequence'] = sequence.id

                    # Location

                    wh_location = self.env['stock.location'].search([('name', '=', 'WH'), ('usage', '=', 'view')],
                                                                    limit=1)
                    if wh_location:
                        inventory_location_id = self.env['stock.location'].create({

                            'name': rec.name,
                            'location_id': wh_location.id,
                            'usage': 'internal'
                        })

                        picking_type_id = self.env['stock.picking.type'].create({
                            'name': rec.name + '- Receipts',
                            'sequence_code': rec.name,
                            'code': 'incoming',
                            # 'company_id': self.company_a.id,
                            'warehouse_id': False,
                            # 'default_location_src_id': self.stock_location_a.id,
                            'default_location_dest_id': inventory_location_id.id,

                        })

                        vals['vendor_picking_type_id'] = picking_type_id.id
                        vals['vendor_contractor_location_id'] = inventory_location_id.id

        return super(ResPartner, self).write(vals)

    def _get_signup_url_for_action(self, url=None, action=None, view_type=None, menu_id=None, res_id=None, model=None):
        """ generate a signup url for the given partner ids and action, possibly overriding
            the url state components (menu_id, id, view_type) """
        # OVERRIDE ACTION TO REMOVE DB NAME IN THE URL

        res = dict.fromkeys(self.ids, False)
        for partner in self:
            base_url = partner.get_base_url()
            # when required, make sure the partner has a valid signup token
            if self.env.context.get('signup_valid') and not partner.user_ids:
                partner.sudo().signup_prepare()

            route = 'login'
            # the parameters to encode for the query
            query = dict(db=self.env.cr.dbname)
            signup_type = self.env.context.get('signup_force_type_in_url', partner.sudo().signup_type or '')
            if signup_type:
                route = 'reset_password' if signup_type == 'reset' else signup_type

            if partner.sudo().signup_token and signup_type:
                query['token'] = partner.sudo().signup_token
            elif partner.user_ids:
                query['login'] = partner.user_ids[0].login
            else:
                continue  # no signup token, no user, thus no signup url!

            if url:
                query['redirect'] = url
            else:
                fragment = dict()
                base = '/web#'
                if action == '/mail/view':
                    base = '/mail/view?'
                elif action:
                    fragment['action'] = action
                if view_type:
                    fragment['view_type'] = view_type
                if menu_id:
                    fragment['menu_id'] = menu_id
                if model:
                    fragment['model'] = model
                if res_id:
                    fragment['res_id'] = res_id

                if fragment:
                    query['redirect'] = base + werkzeug.urls.url_encode(fragment)
            query.pop('db')
            # print("query", query)

            signup_url = "/web/%s?%s" % (route, werkzeug.urls.url_encode(query))
            if not self.env.context.get('relative_url'):
                signup_url = werkzeug.urls.url_join(base_url, signup_url)
            res[partner.id] = signup_url

        return res
