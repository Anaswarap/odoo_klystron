from odoo import models, fields, api, _

class ProductionLot(models.Model):
    _inherit = 'stock.production.lot'

    project_id = fields.Many2one('project.project', 'Project')

    contractor_id = fields.Many2one('res.partner','Contractor',related='project_id.vendor_id',store=False)
    # client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True, related='project_id.site_id',store=False)
    location_id = fields.Many2one('stock.location','Current Location',compute='comp_current_loc',store=False)
    """***sha---altered for excel import"""
    state = fields.Selection(
        [('available', 'Available'), ('assigned', 'Assigned'), ('sold', 'Sold'), ('installed', 'Installed'),
         ('ordered', 'Ordered'),
         ('To be fabricated', 'To be fabricated'), ('To be ordered', 'To be ordered'), ('pre_assign', 'Pre-Assigned')],
        default='ordered', string='Status')
    client_site_id = fields.Many2one('account.asset.site', 'OTC Site ID', tracking=True)
    order_type = fields.Char(string="Order Type")
    stock_order_id = fields.Many2one(
        comodel_name='stock.order',
        string='Stock Order',
        required=False)
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string='Payment Terms',
        required=False)
    supplier_imp_id = fields.Many2one('res.partner', string="Supplier Imp")

    def comp_current_loc(self):
        for rec in self:
            print(rec.name)
            rec.location_id = False
            for i in rec.quant_ids:
                if i.available_quantity > 0:
                    rec.location_id = i.location_id.id
                    print(rec.name)
                    break