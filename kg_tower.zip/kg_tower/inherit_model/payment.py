import ast

from odoo import api, models, fields, _
from odoo.exceptions import UserError


class AccountPayment(models.Model):
    _inherit = ['account.payment', 'kg.approval.transaction']
    _name = 'account.payment'

    # stage = fields.Selection([('account_prepare','Prepared'),('account_review_1','Finance Review #1'),('account_review_2','Finance Review #2'),('auditor_review','Auditor Reviewed'),('authorisor_review_1','First Authorisor Reviewed'),('authorisor_review_2','Second Authorisor Reviewed'),('cancel','Cancelled')],default='account_prepare',tracking=True)

    account_review_1_by = fields.Many2one('res.users', 'First Finance Review By')
    account_review_2_by = fields.Many2one('res.users', 'Second Finance Review By')
    auditor_review_by = fields.Many2one('res.users', 'Auditor Review By')
    authorisor_review_1_by = fields.Many2one('res.users', 'First Authorisor Review By')
    authorisor_review_2_by = fields.Many2one('res.users', 'Second Authorisor Review By')

    move_id_for_reconcile = fields.Many2one('account.move', 'Reconcile move')

    check_status = fields.Selection(
        [('under_collection', 'Under Collection'), ('collected', 'Collected'), ('cancel', 'Cancelled')],
        default='under_collection')

    # **********mini****** additional fileds for data import
    tswo_id = fields.Many2one('kg.tswo', string='WO no')
    old_invoice_no = fields.Char(string="Old Inv No")
    invoice_date = fields.Date(string="Invoice Date")
    site_id = fields.Many2one('account.asset.site', string='Site ID')
    milestone = fields.Char(string='Milestones')
    btf_no = fields.Char(string='BTF No', readonly=False, store=True)
    bank_batch = fields.Char(string='Bank Batch')
    lease_bill_id = fields.Many2one('account.move', string="Lease Bill")
    wo_number_imp = fields.Char(string="WO No Imp")
    is_imported = fields.Boolean(string="Is Imported")
    milestone_imp = fields.Char(string="Milestone Imported")
    # invoice_line = fields.One2many('account.move', string="Invoices")

    # def action_post(self):
    #     active_model = self.env.context.get('active_model')
    #     if active_model != 'account.move':
    #         ''' draft -> posted '''
    #         self.move_id._post(soft=False)
    #     elif active_model == 'account.move':
    #         self.move_id._post(soft=False)
    #         active_id =  self.env.context.get('active_id')
    #         self.move_id_for_reconcile = self.env['account.move'].browse([active_id]).id or False

    # @api.model
    # def create(self, vals):
    #     if vals['payment_type'] == 'outbound' and vals['btf_no'] == 'New':
    #         vals['btf_no'] = self.env['ir.sequence'].next_by_code('account.payment.btf_no') or _('000')
    #     return super().create(vals)

    def _track_subtype(self, init_values):
        # OVERRIDE to log a different message when an invoice is paid using SDD.
        self.ensure_one()
        if 'stage' in init_values and self.stage in ('authorisor_review_2'):
            return self.env.ref('kg_tower.final_stage_msg_acc_pay')
        return super(AccountPayment, self)._track_subtype(init_values)

    def collect_check(self):
        self.check_status = 'collected'

    def cancel_check(self):
        self.check_status = 'cancel'

    def reset_check(self):
        self.check_status = 'under_collection'

    def acc_review_1(self):
        for rec in self:
            if rec.journal_id.id == self.env.ref(
                    'kg_tower.check_journal_customer').id and rec.check_status != 'collected':
                raise UserError(_('Please collect check before reviewing.'))
            if not self.user_has_groups('account.group_account_invoice'):
                raise UserError(_('Only Authorised User can approve.'))

            # rec.stage = 'account_review_1'
            rec.account_review_1_by = self.env.user.id
            accountant_group = self.env.ref('account.group_account_user')
            for user in accountant_group.users:
                self.activity_schedule('kg_tower.payment_stage_approval', note=user.name, user_id=user.id)

    def acc_review_2(self):
        for rec in self:
            if not self.user_has_groups('account.group_account_user'):
                raise UserError(_('Only Authorised User can approve.'))
            # rec.stage = 'account_review_2'
            rec.account_review_2_by = self.env.user.id

            to_clean = self.env['account.payment']
            to_clean |= rec
            if to_clean:
                to_clean.activity_unlink(['kg_tower.payment_stage_approval'])
            auditor_group = self.env.ref('account.group_account_readonly')
            for user in auditor_group.users:
                self.activity_schedule('kg_tower.payment_stage_approval', note=user.name, user_id=user.id)

    def aud_review(self):
        for rec in self:
            if not self.user_has_groups('account.group_account_readonly'):
                raise UserError(_('Only Authorised User can approve.'))
            # rec.stage = 'auditor_review'
            rec.auditor_review_by = self.env.user.id

            to_clean = self.env['account.payment']
            to_clean |= rec
            if to_clean:
                to_clean.activity_unlink(['kg_tower.payment_stage_approval'])
            first_auth_group = self.env.ref('kg_tower.group_first_authoriser')
            for user in first_auth_group.users:
                self.activity_schedule('kg_tower.payment_stage_approval', note=user.name, user_id=user.id)

    def auth_review_1(self):
        for rec in self:
            if not self.user_has_groups('kg_tower.group_first_authoriser'):
                raise UserError(_('Only Authorised User can approve.'))
            # rec.stage = 'authorisor_review_1'
            rec.authorisor_review_1_by = self.env.user.id

            to_clean = self.env['account.payment']
            to_clean |= rec
            if to_clean:
                to_clean.activity_unlink(['kg_tower.payment_stage_approval'])
            second_auth_group = self.env.ref('kg_tower.group_second_authoriser')
            for user in second_auth_group.users:
                self.activity_schedule('kg_tower.payment_stage_approval', note=user.name, user_id=user.id)

    def auth_review_2(self):
        for rec in self:
            if not self.user_has_groups('kg_tower.group_second_authoriser'):
                raise UserError(_('Only Authorised User can approve.'))
            # rec.stage = 'authorisor_review_2'
            rec.authorisor_review_2_by = self.env.user.id

            rec.action_post()

            ## to add payment to bill

            rec.reconcile_with_parent_invoice()
            to_clean = self.env['account.payment']
            to_clean |= rec
            if to_clean:
                to_clean.activity_unlink(['kg_tower.payment_stage_approval'])

    def reconcile_with_parent_invoice(self):
        if self.move_id_for_reconcile and self.move_id_for_reconcile.payment_state in (
                'not_paid', 'partial') and self.move_id_for_reconcile.state == 'posted':
            payments = self
            domain = [('account_internal_type', 'in', ('receivable', 'payable')), ('reconciled', '=', False)]
            to_reconcile = self.move_id_for_reconcile.line_ids.filtered_domain(domain)
            for payment, lines in zip(payments, to_reconcile):

                # When using the payment tokens, the payment could not be posted at this point (e.g. the transaction failed)
                # and then, we can't perform the reconciliation.
                if payment.state != 'posted':
                    continue

                payment_lines = payment.line_ids.filtered_domain(domain)
                for account in payment_lines.account_id:
                    (payment_lines + lines) \
                        .filtered_domain([('account_id', '=', account.id), ('reconciled', '=', False)]) \
                        .reconcile()

    def action_cancel(self):
        ''' draft -> cancelled '''
        # self.stage = 'cancel'
        self.move_id.button_cancel()

    '''
    ----------------------Approval Module Changes----------------------
    Approval Section field override to mentioned corresponding model.
    '''
    model = fields.Char('Related Document Model', index=True, readonly=True, default='account.payment')

    '''
    Inherit final approve and post payment. 
    '''

    def send_back(self):
        res = super(AccountPayment, self).send_back()
        model = self.env['ir.model'].sudo().search([('model', '=', self.model)])
        approval_config_id = self.approval_config_id
        res['context'] = {'default_model_id': model and model.id,
                          'default_approval_config_id': approval_config_id and approval_config_id.id}
        return res

    def kg_final_approval(self):
        res = super(AccountPayment, self).kg_final_approval()
        self.action_post()
        return res

    '''
    Get approval details for print.
    '''

    def get_approve_details(self):
        approval_list = []
        if self.approved_list:
            data = ast.literal_eval(self.approved_list)
            for ad in data:
                user = ""
                if 'user_approved' in ad:
                    user_obj = self.env['res.users'].browse(ad['user_approved'])
                    user = user_obj
                    approval_level = (ad['approval_level'])
                    approval_dict = {'user': user,
                                     'approval_level': approval_level}
                    approval_list.append(approval_dict)

            return approval_list

    def action_post(self):
        """Reconciling Vendor payment for lease or rent registration"""
        res = super(AccountPayment, self).action_post()
        if self.lease_bill_id:
            payment_move_line = self.invoice_line_ids.filtered(
                lambda l: l.account_id.user_type_id.name == 'Payable')
            bill_move_line = self.lease_bill_id.line_ids.filtered(
                lambda l: l.account_id.user_type_id.name == 'Payable')

            (payment_move_line + bill_move_line).reconcile()
        return res


class KgPaymentMatchInherit(models.Model):
    _inherit = 'kg.payment_match'

    milestone_per = fields.Float(related='bill_id.milestone', string="Milestone %")
    site = fields.Many2one('account.asset.site', related='bill_id.site_id', string="Site")
    twso_id = fields.Many2one('kg.tswo', related='bill_id.tswo_id', string="TSWO")
