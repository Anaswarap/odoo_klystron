from odoo import api, models,fields, _
from odoo.exceptions import UserError


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'


    @api.model
    def _get_journals(self):
        company_id = 1
        move_type = 'out_invoice'
        check_id  = self.env.ref('kg_tower.check_journal_customer').id or False
        active_model = self.env.context.get('active_model') or False
        active_id = self.env.context.get('active_id')
        if active_model and active_model == 'account.move':
            move_obj = self.env['account.move'].browse([int(active_id)])
            if move_obj:
                company_id = move_obj.company_id.id
                move_type = move_obj.move_type
        if move_type == 'in_invoice' and check_id:
            domain = [('company_id', '=', company_id), ('type', 'in', ('bank', 'cash')),('id', '!=', check_id)]
        else:
            domain = [('company_id', '=', company_id), ('type', 'in', ('bank', 'cash'))]
        return domain




    journal_id = fields.Many2one('account.journal', store=True, readonly=False,
                                 compute='_compute_journal_id',
                                 domain=lambda self: self._get_journals())


    @api.depends('company_id', 'source_currency_id')
    def _compute_journal_id(self):
        for wizard in self:
            check_id = self.env.ref('kg_tower.check_journal_customer').id or False
            if wizard.payment_type  == 'supplier' and check_id:
                domain = [
                    ('type', 'in', ('bank', 'cash')),
                    ('company_id', '=', wizard.company_id.id),
                    ('id', '!=', check_id)
                ]
            else:
                domain = [
                    ('type', 'in', ('bank', 'cash')),
                    ('company_id', '=', wizard.company_id.id),
                ]

            journal = None
            if wizard.source_currency_id:
                journal = self.env['account.journal'].search(
                    domain + [('currency_id', '=', wizard.source_currency_id.id)], limit=1)
            if not journal:
                journal = self.env['account.journal'].search(domain, limit=1)
            wizard.journal_id = journal
