from odoo import api, models, fields, _
from odoo.exceptions import UserError
from datetime import date, timedelta


class AccountPenalty(models.Model):
    _name = 'account.penalty'
    _description = 'Account Penalty'

    name = fields.Char('Description', required=True)
    move_id = fields.Many2one('account.move', 'Invoice', required=True)
    penalty_move_id = fields.Many2one('account.move', 'Penalty Invoice')
    date = fields.Date('Date')
    amount = fields.Float('Amount')


class AccountMove(models.Model):
    _inherit = ['account.move', 'budget.alert']
    _name = 'account.move'

    tower_invoice_id = fields.Many2one('tower.invoice', 'Tower Invoice')
    project_contractor_expense_id = fields.Many2one('project.contractor.expense', 'Contractor Expense')
    project_contractor_nonreco_expense_id = fields.Many2one('project.contractor.expense.nonrecover', 'Contractor Non Recoverable Expense')
    owner_rent_expense_id = fields.Many2one('project.owner.rent.expense', 'Owner Rent Expense')
    event_gift_id = fields.Many2one('event.gift', 'Gift')
    project_id = fields.Many2one('project.project', 'Project')
    tswo_id = fields.Many2one('kg.tswo','TSWO')
    stock_order_id = fields.Many2one('stock.order','Stock Order')
    vo_id = fields.Many2one('kg.vo','VO')
    srr_id = fields.Many2one('ring.request','SRR')

    due_days = fields.Integer('Due Days', compute='comp_due_days', store=True)

    grace_due_date = fields.Date('Due Date(grace)', compute='comp_due_days', store=True)

    penalty_count = fields.Integer('Penalty Count', compute='comp_penalty_count')
    dispute_count = fields.Integer('Dispute Count', compute='comp_dispute_count')
    lease_count = fields.Integer('Lease Count',  compute='comp_lease_count')
    milestone = fields.Float(string="Milestone %", readonly=True, copy=False)
    site_id = fields.Many2one('account.asset.site')
    old_inv_no = fields.Char(string="Old Invoice No")
    milestone_id = fields.Many2one('project.milestone', string="Milestone")
    wo_number_imp = fields.Char(string="WO No Imp")
    btf_number = fields.Char(string="BTF Number")
    balance_payable = fields.Float(string="Balance Remaining Payable")
    is_imported = fields.Boolean(string="Is Imported")
    additional_site = fields.Char(string="Additional Site")
    # show_warning = fields.Boolean('Show Warning', compute='comp_show_warning',default=False)
    #
    # alert_warning_message = fields.Text('Warning Message',compute='comp_show_warning')

    # @api.depends('line_ids')
    # def comp_show_warning(self):
    #     for rec in self:
    #         rec.show_warning = False
    #         rec.alert_warning_message = ''
    #         for line in rec.line_ids.filtered('account_id.restrict_balance'):
    #             balance = sum(self.env['account.move.line'].search([
    #                 ('account_id', '=', line.account_id.id),
    #                 ('move_id.state', '=', 'posted'),
    #             ]).mapped('balance'))
    #             if balance < line.account_id.alert_limit:
    #                 rec.show_warning = True
    #                 warn_msg = '<b>Warning: </b>'
    #
    #                 warn_msg += "<br/>Alert Limit Exceeded for %s" % (line.account_id.name)
    #
    #                 rec.alert_warning_message = warn_msg
    #             else:
    #                 rec.show_warning = False

    def action_register_payment(self):
        for rec in self:
            unresolved_disputes = rec.env['kg.dispute'].search_count([('move_id', '=', rec.id), ('resolved', '=', False)])
            if unresolved_disputes > 0:
                raise UserError(_(
                    'This invoice has  %s unresolved disputes \n'
                    'Please resolve the disputes and mark them as resolved in order to register payments'
                ) % (unresolved_disputes,))
            res = super(AccountMove, self).action_register_payment()
            return res

    @api.model
    def _get_invoice_in_payment_state(self):
        res = super(AccountMove, self)._get_invoice_in_payment_state()
        penalty_amt = sum(self.env['account.penalty'].search([
            ('move_id', '=', self.id),
            ('move_id.state', '=', 'posted'),
            ('move_id.payment_state', 'in', ['not_paid', 'partial']),
            ('penalty_move_id', '=', False),
        ]).mapped('amount'))
        vals_inv = {}

        vals_inv['partner_id'] = self.partner_id.id
        vals_inv['invoice_date'] = date.today()
        vals_inv['move_type'] = 'out_invoice'
        vals_inv['invoice_payment_term_id'] = self.env.ref('account.account_payment_term_45days').id
        inv_lines = []
        a = (0, 0, {
            'quantity': 1,
            'price_unit': penalty_amt,
            'name': 'Penalty for ' + self.name,
        })

        inv_lines.append(a)
        vals_inv['invoice_line_ids'] = inv_lines
        self.env['account.move'].create(vals_inv)

        ## create penalty invoice here
        return res

    def comp_penalty_count(self):
        for record in self:
            record.penalty_count = self.env['account.penalty'].search_count(
                [('move_id', '=', record.id)])

    def comp_dispute_count(self):
        for record in self:
            record.dispute_count = self.env['kg.dispute'].search_count(
                [('move_id', '=', record.id)])

    def comp_lease_count(self):
        for record in self:
            record.lease_count = self.env['project.owner.rent.expense'].search_count([('site_id', '=', record.site_id.id)])


    def show_penaltys(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Penalty',
                'view_mode': 'tree',
                'res_model': 'account.penalty',
                'domain': [('move_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_disputes(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Disputes',
                'view_mode': 'tree,form',
                'res_model': 'kg.dispute',
                'domain': [('move_id', '=', rec.id)],
                'context': {
                    'default_dispute_date': fields.Date.today(),
                    'default_move_id': rec.id,
                    'default_unpaid_amount': rec.amount_residual
                }
            }


    def show_lease(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Lease',
                'view_mode': 'tree,form',
                'res_model': 'project.owner.rent.expense',
                'domain': [('site_id', '=', rec.site_id.id)],
                'context': "{'create': False,'edit': False}"
            }


    @api.depends('invoice_date_due')
    def comp_due_days(self):
        for rec in self:
            if rec.invoice_date_due:
                date_today = date.today()
                due_days = (rec.invoice_date_due - date_today).days
                rec.due_days = due_days

                grace_period = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.grace_period')) or 30
                grace_due_date = rec.invoice_date_due + timedelta(days=grace_period)
                rec.grace_due_date = grace_due_date

    def invoice_penalty_calculation(self):
        invoices = self.env['account.move'].search([('move_type', '=', 'out_invoice'), ('state', '=', 'posted'),
                                                    ('payment_state', 'in', ('not_paid', 'partial'))])
        penalty_percent = float(self.env['ir.config_parameter'].sudo().get_param('kg_tower.penalty_percent')) or 3
        if invoices:
            for invoice in invoices:

                if not isinstance(invoice.grace_due_date, bool):
                    if invoice.grace_due_date < date.today():
                        penalty_amount = invoice.amount_residual * (penalty_percent / 100)
                        self.env['account.penalty'].create({
                            'move_id': invoice.id,
                            'date': date.today(),
                            'amount': penalty_amount,
                            'name': 'Penalty for ' + str(date.today())
                        })

    def invoice_due_remainder_action_email(self):
        invoices = self.env['account.move'].search([('move_type', '=', 'out_invoice'), ('state', '=', 'posted'),
                                                    ('payment_state', 'in', ('not_paid', 'partial'))])
        if invoices:
            for invoice in invoices:
                email_to = []

                email_to.append(invoice.partner_id.id)
                if not isinstance(invoice.invoice_date_due, bool):

                    if invoice.due_days in (15, 30, 44):
                        template_id = self.env['ir.model.data'].get_object_reference('kg_tower',
                                                                                     'invoice_before_due_remainder_email_template')[
                            1]
                        template_browse = self.env['mail.template'].browse(template_id)
                        due_date = invoice.invoice_date_due
                        if template_browse:
                            values = template_browse.generate_email(invoice.id, fields=None)
                            values['subject'] = "Reminder about " + invoice.name + " due on " + str(due_date)
                            values['email_from'] = self.env['res.users'].browse(
                                self.env['res.users']._context['uid']).partner_id.email
                            values['res_id'] = False
                            values['author_id'] = self.env['res.users'].browse(
                                self.env['res.users']._context['uid']).partner_id.id
                            values['recipient_ids'] = [(6, 0, email_to)]
                            if not values['email_to'] and not values['email_from']:
                                pass
                            msg_id = self.env['mail.mail'].create({
                                'body_html': values['body_html'],
                                'subject': values['subject'],
                                'email_to': values['email_to'],
                                'auto_delete': True,
                                'email_from': values['email_from'],
                                'references': values['mail_server_id'], })
                            mail_mail_obj = self.env['mail.mail']
                            if msg_id:
                                mail_mail_obj.sudo().send(msg_id)
                    else:
                        pass

            return True

    # Set Minimum Balance Fix This

    # def _post(self, soft=False):
    #     """
    #     We check that there is enaught balance.
    #     Now we check on post so we get balance considering this move lines also
    #     (because first we post and later we check).
    #     Before we use _post_validate method that is called from other places
    #     too
    #     """
    #     res = super(AccountMove, self)._post(soft=False)
    #     for move in self:
    #
    #         for line in move.line_ids.filtered('account_id.restrict_balance'):
    #             balance = sum(self.env['account.move.line'].search([
    #                 ('account_id', '=', line.account_id.id),
    #                 ('move_id.state', '=', 'posted'),
    #             ]).mapped('balance'))
    #             if balance < line.account_id.alert_limit:
    #
    #                 warn_msg = "Alert Limit Exceeded for %s" % (line.account_id.name)
    #                 allowed_group_obj = self.env.ref('account.group_account_manager')
    #                 partners = []
    #                 for user in allowed_group_obj.users:
    #                     partners.append(user.partner_id.id)
    #                 move.message_post(body=warn_msg, message_type='notification',
    #                                   subtype_xmlid='mail.mt_comment', partner_ids=partners
    #                                   )
    #
    #             if balance < line.account_id.min_balance:
    #                 raise UserError(_(
    #                     'Can not create move as account %s balance would be %s'
    #                     ' and account has restriction of min balance to %s'
    #                 ) % (
    #                                     line.account_id.name,
    #                                     balance,
    #                                     line.account_id.min_balance))
    #
    #             max_transaction_balance = sum(self.env['account.move.line'].search([
    #                 ('account_id', '=', line.account_id.id),
    #                 ('move_id', '=', move.id),
    #             ]).mapped('balance'))
    #             if abs(max_transaction_balance) > line.account_id.max_transaction:
    #                 raise UserError(_(
    #                     'Can not create move as account %s only allows transaction'
    #                     ' up to %s'
    #                 ) % (
    #                                     line.account_id.name,
    #                                     line.account_id.max_transaction))
    #     return res


class AccountMoveLineInherit(models.Model):
    _inherit = 'account.move.line'

    milestone_percentage = fields.Float(string="Milestone %")
    add_note = fields.Char(string="Description")
    seq = fields.Char(string="Sequence")
    inv_type = fields.Selection(
        related="move_id.move_type",
        string="Type",
        store=True
    )
