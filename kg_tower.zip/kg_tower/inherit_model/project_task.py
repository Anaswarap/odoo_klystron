from odoo import api, models, fields, _
from odoo.exceptions import UserError


class ProjectTask(models.Model):
    _inherit = 'project.task'

    department_id = fields.Many2one(
        comodel_name='hr.department',
        string='Department',
        required=False)
    work_flow = fields.Selection(
        string='Work Flow',
        selection=[('initial', 'Initial'),
                   ('site', 'Site Aquisition'),
                   ('tower', 'Tower Supply'),
                   ('construction', 'Construction'),
                   ('grid', 'Grid Connection'),
                   ('final', 'Final')
                   ],
        required=True, default='initial')
    progress_level = fields.Selection(
        string='Progress Level',
        selection=[('srr_received', 'SRR Received'),
                   ('nswo_received', 'NSWO Received'),
                   ('site', 'Site Aquisition'),
                   ('construction', 'Construction'),
                   ('rfi', 'RFI Notice Issued'), ],
        required=True,  default='srr_received')
    weight = fields.Float(
        string='Weight',
        required=True,default=0.0)
    completion_task = fields.Float(
        string='Triggered by Completion of Task',
        required=True,default=0.0)
    gf_construction = fields.Float(
        string='GF Construction',
        required=True,default=0.0)
    collacation = fields.Float(
        string='Collacation',
        required=True,default=0.0)
    roof_top = fields.Float(
        string='Roof Top',
        required=True,default=0.0)
    sequence = fields.Char(
        string='Sequence',
        required=False)
    ring_request_id = fields.Many2one(
        comodel_name='ring.request',
        string='Ring Request',
        required=False)
    work_order_id = fields.Many2one(
        comodel_name='work.order',
        string='Work Order',
        required=False)
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    construction_id = fields.Many2one(
        comodel_name='site.construction',
        string='Construction',
        required=False)
    rfi_notice_id = fields.Many2one(
        comodel_name='rfi.notice',
        string='RFI Notice',
        required=False)

    override_sequence = fields.Boolean('Override', default=False,
                                       help='Override task sequence to allow parellel completion')
    milestone_task = fields.Boolean('Milestone', default=False, help='Allow invoice after completion of this task')
    milestone_percent = fields.Float(string='Milestone Percentage')


    proposed_date_deadline = fields.Date(string='Proposed Deadline', index=True, copy=False, tracking=True)
    attach_mandatory = fields.Boolean('Attachment mandatory', default=False, )

    # field for notification when task assigned to another user
    assign = fields.Boolean(default=False,copy=False)
    asign_status = fields.Boolean(default=False,copy=False,compute='set_assign')

    @api.depends('assign')
    def set_assign(self):
        for rec in self:
            rec.asign_status = True
            if rec.assign:
                activity = self.env['mail.activity'].sudo().create({
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'res_id': rec.id,
                                'user_id': rec.user_id.id,
                                'res_model_id': self.env.ref('project.model_project_task').id,
                            })
            rec.assign = False

    # state = fields.Selection(selection=[
    #   ('draft', 'Draft'),
    #   ('confirm', 'Confirmed'),
    # ], string='State', required=True, readonly=True, copy=False, tracking=True,
    #   default='draft')

    exp_count = fields.Integer('Expense Count')
    op_exp_count = fields.Integer('Expense Count',compute='comp_exp_count')
    con_exp_count = fields.Integer('Expense Count',compute='comp_exp_count')
    ow_exp_count = fields.Integer('Expense Count',compute='comp_exp_count')
    def comp_exp_count(self):
        for record in self:
            record.op_exp_count = self.env['project.expense.lines'].search_count(
                [('task_id', '=', record.id)])
            record.con_exp_count = self.env['project.expense.lines'].search_count(
                [('task_id', '=', record.id)])
            record.ow_exp_count = self.env['project.expense.lines'].search_count(
                [('task_id', '=', record.id)])


    def show_operator_project_expenses(self):
        for rec in self:
          return {
            'type': 'ir.actions.act_window',
            'name': 'Operator Expenses',
            'view_mode': 'tree,form',
            'res_model': 'project.expense.lines',
            'domain': [('task_id', '=', rec.id)],
            'context': {
              'default_task_id': rec.id,
              'default_project_id':rec.project_id.id,
              'default_type':'operator',
            }
          }

    def show_contractor_project_expenses(self):
        for rec in self:
          return {
            'type': 'ir.actions.act_window',
            'name': 'Contractor Expenses',
            'view_mode': 'tree,form',
            'res_model': 'project.expense.lines',
            'domain': [('task_id', '=', rec.id)],
            'context': {
              'default_task_id': rec.id,
              'default_project_id':rec.project_id.id,
              'default_type':'contractor',
            }
          }

    def show_owner_project_expenses(self):
        for rec in self:
          return {
            'type': 'ir.actions.act_window',
            'name': 'Owner Expenses',
            'view_mode': 'tree,form',
            'res_model': 'project.expense.lines',
            'domain': [('task_id', '=', rec.id)],
            'context': {
              'default_task_id': rec.id,
              'default_project_id':rec.project_id.id,
              'default_type':'owner',
            }
          }

    def action_confirm(self):

        ## find attachments for

        if self.attach_mandatory:
            attachments = self.env['ir.attachment'].search([
                ('res_id', '=', self.id),
                ('res_model', '=', 'project.task'),
                ('type', '=', 'binary')])
            if not attachments:
                raise UserError(_('Attachments are mandatory for this task'))

        current_seq = int(self.sequence)
        next_seq = int(self.sequence) + 1
        prev_seq = int(self.sequence) - 1
        check_previous = self.env['project.task'].search(
            [('project_id', '=', self.project_id.id), ('sequence', '<', current_seq),('stage_id','!=',self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1, order="sequence desc")
        print (check_previous.sequence)
        if check_previous :
        # print (check_previous,self.override_sequence)
        # if check_previous.stage_id.id != self.env.ref('kg_tower.task_stage_confirmed').id:
            if not self.override_sequence:
                raise UserError(_('Confirm Previous Tasks to continue'))
            # if check_previous.state != 'confirm':
            #   raise UserError(_('Confirm Previous Tasks to continue'))
        scheduled_activity = self.env['mail.activity'].search(
            [('res_model', '=', self._name), ('res_id', 'in', self.ids)])
        if scheduled_activity:
            scheduled_activity.action_done()
        task_schedule = self.env['project.task'].search(
            [('project_id', '=', self.project_id.id), ('sequence', '>', current_seq),(
                            'stage_id', '!=', self.env.ref('kg_tower.task_stage_confirmed').id)], limit=1, order="sequence asc")
        print(task_schedule)
        if self.work_order_id and self.work_order_id.current_task_id == self:
            self.work_order_id.current_task_status = 'Completed'
        if self.construction_id and self.construction_id.current_task_id == self:
            self.construction_id.current_task_status = 'Completed'
        if self.site_acq_id and self.site_acq_id.current_task_id == self:
            self.site_acq_id.current_task_status = 'Completed'
        if self.rfi_notice_id and self.rfi_notice_id.current_task_id == self:
            self.rfi_notice_id.current_task_status = 'Completed'
        if task_schedule:

            if task_schedule.work_order_id:
                if task_schedule.work_order_id.current_task_id and task_schedule.work_order_id.current_task_id.sequence < task_schedule.sequence or not task_schedule.work_order_id.current_task_id:
                    task_schedule.work_order_id.current_task_id = task_schedule.id
                    task_schedule.work_order_id.current_task_status = task_schedule.name

            if task_schedule.construction_id:
                if  task_schedule.construction_id.current_task_id and  task_schedule.construction_id.current_task_id.sequence < task_schedule.sequence or not task_schedule.construction_id.current_task_id:
                    task_schedule.construction_id.current_task_id = task_schedule.id
                    task_schedule.construction_id.current_task_status = task_schedule.name

            if task_schedule.site_acq_id:
                if  task_schedule.site_acq_id.current_task_id and  task_schedule.site_acq_id.current_task_id.sequence < task_schedule.sequence or not task_schedule.site_acq_id.current_task_id:
                    task_schedule.site_acq_id.current_task_id = task_schedule.id
                    task_schedule.site_acq_id.current_task_status = task_schedule.name

            if task_schedule.rfi_notice_id:
                if  task_schedule.rfi_notice_id.current_task_id and  task_schedule.rfi_notice_id.current_task_id.sequence < task_schedule.sequence or not task_schedule.rfi_notice_id.current_task_id:
                    task_schedule.rfi_notice_id.current_task_id = task_schedule.id
                    task_schedule.rfi_notice_id.current_task_status = task_schedule.name

            print (task_schedule.user_id.name,'twetwt')
            task_schedule.activity_schedule('mail.mail_activity_data_todo', note=task_schedule.user_id.name, user_id=task_schedule.user_id.id)
            # activity = self.env['mail.activity'].sudo().create({
            #     'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
            #     'res_id': task_schedule.id,
            #     'user_id': task_schedule.user_id.id,
            #     # 'date_deadline':deadline,
            #     'res_model_id': self.env.ref('project.model_project_task').id,
            # })
            # print(":activity", activity)
            # activity._onchange_activity_type_id()

        # self.state = 'confirm'
        self.stage_id = self.env.ref('kg_tower.task_stage_confirmed').id
        task_seq = self.env['project.task'].search(
            [('project_id', '=', self.project_id.id), ('ring_request_id', '=', self.ring_request_id.id)], limit=1,
            order="sequence desc")
        if task_seq.sequence == self.sequence:
            self.ring_request_id.date_completed = fields.Date.today()

    # @api.onchange('stage_id')
    # def onchange_stage_id(self):
    #     for rec in self:
    #         rec.action_confirm()

    def write(self, vals):
        if 'user_id' in vals.keys():
            vals['assign'] = True
        res = super(ProjectTask, self).write(vals)
        return res


        # for rec in self:
        #     user_id = vals.get('user_id')
        #     old_user_id = rec.user_id.id
        #     res = super(ProjectTask, self).write(vals)
        #     rec.update({'assign':True})
        #     # if user_id != old_user_id:
        #     #     print("change", user_id)
        #     #     # activity = self.env['mail.activity'].sudo().create({
        #     #     #     'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
        #     #     #     'res_id': rec.id,
        #     #     #     'user_id': rec.user_id.id,
        #     #     #     # 'date_deadline':deadline,
        #     #     #     'res_model_id': self.env.ref('project.model_project_task').id,
        #     #     # })
        #     #     self.activity_schedule('mail.mail_activity_data_todo', note="Task reallocated", user_id=rec.user_id.id)
        #     return res
