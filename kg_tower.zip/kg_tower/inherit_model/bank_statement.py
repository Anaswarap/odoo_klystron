from odoo import api, models,fields, _
from odoo.exceptions import UserError

class BankStatement(models.Model):
    _inherit = ['account.bank.statement', 'budget.alert']
    _name = 'account.bank.statement'

    number = fields.Char(
        'Number',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    btf_number = fields.Char(string="BTF Number")

    @api.model
    def create(self,vals):
        if vals.get('number', _('New')) == _('New'):
            vals['number'] = self.env['ir.sequence'].next_by_code('account.bank.statement') or _('New')
        return super().create(vals)


class BankStatementLine(models.Model):

    _inherit = 'account.bank.statement.line'
    analytic_account_id = fields.Many2one('account.analytic.account', string="Analytic Account", copy=False,
                                          ondelete='set null',
                                          help="Analytic account to which this project is linked for financial management. "
                                               "Use an analytic account to record cost and revenue on your project.")
    btf_number = fields.Char(string="BTF Number")
