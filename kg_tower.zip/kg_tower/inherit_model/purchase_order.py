from odoo import models, fields, api, _
from odoo.exceptions import UserError




class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    vendor_contractor_id = fields.Many2one('res.partner','Vendor/Contractor')
    contract_count = fields.Integer('Contract Count', compute='compute_contract_count')

    def compute_contract_count(self):
        for res in self:
            res.contract_count = self.env['contract.pricelist'].search_count([('purchase_id','=',res.id)])

    def action_view_contract(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Contract Pricelist',
            'view_mode': 'tree,form',
            'res_model': 'contract.pricelist',
            'context': {'create': False},
            'domain': [('purchase_id', '=', self.id)],
        }


    def button_create_contract(self):
        for rec in self:
            line_data = []
            index = 1
            for line in rec.order_line:
                prod_data = {
                    'name': index,
                    'product_id' : line.product_id.id,
                }
                index +=1
                line_data.append((0,0,prod_data))
            return {
                'type': 'ir.actions.act_window',
                'name': 'Contract Pricelist',
                'view_mode': 'form',
                'res_model': 'contract.pricelist',
                'context': {
                    'default_partner_id': rec.partner_id.id,
                    'default_purchase_id': rec.id,
                    'default_date_order':fields.datetime.now(),
                    'default_pricelist_line_ids': line_data,
                }
            }

    @api.onchange('vendor_contractor_id')
    def onchange_vendor_contract(self):
        for rec in self:
            if rec.vendor_contractor_id:
                rec.picking_type_id = rec.vendor_contractor_id.vendor_picking_type_id and rec.vendor_contractor_id.vendor_picking_type_id.id or False
