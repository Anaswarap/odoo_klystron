
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'


    payment_approval = fields.Boolean('Payment Approval', config_parameter='kg_tower.payment_approval')

    approval_amount = fields.Float('Minimum Approval Amount', config_parameter='kg_tower.approval_amount',
                                   help="If amount is 0.00, All the payments go through approval.")

    grace_period  = fields.Integer('Grace Period',config_parameter='kg_tower.grace_period',help="If grace period is 0, Penalty will be calculated after due date.",default=30)


    penalty_percent = fields.Float('Penalty %', config_parameter='kg_tower.penalty_percent',help="If pernalty is 0, No  Penalty will be calculated after grace due date.",default=3)

    max_tenants = fields.Integer('Max Tenants',config_parameter='kg_tower.max_tenants',help='Max Tenants allowed in a project',default=3)

    srr_charge = fields.Float('Ring Request Charge', config_parameter='kg_tower.srr_charge',
                                   help="Amount to be paid if not proceeding with NSWO.")
    srr_product_id = fields.Many2one(
        comodel_name='product.product',
        config_parameter = 'kg_tower.srr_product_id',
        string='SRR Product')

    expense_product_id = fields.Many2one(
        comodel_name='product.product', domain="[('type', '=', 'service')]",
        config_parameter = 'kg_tower.expense_product_id',
        string='Product')