# -*- coding: utf-8 -*-


from odoo import models, fields


class TaskListCategory(models.Model):
    _name = 'task.list.category'
    _description = 'Task List Category'

    name = fields.Char(string="Name", required=True)
    description = fields.Text(string="Description")
