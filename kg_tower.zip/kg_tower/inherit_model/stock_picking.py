from odoo import models, fields, api, _

class Picking(models.Model):
    _inherit = 'stock.picking'

    project_id = fields.Many2one('project.project', 'Project')
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)
    tower_transfer_id = fields.Many2one('tower.transfer','Transfer')
    stock_order_id = fields.Many2one('stock.order','Stock Order')

    def button_validate(self):
        res = super(Picking, self).button_validate()
        for rec in self:
            if rec.project_id and rec.picking_type_code == 'internal':
                for line in rec.move_line_ids_without_package:
                    line.lot_id.project_id = rec.project_id.id
                    line.lot_id.state = 'assigned'
            if rec.picking_type_code == 'incoming':
                for line in rec.move_line_ids_without_package:
                    if line.qty_done:
                        line.lot_id.state = 'available'
        return res


class Move(models.Model):
    _inherit = 'stock.move'

    project_id = fields.Many2one('project.project', 'Project')
    site_acq_id = fields.Many2one(
        comodel_name='site.acquisition',
        string='Site Acquisition',
        required=False)

