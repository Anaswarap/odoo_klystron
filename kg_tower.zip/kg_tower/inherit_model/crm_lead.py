from odoo import api, models, fields, _
from odoo.exceptions import UserError
from datetime import date, timedelta
from odoo.exceptions import ValidationError


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    nda_count = fields.Integer('NDA Count', compute='comp_nda_count')



    def comp_nda_count(self):
        for record in self:
            record.nda_count = self.env['kg.nda'].search_count(
                [('lead_id', '=', record.id)])

    def show_ndas(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "NDA's",
                'view_mode': 'tree,form',
                'res_model': 'kg.nda',
                'domain': [('lead_id', '=', rec.id)],
                'context': {
                    'default_date': fields.Date.today(),
                    'default_lead_id': rec.id,
                    'default_partner_id':rec.partner_id and rec.partner_id.id or False,

                }
            }


class HrDepartmentInherit(models.Model):
    _inherit = 'hr.department'

    analytic_group_id = fields.Many2one('account.analytic.group', string="Analytic Group")

    @api.model
    def create(self, vals):
        department_name = vals.get('name')
        is_exiting_department = self.env['account.analytic.group'].search([('name', '=', department_name)])
        if is_exiting_department:
            raise ValidationError('This name is already exist for an analytic account group, please change name')
        else:
            analytic_acc_grp_obj = self.env['account.analytic.group'].create({'name': department_name})
            vals['analytic_group_id'] = analytic_acc_grp_obj.id
        return super(HrDepartmentInherit, self).create(vals)
