from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools.misc import get_lang


class PurchaseTender(models.Model):
    _inherit = 'kg.purchase.tender'

    def action_view_contract_pricelists(self):
        action = self.env["ir.actions.actions"]._for_xml_id("kg_tower.contract_pricelist_action")
        action['context'] = {'default_tender_id': self.ids[0]}
        action['domain'] = [('tender_id', 'in', self.ids)]
        return action
