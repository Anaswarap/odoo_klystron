from odoo import models, fields, _, api
from odoo.exceptions import UserError
from datetime import date


# Replaced strucutre type to master
class AssetPac(models.Model):
    _inherit = 'account.asset.pac'

    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    state = fields.Selection([('draft', 'Pending'),
                              ('approval_two', 'Approved by Senior Projects'),
                              ('approval_three', 'Approved by Asset Manager'),
                              ('approval_four', 'Approved by Project Advisor'),
                              ('approval_five', 'Approved by Finance Controller'),
                              ('confirm', 'PAC Issued'),
                              ('cancel', 'Cancelled')], string='Status', default='draft', tracking=True)
    # , ('approval_one', 'Approved by Contrator'),

    tswo_ids = fields.One2many(
        comodel_name='project.tswo',
        inverse_name='pac_id',
        related='project_id.tswo_ids',
        string='TSWOs',
        required=False)
    contract_number = fields.Many2one('contract.pricelist', string="Contract No")

    """fields added for excel import"""
    """sha"""
    total_site_value = fields.Float(string="PAC  Value", digits="OTC Decimal", store=True)
    work_order_value = fields.Float('Work Order Value', related='project_id.work_order_value', readonly=False)
    vo_value = fields.Float('Variation Order Value', related='project_id.vo_value')
    addt_exp_value = fields.Float('Addt Expense Values', related='project_id.addt_exp_value')
    balance_amount = fields.Float('Balance Amount', related='project_id.balance_amount')
    total_work_order_value = fields.Float('Total Site Value', compute='comp_total_value', store=True, copy=False,
                                          digits="OTC Decimal")
    """fields added for excel import"""
    """sumayya"""
    sf_status = fields.Selection([('rec_sf', 'Received SF'), ('not_rec_sf', 'Not Received SF')], default='not_rec_sf',
                                 string='Soft Copy Site Folder')
    sf_status_hard = fields.Selection([('rec_sf', 'Received SF'), ('not_rec_sf', 'Not Received SF')],
                                      default='not_rec_sf',
                                      string='Site Folder Hard Copy')
    final_site_value = fields.Float('Final Site Value', store=True, digits="OTC Decimal")
    other_expense = fields.Float('Other Expenses', store=True)
    pac_type = fields.Selection([('pac1', 'PAC 1'), ('pac2', 'PAC 2'),
                                 ('pac3', 'PAC 3')], string='PAC Type')

    def notify_users(self, allowed_user_ids, allowed_group):
        self.activity_unlink(['kg_tower.pac_approval'])
        print(allowed_user_ids, allowed_group)
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_tower.pac_approval', note=user.name, user_id=user.id)
        if allowed_user_ids:
            user_ids = allowed_user_ids.split(',')
            user_ids = list(map(int, user_ids))
            for user in self.env['res.users'].browse(user_ids):
                self.activity_schedule('kg_tower.pac_approval', note=user.name, user_id=user.id)

        return True

    def action_approve_contractor(self):
        self.notify_users(False, 'kg_tower.group_comm_dept')
        self.state = 'approval_one'

    def action_approve_senior_project(self):
        self.notify_users(False, 'project.group_project_manager')
        self.state = 'approval_two'

    def action_approve_project(self):
        self.notify_users(False, 'otc_assets.group_otc_asset_manager')
        self.state = 'approval_four'

    def action_approve_assets(self):
        self.notify_users(False, 'account.group_account_manager')
        self.state = 'approval_three'

    def action_approve_finance(self):
        self.state = 'approval_five'

    def create_op_assets(self):
        year_today = date.today().year
        existing_asset = self.env['account.asset'].search(
            [('site_id', '=', self.site_id.id), ('state', '=', 'open')], limit=1, order="create_date desc")

        asset_account_fixed_asset_id = self.project_id.company_id.asset_account_fixed_asset_id.id
        asset_account_depreciation_id = self.project_id.company_id.asset_account_depreciation_id.id
        asset_account_depreciation_expense_id = self.project_id.company_id.asset_account_depreciation_expense_id.id
        asset_journal_id = self.project_id.company_id.asset_journal_id.id
        account_asset_counterpart_id = self.project_id.company_id.account_asset_counterpart_id.id
        if not asset_account_fixed_asset_id or not asset_account_depreciation_id or not asset_account_depreciation_expense_id or not asset_journal_id or not account_asset_counterpart_id:
            raise UserError("Configure accounts and journal in asset settings.")
        # if there is any asset exist, will modify depreciation
        if existing_asset:
            modify_wizard = self.env['asset.modify'].create({
                'asset_id': existing_asset.id,
                'name': _('New Tenant'),
                'value_residual': existing_asset.value_residual + self.total_work_order_value,
                'account_asset_counterpart_id': account_asset_counterpart_id,
            })
            result = modify_wizard.modify()
            self.otc_id = existing_asset.id

            # cumulated_period = year_today - existing_asset.first_depreciation_date.year
            # remaining_entries = existing_asset.depreciation_move_ids.filtered(lambda l: l.date.year >= year_today)
            # remain_dep_amount = sum(remaining_entries.mapped('amount_total'))
            # remaining_entries.button_draft()
            # existing_asset.action_asset_pause()
            # # existing_asset.set_to_draft()
            # dep_value = self.total_work_order_value + remain_dep_amount
            # asset_id = self.env['account.asset'].create({
            #     'name': self.project_id.number,
            #     'vendor_id': self.partner_id.id,
            #     'operation_status': 'op',
            #     'method_number': self.structure_type_id.validity - cumulated_period,
            #     'method_period': '12',
            #     'method': 'linear',
            #     'asset_type': 'purchase',
            #     'original_value': dep_value,
            #     'pac_id': self.id,
            #     'project_id': self.project_id.id,
            #     'site_id': self.site_id and self.site_id.id,
            #     'account_asset_id':asset_account_fixed_asset_id,
            #     'account_depreciation_id':asset_account_depreciation_id,
            #     'account_depreciation_expense_id':asset_account_depreciation_expense_id,
            #     'journal_id':asset_journal_id,
            #
            # })
            # self.otc_id = asset_id.id
        else:
            asset_id = self.env['account.asset'].create({
                'name': self.project_id.number,
                'vendor_id': self.partner_id.id,
                'operation_status': 'op',
                'method_number': self.structure_type_id.validity*12,
                'method_period': '1',
                'method': 'linear',
                'asset_type': 'purchase',
                'original_value': self.total_work_order_value,
                'pac_id': self.id,
                'project_id': self.project_id.id,
                'site_id': self.site_id and self.site_id.id,
                'account_asset_id': asset_account_fixed_asset_id,
                'account_depreciation_id': asset_account_depreciation_id,
                'account_depreciation_expense_id': asset_account_depreciation_expense_id,
                'journal_id': asset_journal_id,

            })
            self.otc_id = asset_id.id

    def action_confirm(self):
        if not self.project_id:
            raise UserError(_('Please Select Project'))
        # self.project_id.work_order_value = self.work_order_value
        # self.project_id.vo_value = self.vo_value
        # self.project_id.addt_exp_value = self.addt_exp_value
        # self.project_id.total_work_order_value = self.total_work_order_value

        self.create_op_assets()
        self.state = 'confirm'

    def action_cancel(self):
        self.state = 'cancel'

    def create_insurance_decl(self):
        for rec in self:
            tswo_id = rec.tswo_ids[0].tswo_id
            self.env['account.asset.declaration'].create({
                'pac_id': rec.id,
                'project_id': rec.project_id.id,
                'site_id': rec.site_id.id,
                'name': rec.project_id.name,
                'otc_id': rec.otc_id.id,
                'tower_install': tswo_id.tower_install,
                'other_cw': tswo_id.other_cw,
                'gird_conn': tswo_id.grid_connection,
                'access_road': tswo_id.access_road,
                'dev_add_ten': tswo_id.development,

            })
            rec.insurance_status = 'insured'

    def get_ins_decl(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Insurance Declaration',
            'view_mode': 'tree,form',
            'res_model': 'account.asset.declaration',
            'domain': [('pac_id', '=', self.id)],
            'context': "{'create': False}"
        }

    ins_dec_count = fields.Integer(compute='compute_decl_count')


    def compute_decl_count(self):
        for record in self:
            record.ins_dec_count = self.env['account.asset.declaration'].search_count(
                [('pac_id', '=', record.id)])

    def create_insurance_tracker(self):
        for rec in self:
            tswo_id = False
            if len(rec.tswo_ids) > 0:
                tswo_id = rec.tswo_ids[0] and rec.tswo_ids[0].tswo_id

            return self.env['account.asset.insurance'].create({
                'otc_id': self.otc_id.id,
                'pac_id': self.id,
                'site_id': self.site_id.id,
                'project_id': self.project_id.id,
                'wilayat_id': self.project_id.work_order_id.wilayat.id,
                'structure_type_id': self.structure_type_id.id,
                'tower_install': tswo_id and tswo_id.tower_install,
                'other_cw': tswo_id and tswo_id.other_cw,
                'gird_conn': tswo_id and tswo_id.grid_connection,
                'access_road': tswo_id and tswo_id.access_road,
                'dev_add_ten': tswo_id and tswo_id.development,
            })

    @api.onchange('project_id')
    def onchange_project_id(self):
        if self:
            if self.tswo_ids:
                tswo_id = self.tswo_ids[0].tswo_id
                if tswo_id:
                    self.contract_number = tswo_id.contract_no.id
                    self.contract_title = tswo_id.contract_no.contract_title

    def view_pac(self):
        if self:
            pac_ids = self.env['account.asset.pac'].search([('site_id', '=', self.site_id.id)])
            if pac_ids:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'PAC',
                    'view_mode': 'tree,form',
                    'res_model': 'account.asset.pac',
                    'domain': [('id', '=', pac_ids.ids)],
                    'context': "{'create': False}"
                }

    def view_assets(self):
        if self:
            assets_ids = self.env['account.asset'].search([('project_id', '=', self.project_id.id)])
            if assets_ids:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Assets',
                    'view_mode': 'tree,form',
                    'res_model': 'account.asset',
                    'domain': [('id', '=', assets_ids.ids)],
                    'context': "{'create': False}"
                }

    @api.depends('work_order_value', 'vo_value', 'addt_exp_value')
    def comp_total_value(self):
        """overwritten total compute action to add paid amount from tswo"""
        for rec in self:
            if rec.tswo_ids:
                tswo_id = rec.tswo_ids[0].tswo_id
                if tswo_id:
                    paint_amount = sum(tswo_id.tswo_line_ids.mapped('paid_amount'))
                    if paint_amount:
                        rec.total_work_order_value = rec.work_order_value + rec.vo_value + rec.addt_exp_value + paint_amount
                    else:
                        rec.total_work_order_value = rec.work_order_value + rec.vo_value + rec.addt_exp_value
                else:
                    rec.total_work_order_value = rec.work_order_value + rec.vo_value + rec.addt_exp_value
            else:
                rec.total_work_order_value = rec.work_order_value + rec.vo_value + rec.addt_exp_value


class AssetInsurance(models.Model):
    _inherit = 'account.asset.insurance'

    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    tswo_ids = fields.One2many(
        comodel_name='project.tswo',
        inverse_name='ins_tracker_id',
        string='TSWOs',
        required=False)


class AccountAssetInherit(models.Model):
    _inherit = 'account.asset'

    project_id = fields.Many2one('project.project', string="Project")
    pac_id = fields.Many2one('account.asset.pac', string="PAC")
    site_id = fields.Many2one('account.asset.site', string="OTC Site ID")
