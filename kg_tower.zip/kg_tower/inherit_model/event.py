from odoo import models, fields, api, _
from odoo.exceptions import UserError


class Events(models.Model):
    _inherit = 'event.event'


    gift_count = fields.Integer('Gift Count', compute='comp_gift_count')


    def comp_gift_count(self):
        for record in self:
            record.gift_count = self.env['event.gift'].search_count(
                [('event_id', '=', record.id)])


    def show_gifts(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Gifts',
                'view_mode': 'tree,form',
                'res_model': 'event.gift',
                'domain': [('event_id', '=', rec.id)],
                'context': {
                    'default_event_id': rec.id,
                    }
            }
