from datetime import date

from odoo import api, models, fields, _
from odoo.exceptions import UserError, ValidationError


class ProjectProject(models.Model):
    _inherit = 'project.project'
    _rec_name = 'number'

    # def name_get(self):
    #     res = super(ProjectProject, self).name_get()
    #     for record in self:
    #         if record.display_name:
    #             name = record.display_name
    #             res.append((record.id, name))
    #         if not record.display_name:
    #             name = record.name
    #             res.append((record.id, name))
    #     return res

    @api.model
    def _get_default_picking(self):
        transfer_type_id = self.env['stock.picking.type'].search([('code', '=', 'internal')], limit=1,
                                                                 order='id ASC').id
        return transfer_type_id

    """field added for excel importing..........***sumayya***********"""
    number = fields.Char(
        'Reference',
        # copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=False)
    # project_contractor_ids = fields.One2many('partner.project','project_id', string='Project Contractor')

    name = fields.Char(required=False)
    site_id = fields.Many2one('account.asset.site', 'Site ID')

    project_expenses = fields.One2many('project.expense.lines', 'project_id', 'Project Expenses')

    project_addt_resources = fields.One2many('project.addt.resources', 'project_id', 'Additional Resources')
    inv_count = fields.Integer('Inv Count', compute='comp_inv_count')
    vendor_inv_count = fields.Integer('Vendor Inv Count', compute='comp_inv_count')

    bill_count = fields.Integer('BIll COunt', compute='comp_bill_count')

    tower_inv_count = fields.Integer('Tower Inv count', compute='comp_tower_inv_count')

    pac_count = fields.Integer('PAC Count', compute='comp_pac_count')
    contractor_expense_count = fields.Integer('Contract Expense', compute='comp_contractor_expense_count')
    owner_rent_expense_count = fields.Integer('Owner Rent Expense', compute='comp_owner_rent_expense_count')

    vendor_id = fields.Many2one('res.partner', 'Vendor/Contractor', domain=[('contractor', '=', True)])
    is_completed = fields.Boolean('Is Completed', default=False)

    inventory_location = fields.Many2one('stock.location', 'Inventory Location')
    srr_id = fields.Many2one('ring.request', 'Search Ring Request')
    work_order_id = fields.Many2one('work.order', 'NSWO')
    structure_type_id = fields.Many2one('structure.type', 'Structure Type')
    internal_transfer_picking_id = fields.Many2one('stock.picking.type', 'Internal Transfer Type',
                                                   default=_get_default_picking)

    ## Tenant details
    project_tenant_detail_ids = fields.One2many('project.tenant.details', 'project_id', 'Tenant Details')

    work_order_value = fields.Float('Work Order Value', compute='comp_values_from_vo', copy=False,
                                    digits="OTC Decimal")
    vo_value = fields.Float('Variation Order Value', compute='comp_values_from_vo', copy=False,
                            digits="OTC Decimal")
    addt_exp_value = fields.Float('Addt Expense Values', copy=False, digits="OTC Decimal")
    total_work_order_value = fields.Float('Total Work Order Value', compute='comp_total_value', store=True, copy=False,
                                          digits="OTC Decimal")
    total_amount_paid = fields.Float('Total Amount Value', compute='get_total_amount_paid', copy=False,
                                     digits="OTC Decimal")
    tswo_ids = fields.One2many(
        comodel_name='project.tswo',
        inverse_name='project_id',
        string='TSWOs',
        required=False)

    milestone_ids = fields.One2many(
        comodel_name='project.milestone',
        inverse_name='project_id',
        string='Milestone',
        required=False)

    task_status = fields.Char('Task Status', compute='comp_task_status')
    invoiced_amount = fields.Float(string="Total Invoiced", readonly=True, copy=False, digits="OTC Decimal")
    balance_amount = fields.Float(string="Balance Amount", readonly=True, copy=False, digits="OTC Decimal")
    vo_ids = fields.One2many('kg.vo', 'project_id', string=" Variation Orders")
    expense_ids = fields.Many2many('account.move', string="Expense Bill")
    stock_order_id = fields.Many2one(
        comodel_name='stock.order',
        string='Stock Order',
        required=False)
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string='Payment Terms',
        required=False)
    # this field for temporary purpose to store same as wo value
    temp_wo_value = fields.Float('Work Order Value', copy=False, digits="OTC Decimal")

    @api.depends('tswo_ids')
    def get_total_amount_paid(self):
        for rec in self:
            amt = 0
            for ts in rec.tswo_ids:
                amt = sum(ts.tswo_id.tswo_line_ids.mapped('paid_amount'))
            rec.total_amount_paid = amt
            work_order_value = sum(self.tswo_ids.tswo_id.mapped('actual_wo_value')) + sum(self.tswo_ids.tswo_id.mapped('amount_total'))
            rec.work_order_value = work_order_value
            rec.temp_wo_value = rec.work_order_value
            rec.vo_value = sum(self.tswo_ids.tswo_id.mapped('variation_value'))

    def comp_task_status(self):
        for rec in self:

            info = """<h2 > Task Status </h2>    
                <table class="table table-bordered table-sm">
                   <thead class="thead-light">
                            <tr>
                                <th scope="col">Sr No</th>
                                <th scope="col">Desc</th>
                                <th scope="col">Assignee</th>

                                <th scope="col">Status</th>

                            </tr>
                        </thead>
                        <tbody>

                """
            count = 1
            for task in self.env['project.task'].search([('project_id', '=', rec.id), ('milestone_task', '=', True)]):
                if task.stage_id.is_closed:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:green;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                else:
                    info += """  <tr><td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td><span style="color:black;">%s</span> </td> <td> <span style="color:red;">%s</span> </td> </tr>""" % (
                        count, task.name, task.user_id.name, task.stage_id.name)
                count += 1
            info += """</tbody></table>"""

            rec.task_status = info

    def show_owner_rent_expense(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "Owner Rent Expense",
                'view_mode': 'tree,form',
                'res_model': 'project.owner.rent.expense',
                'domain': [('project_id', '=', rec.id)],
                'context': {
                    'default_partner_id': rec.partner_id.id or False,
                    'default_site_id': rec.site_id.id or False,
                    'default_project_id': rec.id,
                }
            }

    def show_contractor_expense(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': "Contractor Expense",
                'view_mode': 'tree,form',
                'res_model': 'project.contractor.expense',
                'domain': [('project_id', '=', rec.id)],
                'context': {
                    'default_partner_id': rec.partner_id.id or False,
                    'default_site_id': rec.site_id.id or False,
                    'default_project_id': rec.id,
                }
            }

    def comp_values_from_vo(self):
        for rec in self:
            variation_orders = self.env['kg.vo'].search([('project_id', '=', rec.id)])
            tswos = self.env['project.tswo'].search([('project_id', '=', rec.id)])
            # print(variation_orders, 'avavas')
            wo_value = 0
            vo_value = 0
            for t in tswos:
                wo_value += t.tswo_id.amount_total

            for i in variation_orders:
                vo_value += i.variation_subtotal
            rec.work_order_value = wo_value
            rec.vo_value = vo_value
            # amt = 0
            # for ts in rec.tswo_ids:
            #     amt = sum(ts.tswo_id.tswo_line_ids.mapped('paid_amount'))
            # rec.total_amount_paid = amt

    @api.depends('work_order_value', 'vo_value', 'addt_exp_value')
    def comp_total_value(self):
        for rec in self:
            rec.total_work_order_value = rec.work_order_value + rec.vo_value + rec.addt_exp_value
            rec.balance_amount = rec.total_work_order_value - rec.invoiced_amount

    # structure_type = fields.Selection(
    #     string='Structure Type',
    #     selection=[('greenfield', 'Greenfield'),
    #                ('rooftop', 'Rooftop'),
    #                ('collocation', 'Collocation'), ])

    def comp_bill_count(self):
        for record in self:
            record.bill_count = self.env['account.move'].search_count(
                [('project_id', '=', record.id), ('move_type', '=', 'in_invoice')])

    def show_create_vendor_bills(self):
        for rec in self:
            vendor_bills = self.env['account.move'].search(
                [('project_id', '=', rec.id), ('move_type', '=', 'in_invoice')])
            if vendor_bills:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Bills',
                    'view_mode': 'tree,form',
                    'res_model': 'account.move',
                    'domain': [('id', 'in', vendor_bills.ids)],
                    'context': {
                        'default_partner_id': rec.vendor_id.id,
                        'default_move_type': 'in_invoice',
                        'default_project_id': rec.id,
                    }
                }
            else:
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Bills',
                    'view_mode': 'form',
                    'res_model': 'account.move',
                    'context': {
                        'default_partner_id': rec.vendor_id.id,
                        'default_move_type': 'in_invoice',
                        'default_project_id': rec.id,
                    }
                }

    def comp_pac_count(self):
        for record in self:
            record.pac_count = self.env['account.asset.pac'].search_count(
                [('project_id', '=', record.id)])

    def comp_contractor_expense_count(self):
        for record in self:
            record.contractor_expense_count = self.env['project.contractor.expense'].search_count(
                [('project_id', '=', record.id)])

    def comp_owner_rent_expense_count(self):
        for record in self:
            record.owner_rent_expense_count = self.env['project.owner.rent.expense'].search_count(
                [('project_id', '=', record.id)])

    def create_pac(self):
        for rec in self:
            if not rec.vendor_id:
                raise UserError(_('Please add Vendor in settings tab'))
            if rec.work_order_id:
                structure_type_id = rec.work_order_id.structure_type_id.id or rec.structure_type_id.id
            self.env['account.asset.pac'].create({
                'project_id': rec.id,
                'site_id': rec.site_id.id,
                'partner_id': rec.vendor_id.id,
                'structure_type_id': rec.structure_type_id.id,
                'pac_date': fields.Date.today(),
                'work_order_value': rec.work_order_value,
                'vo_value': rec.vo_value,
                'addt_exp_value': rec.addt_exp_value,
                'total_work_order_value': rec.total_work_order_value
            })

    def show_pac(self):

        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'PAC',
                'view_mode': 'tree,form',
                'res_model': 'account.asset.pac',
                'domain': [('project_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    # def show_contractor_expense(self):
    #     for rec in self:
    #         return {
    #             'type': 'ir.actions.act_window',
    #             'name': 'Contractor Expenses',
    #             'view_mode': 'tree,form',
    #             'res_model': 'project.contractor.expense',
    #             'domain': [('project_id', '=', rec.id)],
    #             'context': "{'create': False,'edit': False}"
    #         }

    # def show_owner_rent_expense(self):
    #     for rec in self:
    #         return {
    #             'type': 'ir.actions.act_window',
    #             'name': 'Owner Rent Expenses',
    #             'view_mode': 'tree,form',
    #             'res_model': 'project.owner.rent.expense',
    #             'domain': [('project_id', '=', rec.id)],
    #             'context': "{'create': False,'edit': False}"
    #         }

    def mark_complete(self):
        find_pacs = self.env['account.asset.pac'].search_count(
            [('project_id', '=', self.id), ('state', '!=', 'confirm')])
        if find_pacs > 0:
            raise UserError(_("PAC'S not Confirmed"))

        self.is_completed = True

    def comp_tower_inv_count(self):
        for record in self:
            invoice_list = self.env['tower.invoice.line'].search([('project_id', '=', record.id)]).mapped(
                'tower_invoice_id').ids
            invoice_list = list(set(invoice_list))
            record.tower_inv_count = self.env['tower.invoice'].search_count(
                [('id', 'in', invoice_list)])

    def show_tower_invoices(self):

        for rec in self:
            invoice_list = self.env['tower.invoice.line'].search([('project_id', '=', rec.id)]).mapped(
                'tower_invoice_id').ids
            invoice_list = list(set(invoice_list))

            return {
                'type': 'ir.actions.act_window',
                'name': 'Tower Invoices',
                'view_mode': 'tree,form',
                'res_model': 'tower.invoice',
                'domain': [('id', 'in', invoice_list)],
                'context': "{'create': False}"
            }

    def comp_inv_count(self):
        for record in self:
            analytic_account_id = record.analytic_account_id and record.analytic_account_id.id or False
            if analytic_account_id:
                out_moves = self.env['account.move.line'].search(
                    [('analytic_account_id', '=', analytic_account_id),
                     ('move_id.move_type', '=', 'out_invoice')]).mapped('move_id').ids
                record.inv_count = len(out_moves)

                in_moves = self.env['account.move.line'].search(
                    [('analytic_account_id', '=', analytic_account_id),
                     ('move_id.move_type', '=', 'in_invoice')]).mapped('move_id').ids
                record.vendor_inv_count = len(in_moves)
            else:
                record.inv_count = 0
                record.vendor_inv_count = 0

    def show_invoices(self):
        for rec in self:
            analytic_account_id = rec.analytic_account_id and rec.analytic_account_id.id or False
            if analytic_account_id:
                moves = self.env['account.move.line'].search(
                    [('analytic_account_id', '=', analytic_account_id)]).mapped(
                    'move_id').ids
            else:
                moves = []
            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('id', 'in', moves), ('move_type', '=', 'out_invoice')],
                'context': "{'create': False}"
            }

    def show_in_invoices(self):
        for rec in self:
            analytic_account_id = rec.analytic_account_id and rec.analytic_account_id.id or False
            if analytic_account_id:
                moves = self.env['account.move.line'].search(
                    [('analytic_account_id', '=', analytic_account_id)]).mapped(
                    'move_id').ids
            else:
                moves = []
            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoices',
                'view_mode': 'tree,form',
                'res_model': 'account.move',
                'domain': [('id', 'in', moves), ('move_type', '=', 'in_invoice')],
                'context': "{'create': False}"
            }

    """field added for excel importing..........***sumayya***********"""

    # def update_old_project(self):
    #     for rec in self:
    #         if rec.number == _('New') or not rec.number:
    #             rec.number = self.env['ir.sequence'].next_by_code('project.project') or _('New')

    def action_create_invoice(self):
        """Action to create invoice from project for next milestone"""
        invoice = self.env['account.move']
        for rec in self:
            tswo_id = rec.tswo_ids[0].tswo_id
            if not rec.company_id.project_asset_acc_id:
                raise ValidationError("Please Specify Project Asset Account in Accounting Configuration")
            project_asset_acc_id = rec.company_id.project_asset_acc_id
            vendor_id = rec.tswo_ids[0].tswo_id.partner_id
            if rec.milestone_ids:
                if any(item.move_id for item in rec.milestone_ids):
                    milestone = rec.milestone_ids.filtered(lambda l: not l.move_id)
                    # milestone = milestone.sorted('id')[0]
                    if milestone:
                        milestone = milestone.sorted('id')[0]
                        if not milestone.milestone_per:
                            raise ValidationError("Please Specify Milestone percentage")
                        else:
                            milestone_sum_percent = sum(
                                rec.milestone_ids.filtered(lambda o: o.move_id).mapped('milestone_per'))
                            if milestone_sum_percent * rec.total_work_order_value == rec.invoiced_amount:
                                """"if there is no variation in project, ie eg:VO or Additional Expense, then create invoice as normal"""
                                label = 'Invoice For Milestone ' + milestone.milestone
                                move_vals = (0, 0, {
                                    'name': label,
                                    'account_id': project_asset_acc_id.id,
                                    'quantity': milestone.milestone_per,
                                    'milestone_percentage':  milestone.milestone_per,
                                    'price_unit': rec.total_work_order_value,
                                    'analytic_account_id': rec and rec.analytic_account_id and rec.analytic_account_id.id or False,
                                })
                                invoice_values = {
                                    'partner_id': vendor_id.id,
                                    'invoice_date': milestone.invoicing_date if milestone.invoicing_date else date.today(),
                                    'move_type': 'in_invoice',
                                    'tswo_id': tswo_id.id,
                                    'site_id': rec.site_id.id,
                                    'milestone': milestone.milestone_per,
                                    'milestone_id': milestone.id,
                                    'invoice_line_ids': move_vals,
                                }
                                create_invoice = invoice.create(invoice_values)
                                rec.invoiced_amount += create_invoice.amount_total
                                rec.balance_amount = rec.total_work_order_value - rec.invoiced_amount
                                milestone.move_id = create_invoice.id
                                create_invoice.action_post()
                                create_invoice.project_id = rec.id
                            else:
                                """"if there is any variation in project, ie eg:VO or additional expense, then create invoice with adding variation amount"""
                                lines = []
                                actual_label = 'Invoice For Milestone ' + milestone.milestone

                                actual_move_vals = (0, 0, {
                                    'name': actual_label,
                                    'account_id': project_asset_acc_id.id,
                                    'quantity': milestone.milestone_per,
                                    'price_unit': rec.total_work_order_value,
                                    'analytic_account_id': rec and rec.analytic_account_id and rec.analytic_account_id.id or False,
                                })
                                lines.append(actual_move_vals)
                                price_difference = (milestone_sum_percent * rec.total_work_order_value) \
                                                   - rec.invoiced_amount
                                dif_move_vals = (0, 0, {
                                    'name': 'Difference  For Milestones',
                                    'account_id': project_asset_acc_id.id,
                                    'quantity': 1,
                                    'price_unit': price_difference,
                                    'analytic_account_id': rec and rec.analytic_account_id and rec.analytic_account_id.id or False,
                                })
                                lines.append(dif_move_vals)
                                invoice_values = {
                                    'partner_id': vendor_id.id,
                                    'invoice_date': milestone.invoicing_date if milestone.invoicing_date else date.today(),
                                    'move_type': 'in_invoice',
                                    'tswo_id': tswo_id.id,
                                    'site_id': rec.site_id.id,
                                    'milestone': milestone.milestone_per,
                                    'milestone_id': milestone.id,
                                    'invoice_line_ids': lines,
                                }
                                create_invoice = invoice.create(invoice_values)
                                create_invoice.action_post()
                                rec.invoiced_amount += create_invoice.amount_total
                                rec.balance_amount = rec.total_work_order_value - rec.invoiced_amount
                                milestone.move_id = create_invoice.id
                                create_invoice.project_id = rec.id


class ProjectAddtResources(models.Model):
    _name = 'project.addt.resources'
    _description = 'Project Addt Resources'

    name = fields.Char('Description')
    job_id = fields.Many2one('hr.job', 'Type')
    hours = fields.Float('Hours')
    project_id = fields.Many2one('project.project', 'Project')


class TenantDetails(models.Model):
    _name = 'project.tenant.details'
    _description = 'Tenant Details'

    _sql_constraints = [
        ('project_operator_uniq', 'unique(project_id,partner_id)', "Choose Different Operator")
    ]

    name = fields.Char('Description')
    sequence = fields.Integer('Sequence', default=10)
    partner_id = fields.Many2one('res.partner', 'Operator', domain=[('operator', '=', True)])
    rfi_notice_id = fields.Many2one('rfi.notice', 'RFI Notice')
    scd_date = fields.Date('Site Commencement Date')
    discount_percent = fields.Float('Tenancy Discount')
    project_id = fields.Many2one('project.project', 'Project')

    @api.onchange('rfi_notice_id')
    def onchange_rfi_notice_id(self):
        for rec in self:
            if rec.rfi_notice_id:
                rec.scd_date = rec.rfi_notice_id.scd_date

    @api.constrains('project_id')
    def _check_max_tenant_limit(self):
        for rec in self:
            max_tenants = int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.max_tenants'))
            current_tenants = self.env['project.tenant.details'].search_count([('project_id', '=', rec.project_id.id)])
            if current_tenants > max_tenants:
                raise UserError(_("Only %s Tenants Allowed", str(max_tenants)))


class AssetSite(models.Model):
    _inherit = 'account.asset.site'

    project_ids = fields.One2many('project.project', 'site_id', string='Linked Projects')
    lot_id = fields.Many2one('stock.production.lot', string="Tower")

    def show_nswo(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'NSWO',
                'view_mode': 'tree,form',
                'res_model': 'work.order',
                'domain': [('client_site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_project(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Projects',
                'view_mode': 'tree,form',
                'res_model': 'project.project',
                'domain': [('site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_saq(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Site Aquisition',
                'view_mode': 'tree,form',
                'res_model': 'site.acquisition',
                'domain': [('client_site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_construction(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Construction',
                'view_mode': 'tree,form',
                'res_model': 'site.construction',
                'domain': [('client_site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_rfi(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'RFI Notice',
                'view_mode': 'tree,form',
                'res_model': 'rfi.notice',
                'domain': [('client_site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_pac(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'PAC',
                'view_mode': 'tree,form',
                'res_model': 'account.asset.pac',
                'domain': [('site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def show_fac(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'FAC',
                'view_mode': 'tree,form',
                'res_model': 'account.asset.fac',
                'domain': [('site_id', '=', rec.id)],
                'context': "{'create': False,'edit': False}"
            }

    def action_show_pm(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Preventive Maintenance',
                'view_mode': 'tree,form',
                'res_model': 'kg.preventive.maintenance',
                'domain': [('client_site_id', '=', rec.id)],
                # 'context': "{'create': False,'edit': False}"
            }

    def action_install(self):
        if self:
            for rec in self:
                if rec.lot_id:
                    rec.lot_id.state = 'installed'

    # Nafi
    """"server action for import records"""

    def update_site_project(self):
        sites = self.env['account.asset.site'].search([('project_ids', '=', False)])
        for rec in sites:
            site_name = rec.name[:5]

            corresponding_project = self.env['project.project'].search([('name', '=', site_name)], limit=1)
            if corresponding_project:
                rec.project_ids |= corresponding_project


class ProjectMilestone(models.Model):
    _name = 'project.milestone'
    _description = 'Project Milestone'
    _rec_name = 'milestone'

    project_id = fields.Many2one(
        comodel_name='project.project',
        string='Project',
        required=False)
    move_id = fields.Many2one('account.move')
    milestone_per = fields.Float()
    milestone = fields.Char()
    tswo = fields.Many2one('kg.tswo')
    # field added by Nafi
    milestone_no = fields.Char(string="Milestone No", readonly=True, required=True, copy=False, default='New')
    stock_order_id = fields.Many2one('stock.order', string="Stock Order")
    invoicing_date = fields.Date(strnig="Invoicing Date", related='move_id.invoice_date', readonly=False)
    progress = fields.Float(strnig="Progress")
    milestone_task_id = fields.Many2one('project.task', string="Milestone Task")
    task_stage_id = fields.Many2one('project.task.type', string="Task Status", related='milestone_task_id.stage_id')
    work_total_value = fields.Float(related='project_id.total_work_order_value')
    work_order_invoiced_value = fields.Float(related='project_id.invoiced_amount', string="Value Invoiced")
    balance_amount = fields.Float(related='project_id.balance_amount', string="Balance")
    is_invoiced = fields.Boolean(string="Invoiced")
    next_to_invoice = fields.Boolean(string="To Invoice", store=True)

    @api.model
    def create(self, vals):
        if vals.get('milestone_no', 'New') == 'New':
            vals['milestone_no'] = self.env['ir.sequence'].next_by_code('project.milestone') or 'New'

        res = super(ProjectMilestone, self).create(vals)
        return res

    def action_list_milestone(self):
        """ List records which has to rise invoice in the Milestone view. """
        milestone_list = []
        project_id = self.env['project.project'].search([])
        for record in project_id:
            if record.milestone_ids:
                if any(item.move_id for item in record.milestone_ids):
                    milestone = record.milestone_ids.filtered(lambda l: not l.move_id)
                    # milestone = milestone.sorted('id')[0]
                    if milestone:
                        milestone = milestone.sorted('id')[0]
                        milestone_list.append(milestone.id)
        action = {
            'name': _('Milestone'),
            'view_mode': 'tree',
            'res_model': 'project.milestone',
            'view_id': self.env.ref('kg_tower.view_tree_project_milestone').id,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', milestone_list)],
        }
        return action

    def action_create_invoice(self):
        """"This action for generating invoices for particular task specified in the Milestone"""
        invoice = self.env['account.move']
        for record in self:
            vendor_id = record.project_id.tswo_ids[0].tswo_id.partner_id
            if not record.milestone_per:
                raise ValidationError("Please Specify Milestone percentage")
            else:
                milestone_sum_percent = sum(
                    record.project_id.milestone_ids.filtered(lambda o: o.move_id).mapped('milestone_per'))
                if milestone_sum_percent * record.work_total_value == record.project_id.invoiced_amount:
                    """"if there is no variation in project, ie eg:VO or Additional Expense, then create invoice as normal"""
                    label = 'Invoice For Milestone ' + record.milestone
                    move_vals = (0, 0, {
                        'name': label,
                        'quantity': record.milestone_per,
                        'milestone_percentage': record.milestone_per,
                        'price_unit': record.work_total_value,
                        'analytic_account_id': record.project_id and record.project_id.analytic_account_id and record.project_id.analytic_account_id.id or False,
                    })
                    invoice_values = {
                        'partner_id': vendor_id.id,
                        'invoice_date': record.invoicing_date if record.invoicing_date else date.today(),
                        'move_type': 'in_invoice',
                        'milestone_id': record.id,
                        'invoice_line_ids': move_vals,
                    }
                    create_invoice = invoice.create(invoice_values)
                    record.project_id.invoiced_amount += create_invoice.amount_total
                    record.project_id.balance_amount = record.project_id.total_work_order_value - record.project_id.invoiced_amount
                    record.move_id = create_invoice.id
                    create_invoice.action_post()
                    create_invoice.project_id = record.project_id.id
                else:
                    """"if there is any variation in project, ie eg:VO or additional expense, then create invoice with adding variation amount"""
                    lines = []
                    actual_label = 'Invoice For Milestone ' + record.milestone

                    actual_move_vals = (0, 0, {
                        'name': actual_label,
                        'quantity': record.milestone_per,
                        'price_unit': record.project_id.total_work_order_value,
                        'analytic_account_id': record.project_id and record.project_id.analytic_account_id and record.project_id.analytic_account_id.id or False,
                    })
                    lines.append(actual_move_vals)
                    price_difference = (milestone_sum_percent * record.project_id.total_work_order_value) \
                                       - record.project_id.invoiced_amount
                    dif_move_vals = (0, 0, {
                        'name': 'Difference  For Milestones',
                        'quantity': 1,
                        'price_unit': price_difference,
                        'analytic_account_id': record.project_id and record.project_id.analytic_account_id and record.project_id.analytic_account_id.id or False,
                    })
                    lines.append(dif_move_vals)
                    invoice_values = {
                        'partner_id': vendor_id.id,
                        'invoice_date': record.invoicing_date if record.invoicing_date else date.today(),
                        'move_type': 'in_invoice',
                        'milestone_id': record.id,
                        'invoice_line_ids': lines,
                    }
                    create_invoice = invoice.create(invoice_values)
                    create_invoice.action_post()
                    record.project_id.invoiced_amount += create_invoice.amount_total
                    record.project_id.balance_amount = record.project_id.total_work_order_value - record.project_id.invoiced_amount
                    record.move_id = create_invoice.id
                    create_invoice.project_id = record.project_id.id

    @api.onchange('move_id')
    def onchange_move_id(self):
        self.invoicing_date = self.move_id.invoice_date


class ProjectTSWO(models.Model):
    _name = 'project.tswo'
    _description = 'ProjectTSWO'

    tswo_id = fields.Many2one(
        comodel_name='kg.tswo',
        string='TSWO',
        required=False)
    pac_id = fields.Many2one(
        comodel_name='account.asset.pac',
        string='PAC',
        required=False)
    ins_tracker_id = fields.Many2one(
        comodel_name='account.asset.insurance',
        string='Insurance Tracker',
        required=False)
    project_id = fields.Many2one(
        comodel_name='project.project',
        string='Project',
        required=False)
    partner_id = fields.Many2one('res.partner', 'Vendor/Contractor', domain=[('contractor', '=', True)])

    """field added for excel importing..........***sumayya***********"""
# class PartnerProject(models.Model):
#     _name = 'partner.project'
#     _description = 'PartnerProject'
#
#     partner_id = fields.Many2one('res.partner', 'contractor', domain=[('contractor', '=', True)])
#     project_id = fields.Many2one('project.project', string='Project')
#     wo_value = fields.Float("Work Order Value")
#     variation_o_value = fields.Float("Variation Order Value")
#     contract_no = fields.Many2one('contract.pricelist', 'Contract Pricelist')
