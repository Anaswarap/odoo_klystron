from odoo import api, models,fields, _
from odoo.exceptions import UserError
class PaymentTermLine(models.Model):
    _inherit = 'account.payment.term.line'

    description = fields.Char('Description')
class AccountAccount(models.Model):
    _inherit = 'account.account'

    restrict_balance = fields.Boolean(
        'Add Restrictions?',
    )
    min_balance = fields.Float(
        'Minimum Balance',)
    max_transaction = fields.Float('Maximum Transaction')
    alert_limit = fields.Float('Alert Limit')
    # # *******MINI removed compute and readonly of group id for data import*************
    # group_id = fields.Many2one('account.group', compute='_compute_account_group', store=False, readonly=True)
    #
    # @api.depends('code')
    # def _compute_account_group(self):
    #     if self.ids:
    #         self.env['account.group']._adapt_accounts_for_account_groups(self)
    #     else:
    #         self.group_id = False
    #
    #
    # def _adapt_accounts_for_account_groups(self, account_ids=None):
    #     """Ensure consistency between accounts and account groups.
    #
    #     Find and set the most specific group matching the code of the account.
    #     The most specific is the one with the longest prefixes and with the starting
    #     prefix being smaller than the account code and the ending prefix being greater.
    #     """
    #     if not self and not account_ids:
    #         return
    #     self.env['account.group'].flush(self.env['account.group']._fields)
    #     self.env['account.account'].flush(self.env['account.account']._fields)
    #     query = """
    #         WITH relation AS (
    #    SELECT DISTINCT FIRST_VALUE(agroup.id) OVER (PARTITION BY account.id ORDER BY char_length(agroup.code_prefix_start) DESC, agroup.id) AS group_id,
    #                    account.id AS account_id
    #               FROM account_group agroup
    #               JOIN account_account account
    #                 ON agroup.code_prefix_start <= LEFT(account.code, char_length(agroup.code_prefix_start))
    #                AND agroup.code_prefix_end >= LEFT(account.code, char_length(agroup.code_prefix_end))
    #                AND agroup.company_id = account.company_id
    #              WHERE account.company_id IN %(company_ids)s {where_account}
    #         )
    #         UPDATE account_account account
    #            SET group_id = relation.group_id
    #           FROM relation
    #          WHERE relation.account_id = account.id;
    #     """.format(
    #         where_account=account_ids and 'AND account.id IN %(account_ids)s' or ''
    #     )
    #     self.env.cr.execute(query, {'company_ids': tuple((self.company_id or account_ids.company_id).ids), 'account_ids': account_ids and tuple(account_ids.ids)})
    #     self.env['account.account'].invalidate_cache(fnames=['group_id'])
