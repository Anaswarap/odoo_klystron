odoo.define('kg_tower.kg_tower', function (require) {
'use strict';



var publicWidget = require('web.public.widget');
var rpc = require('web.rpc');

publicWidget.registry.searchRingRequest = publicWidget.Widget.extend({
    selector: '.o_portal_wrap',
    events: {
        'click #edit_srr': '_EditSrr',
        'click #save_srr': '_SaveSrr',
        'click #discard_srr': '_reloadWindow',
        'click #edit_request': '_changeState',
        'click #reset_srr_sign': '_resetSignCanvas',
    },

    start: function () {
//    var now = new Date();
//    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
//    if (document.getElementById("date_local")) {
//        document.getElementById('dt').value = now.toISOString().slice(0,16);
//        }

        var date = new Date();
        var day = date.getDate();
        var month = date.getMonth() + 1;
        var year = date.getFullYear();

        if (month < 10) month = "0" + month;
        if (day < 10) day = "0" + day;

        var today = year + "-" + month + "-" + day;
        if (document.getElementById("date_local")) {
             document.getElementById("date_local").value = today;
             }
        $('#signature_srr').jSignature();
        var $sigdiv = $('#signature_srr');

        var datapair = $sigdiv.jSignature('getData', 'svgbase64');

        $('#signature_srr').bind('change', function(e) {
          var data = $('#signature_srr').jSignature('getData');
          if (data) {
            data=data.replace('data:image/png;base64,', '')
            }
          $("#signature_capture").val(data);
          $("#help").slideDown(300);
        });
        return this._super.apply(this, arguments);
    },

    _resetSignCanvas: function (ev) {
        $('#signature_srr').jSignature('clear');
        $("#signature_capture").val('');
        //$("#help").slideUp(300);
        ev.preventDefault();
    },

    _EditSrr: function (ev) {
        var $current = $(ev.currentTarget);
        var $card = $current.parents('.card')
        var $inputs = $card.find('.editable')
        $card.find("input[type='file']").prop( "disabled", false);
        $card.find("select").prop( "disabled", false);
        $card.find("checkbox").prop( "disabled", false);
        $inputs.prop("readonly", false);
        $inputs.removeClass('gray-border')
        $card.find('.edit-mode').removeClass('d-none')
        $card.find('#edit_srr').addClass('d-none')
        $card.find('#save_srr').removeClass('d-none')
        $card.find('#discard_srr').removeClass('d-none')

    },

    _SaveSrr: function (ev) {
        $('#srr_modify_form').submit()

    },

    _changeState: function (ev) {
        var self = this;
        var $current = $(ev.currentTarget);
        var $form = $current.parents('.card').find('#srr_modify_form')
        var rec_id = $form.find('input[name=rec_id]').val()
        this._rpc({
                model: 'ring.request',
                method: 'request_modification_from_front_end',
                args: [rec_id],
            })
            .then(function(result) {
                self._reloadWindow()
            });
    },

    _reloadWindow: function () {
        location.reload(true);
    },


});




publicWidget.registry.searchWorkOrder = publicWidget.Widget.extend({
    selector: '.o_portal_wrap',
    events: {
        'click #edit_nswo': '_EditNSWO',
        'click #save_nswo': '_SaveNswo',
        'click #discard_nswo': '_reloadWindow',
        'click #edit_request': '_changeStates',
        'click #publish_nswo': '_publishNSWO',
        'click #add_antenna': '_addAntenna',
        'click #remove_antenna': '_remove_antenna',
        'click #reset_antenna': '_reset_antenna',
        'click #add_microwave': '_addMicrowave',
        'click #remove_microwave': '_remove_microwave',
        'click #reset_microwave': '_reset_microwave',
        'click #add_rru': '_add_rru',
        'click #remove_rru': '_remove_rru',
        'click #reset_rru': '_reset_rru',
        'change #governorate': '_select_governorate',
        'click #create_mw_model': '_createMicrowave',
        'click #create_rru_model': '_createRruModel',
        'change #tower_height_input': '_validate_tower_height',
        'change #epa_allowance_1': '_validate_epa_allowance',
        'change #equipment_housing': '_change_equipment_housing',
        'change #expected_grid_connection': '_change_expected_grid_connection',
        'change #off_grid_power_supply': '_change_off_grid_power_supply',
        'change #cabinet_space': '_change_cabinet_space',
        'change #extra_space_request': '_change_extra_space',
        'change #extra_space_meter': '_change_extra_space_meter'

    },

    start: function () {
        var page_name = $("form:first").find('input[name=page_name]').val();
        var equipment_housing_type = $("form:first").find('select[name=equipment_housing]').val()
        var extra_space_request_val = $("form:first").find('select[name=extra_space_request]').val()
        var expected_grid_connection_val = $("form:first").find('select[name=expected_grid_connection]').val()
        var is_off_grid_power_supply = $("form:first").find('select[name=off_grid_power_supply]').val()
        console.log(page_name, equipment_housing_type)
        $('select').select2({
            placeholder: "Search..",
            allowClear: true
        });
        $('#tower_height_input').attr({
            'min': $('#min_tw_height').val(),
            'max': $('#max_tw_height').val(),
        });
        $('#epa_allowance_1').attr({
            'min': $('#min_epa_allowance').val(),
            'max': $('#max_epa_allowance').val(),
        });
        $('.otc-yes').hide();
        $('.off-grid-power-supply').hide();
        $('.load_category').hide();
        $('.cabinet_space_div').hide();
        $('.tower-height-sel').hide();
        $('.cabinet_container').hide();
        $('.shelter-container').hide();
        $('.extra-shelter-space').hide();
//        $('.extra-space').hide();
        $('.extra-space-above').hide();
        $('.select2-selection').css('border-radius','0px')
        $('.select2-container').children().css('border-radius','0px')
        if (page_name == 'existing_site_work_order'){
            if (equipment_housing_type == 'shelter'){
                $('.shelter-container').show();
            }
            else{
                $('.cabinet_space_div').show();
            }
            if (extra_space_request_val == 'yes'){
                $('.extra-space-above').show();
            }
            if (expected_grid_connection_val == 'no'){
                $('.off-grid-power-supply').show();
            }
            if (is_off_grid_power_supply){
                $('.otc-yes').show();
                $('.load_category').show();
            }
        }
       return this._super.apply(this, arguments);
    },

    _change_off_grid_power_supply: function(ev){
        var $grid_power_supply = $('#off_grid_power_supply').is(':checked')
        if ($grid_power_supply){
            $('.otc-yes').show();
            $('.load_category').show();
        }else{
            $('.otc-yes').hide();
            $('.load_category').hide();
        }
    },

    _change_cabinet_space: function(ev){
        var cabinet_space_val =  $('#cabinet_space').val();
        if (cabinet_space_val == 'others'){
            $('.cabinet_container').show();
        }
        else{
            $('.cabinet_container').hide();
        }
    },

    _change_extra_space: function(ev){
        var extra_space_val =  $('#extra_space_request').val();
        if (extra_space_val == 'yes'){
            $('.extra-space-above').show();
        }
        else{
            $('.extra-space-above').hide();
        }
    },

    _change_extra_space_meter: function(ev){
        var extra_space_rent =  $('#extra_space_meter').val();
        if (parseFloat(extra_space_rent) > parseInt(extra_space_rent)){
            extra_space_rent = parseInt(extra_space_rent) + 1
        }
        else{
            extra_space_rent = parseInt(extra_space_rent)
        }
        if (extra_space_rent > 0){
            var rent = extra_space_rent * 3
            $("#extra-space-rent").val(rent)
        }
        else{
            $("#extra-space-rent").val(0)
        }

    },

    _change_expected_grid_connection: function(ev){
        var $grid_connection = $('#expected_grid_connection').val()
        if ($grid_connection == 'yes'){
            $('.off-grid-power-supply').hide();
            $('.otc-yes').hide();
            $('.load_category').hide();
            $('#off_grid_power_supply').prop('checked',false)
        }else if($grid_connection == 'no'){
            $('.off-grid-power-supply').show();
            $('.load_category').hide();
        }else{
            $('.off-grid-power-supply').hide();
            $('.otc-yes').hide();
            $('.load_category').hide();
            $('#off_grid_power_supply').prop('checked',false)
        }
    },

    _change_equipment_housing: function(ev){
        var $id = $('#equipment_housing').val()
        if ($id){
            if ($id == 'shelter'){
                $('.shelter-container').show();
//                $('.extra-space').show();
                $('.cabinet_space_div').hide();
                $('.cabinet_container').hide();
            }else if ($id == 'cabinet') {
                $('.shelter-container').hide();
//                $('.extra-space').hide();
                $('.cabinet_space_div').show();
                $('.cabinet_container').hide();
                $('.extra-shelter-space').hide();
            }
        }
        else{
            $('.shelter-container').hide();
//            $('.extra-space').hide();
            $('.cabinet_space_div').hide();
            $('.cabinet_container').hide();
            $('.extra-shelter-space').hide();
        }
    },

    _getNextHighestIndex: function (arr, value) {
        var ans = arr.sort( (a, b) => {
          return b[0] - a[0]
        })
        var filtered = ans.filter(function(val) {
            if (val[0] >= value) {
                return val;
            }
        });
        var content = filtered.length ? filtered.at(-1)[1] : ''
        return content
    },

    _validate_tower_height: function(ev){
        var $min_height = parseFloat($('#min_tw_height').val()) || 0
        var $max_height = parseFloat($('#max_tw_height').val()) || 0
        var $tw_height = parseFloat($('#tower_height_input').val()) || 0
        var $tower_height_list = []
        var $tw_list = []
        if ($tw_height >= $min_height && $tw_height <= $max_height){
            $("#tower_height option").each(function()
            {
                var $tw = $(this).text()
                var $vl = $(this).val()
                if ($tw){
                   $tower_height_list.push([$tw, $vl])
                }
            });
            var next_highest_val = this._getNextHighestIndex($tower_height_list, $('#tower_height_input').val())
            $("#tower_height").val(next_highest_val).trigger('change')

        }
        else{
            $('#tower_height_input').val('');
            alert('Please enter a value between '+$min_height+'and '+$max_height+'')
        }
    },
    _validate_epa_allowance: function(ev){
//        var $min_epa_allowance = parseFloat($('#min_epa_allowance').val()) || 0
//        var $max_epa_allowance = parseFloat($('#max_epa_allowance').val()) || 0
//        var $epa_allowance = parseFloat($('#epa_allowance_1').val()) || 0
//        var $epa_allowance_list = []
//        if ($epa_allowance >= $min_epa_allowance && $epa_allowance <= $max_epa_allowance){
//            $("#epa_allowance option").each(function()
//            {
//                var $epa = $(this).text()
//                var $vl = $(this).val()
//                if ($epa){
//                   $epa_allowance_list.push([$epa, $vl])
//                }
//            });
//            var next_highest_val = this._getNextHighestIndex($epa_allowance_list, $('#epa_allowance_1').val())
//            $("#epa_allowance").val(next_highest_val).trigger('change')
//        }
//        else{
//            $('#epa_allowance_1').val('');
//            alert('Please enter a value between '+$min_epa_allowance+'and '+$max_epa_allowance+'')
//        }
    },
     get_antenna_count: function () {
        var antenna_count = $('#work-order').find('.extra-antenna')
        console.log('annnn', antenna_count)
        return antenna_count.length + 2
    },

    _select_governorate: async function(ev){
        var $governorate = $('#governorate').val()
        var self = this
        var $wilayat_val = []
        $('#wilayat').find('option').remove().end();
        $('#wilayat').append('<option value=""> </option>');
        await this._rpc({
            model: 'work.order',
            method: 'get_wilayat',
            args: [$governorate],
        }).then(function(result) {
            $wilayat_val = result
        });
        for (var i = 0; i < $wilayat_val.length; i++)
        {
             $('#wilayat').append('<option value="'+$wilayat_val[i].id+'">'+$wilayat_val[i].name+'</option>');
        }
        $('#wilayat').val('').trigger('change');
    },

    getAntennaCount: function() {
        var antennaCountElement = document.getElementById('antenna_count');
        var antennaCount = parseInt(antennaCountElement.value);
        return antennaCount;
    },

    getMicroWaveCount: function() {
        var microwaveCountElement = document.getElementById('micro_lines_count');
        var microwaveCount = parseInt(microwaveCountElement.value);
        return microwaveCount;
    },

    getRruCount: function() {
        var rruCountElement = document.getElementById('rru_lines_count');
        var rruCount = parseInt(rruCountElement.value);
        return rruCount;
    },

    _addAntenna: function (ev) {
        $('select').select2("destroy");
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#antenna_base_update');
        console.log($base_el,"BASE ELLL")
        var antennaCount = this.getAntennaCount();
        antennaCount += 1;
        $base_el.find(".select2").each(function(index) {
            $(this).select2('destroy');
        });
        var $new_el = $base_el.clone();
        $new_el.removeClass('d-none');
//        $new_el.attr('class').removeClass(' d-none');
        $new_el.find("select").each(function(index) {
            $(this).select2();
        });
        $('select').select2({
            placeholder: "Search..",
            allowClear: true
        });
        var class_name = $base_el.attr('class').replace('d-none', '') + ' extra-antenna';
        var el_count = this.get_antenna_count();
        console.log(el_count, "EL");
        var new_id = 'antenna_' + antennaCount;
        $new_el.attr({
            id: '',
            class: class_name,
        });
        $new_el.find('#contents_dummy').attr({
            'id': 'contents_' + antennaCount,
        });
        $new_el.find('#antenna_dummy').attr({
            'id': new_id,
            'name': new_id,
        });  // Remove the t-att-value attribute
        $new_el.find('#sector_height_dummy').attr({
            id: 'sector_height_' + antennaCount,
            name: 'sector_height_' + antennaCount,
        }).val('');
        $new_el.find('#sector_azimuth_dummy').attr({
            id: 'sector_azimuth_' + antennaCount,
            name: 'sector_azimuth_' + antennaCount,
        }).val('');
        $new_el.insertBefore('#antenna_count_div');
        $('#no_of_antennas').val(antennaCount);
        $('#antenna_count').val(antennaCount);
    },

    _remove_antenna: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_antenna_el = $current.parents('#work_order_new').find('.extra-antenna')
        var $ext_line_count = $current.parents('#work_order_new').find('#ext_line_count').val()
        console.log($ext_line_count,"ext_line_count")
        var $last_el = $extra_antenna_el.last().remove()
        var el_count = this.getAntennaCount() - 1
        $('#antenna_count').val(el_count);
        $('#no_of_antennas').val(el_count);

    },


    _reset_antenna: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_antenna_el = $current.parents('#work_order_new').find('.extra-antenna')
        $extra_antenna_el.remove()
        var el_count = 0
        $('#antenna_count').val(el_count);
    },

     get_microwave_count: function () {
        var microwave_count = $('#work-order').find('.extra-microwave')
        return microwave_count.length + 2
    },

    _createMicrowave: async function(ev){
        var $microwave_model = $('#microwave_model').val()
        var $microwave_height = $('#microwave_height').val()
        var $microwave_diameter = $('#microwave_diameter').val()
//        var $microwave_azimuth = $('#microwave_azimuth').val()
        var $microwave_shape = $('#microwave_shape').val()
        var $microwave_vals = []
        var value = $("#microwave_1").val()
        var prev_mw_id = $('.microwave-button-panel').prev().find('select').attr('id')
        $("#" +prev_mw_id).find('option').remove().end();
        $("#microwave_1").find('option').remove().end();
        $("#" +prev_mw_id).append('<option value=""> </option>');
        $("#microwave_1").append('<option value=""> </option>');
        await this._rpc({
                model: 'work.order',
                method: 'create_microwave_model',
                args: [$microwave_model, $microwave_height, $microwave_diameter, $microwave_shape],
            })
            .then(function(result) {
                $microwave_vals = result
            });
        for (var i = 0; i < $microwave_vals.length; i++)
        {
             $("#" +prev_mw_id).append('<option value="'+$microwave_vals[i].id+'">'+$microwave_vals[i].display_name+'</option>');
             $("#microwave_1").append('<option value="'+$microwave_vals[i].id+'">'+$microwave_vals[i].display_name+'</option>');
        }
        $("#" +prev_mw_id).val('').trigger('change');
        $("#microwave_1").val(value).change()
        $("#addMicrowave").modal('hide');
    },

    _addMicrowave: function (ev) {
        $('select').select2("destroy")
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#microwave_base_update')
        var microWaveCount = this.getMicroWaveCount();
        microWaveCount += 1;
        $base_el.find(".select2").each(function(index)
        {
            $(this).select2('destroy');
        });
        var $new_el = $base_el.clone()
        $new_el.removeClass('d-none');
        $new_el.find("select").each(function(index)
        {
            $(this).select2();
        });
        $('select').select2()
        var class_name = $base_el.attr('class').replace('d-none', '') + ' extra-microwave';
        var el_count = this.get_microwave_count()
        var new_id = 'microwave_' + microWaveCount
        $new_el.attr({
            id: '',
            class: class_name,
        })
        $new_el.find('#contents_mw_dummy').attr({
            'id': 'contents_mw_' + microWaveCount,
        });
        $new_el.find('#microwave_1_dummy').attr({
        'id': new_id,
        'name': new_id,
        })
        $new_el.find('#microwave_height_1_dummy').attr({
                    id: 'microwave_height_' + microWaveCount,
                    name: 'microwave_height_' + microWaveCount,
                }).val('');
        $new_el.find('#microwave_azimuth_1_dummy').attr({
                    id: 'microwave_azimuth_' + microWaveCount,
                    name: 'microwave_azimuth_' + microWaveCount,
                }).val('');
        $new_el.find('select').val('')
        $new_el.find('label').attr('for', new_id)
        $new_el.insertBefore('#microwave_count_div');
        $('#no_of_microwave').val(microWaveCount);
        $('#micro_lines_count').val(microWaveCount);
    },

    _remove_microwave: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_microwave_el = $current.parents('#work_order_new').find('.extra-microwave')
        var $last_el = $extra_microwave_el.last().remove()
        var el_count = this.getMicroWaveCount() - 1
        $('#micro_lines_count').val(el_count);
        $('#no_of_microwave').val(el_count);
    },


    _reset_microwave: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_microwave_el = $current.parents('#work_order_new').find('.extra-microwave')
        $extra_microwave_el.remove()
        var el_count = 0
        $('#micro_lines_count').val(el_count);
    },

    _createRruModel: async function(ev){
        var $rru_model = $('#rru_model').val()
        var $rru_height = $('#rru_height').val()
        var $rru_width = $('#rru_width').val()
        var $rru_depth = $('#rru_depth').val()
        var $rru_vals = []
        var value = $("#rru_1").val()
        var prev_rru_id = $('.rru-button-panel').prev().find('select').attr('id')
        $("#" +prev_rru_id).find('option').remove().end();
        $('#rru_1').find('option').remove().end();
        $("#" +prev_rru_id).append('<option value=""> </option>');
        $('#rru_1').append('<option value=""> </option>');
        await this._rpc({
                model: 'work.order',
                method: 'create_rru_model',
                args: [$rru_model, $rru_height, $rru_width, $rru_depth],
            })
            .then(function(result) {
                $rru_vals = result
            });
        for (var i = 0; i < $rru_vals.length; i++)
        {
             $('#rru_1').append('<option value="'+$rru_vals[i].id+'">'+$rru_vals[i].complete_name+'</option>');
             $("#" +prev_rru_id).append('<option value="'+$rru_vals[i].id+'">'+$rru_vals[i].complete_name+'</option>');
        }
        $("#" +prev_rru_id).val('').trigger('change');
        $("#rru_1").val(value).change()
        $("#addRRU").modal('hide');
    },

     get_rru_count: function () {
        var rru_count = $('#work-order').find('.extra-rru')
        return rru_count.length + 2
    },
     _add_rru: function (ev) {
        $('select').select2("destroy")
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#rru_base_update')
        var rruCount = this.getRruCount();
        rruCount += 1;
        $base_el.find(".select2").each(function(index)
        {
            $(this).select2('destroy');
        });
        var $new_el = $base_el.clone()
        $new_el.removeClass('d-none');
        $new_el.find("select").each(function(index)
        {
            $(this).select2();
        });
        $('select').select2()
        var class_name = $base_el.attr('class').replace('d-none', '') + ' extra-rru';
        var el_count = this.get_rru_count()
        var new_id = 'rru_' + rruCount
        $new_el.attr({
            id: '',
            class: class_name,
        })
        $new_el.find('#contents_rru_dummy').attr({
            'id': 'contents_rru_' + rruCount,
        });
        $new_el.find('#rru_1_dummy').attr({
        'id': new_id,
        'name': new_id,
        })
        var new_rp_id = 'site_type_' + rruCount
        $new_el.find('#site_type_dummy').attr({
        'id': new_rp_id,
        'name': new_rp_id,
        })

        $new_el.find('select').val('')
        $new_el.find('label').attr('for', new_id)
        $new_el.insertBefore('#rru_count_div');
        $('#no_of_rru').val(rruCount);
        $('#rru_lines_count').val(rruCount);
    },

    _remove_rru: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_rru_el = $current.parents('#work_order_new').find('.extra-rru')
        var $last_el = $extra_rru_el.last().remove()
        var el_count = this.getRruCount() - 1
        $('#rru_lines_count').val(el_count);
        $('#no_of_rru').val(el_count);
    },


    _reset_rru: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_rru_el = $current.parents('#work_order_new').find('.extra-rru')
        $extra_rru_el.remove()
        var el_count = 0
        $('#rru_lines_count').val(el_count);
    },

    _EditNSWO: function (ev) {
        var $current = $(ev.currentTarget);
        var $card = $current.parents('.card')
        var $inputs = $card.find('.editable')

        $card.find("select").prop( "disabled", false);
        $card.find("input[type='checkbox']").prop( "disabled", false);
        $inputs.prop("readonly", false);
        $inputs.removeClass('gray-border')
        $card.find('.edit-mode').removeClass('d-none')
        $card.find('#edit_nswo').addClass('d-none')
        $card.find('#save_nswo').removeClass('d-none')
        $card.find('#discard_nswo').removeClass('d-none')
    },

    _SaveNswo: function (ev) {
        $('#nswo_modify_form').submit()

    },

    _changeStates: function (ev) {
        var self = this;
        var $current = $(ev.currentTarget);
        var $form = $current.parents('.card').find('#nswo_modify_form')
        var rec_id = $form.find('input[name=rec_id]').val()
        this._rpc({
                model: 'work.order',
                method: 'request_modifications_from_front_end',
                args: [rec_id],
            })
            .then(function(result) {
                self._reloadWindow()
            });
    },
    _publishNSWO: function (ev) {
        var self = this;
        var $current = $(ev.currentTarget);
        var $form = $current.parents('.card').find('#nswo_modify_form')
        var rec_id = $form.find('input[name=rec_id]').val()
        this._rpc({
                model: 'work.order',
                method: 'request_action_publish_frontend',
                args: [rec_id],
            })
            .then(function(result) {
                self._reloadWindow()
            });
    },

    _reloadWindow: function (ev) {
        location.reload(true);
    },



});

var a, b, c,
    submitContent,
    captcha,
    locked,
    validSubmit = false,
    timeoutHandle;


  // Generating a simple sum (a + b) to make with a result (c)
function generateCaptcha(){
  a = Math.ceil(Math.random() * 10);
  b = Math.ceil(Math.random() * 10);
  c = a + b;
  submitContent = '<span>' + a + '</span> + <span>' + b + '</span>' +
    ' = <input class="submit__input" type="text" maxlength="2" size="2" required />';
  $('.submit__generated').html(submitContent);

  init();
}


// Check the value 'c' and the input value.
function checkCaptcha(){
  if(captcha === c){
    // Pop the green valid icon
    $('.submit__generated')
      .removeClass('unvalid')
      .addClass('valid');
    $('.submit').removeClass('overlay');
    $('.submit__overlay').fadeOut('fast');

    $('.submit__error').addClass('d-none');
    $('.submit__error--empty').addClass('d-none');
    validSubmit = true;
  }
  else {
    if(captcha === ''){
      $('.submit__error').addClass('d-none');
      $('.submit__error--empty').removeClass('d-none');
    }
    else {
      $('.submit__error').removeClass('d-none');
      $('.submit__error--empty').addClass('d-none');
    }
    // Pop the red unvalid icon
    $('.submit__generated')
      .removeClass('valid')
      .addClass('unvalid');
    $('.submit').addClass('overlay');
    $('.submit__overlay').fadeIn('fast');
    validSubmit = false;
  }
  return validSubmit;
}

function unlock(){ locked = false; }


// Refresh button click - Reset the captcha
$('.submit__control i.fa-refresh').on('click', function(){
  if (!locked) {
    locked = true;
    setTimeout(unlock, 500);
    generateCaptcha();
    setTimeout(checkCaptcha, 0);
  }
});


// init the action handlers - mostly useful when 'c' is refreshed
function init(){
  $('.submit__input').on('click', function(e){
    e.preventDefault();
    if($('.submit__generated').hasClass('valid')){
      // var formValues = [];
      captcha = $('.submit__input').val();
      if(captcha !== ''){
        captcha = Number(captcha);
      }
      checkCaptcha();
      if(validSubmit === true){
      window.alert("validSubmit")
        validSubmit = false;
        // Temporary direct 'success' simulation
        submitted();
      }
    }
    else {
      return false;
    }
  });


  // Captcha input result handler
  $('.submit__input').on('propertychange change keyup input paste', function(){
    // Prevent the execution on the first number of the string if it's a 'multiple number string'
    // (i.e: execution on the '1' of '12')
    window.clearTimeout(timeoutHandle);
    timeoutHandle = window.setTimeout(function(){
      captcha = $('.submit__input').val();
      if(captcha !== ''){
        captcha = Number(captcha);
      }
      checkCaptcha();
    },150);
  });
}

generateCaptcha();


$('#epa_allowance, #tower_height, #with_cable, #structure_type_id').change(function(ev){
  var $parent = $(ev.currentTarget).parents('.contact-form')
  var $epa_allowance_el = $parent.find('#epa_allowance')
  var $tower_height_el = $parent.find('#tower_height')
  var $rent_el = $parent.find('#rent')
  var $structure_type_id_el = $parent.find('#structure_type_id')
  var $with_cable_el = $parent.find('#with_cable')
  var epa_allowance = $epa_allowance_el.val()
  var tower_height = $tower_height_el.val()
  var structure_type_id = $structure_type_id_el.val()
  var with_cable = $with_cable_el.prop("checked")
  rpc.query({
            model: 'rent.calculation',
            method: 'get_monthly_rent',
            args: [epa_allowance,tower_height,with_cable,structure_type_id],
        }).then(function(result) {
            $rent_el.val(0)
            if(result) {
                $rent_el.val(result)
            }
        });
});

$('#shelter_space').change(function(ev){
  var $parent = $(ev.currentTarget).parents('.contact-form')
  var $shelter_space_el = $parent.find('#shelter_space')
  var $shelter_rent_el = $parent.find('#shelter_rent')
  var shelter_space = $shelter_space_el.val()
  if (shelter_space == 'others'){
    $('.extra-shelter-space').show();
    $shelter_rent_el.val(0)
    $('#extra_space_request').val('').trigger('change')
  }
  else{
    $('.extra-shelter-space').hide();
    rpc.query({
        model: 'shelter.rent',
        method: 'get_shelter_rent',
        args: [shelter_space],
    }).then(function(result) {
        $shelter_rent_el.val(0)
        if(result) {
            $shelter_rent_el.val(result[0])
        }
        if (result[1]){
            $('#extra_space_request').val('yes').trigger('change')
        }
        else{
        $('#extra_space_request').val('').trigger('change')
        }
    });
    }


});

$('#client_site_id').change(function(ev){
  var $parent = $(ev.currentTarget).parents('.contact-form')
  var $client_site_id_el = $parent.find('#client_site_id')
  var $tenants_el = $parent.find('#tenants')
  var client_site_id = $client_site_id_el.val()
  rpc.query({
            model: 'work.order',
            method: 'get_existing_tenants',
            args: [client_site_id],
        }).then(function(result) {
            $tenants_el.val(0)
            if(result) {
                $tenants_el.val(result)
            }
        });

});

//$('.planned_technology').on('click', function(){
//
//    var is_tech_checked = $('.technology').find("input[name='Other']").checked
//    if (is_tech_checked) {
//        $('.radio_technology_note').show()
//    }
//        else {
//        $('.radio_technology_note').hide()
//    }
//});

$('.check_toggle').on('click', function(){

if (document.getElementById("upload").checked == true) {
    document.getElementById("up_signature").style.display = "";
    document.getElementById("signature_container").style.display = "none";
    }
else {

    document.getElementById("up_signature").style.display = "none";
    document.getElementById("signature_container").style.display = "";
    }

});

$('#is_ssr').on('click', function(){
    if (document.getElementById("is_ssr").checked == true) {
        document.getElementById("ssr_number").style.display = "";
    }
    else
    {
        document.getElementById("ssr_number").style.display = "none";
        document.getElementById("ssr_number").val = '';
    }

});

$('#ignore_pan_antenna').on('click', function(){
    if (document.getElementById("ignore_pan_antenna").checked == false) {
        document.getElementById("antenna_base").style.display = "";
        if (document.getElementById("antenna-add-rem")){
            document.getElementById("antenna-add-rem").style.display = "";
        }
//        document.getElementById("antenna-add-rem").style.display = "";
        if (document.getElementById("antenna_count_div")){
            document.getElementById("antenna_count_div").style.display = "";
        }
//        document.getElementById("antenna_count_div").style.display = "";
        var cons = document.getElementsByClassName("extra-antenna");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "";
            }
        }
    }
    else
    {
        document.getElementById("antenna_base").style.display = "none";
        if (document.getElementById("antenna-add-rem")){
            document.getElementById("antenna-add-rem").style.display = "none";
        }
//        document.getElementById("antenna-add-rem").style.display = "none";
        if (document.getElementById("antenna_count_div")){
            document.getElementById("antenna_count_div").style.display = "none";
        }
//        document.getElementById("antenna_count_div").style.display = "none";
        var cons = document.getElementsByClassName("extra-antenna");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "none";
            }
        }
    }

});


$('#ignore_microwave').on('click', function(){
    if (document.getElementById("ignore_microwave").checked == false) {
        document.getElementById("microwave_base").style.display = "";
        if (document.getElementById("microwave-add-rem")){
            document.getElementById("microwave-add-rem").style.display = "";
        }
//        document.getElementById("microwave-add-rem").style.display = "";
        if (document.getElementById("create-microwave")){
            document.getElementById("create-microwave").style.display = "";
        }
//        document.getElementById("create-microwave").style.display = "";
        if (document.getElementById("microwave_count_div")){
            document.getElementById("microwave_count_div").style.display = "";
        }
//        document.getElementById("microwave_count_div").style.display = "";
        var cons = document.getElementsByClassName("extra-microwave");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "";
            }
        }
    }
    else
    {
        document.getElementById("microwave_base").style.display = "none";
        if (document.getElementById("microwave-add-rem")){
            document.getElementById("microwave-add-rem").style.display = "none";
        }
//        document.getElementById("microwave-add-rem").style.display = "none";
        if (document.getElementById("create-microwave")){
            document.getElementById("create-microwave").style.setProperty('display', 'none', 'important');
        }
//        document.getElementById("create-microwave").style.setProperty('display', 'none', 'important');
        if (document.getElementById("microwave_count_div")){
            document.getElementById("microwave_count_div").style.display = "none";
        }
//        document.getElementById("microwave_count_div").style.display = "none";
        var cons = document.getElementsByClassName("extra-microwave");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "none";
            }
        }
    }

});

$('#ignore_rru').on('click', function(){
    if (document.getElementById("ignore_rru").checked == false) {
        document.getElementById("rru_base").style.display = "";
        if (document.getElementById("rru-add-rem")){
            document.getElementById("rru-add-rem").style.display = "";
        }
//        document.getElementById("rru-add-rem").style.display = "";
        if (document.getElementById("create-rru")){
            document.getElementById("create-rru").style.display = "";
        }
//        document.getElementById("create-rru").style.display = "";
        if (document.getElementById("rru_count_div")){
            document.getElementById("rru_count_div").style.display = "";
        }
//        document.getElementById("rru_count_div").style.display = "";
        var cons = document.getElementsByClassName("extra-rru");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "";
            }
        }
    }
    else
    {
        document.getElementById("rru_base").style.display = "none";
        if (document.getElementById("rru-add-rem")){
            document.getElementById("rru-add-rem").style.display = "none";
        }
//        document.getElementById("rru-add-rem").style.display = "none";
        if (document.getElementById("create-rru")){
            document.getElementById("create-rru").style.setProperty('display', 'none', 'important');
        }
//        document.getElementById("create-rru").style.setProperty('display', 'none', 'important');
        if (document.getElementById("rru_count_div")){
            document.getElementById("rru_count_div").style.display = "none";
        }
//        document.getElementById("rru_count_div").style.display = "none";
        var cons = document.getElementsByClassName("extra-rru");
        if (cons.length > 0){
            for (var i = 0; i < cons.length; i++){
                cons[i].style.display = "none";
            }
        }
    }

});
//$(document).ready(function() {
//  var today = new Date();
//  var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
//  var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
//  var dateTime = date + ' ' + time;
//  $("#date_local").val(dateTime);
//});



});