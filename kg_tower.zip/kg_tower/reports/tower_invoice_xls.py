import base64
import datetime
import io

from odoo import models


class TowerInvoiceXlsx(models.AbstractModel):
    _name = 'report.kg_tower.tower_invoice_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, invoice):
        custom_value = {}
        for rec in invoice:
            report_name = rec.name
            invoice = []
            total = 0
            total_starting = 0
            total_line_due = 0
            # list greenfield_a1_lines values
            lien_section = False
            for line in rec.a1_lines:
                item = {}
                if line.display_type == 'line_section':
                    continue
                item['site_id'] = line.site_id.name
                item['name'] = line.name
                item['actual_max_height'] = line.actual_max_height
                item['invoiced_height'] = line.invoiced_height
                item['epa_allowance'] = line.epa_allowance
                item['ground_space_allow'] = line.ground_space_allow
                item['base_rent'] = line.base_rent
                item['tenancy_discount'] = line.tenancy_discount
                item['actual_epa'] = line.actual_epa
                item['epa_add_fee'] = line.epa_add_fee
                item['vertical_space_used'] = line.vertical_space_used
                item['vertical_space_add_fee'] = line.vertical_space_add_fee
                item['ground_space_used'] = line.ground_space_used
                item['ground_space_add_fee'] = line.ground_space_add_fee
                item['total_rent'] = line.total_rent
                item['rfi_notice'] = line.rfi_notice
                item['tenant_commen_before_30days'] = line.tenant_commen_before_30days
                item['site_commen_date'] = line.site_commen_date
                item['last_date'] = line.last_date
                item['quarter'] = line.quarter
                item['end_of_quarter_date'] = line.end_of_quarter_date
                item['nb_full_months_due'] = line.nb_full_months_due
                item['nb_days_due'] = line.nb_days_due
                item['nb_days_in_month'] = line.nb_days_in_month
                item['amount_due'] = line.amount_due
                item['amount_due_starting'] = float(line.base_rent or 0) * 3
                item['total_line_due'] = float(item['amount_due']) + float(item['amount_due_starting'])
                total += line.amount_due
                total_starting += item['amount_due_starting']
                total_line_due += item['total_line_due']
                invoice.append(item)
            custom_value['item'] = invoice
            custom_value['partner_id'] = rec.partner_id.name
            custom_value['invoice_date'] = rec.invoice_date
            custom_value['total_amount_due'] = rec.total_amount_due
            custom_value['approval1_user_id'] = rec.approval1_user_id.name
            custom_value['approval2_user_id'] = rec.approval2_user_id.name
            custom_value['approval3_user_id'] = rec.approval3_user_id.name
            custom_value['user1_designation'] = rec.user1_designation
            custom_value['user2_designation'] = rec.user2_designation
            custom_value['user3_designation'] = rec.user3_designation
            custom_value['aproval_date1'] = rec.aproval_date1
            custom_value['aproval_date2'] = rec.aproval_date2
            custom_value['aproval_date3'] = rec.aproval_date3
            custom_value['today'] = datetime.date.today().strftime('%m-%d-%Y')
            logo_image = io.BytesIO(base64.b64decode(rec.company_id.logo))
            invoice1 = []
            total1 = 0
            # list greenfield_a2_lines
            for line1 in rec.greenfield_a2_lines:
                item1 = {}
                item1['site_id'] = line1.site_id.name
                item1['period_start_date'] = line1.period_start_date
                item1['last_date'] = line1.last_date
                item1['period_end_date'] = line1.period_end_date
                item1['name'] = line1.name
                item1['monthly_rent_previous'] = line1.monthly_rent_previous
                item1['monthly_rent_current'] = line1.monthly_rent_current
                item1['nb_od_days'] = line1.nb_od_days
                item1['nb_days_due'] = line1.nb_days_due
                item1['nb_days_in_month'] = line1.nb_days_in_month
                item1['amount_due'] = line1.amount_due
                total1 += line1.amount_due
                invoice1.append(item1)
            custom_value['item1'] = invoice1
            invoice2 = []
            total2 = 0
            # List greenfield_a3_lines
            for line2 in rec.greenfield_a3_lines:
                item2 = {}
                item2['site_id'] = line2.site_id.name
                item2['actual_max_height'] = line2.actual_max_height
                item2['invoiced_height'] = line2.invoiced_height
                item2['epa_allowance'] = line2.epa_allowance
                item2['ground_space_allow'] = line2.ground_space_allow
                item2['base_rent'] = line2.base_rent
                item2['tenancy_discount'] = line2.tenancy_discount
                item2['actual_epa'] = line2.actual_epa
                item2['epa_add_fee'] = line2.epa_add_fee
                item2['vertical_space_used'] = line2.vertical_space_used
                item2['vertical_space_add_fee'] = line2.vertical_space_add_fee
                item2['ground_space_used'] = line2.ground_space_used
                item2['ground_space_add_fee'] = line2.ground_space_add_fee
                item2['total_rent'] = line2.total_rent
                item2['amount_due'] = line2.amount_due
                total2 += line2.amount_due
                invoice2.append(item2)
            custom_value['item2'] = invoice2
            invoice3 = []
            total3 = 0
            # List b_lines
            for line3 in rec.b_lines:
                item3 = {}
                item3['site_id'] = line3.site_id.name
                item3['total_rent'] = line3.total_rent
                item3['period_start_date'] = line3.period_start_date
                item3['period_end_date'] = line3.period_end_date
                item3['nb_full_months_due'] = line3.nb_full_months_due
                item3['amount_due'] = line3.amount_due
                total3 += line3.amount_due
                invoice3.append(item3)
            custom_value['item3'] = invoice3
            invoice4 = []
            total4 = 0
            # List c_lines
            for line4 in rec.c_lines:
                item4 = {}
                item4['site_id'] = line4.site_id.name
                item4['srr_id'] = line4.srr_id.id
                item4['name'] = line4.name
                item4['total_rent'] = line4.total_rent
                item4['amount_due'] = line4.amount_due
                total4 += line4.amount_due
                invoice4.append(item4)
            custom_value['item4'] = invoice4

            format1 = workbook.add_format({'font_size': 13, 'align': 'center', 'bold': True})
            format12 = workbook.add_format({'font_size': 14, 'align': 'left', 'bold': True, 'underline': True})
            format13 = workbook.add_format({'font_size': 13, 'align': 'left', 'bold': True, 'num_format': 'dd-mm-yyyy'})
            formt11 = workbook.add_format(
                {'align': 'center', 'font_size': 10, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, })
            formt111 = workbook.add_format(
                {'align': 'left', 'font_size': 12, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, })
            formt1112 = workbook.add_format({'align': 'left', 'font_size': 12, 'num_format': '#,##0.00'})
            date_formt111 = workbook.add_format({'align': 'left', 'num_format': 'dd-mm-yyyy', 'font_size': 12})
            formt1111 = workbook.add_format(
                {'align': 'center', 'font_size': 12, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, })
            formt112 = workbook.add_format(
                {'align': 'center', 'font_size': 9, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1})
            formt116 = workbook.add_format(
                {'align': 'center', 'font_size': 10, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, 'bold': True,
                 'bg_color': '#E2F0D9', 'num_format': '#,##0.000'})
            formt117 = workbook.add_format(
                {'align': 'center', 'font_size': 9, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, 'bold': True})
            formt113 = workbook.add_format({'align': 'left', 'font_size': 12, 'bg_color': '#BFBFBF', 'bold': True})
            formt114 = workbook.add_format({'align': 'left', 'font_size': 12, 'bg_color': '#D9D9D9', 'bold': True})
            formt118 = workbook.add_format({'align': 'left', 'font_size': 12, 'bold': True})
            formt1181 = workbook.add_format(
                {'align': 'center', 'font_size': 12, 'bold': True, 'num_format': '#,##0.000'})
            formt1183 = workbook.add_format(
                {'align': 'center', 'font_size': 12, 'bold': True, 'num_format': '#,##0.000', 'bg_color': '#E2F0D9', })
            formt1182 = workbook.add_format({'align': 'right', 'font_size': 12, 'bold': True})
            formt115 = workbook.add_format(
                {'align': 'left', 'font_size': 12, 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, 'italic': True})
            formt1151 = workbook.add_format({'align': 'left', 'font_size': 12, 'italic': True})
            formt1152 = workbook.add_format({'align': 'left', 'font_size': 11, 'italic': True, 'bold': True, })
            formt1153 = workbook.add_format({'align': 'right', 'font_size': 9, })
            formt1154 = workbook.add_format({'align': 'left', 'font_size': 9, })
            format_date = workbook.add_format(
                {'font_size': 12, 'align': 'center', 'bold': True, 'bg_color': '#E2F0D9', 'color': 'black',
                 'num_format': 'dd-mm-yyyy', 'bottom': 1, 'right': 1, 'top': 1, 'left': 1, })
            format_date1 = workbook.add_format(
                {'font_size': 9, 'align': 'center', 'color': 'black', 'num_format': 'dd-mm-yyyy', 'bottom': 1,
                 'right': 1, 'top': 1, 'left': 1, })
            format_str_type = workbook.add_format(
                {'font_size': 11, 'align': 'left', 'bold': True, 'bg_color': '#CCFFFF', 'font_name': 'Calibri',
                 'border': 1})
            sheet = workbook.add_worksheet(report_name[:31])
            sheet.set_row(0, 20)
            sheet.set_row(1, 20)
            sheet.set_row(2, 20)
            sheet.set_row(3, 20)
            sheet.set_row(4, 20)
            sheet.merge_range('A1:J1', 'Oman Tower Company - Quarterly Invoice - ' + rec.name, format1)
            sheet.merge_range('A2:B2', 'Client:', formt111)
            sheet.insert_image('Z1', "image.png", {'image_data': logo_image})
            sheet.merge_range('C2:J2', custom_value['partner_id'], formt1111)
            sheet.merge_range('A3:J3', 'All amounts in OMR - Capitalized terms are as defined in the MLA.', formt115)
            sheet.merge_range('K2:L2', 'Invoice date', formt111)
            sheet.merge_range('M2:N2', rec.invoice_date, format_date)
            sheet.merge_range('A4:AB4', 'PART A - Tower Rental', formt113)
            sheet.merge_range('A5:AB5', 'Part A1 - Retroactive Invoicing', formt114)
            n = 6;
            m = 0;
            i = j = k = l = p = 1;
            sheet.write(n, m, rec.a1_lines[0].name, format_str_type)
            sheet.merge_range(n, m + 1, n, m + 27, '  ', format_str_type)
            n += 1
            if rec.a1_lines:
                for item in custom_value['item']:
                    sheet.set_row(5, 40)
                    sheet.set_column(5, 0, 15)
                    sheet.set_column(5, 1, 15)
                    sheet.set_column(5, 2, 15)
                    sheet.set_column(5, 3, 20)
                    sheet.set_column(5, 4, 20)
                    sheet.set_column(5, 5, 20)
                    sheet.set_column(5, 6, 20)
                    sheet.set_column(5, 7, 15)
                    sheet.set_column(5, 8, 20)
                    sheet.set_column(5, 9, 20)
                    sheet.set_column(5, 10, 20)
                    sheet.set_column(5, 11, 20)
                    sheet.set_column(5, 12, 20)
                    sheet.set_column(5, 13, 20)
                    sheet.set_column(5, 14, 10)
                    sheet.set_column(5, 15, 20)
                    sheet.set_column(5, 16, 20)
                    sheet.set_column(5, 17, 20)
                    sheet.set_column(5, 18, 20)
                    sheet.set_column(5, 19, 20)
                    sheet.set_column(5, 20, 10)
                    sheet.set_column(5, 21, 20)
                    sheet.set_column(5, 22, 20)
                    sheet.set_column(5, 23, 20)
                    sheet.set_column(5, 24, 20)
                    sheet.set_column(5, 25, 20)
                    sheet.set_column(5, 26, 20)
                    sheet.set_column(5, 27, 20)
                    sheet.set_column(5, 28, 15)
                    sheet.write(5, 0, '#', formt11)
                    sheet.write(5, 1, 'OTC Site ID', formt11)
                    sheet.write(5, 2, 'Client Site ID', formt11)
                    sheet.write(5, 3, 'Actual Height (m)', formt11)
                    sheet.write(5, 4, 'Applicable pricing Table Height (m)', formt11)
                    sheet.write(5, 5, 'EPA Allowance (m2)', formt11)
                    sheet.write(5, 6, 'Ground Space Allow. (m2)', formt11)
                    sheet.write(5, 7, 'Base monthly Rent', formt11)
                    sheet.write(5, 8, 'Tenancy Discount', formt11)
                    sheet.write(5, 9, 'Actual EPA (m2)', formt11)
                    sheet.write(5, 10, 'EPA Add. Fee', formt11)
                    sheet.write(5, 11, 'Vertical Space used (m)', formt11)
                    sheet.write(5, 12, 'Vertical Space Add. Fee', formt11)
                    sheet.write(5, 13, 'Ground Space used (m2)', formt11)
                    sheet.write(5, 14, 'Ground Space Add. Fee', formt11)
                    sheet.write(5, 15, 'AWL Fee', formt11)
                    sheet.write(5, 16, 'Total monthly Rent', formt117)
                    sheet.write(5, 17, 'Equipment Installation Date', formt11)
                    sheet.write(5, 18, 'Tenant install date before 45 days(Y/N)', formt11)
                    sheet.write(5, 19, 'Site Commencement Date', formt11)
                    sheet.write(5, 20, 'Last day of such month', formt11)
                    sheet.write(5, 21, 'Quarter', formt11)
                    sheet.write(5, 22, 'End of ending quarter date', formt11)
                    sheet.write(5, 23, 'Nb of full months due', formt11)
                    sheet.write(5, 24, 'Nb of days due (partial month)', formt11)
                    sheet.write(5, 25, 'Nb days in that month', formt11)
                    sheet.write(5, 26, 'Amount due for ending quarter', formt116)
                    sheet.write(5, 27, 'Amount due for starting quarter', formt116)
                    sheet.write(5, 28, 'Total amount due under this invoice', formt116)
                    sheet.write(n, m, i, formt112)
                    sheet.write(n, m + 1, item['site_id'], formt112)
                    sheet.write(n, m + 2, item['name'], formt112)
                    sheet.write(n, m + 3, item['actual_max_height'], formt112)
                    sheet.write(n, m + 4, item['invoiced_height'], formt112)
                    sheet.write(n, m + 5, item['epa_allowance'], formt112)
                    sheet.write(n, m + 6, item['ground_space_allow'], formt112)
                    sheet.write(n, m + 7, item['base_rent'], formt112)
                    sheet.write(n, m + 8, item['tenancy_discount'], formt112)
                    sheet.write(n, m + 9, item['actual_epa'], formt112)
                    sheet.write(n, m + 10, str(item['epa_add_fee']) + '%', formt112)
                    sheet.write(n, m + 11, item['vertical_space_used'], formt112)
                    sheet.write(n, m + 12, str(item['vertical_space_add_fee']) + '%', formt112)
                    sheet.write(n, m + 13, item['ground_space_used'], formt112)
                    sheet.write(n, m + 14, item['ground_space_add_fee'], formt112)
                    sheet.write(n, m + 15, ' ', formt112)
                    sheet.write(n, m + 16, item['total_rent'], formt117)
                    sheet.write(n, m + 17, item['rfi_notice'], format_date1)
                    sheet.write(n, m + 18, item['tenant_commen_before_30days'], formt112)
                    sheet.write(n, m + 19, item['site_commen_date'], format_date1)
                    sheet.write(n, m + 20, item['last_date'], format_date1)
                    sheet.write(n, m + 21, item['quarter'], formt112)
                    sheet.write(n, m + 22, item['end_of_quarter_date'], format_date1)
                    sheet.write(n, m + 23, item['nb_full_months_due'], formt112)
                    sheet.write(n, m + 24, item['nb_days_due'], formt112)
                    sheet.write(n, m + 25, item['nb_days_in_month'], formt112)
                    sheet.write(n, m + 26, item['amount_due'], formt116)
                    sheet.write(n, m + 27, item['amount_due_starting'], formt116)
                    sheet.write(n, m + 28, item['total_line_due'], formt116)

                    n += 1
                    i += 1
            sheet.write(n, m + 24, 'Subtotal', formt116)
            sheet.write(n, m + 25, total, formt116)
            sheet.write(n, m + 26, total_starting, formt116)
            sheet.write(n, m + 27, total_line_due, formt116)
            sheet.merge_range(n + 2, m, n + 2, m + 25, 'Part A2 - Adjustments of invoicing for the ending quarter',
                              formt114)
            n = n + 3

            if rec.greenfield_a2_lines:
                sheet.set_row(n, 30)
                sheet.write(n, 0, '#', formt11)
                sheet.write(n, 1, 'OTC Site ID', formt11)
                sheet.write(n, 2, 'Period Start Date', formt11)
                sheet.write(n, 3, 'Last day of such month', formt11)
                sheet.write(n, 4, 'Period End Date', formt11)
                sheet.write(n, 5, 'Description of the correction', formt11)
                sheet.write(n, 6, 'Monthly rent previously applied', formt11)
                sheet.write(n, 7, 'Monthly rent actually applicable', formt11)
                sheet.write(n, 8, 'Nb of full months concerned', formt11)
                sheet.write(n, 9, 'Nb of days due (partial month)', formt11)
                sheet.write(n, 10, 'Nb days in that month', formt11)
                sheet.write(n, 11, 'Invoice Correction', formt116)
                n = n + 1
                for item in custom_value['item1']:
                    sheet.write(n, m, j, formt112)
                    sheet.write(n, m + 1, item['site_id'], formt112)
                    sheet.write(n, m + 2, item['period_start_date'], format_date1)
                    sheet.write(n, m + 3, ' ', format_date1)
                    sheet.write(n, m + 4, item['period_end_date'], format_date1)
                    sheet.write(n, m + 5, item['name'], formt112)
                    sheet.write(n, m + 6, item['monthly_rent_previous'], formt112)
                    sheet.write(n, m + 7, item['monthly_rent_current'], formt112)
                    sheet.write(n, m + 8, item['nb_od_days'], formt112)
                    sheet.write(n, m + 9, item['nb_days_due'], formt112)
                    sheet.write(n, m + 10, item['nb_days_in_month'], formt112)
                    sheet.write(n, m + 11, item['amount_due'], formt117)
                    n += 1
                    j += 1
            sheet.write(n, m + 10, 'Subtotal', formt117)
            sheet.write(n, m + 11, total1, formt116)
            # sheet.merge_range(n + 2, m, n + 2, m + 25, 'Part A3 - Invoicing for the Starting Quarter', formt114)
            # n = n + 3
            #
            # if rec.greenfield_a3_lines:
            #     sheet.set_row(n, 30)
            #     sheet.write(n, 0, '#', formt11)
            #     sheet.write(n, 1, 'OTC Site ID', formt11)
            #     sheet.write(n, 2, 'Actual Height (m)', formt11)
            #     sheet.write(n, 3, 'Applicable pricing Table Height (m)', formt11)
            #     sheet.write(n, 4, 'EPA Allowance (m2)', formt11)
            #     sheet.write(n, 5, 'Ground Space Allow. (m2)', formt11)
            #     sheet.write(n, 6, 'Base monthly Rent', formt117)
            #     sheet.write(n, 7, 'Tenancy Discount', formt11)
            #     sheet.write(n, 8, 'Actual EPA (m2)', formt11)
            #     sheet.write(n, 9, 'EPA Add. Fee', formt117)
            #     sheet.write(n, 10, 'Vertical Space used (m)', formt11)
            #     sheet.write(n, 11, 'Vertical Space Add. Fee', formt117)
            #     sheet.write(n, 12, 'Ground Space used (m2)', formt11)
            #     sheet.write(n, 13, 'Ground Space Add. Fee', formt117)
            #     sheet.write(n, 14, 'AWL Fee', formt117)
            #     sheet.write(n, 15, 'Total monthly Rent', formt117)
            #     sheet.write(n, 16, 'Amount due', formt116)
            #     n = n + 1
            #     for item in custom_value['item2']:
            #         sheet.write(n, m, k, formt112)
            #         sheet.write(n, m + 1, item['site_id'], formt112)
            #         sheet.write(n, m + 2, item['actual_max_height'], formt112)
            #         sheet.write(n, m + 3, item['invoiced_height'], formt112)
            #         sheet.write(n, m + 4, item['epa_allowance'], formt112)
            #         sheet.write(n, m + 5, item['ground_space_allow'], formt112)
            #         sheet.write(n, m + 6, item['base_rent'], formt112)
            #         sheet.write(n, m + 7, item['tenancy_discount'], formt112)
            #         sheet.write(n, m + 8, item['actual_epa'], formt112)
            #         sheet.write(n, m + 9, str(item['epa_add_fee']) + '%', formt112)
            #         sheet.write(n, m + 10, item['vertical_space_used'], formt112)
            #         sheet.write(n, m + 11, str(item['vertical_space_add_fee']) + '%', formt112)
            #         sheet.write(n, m + 12, item['ground_space_used'], formt112)
            #         sheet.write(n, m + 13, item['ground_space_add_fee'], formt112)
            #         sheet.write(n, m + 14, ' ', formt112)
            #         sheet.write(n, m + 15, item['total_rent'], formt117)
            #         sheet.write(n, m + 16, item['amount_due'], formt116)
            #         n += 1
            #         k += 1
            # sheet.write(n, m + 15, 'Subtotal', formt117)
            # sheet.write(n, m + 16, total2, formt116)
            sheet.merge_range(n + 2, m, n + 2, m + 25, 'PART B - Additional Services', formt113)
            sheet.merge_range(n + 3, m, n + 3, m + 25, 'Part B2 - Temporary Power Supply', formt114)
            n = n + 4

            if rec.b_lines:
                sheet.set_row(n, 30)
                sheet.write(n, 0, '#', formt11)
                sheet.write(n, 1, 'OTC Site ID', formt11)
                sheet.write(n, 2, 'Monthly Fee', formt117)
                sheet.write(n, 3, 'Start Date', formt11)
                sheet.write(n, 4, 'End date', formt11)
                sheet.write(n, 5, 'Nb of monthly fees due', formt11)
                sheet.write(n, 6, '', formt117)
                sheet.write(n, 7, '', formt11)
                sheet.write(n, 8, '', formt11)
                sheet.write(n, 9, '', formt117)
                sheet.write(n, 10, 'Amount due', formt116)
                n = n + 1
                for item in custom_value['item3']:
                    sheet.write(n, m, l, formt112)
                    sheet.write(n, m + 1, item['site_id'], formt112)
                    sheet.write(n, m + 2, item['total_rent'], formt112)
                    sheet.write(n, m + 3, item['period_start_date'], format_date1)
                    sheet.write(n, m + 4, item['period_end_date'], format_date1)
                    sheet.write(n, m + 5, item['nb_full_months_due'], formt112)
                    sheet.write(n, m + 6, ' ', formt112)
                    sheet.write(n, m + 7, ' ', formt112)
                    sheet.write(n, m + 8, ' ', formt112)
                    sheet.write(n, m + 9, ' ', formt112)
                    sheet.write(n, m + 10, item['amount_due'], formt116)
                    n += 1
                    l += 1
            sheet.write(n, m + 9, 'Subtotal', formt117)
            sheet.write(n, m + 10, total3, formt116)
            sheet.merge_range(n + 2, m, n + 2, m + 25, 'PART C - One-off costs', formt114)
            n = n + 3

            if rec.c_lines:
                sheet.set_row(n, 30)
                sheet.write(n, 0, '#', formt11)
                sheet.write(n, 1, 'OTC Site ID', formt11)
                sheet.write(n, 2, 'SRR No', formt117)
                sheet.write(n, 3, 'Description', formt11)
                sheet.write(n, 4, 'Fees', formt11)
                sheet.write(n, 5, '', formt11)
                sheet.write(n, 6, '', formt117)
                sheet.write(n, 7, '', formt11)
                sheet.write(n, 8, '', formt11)
                sheet.write(n, 9, '', formt117)
                sheet.write(n, 10, 'Amount due', formt116)
                n = n + 1
                for item in custom_value['item4']:
                    sheet.write(n, m, p, formt112)
                    sheet.write(n, m + 1, item['site_id'], formt112)
                    sheet.write(n, m + 2, item['srr_id'], formt112)
                    sheet.write(n, m + 3, item['name'], formt112)
                    sheet.write(n, m + 4, item['total_rent'], formt112)
                    sheet.write(n, m + 5, ' ', formt112)
                    sheet.write(n, m + 6, ' ', formt112)
                    sheet.write(n, m + 7, ' ', formt112)
                    sheet.write(n, m + 8, ' ', formt112)
                    sheet.write(n, m + 9, ' ', formt112)
                    sheet.write(n, m + 10, item['amount_due'], formt116)
                    n += 1
                    p += 1
            sheet.write(n, m + 9, 'Subtotal', formt117)
            sheet.write(n, m + 10, total4, formt116)
            n = n + 1
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', custom_value['total_amount_due'])
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
            sheet.merge_range(n, m, n, m + 2, 'TOTAL AMOUNT DUE (OMR)', formt1181)
            sheet.merge_range(n, m + 3, n, m + 4, custom_value['total_amount_due'], formt1183)
            sheet.merge_range(n, m + 6, n, m + 10, 'Invoice payment term, as per MLA: 45 days.', formt1151)

            sheet.merge_range(n + 2, m + 1, n + 2, m + 5, 'On behalf of Oman Tower Company:', formt118)

            sheet.merge_range(n + 3, m + 1, n + 3, m + 2, 'Name:', formt1182)
            sheet.merge_range(n + 3, m + 3, n + 3, m + 5, custom_value['approval1_user_id'], formt1112)
            sheet.merge_range(n + 4, m + 1, n + 4, m + 2, 'Title:', formt1182)
            sheet.merge_range(n + 4, m + 3, n + 4, m + 5, custom_value['user1_designation'], formt1112)
            sheet.merge_range(n + 5, m + 1, n + 5, m + 2, 'Date:', formt1182)
            sheet.merge_range(n + 5, m + 3, n + 5, m + 5, custom_value['aproval_date1'], date_formt111)
            sheet.merge_range(n + 6, m + 1, n + 6, m + 2, 'Signature:', formt1182)
            sheet.merge_range(n + 6, m + 3, n + 6, m + 5, ' ', formt1112)
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>1')

            sheet.merge_range(n + 3, m + 6, n + 3, m + 7, 'Name:', formt1182)
            sheet.merge_range(n + 3, m + 8, n + 3, m + 10, custom_value['approval2_user_id'], formt1112)
            sheet.merge_range(n + 4, m + 6, n + 4, m + 7, 'Title:', formt1182)
            sheet.merge_range(n + 4, m + 8, n + 4, m + 10, custom_value['user2_designation'], formt1112)
            sheet.merge_range(n + 5, m + 6, n + 5, m + 7, 'Date:', formt1182)
            sheet.merge_range(n + 5, m + 8, n + 5, m + 10, custom_value['aproval_date2'], date_formt111)
            sheet.merge_range(n + 6, m + 6, n + 6, m + 7, 'Signature:', formt1182)
            sheet.merge_range(n + 6, m + 8, n + 6, m + 10, ' ', formt1112)
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>2')

            sheet.merge_range(n + 3, m + 11, n + 3, m + 12, 'Name:', formt1182)
            sheet.merge_range(n + 3, m + 13, n + 3, m + 15, custom_value['approval3_user_id'], formt1112)
            sheet.merge_range(n + 4, m + 11, n + 4, m + 12, 'Title:', formt1182)
            sheet.merge_range(n + 4, m + 13, n + 4, m + 15, custom_value['user3_designation'], formt1112)
            sheet.merge_range(n + 5, m + 11, n + 5, m + 12, 'Date:', formt1182)
            sheet.merge_range(n + 5, m + 13, n + 5, m + 15, custom_value['aproval_date3'], date_formt111)
            sheet.merge_range(n + 6, m + 11, n + 6, m + 12, 'Signature:', formt1182)
            sheet.merge_range(n + 6, m + 13, n + 6, m + 15, ' ', formt1112)
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>3')

            sheet.merge_range(n + 8, m, n + 8, m + 1, 'Footnotes:', formt1152)
            sheet.write(n + 9, m, '1', formt1153)
            sheet.merge_range(n + 9, m + 1, n + 9, m + 20,
                              'Part A1 covers the Sites whose Site Commencement Date was during the ending quarter. As per MLA, these sites will be invoiced retroactively as part of the next quarterly invoice.',
                              formt1154)
            sheet.write(n + 10, m, '2', formt1153)
            sheet.merge_range(n + 10, m + 1, n + 10, m + 20,
                              'Part A2 covers the changes of Rent or Additional Fees (upwards or downwards) which occurred during the ending quarter and were therefore not covered in the previous quarterly invoice.',
                              formt1154)
            sheet.write(n + 11, m, '3', formt1153)
            sheet.merge_range(n + 11, m + 1, n + 11, m + 20,
                              'Part A3 covers the normal invoicing of the Rent and Additional Fees, quarterly in advance',
                              formt1154)
            sheet.write(n + 12, m, '4', formt1153)
            sheet.merge_range(n + 12, m + 1, n + 12, m + 20,
                              'Part B covers additional services that may be provided at the sites: Shelter Rental, various types of power supply, etc.',
                              formt1154)
            sheet.write(n + 13, m, '5', formt1153)
            sheet.merge_range(n + 13, m + 1, n + 13, m + 20,
                              'Part C covers one-off (non-recurring) invoicing amounts that may occur, for example Search Ring Fees, contributions to grid connection cost in excess of RO 6,000, etc.',
                              formt1154)

            sheet.merge_range(n + 14, m + 1, n + 14, m + 5, 'Bank Account Detalis', format12)
            sheet.merge_range(n + 15, m + 1, n + 15, m + 6, 'AC Name: Oman Tower company LLC', format13)
            sheet.merge_range(n + 16, m + 1, n + 16, m + 6, 'Bank Name: Bank Muscat', format13)
            sheet.merge_range(n + 17, m + 1, n + 17, m + 6, 'AC No: 0423053711100860011', format13)
            sheet.merge_range(n + 18, m + 1, n + 18, m + 6, 'Swift Code: BMUSOMRXXXX', format13)
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>4')
