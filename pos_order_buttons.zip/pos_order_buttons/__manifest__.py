{
    'name': 'POS Orders Button',
    'version': '16.0.1.0.0',
    'sequence': 1,
    'category': 'POS Orders',
    'depends': [
        'base', 'point_of_sale',
    ],
    'data': ['security/ir.model.access.csv',
             'views/book_order.xml', 'views/pos_book_order.xml',
             'data/sequence.xml',

             ],

    'assets': {
        'point_of_sale.assets': [

            'pos_order_buttons/static/src/xml/pos_order_button.xml',
            'pos_order_buttons/static/src/xml/booking_button.xml',
            'pos_order_buttons/static/src/xml/deliver_order.xml',
            'pos_order_buttons/static/src/xml/pickup_order.xml',
            'pos_order_buttons/static/src/xml/recipet.xml',
            'pos_order_buttons/static/src/js/models.js',
            'pos_order_buttons/static/src/js/pos_order_button.js',
            'pos_order_buttons/static/src/js/booking_button.js',
            'pos_order_buttons/static/src/js/popup.js',
            'pos_order_buttons/static/src/js/booked_screen.js',
            'pos_order_buttons/static/src/js/pickup_order.js',
            'pos_order_buttons/static/src/js/deliver_order.js',

        ],
    },
    'installable': True,
    'application': True,

}
