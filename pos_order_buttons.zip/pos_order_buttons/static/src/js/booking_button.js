odoo.define('pos_order_buttons.Booking', function(require) {
'use strict';
    const { Gui } = require('point_of_sale.Gui');
    const PosComponent = require('point_of_sale.PosComponent');
    const { identifyError } = require('point_of_sale.utils');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const { useListener } = require("@web/core/utils/hooks");
    const Registries = require('point_of_sale.Registries');
    const PaymentScreen = require('point_of_sale.PaymentScreen');
    const PopupWidget = require('point_of_sale.AbstractAwaitablePopup');
    const { _t } = require('web.core');const { parse } = require('web.field_utils');
   const { useRef, useState } = owl;

     class Booking extends PosComponent {
         setup() {
          super.setup();
          useListener('click', this.onClick);
      }
      toggletTobook(){
       console.log('dffd')
       this.showPopup('PopupWidget',{
       title : this.env._t("Title"),
       body : this.env._t("Your Body"),
      });
}
      async onClick() {
        var order = this.env.pos.get_order();


        if (order.partner==null){
            const { confirmed} = await this.showPopup("ErrorPopup", {
              title: this.env._t('Please select the Customer'),
              body: this.env._t('You need to select a customer for using this option'),
            });
        }

        else if(order.orderlines.length== 0 ){
         const { confirmed} = await this.showPopup("ErrorPopup", {

                                title: this.env._t('Orderline is empty'),
                               body: this.env._t('You need to select at least one item'),
                                });
                            }


        }



}




   Booking.template = 'Booking';
   ProductScreen.addControlButton({
       component: Booking,
       condition: function() {
       var len = this.env.pos.config.book_order

                if (len){
           return this.env.pos;
      }
       },
   });
   Registries.Component.add(Booking);
   return Booking;
});


