odoo.define('pos_order_buttons.PickupOrdersPage', function(require) {
  'use strict';
   const PosComponent = require('point_of_sale.PosComponent');
   const ProductScreen = require('point_of_sale.ProductScreen');
   const { useListener } =require("@web/core/utils/hooks");
   const Registries = require('point_of_sale.Registries');
   var rpc = require('web.rpc');
   var core = require('web.core');
   var Qweb = core.qweb;
   const { onMounted, onWillUnmount, useState } = owl;
   class PickupOrdersPage extends PosComponent {
   setup(){
           super.setup();
       }
   back() {
           this.showScreen('BookedPageScreen');
       }
   posconfirm(ev) {
            var self = this
            var $current = $(ev.currentTarget);
            var current_order  = $current.closest('#confirm_order').attr('order');
            var pos_book_orders = this.env.pos.booked_orders
            var lines = this.env.pos.booked_orders_lines
            pos_book_orders.forEach(function(datas){
            if (datas.id==current_order){
            lines.forEach(function(item){
                    if (item.order_id[0]==datas.id){
                        var product = self.env.pos.db.get_product_by_id(item['product_id'][0])
                        var qty = item['qty']
                        self.env.pos.get_order().add_product(product,{quantity: qty})
                    }
            var partner_id = datas.partner_id[0]
                console.log(partner_id,'partner_id')
               self.env.pos.get_order().set_partner(self.env.pos.db.get_partner_by_id(partner_id));
               self.env.pos.selectedOrder.booked_data = datas
            });
            }
            });
            this.showScreen('ProductScreen');


   }

   };
 PickupOrdersPage.template = 'PickupOrdersPage';
 Registries.Component.add(PickupOrdersPage);
 return PickupOrdersPage;
});