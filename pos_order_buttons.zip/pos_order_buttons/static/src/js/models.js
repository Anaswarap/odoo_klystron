/** @odoo-module **/
import Registries from 'point_of_sale.Registries';
import {PosGlobalState,Order} from 'point_of_sale.models'

     const  BookOrders = (PosGlobalState) => class  BookOrders extends PosGlobalState {
        async _processData(loadedData) {
            await super._processData(loadedData);
            this.booked_orders = loadedData['pos.book.order'];
            this.booked_orders_lines = loadedData['pos.book.order.line'];

        }
      }
     Registries.Model.extend(PosGlobalState,BookOrders);


     const BookedOrder = (Order) => class BookedOrder extends Order {
        constructor(obj, options) {
            super(...arguments);
            if (options.json) {
                this.booked_orders = options.json.booked_orders || undefined;
                this.is_booked = options.json.is_booked || false;
                this.booked_data = options.json.booked_data || undefined;
            }
        }

        init_from_JSON(json){
                super.init_from_JSON(...arguments);
                this.booked_orders = json.booked_orders;
                this.is_booked = json.is_booked;
                this.booked_data = json.booked_data
        }
        export_as_JSON(){
            const json = super.export_as_JSON(...arguments);
            json.booked_orders = this.booked_orders;
            json.booked_data = this.booked_data;
            json.is_booked = this.is_booked;
            return json;
        }
     }
     Registries.Model.extend(Order, BookedOrder);
