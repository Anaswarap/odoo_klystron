odoo.define('point_of_sale.PopupWidget', function(require) {
    'use strict';

    const AbstractAwaitablePopup = require('point_of_sale.AbstractAwaitablePopup');
    const Registries = require('point_of_sale.Registries');
    const {
        _lt
    } = require('web.core');
    const {
      parse
    } = require('web.field_utils');
    var rpc = require('web.rpc')
    var models = require('point_of_sale.models');
    console.log('gh', models)
    console.log('jhsdn', AbstractAwaitablePopup)
    const {
        _t
    } = require('@web/core/l10n/translation');


    class PopupWidget extends AbstractAwaitablePopup {
        confirm() {
            var self = this;
            var order = self.env.pos.get_order()
            var pickup_date = document.querySelector('[name="pickup_date"]').value || false;
            var deliver_date = document.querySelector('[name="deliver_date"]').value || false;
            var partner_id = self.env.pos.get_order().partner['id']
            var booking_date = new Date().toJSON().slice(0, 10)
            var pricelist = self.env.pos.get_order().pricelist['id']
            var phone = order.partner.phone
            var delivery_address = self.env.pos.get_order().partner['address']
            var note = document.querySelector('[name="order_note"]').value

            var order_lines = order.get_orderlines()
            var lines = []
            for (var line in order_lines) {
                var values = {
                    'product_id': order_lines[line]['product']['id'],
                    'quantity': order_lines[line]['quantity'],
                    'discount': order_lines[line]['discount']
                }
                lines.push(values)

            }
            console.log('lines', lines)
            if (!pickup_date && !deliver_date) {
                this.showPopup('ErrorPopup', {
                    'title': _t('Date field is empty'),
                    'body': _t('Please select pickup or deliver date!!'),
                });
            } else if (pickup_date && deliver_date) {
                this.showPopup('ErrorPopup', {
                    'title': _t('Select only one date'),
                    'body': _t('Select only one date (Deliver or Pickup date)'),
                });
            } else if (pickup_date) {
                if (pickup_date < booking_date) {
                    this.showPopup('ErrorPopup', {
                        'title': _t('Please Select Valid Pickup Date!'),
                        'body': _t('Date must be greater than today'),
                    });
                } else {
                    rpc.query({
                            model: 'pos.book.order',
                            method: 'create_from_ui',
                            args: [partner_id, booking_date, pickup_date, pricelist, phone, deliver_date, delivery_address, note, lines],
                        })
                        .then(function(order) {
                            console.log('order', order)


                        });
                        this.env.pos.add_new_order()
                }

            } else {
                if (deliver_date < booking_date) {
                    this.showPopup('ErrorPopup', {
                        'title': _t('Please Select Valid Deliver Date!'),
                        'body': _t('Date must be greater than today'),
                    });
                } else {
                    rpc.query({
                            model: 'pos.book.order',
                            method: 'create_from_ui',
                             args: [partner_id, booking_date, pickup_date, pricelist, phone, deliver_date, delivery_address, note, lines],
                        })
                        .then(function(order) {
                            console.log('order', order)

                        });
                }
            }

            return super.confirm();
        }


    }
    PopupWidget.template = 'PopupWidget';

    Registries.Component.add(PopupWidget);
    return PopupWidget;

});