odoo.define('pos_order_buttons.BookOrder', function(require) {
'use strict';
   const { Gui } = require('point_of_sale.Gui');
   const PosComponent = require('point_of_sale.PosComponent');
   const { identifyError } = require('point_of_sale.utils');
   const ProductScreen = require('point_of_sale.ProductScreen');
   const { useListener } = require("@web/core/utils/hooks");
   const Registries = require('point_of_sale.Registries');
   const PaymentScreen = require('point_of_sale.PaymentScreen');
   const core = require('web.core');
   const QWeb = core.qweb;



   class BookOrder extends PosComponent {
   setup() {
       super.setup();
       useListener('click', this.onClick);
       }
           booked_order_count() {
        if (this.env.pos.orders) {
             return this.env.pos.booked_orders.length;
            } else {
                return 0;
            }
        }
       async onClick() {
        var order = this.env.pos.get_order();

          if(order.orderlines.length == 0){
           this.showScreen('BookedPageScreen');
           }
           else{
              const { confirmed} = await this.showPopup("ErrorPopup", {
              title: this.env._t('Process Only one operation at a time'),
              body: this.env._t('Process the current order first'),
            });
           }
   }





   }



   BookOrder.template = 'BookOrder';
   ProductScreen.addControlButton({
       component: BookOrder,
       condition: function() {
        var len = this.env.pos.config.book_order
             console.log('order',len)

                if (len){
           return this.env.pos;
     }  },
   });
   Registries.Component.add(BookOrder);
   return BookOrder;
});
