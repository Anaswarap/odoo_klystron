from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _pos_ui_models_to_load(self):
        result = super()._pos_ui_models_to_load()
        result += [
            'pos.book.order',
            'pos.book.order.line'
        ]
        print(result,'result')
        return result

    def _loader_params_pos_book_order(self):
        return {
            'search_params': {
                'fields': ['name', 'pickup_date', 'deliver_date', 'delivery_address', 'phone', 'note', 'partner_id',
                            'lines', 'state', 'date_quotation', 'amount_total']
            }
        }

    def _get_pos_ui_pos_book_order(self, params):
        print('aaaabcd',self.env['pos.book.order'].search_read(**params['search_params']))
        return self.env['pos.book.order'].search_read(**params['search_params'])



    def _loader_params_pos_book_order_line(self):
        return {
            'search_params': {
                'fields': ['product_id','price_unit','order_id','qty']
            }
        }

    def _get_pos_ui_pos_book_order_line(self, params):
        print('orderliness',self.env['pos.book.order.line'].search_read(**params['search_params']))
        return self.env['pos.book.order.line'].search_read(**params['search_params'])
