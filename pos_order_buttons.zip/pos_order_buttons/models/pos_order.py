from odoo import models, fields, api


class PosOrder(models.Model):
    _inherit = 'pos.order'

    booking_ref = fields.Many2one('pos.book.order', string='Booking Ref')


    @api.model
    def _order_fields(self, ui_order):

        order_fields = super(PosOrder, self)._order_fields(ui_order)

        order_fields['booking_ref'] = ui_order['booked_data']['id']
        self.env['pos.book.order'].search([('id','=',ui_order['booked_data']['id'])]).write({'state':'confirmed'})
        return order_fields
