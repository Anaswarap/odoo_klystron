from odoo import fields, models, _, api


class BookOrder(models.Model):
    _inherit = 'pos.config'

    book_order = fields.Boolean(string="Book Order")






