from odoo import models, fields, api, _


class PosBookOrder(models.Model):
    _name = 'pos.book.order'
    _inherit = 'mail.thread'

    name = fields.Char(string='Booking Ref', required=True, readonly=True, copy=False, default=lambda self: _('New'))
    company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True,
                                 default=lambda self: self.env.user.company_id)
    date_quotation = fields.Date(string='Quotation Date',
                                 readonly=True, index=True, default=fields.Datetime.now())
    date_order = fields.Date(string='Order Date',
                             readonly=True, index=True, default=fields.Datetime.now())
    # amount_tax = fields.Float(string='Taxes', digits=0, default=1.2,compute='_compute_amount_all')
    amount_total = fields.Float(string='Total', compute='_compute_amount_all')
    lines = fields.One2many('pos.book.order.line', 'order_id', string='Order Lines', copy=True)
    partner_id = fields.Many2one('res.partner', string='Customer')
    state = fields.Selection([('draft', 'New'), ('confirmed', 'Confirmed')],
                             'Status', readonly=True, copy=False, default='draft')
    note = fields.Text(string='Internal Notes')
    fiscal_position_id = fields.Many2one('account.fiscal.position', string='Fiscal Position')
    book_order_ref = fields.Char(string='Booked Order Ref', readonly=True, copy=False)
    pickup_date = fields.Datetime(string='Pickup Date', readonly=True)
    deliver_date = fields.Datetime(string='Deliver Date', readonly=True)
    phone = fields.Char(string='Contact no', help='Phone of customer for delivery')
    delivery_address = fields.Char('Delivery Address', help='Address of customer for delivery')
    book_order = fields.Boolean('Booking Order', readonly=True)
    pricelist_id = fields.Many2one('product.pricelist', string='Pricelist')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'pos.book.order') or _('New')
        res = super(PosBookOrder, self).create(vals)
        return res


    @api.model
    def create_from_ui(self, partner_id, booking_date, pickup_date, pricelist, phone, deliver_date, delivery_address,
                       note, lines):
        values = []
        for l in lines:
            val = {'product_id': l['product_id'], 'qty': l['quantity'], 'discount': l['discount']}

            values.append((0, 0, val))

        if pickup_date != False:

            order_id = self.create({
                'partner_id': partner_id,
                'date_order': booking_date,
                'pickup_date': pickup_date,
                'pricelist_id': pricelist,
                'phone': phone,
                'note': note,
                'lines': values
            })
        else:
            order_id = self.create({
                'partner_id': partner_id,
                'date_order': booking_date,
                'pricelist_id': pricelist,
                'phone': phone,
                'deliver_date': deliver_date,
                'delivery_address': delivery_address,
                'note': note,
                'lines': values

            })
        return order_id

    @api.depends('lines.price_subtotal_incl')
    def _compute_amount_all(self):
        for rec in self:
            rec.amount_total = (sum(line.price_subtotal_incl for line in rec.lines))


class PosBookOrderLine(models.Model):
    _name = 'pos.book.order.line'

    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.user.company_id)
    name = fields.Char(string='Line No')
    notice = fields.Char(string='Discount Notice')
    product_id = fields.Many2one('product.product',
                                 string='Product',
                                 required=True)
    price_unit = fields.Float(string='Unit Price', digits=0, related='product_id.lst_price')
    qty = fields.Float('Quantity', default=1)
    price_subtotal = fields.Float(digits=0,
                                  string='Subtotal w/o Tax')
    price_subtotal_incl = fields.Float(
        digits=0, compute='_compute_amount_line_all',
        string='Subtotal')
    discount = fields.Float(string='Discount (%)', digits=0, default=0.0)
    order_id = fields.Many2one('pos.book.order', string='Order Ref', ondelete='cascade')
    create_date = fields.Datetime(string='Creation Date', readonly=True)
    tax_ids = fields.Many2many('account.tax', string='Taxes', readonly=True)

    pack_lot_ids = fields.One2many('pos.pack.operation.lot', 'pos_order_line_id',
                                   string='Lot/serial Number')

    @api.depends('price_unit', 'tax_ids', 'qty', 'discount', 'product_id')
    def _compute_amount_line_all(self):
        for line in self:
            currency = line.order_id.pricelist_id.currency_id
            # print(currency, "currency")
            taxes = line.tax_ids.filtered(
                lambda tax: tax.company_id.id == line.order_id.company_id.id)
            # print(taxes, 'taxes')
            fiscal_position_id = line.order_id.fiscal_position_id
            # print(fiscal_position_id, 'fiscal_position_id')
            if fiscal_position_id:
                taxes = fiscal_position_id.map_tax(taxes, line.product_id, line.order_id.partner_id)
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            line.price_subtotal = line.price_subtotal_incl = price * line.qty
            if taxes:
                taxes = taxes.compute_all(price, currency, line.qty, product=line.product_id,
                                          partner=line.order_id.partner_id or False)
                line.price_subtotal = taxes['total_excluded']
                line.price_subtotal_incl = taxes['total_included']

            line.price_subtotal = currency.round(line.price_subtotal)
            line.price_subtotal_incl = currency.round(line.price_subtotal_incl)
