from odoo import fields, models,api



class EmployeePayslip(models.Model):
    _inherit = 'hr.payslip'

    year = fields.Char(string='Year',compute='_compute_period_fields')
    month = fields.Char(string='Month',compute='_compute_period_fields')
    days_in_month = fields.Char(string='Worked Days',compute='_compute_period_fields')


    @api.depends('date_from','date_to')
    def _compute_period_fields(self):
        print("aaa")
        for slip in self:
            print(slip,"bbb")
            print(slip.date_from, "ccc")
            print(slip.date_to, "dd")
            if slip.date_to and slip.date_from:
                date_from_yr =slip.date_from.year
                print(date_from_yr,"y1")
                date_from_month =slip.date_from.month
                print(date_from_month, "m1")
                date_to_yr =slip.date_to.year
                print(date_to_yr,"y2")
                date_to_month =slip.date_to.month
                print(date_to_month,"mon2")

                if (date_from_yr == date_to_yr):
                    print('equal')
                    slip.year = date_from_yr
                else:
                    print('!equal')
                    slip.year = False
                if  (date_from_month == date_to_month):
                    slip.month = date_from_month
                    print( type(slip.month), "month12")
                    if int(slip.month) == 2:
                        print(slip.month, "workdays1")
                        slip.days_in_month = 28

                    else:
                        slip.days_in_month = 30
                        print(slip.month, "workdays2")

                else:
                    slip.month = False



