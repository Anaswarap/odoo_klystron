{
    'name': 'Employee Payslips',
    'version': '16.0.1.0.0',
    'depends': ['base', 'hr_payroll', ],
    'data': [
        'report/payroll_payslip_template.xml',
        'views/kg_payslip_view.xml',
    ],

    'installable': True,
    'application': True
}
