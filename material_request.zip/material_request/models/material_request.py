from odoo import fields, models,api,_



class MaterialRequest(models.Model):
    _name = 'material.request'
    _inherit = 'mail.thread'
    _rec_name = 'reference_no'


    reference_no = fields.Char(string='Material Reference', required=True, readonly=True, default=lambda self: _('New'))
    employee_id = fields.Many2one('res.partner',string='Employee')
    request_date = fields.Date(string='Date',required=True)
    acquire_methods = fields.Selection(
        [('internal transfer', 'Internal Transfer'), ('purchase order', 'Purchase Order')],
        string='Acquire Method')
    request_state = fields.Selection(
        selection=[
            ('new_request', "New Request"),
            ('waiting_approve', "Waiting Approve"),('manager_approve', "Manager Approve"),('head_approve', "Head Approve"),('reject',"Reject"),('done',"Done")
        ],
        string="State",
        readonly=True, copy=False, index=True,
        tracking=3,
        default='new_request')
    picking_type_id = fields.Many2one('stock.picking.type',string='Operation Type')
    material_request_ids = fields.One2many('material.request.tree','material_request_id',string='Material Requests')
    grand_total = fields.Float(string='Total', compute='_compute_grand_total')
    internal_move_id = fields.Many2one('stock.picking')



    def _compute_grand_total(self):
        for rec in self:
            rec.grand_total = sum((rec.material_request_ids.mapped('sub_total_price')))

    def submit_material_request(self):
        self.request_state = 'waiting_approve'


    def approve_manager(self):
        self.request_state = 'manager_approve'


    def approve_head(self):
        self.request_state = 'head_approve'

    def create_rfq(self):
        return {
            'name': _('Vendors'),
            'type': 'ir.actions.act_window',
            'res_model': 'vendor.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_order_id': self.id}
        }

    def create_transfer(self):
        rec = []

        for item in self.material_request_ids:
            rec.append((0, 0, {
                'product_id': item.products_id.id,
                'product_uom_qty': item.product_qty,
                'quantity_done': item.product_qty,
                'location_id': self.picking_type_id.default_location_src_id.id,
                'location_dest_id': self.picking_type_id.default_location_dest_id.id,
                'name': "transfer"

            }))
        internal_move = self.env['stock.picking'].create({
                'partner_id': self.employee_id.id,
                'picking_type_id': self.picking_type_id.id,
                'location_id': self.picking_type_id.default_location_src_id.id,
                'location_dest_id': self.picking_type_id.default_location_dest_id.id,
                'move_ids': rec,

            })
        self.internal_move_id = internal_move.id


    def reject_head(self):
        self.request_state = 'reject'




    @api.model
    def create(self, vals):
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code(
                'material.request') or _('New')
        res = super(MaterialRequest, self).create(vals)
        return res


class MaterialRequestTree(models.Model):
    _name = 'material.request.tree'


    material_request_id = fields.Many2one('material.request',string='Material Requests')


    products_id = fields.Many2one('product.product',string='Products')
    product_qty = fields.Float(string='Quantity',default=1)
    unit_price = fields.Float(string='Unit Price')
    sub_total_price = fields.Float(string='Sub Total Price',compute='_compute_sub_total')


    @api.depends('product_qty', 'unit_price')
    def _compute_sub_total(self):
        for rec in self:
            rec.sub_total_price = rec.product_qty * rec.unit_price

class InternalTransfer(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super(InternalTransfer,self).button_validate()
        material_orders = self.env['material.request'].search([('internal_move_id','=',self.id)])
        material_orders.request_state = 'done'
        return res