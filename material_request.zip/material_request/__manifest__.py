{
    'name': 'Material Request',
    'version': '16.0.1.0.0',
    'depends': ['base', 'product', 'stock','mail','purchase'],
    'data': [
        'security/material_request_security_view.xml',
        'security/ir.model.access.csv',
        'data/material_request_sequence_view.xml',
        'wizards/vendor_multiple_wizard_view.xml',

        'views/material_request_view.xml',


    ],

    'installable': True,
    'application': True
}
