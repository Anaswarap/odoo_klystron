from odoo import fields, models


class VendorWizard(models.TransientModel):
    _name = 'vendor.wizard'

    partner_ids = fields.Many2many('res.partner', string="Vendor")
    order_id = fields.Many2one('material.request', string='Orders')
    order_purchase_id = fields.Many2one('purchase.order')

    def vendor_confirm(self):
        for vals in self.partner_ids:
            rec = []
            print(vals)
            for item in self.order_id.material_request_ids:
                rec.append((0, 0, {
                'product_id': item.products_id.id,
                'product_qty': item.product_qty,
                'price_unit': item.unit_price,
                'price_subtotal': item.sub_total_price,

            }))
            purchase_order = self.env['purchase.order'].create({
                'partner_id': vals.id,
                'order_line': rec

            })
        self.order_purchase_id = purchase_order.id

class PurchaseOrderButton(models.Model):
    _inherit = 'purchase.order'



    def button_confirm(self):
        res = super(PurchaseOrderButton,self).button_confirm()
        orders = self.env['vendor.wizard'].search([('order_purchase_id','=',self.id)])
        orders.order_id.request_state = 'done'
        return res