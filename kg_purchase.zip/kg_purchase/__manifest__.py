# -*- coding: utf-8 -*-
{
    'name': "KG PURCHASE",
    'summary': """
        Cutomization of PURCHASE""",

    'description': """
        Cutomization of Purchase
    """,
    'author': "ANAL JOY",
    'website': "https://www.klystronglobal.com",
    'category': 'Project',
    'version': '16.0.0.0',
    'depends': ['base', 'purchase', 'kg_crm', 'planning'],
    'data': ['data/ir_sequence.xml',
             'data/lpo_paper_format.xml',
             'reports/lpo_template.xml',
             'reports/lpo_report_template.xml',
             # 'reports/purchase_terms_template.xml',

             'views/planning.xml',
             'views/mobilization_expense.xml',
             'views/purchase_order.xml',

             # 'data/activity.xml',
             # 'security/security_group.xml',
             # 'views/views.xml',
             ],
}
