from odoo import api, fields, models


class PlanningSlot(models.Model):
    _inherit = 'planning.slot'

    project_start_date = fields.Date("Project Start Date")
    project_end_date = fields.Date("Project End Date")
