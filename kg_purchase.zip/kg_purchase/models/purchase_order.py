from odoo import api, fields, models


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    state = fields.Selection([
        ('draft', 'PO Requisition'),
        ('sent', 'PO Sent'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)


    @api.model_create_multi
    def create(self, vals_list):
        for i in vals_list:
            req_for_quo = self.env['ir.sequence'].next_by_code('kg.req.for.quot')
            update_seq = {'name': req_for_quo}
            i.update(update_seq)
        res = super(PurchaseOrder, self).create(vals_list)
        return res

    def button_confirm(self):
        res = super(PurchaseOrder, self).button_confirm()
        if self.state == 'purchase':
            self.name = self.env['ir.sequence'].next_by_code('kg.purchase.order.seq.code')
        return res


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    percentage_qty = fields.Float(string='Qty Percentage')

    @api.onchange('percentage_qty')
    def _onchange_percentage_qty(self):
        for rec in self:
            if rec.percentage_qty:
                rec.product_qty = rec.percentage_qty
            else:
                self.percentage_qty = 0.0

    # @api.onchange('analytic_distriubution')
    # def _onchange_percentage_qty(self):
    #     for rec in self:
    #         print("sssssssss",rec.analytic_distriubution)