from odoo import fields, models, api


class MergeSale(models.Model):
    _inherit = 'sale.order'

    def merge_duplicate_product(self, res):
        for line in res.order_line:
            if line.id in res.order_line.ids:
                line_ids = res.order_line.filtered(lambda m: m.product_id.id == line.product_id.id)
                print(line_ids)
        quantity = 0
        for qty in line_ids:
            quantity += qty.product_uom_qty
            print(quantity)
            line_ids[0].write({'product_uom_qty': quantity,
                               'order_id': line_ids[0].order_id.id})
        line_ids[1:].unlink()

    @api.model
    def create(self, vals):
        res = super(MergeSale, self).create(vals)
        print(res)
        res.merge_duplicate_product(res)
        return res

    def write(self, vals):
        res = super(MergeSale, self).write(vals)
        print(res)
        self.merge_duplicate_product(self)
        return res
