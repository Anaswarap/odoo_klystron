{
    'name': 'Merge Order Line',
    'version': '16.0.1.0.0',
    'depends': ['base','sale'],








    'installable': True,
    'application': True
}
