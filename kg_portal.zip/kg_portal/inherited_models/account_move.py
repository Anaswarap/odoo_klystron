from odoo import fields, models, api


class AccountMove(models.Model):
    _inherit = 'account.move'

    registration_id = fields.Many2one(
        comodel_name='vendor.registration',
        string='Registration No',
        required=False)
