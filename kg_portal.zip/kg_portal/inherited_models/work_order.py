import logging

from odoo import fields, models, api,_
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError

_logger = logging.getLogger('odoo')



class WorkOrder(models.Model):
    _inherit = 'work.order'
    _description = 'Work Order'

    published_notify = fields.Boolean(required=False, default=False)
    after_sixty_days = fields.Date(
        string='60 days',
        required=False)

# To Sent Email After 60 Days

    @api.model
    def create(self, vals):
        print('model - vals 1', vals)
        res = super().create(vals)
        if res.srr_id and res.srr_id.date_completed:
            res.after_sixty_days = res.srr_id.date_completed + relativedelta(days=60)
        else:
            _logger.info(_("Ring request is not completed"))
            # raise UserError(_("Ring request is not completed"))
        print('model - vals 2',vals)

        return res


    # @api.onchange('srr_id')
    # def onchange_work_order_date(self):
    #     if self.create_date:
    #         srr_complete_date = self.srr_id.date_completed

# Mail if NSWO Is not published after 60 days

    def nswo_reminder(self):
        today = fields.Date.today()
        # today = today.replace(day=10)
        work_order = self.env['work.order'].search(
            [ ('after_sixty_days', '=', today), ('published_notify', '=', False)])
        for rec in work_order:
            template_id = rec.env.ref('kg_portal.notify_nswo_published_email')
            template_id.send_mail(rec.id, force_send=True)
            rec.write({'published_notify': True})

    """Following action are only using for import records
    #Nafi"""

    def link_nswo_vs_project(self):
        nswo = self.env['work.order'].search([('project_id', '=', False)])
        for rec in nswo:
            site_id = rec.client_site_id.name
            corresponding_project = self.env['project.project'].search([('name', '=', site_id)], limit=1)
            if corresponding_project:
                rec.project_id = corresponding_project.id

    def update_tower_height(self):
        nswo = self.env['work.order'].search([])
        for rec in nswo:
            # update epa
            # ******************************#
            current_epa = rec.epa_allowance_import
            if current_epa == 6.0:
                current_epa = 6
            if current_epa == 9.0:
                current_epa = 9
            exact_epa = self.env['epa.allowance'].search([('name', '>=', current_epa)], limit=1)
            rec.epa_allowance = exact_epa.id
            # ...............................#
            # update tower height
            # ******************************#
            tower_height = rec.tower_height_new
            exact_tower_height = self.env['tower.height'].search([('name', '>=', tower_height)], limit=1)
            if exact_tower_height:
                rec.tower_height = exact_tower_height.id
            # .............................#
            # Calculating Monthly Rent
            if rec.epa_allowance and rec.tower_height:
                if rec.structure_type_id.name == 'Rooftop':
                    rent_id = self.env['rent.calculation'].sudo().search(
                        [('partner_id', '=', rec.operator_id.id), ('structure_type_id', '=', rec.structure_type_id.id)],
                        limit=1)
                    rec.rent = rent_id.rent_with_cable if rec.with_cable else rent_id.rent_without_cable
                else:
                    rent_id = self.env['rent.calculation'].sudo().search(
                        [('epa_allowance', '=', rec.epa_allowance.id), ('tower_height_id', '=', rec.tower_height.id),
                         ('partner_id', '=', rec.operator_id.id), ('structure_type_id', '=', rec.structure_type_id.id)],
                        limit=1)

                    rec.rent = rent_id.rent_with_cable if rec.with_cable else rent_id.rent_without_cable
            else:
                rec.rent = 0
