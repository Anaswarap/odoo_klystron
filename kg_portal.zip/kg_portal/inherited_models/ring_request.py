from datetime import date

from dateutil.relativedelta import relativedelta
from odoo import fields, models, api, _


class RingRequest(models.Model):
    _inherit = 'ring.request'
    _description = 'Search Ring Request'

    # These fields added into "kg_tower" module due to dependency error while upgrading module(kg_tower)
    # notify_fine = fields.Boolean(
    #     string='Fine Reminder Sent',
    #     required=False, default=False)
    # notify_nswo = fields.Boolean(
    #     string='Fine Created',
    #     required=False, default=False)
    # date_completed = fields.Date(
    #     string='Completion Date',
    #     required=False, tracking=True)
    # after_sixty_days = fields.Date(
    #     string='Generate fine on',
    #     required=False, tracking=True)
    # after_fifty_days = fields.Date(
    #     string='Send NSWO Create Warning on',
    #     required=False, tracking=True)

    def show_fines(self):
        for rec in self:
            srr = self.env['srr.fine'].search([('srr_id', '=', rec.id), ])
            if srr:
                return {
                    'type': 'ir.actions.act_window',
                    'name': "SRR Fine",
                    'view_mode': 'tree,form',
                    'res_model': 'srr.fine',
                    'domain': [('id', 'in', srr.ids)],
                    'context': "{'create': False}",

                }

    @api.onchange('date_completed')
    def onchange_date_completed(self):
        if self.date_completed:
            self.after_sixty_days = self.date_completed + relativedelta(days=60)
            self.after_fifty_days = self.date_completed + relativedelta(days=50)

    def write(self, vals):
        if vals.get('date_completed'):
            completed_date = fields.Date.from_string(vals['date_completed'])
            vals['after_sixty_days'] = completed_date + relativedelta(days=60)
            vals['after_fifty_days'] = completed_date + relativedelta(days=50)

        return super().write(vals)

    def ring_request_reminder(self):
        today = fields.Date.today()
        # today = today.replace(day=10)
        ring_request = self.env['ring.request'].search(
            ['|', ('after_sixty_days', '=', today), ('after_fifty_days', '=', today)])
        for rec in ring_request:
            find_nswo = self.env['work.order'].search([('srr_id', '=', rec.id)], limit=1)
            print('inside', rec.name)
            if not find_nswo:
                print('llk', today)
                if rec.after_fifty_days == today and rec.notify_fine == False:
                    template_id = rec.env.ref('kg_portal.notify_srr_fine_email')
                    template_id.send_mail(rec.id, force_send=True)
                    rec.write({'notify_fine': True})
                if rec.after_sixty_days == today and rec.notify_nswo == False:
                    template_id = rec.env.ref('kg_portal.notify_nswo_email')
                    rec.create_fines()
                    template_id.send_mail(rec.id, force_send=True)
                    rec.write({'notify_nswo': True})

    def create_fines(self):
        vals_inv = {}
        vals_inv['srr_id'] = self.id
        vals_inv['partner_id'] = self.partner_id.id
        vals_inv['date'] = date.today()
        # vals_inv['move_type'] = 'in_invoice'
        lines = []
        a = (0, 0, {
            'quantity': 1,
            'price_unit': float(self.env['ir.config_parameter'].sudo().get_param('kg_tower.srr_charge')) or 300.00,
            'name': 'Fine for not creating NSWO for ' + self.name,
            'product_id': int(self.env['ir.config_parameter'].sudo().get_param('kg_tower.srr_product_id')) or False,
            'analytic_account_id': self.project_id and self.project_id.analytic_account_id and self.project_id.analytic_account_id.id or False,
        })
        lines.append(a)
        vals_inv['line_ids'] = lines
        self.env['srr.fine'].create(vals_inv)


class SRRFine(models.Model):
    _name = 'srr.fine'
    _description = 'SRRFine'

    name = fields.Char(
        readonly=True,
        default=lambda x: _('New'), )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Partner',
        required=False)
    srr_id = fields.Many2one(
        comodel_name='ring.request',
        string='SRR',
        required=False)
    date = fields.Date(
        string='Date',
        required=False)
    line_ids = fields.One2many(
        comodel_name='srr.fine.lines',
        inverse_name='srr_fine_id',
        string='Lines',
        required=False)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('srr.fine') or _('New')
        res = super(SRRFine, self).create(vals)
        return res


class SRRFineLines(models.Model):
    _name = 'srr.fine.lines'
    _description = 'SRRFineLines'

    name = fields.Char()
    quantity = fields.Float(
        string='Quantity',
        required=False)
    price_unit = fields.Float(
        string='Price Unit',
        required=False)
    product_id = fields.Many2one(
        comodel_name='product.product',
        string='Product',
        required=False)
    analytic_account_id = fields.Many2one(
        comodel_name='account.analytic.account',
        string='Analytic_account_id',
        required=False)
    srr_fine_id = fields.Many2one(
        comodel_name='srr.fine',
        string='SRR Fine',
        required=False)
