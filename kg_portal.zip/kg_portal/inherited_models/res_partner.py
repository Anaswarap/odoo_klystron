from odoo import fields, models, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    grade = fields.Selection(
        string='Grade',
        selection=[('excellent', 'Excellent'),
                   ('g1', 'Grade One'),
                   ('g2', 'Grade Two'),
                   ('g3', 'Grade Three'),
                   ('g4', 'Grade Four'),
                   ('international', 'International (Payment USD)'),
                   ('others', 'Others'),
                   ], )
    formed_on = fields.Date(
        string='Formed On', )
    category = fields.Selection(
        string='Category',
        selection=[('llc', 'LLC'),
                   ('soag', 'SOAG'),
                   ('individual', 'Individual Firm / Merchant'),
                   ('other', 'Other'), ], )
    cr_no = fields.Char(
        string='CR No',
        required=False)
    cr_expiry_date = fields.Date(
        string='CR Expiry Date',
        required=False)
    registered_sme = fields.Selection(
        string='Registered as SME',
        selection=[('yes', 'YES'),
                   ('no', 'NO'), ],
        required=False, )
    bank = fields.Char(
        string='Bank',
        required=False)
    branch = fields.Char(
        string='Branch',
        required=False)
    swift_no = fields.Char(
        string='Swift Number',
        required=False)
    account_no = fields.Char(
        string='Account No',
        required=False)
    account_name = fields.Char(
        string='Account Name',
        required=False)
    total_strength = fields.Float(
        string='Total Strength',
        required=False)
    total_omanies = fields.Float(
        string='Total Omanies',
        required=False)
    total_expatriate = fields.Float(
        string='Total Expatriate',
        required=False)
    qhse_rep = fields.Char(
        string='QHSE Representative',
        required=False)
    qhse_contact = fields.Char(
        string='QHSE Contact No',
        required=False)
    finance_rep = fields.Char(
        string='Finance Representative',
        required=False)
    finance_contact = fields.Char(
        string='Finance Contact No',
        required=False)
    main_office_location = fields.Char(
        string='Main Office Location',
        required=False)
    landphone = fields.Char(
        string='Landphone',
        required=False)
    expiry_date = fields.Date(
        string='Expiry Date',
        help="The date of expiry", tracking=True)
    expiry = fields.Boolean(
        default=False,
        string='Expiry',
        required=False, tracking=True)
    vendor_registration = fields.Many2one(
        comodel_name='vendor.registration',
        string='Vendor Registration',
        required=False)
    commercial_activities = fields.Text(
        string="Registered Commercial Activitives",
        required=False)

    @api.onchange('expiry')
    def onchange_expiry(self):
        if self.expiry:
            self.expiry_date = fields.Date.today()
        else:
            self.expiry_date = None
