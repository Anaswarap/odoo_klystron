from odoo import fields, models, api


class ResCompany(models.Model):
    _inherit = 'res.company'
    _description = 'Company'

    decleration_letter = fields.Binary(
        string='Decleration Letter', attachment=True,
        required=False)
    registration_request = fields.Binary(
        string='Registration Request', attachment=True,
        required=False)
    commercial_registration = fields.Binary(
        string='Commercial Registration', attachment=True,
        required=False)
    default_partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Default Partner',
        required=False)
    default_product_id = fields.Many2one(
        comodel_name='product.product',
        string='Default Product',
        required=False)
