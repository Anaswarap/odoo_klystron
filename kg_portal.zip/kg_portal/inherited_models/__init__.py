from . import res_company
from . import res_partner
from . import ring_request
from . import work_order
