odoo.define('kg_portal.kg_portal', function (require) {
'use strict';

var publicWidget = require('web.public.widget');
var rpc = require('web.rpc');
publicWidget.registry.vendorRegistration = publicWidget.Widget.extend({
    selector: '#vendor_registration',
    events: {
        'click #add_owner': '_addOwner',
        'click #remove_owner': '_remove_owner',
        'click #reset_owner': '_reset_owner',
        'click #add_authority': '_addAuthority',
        'click #remove_authority': '_remove_authority',
        'click #reset_authority': '_reset_authority',
        'click #add_activity': '_addActivity',
        'click #remove_activity': '_remove_activity',
        'click #reset_activity': '_reset_activity',
        'click #is_offline_payment': '_paymentOptionVisibility',
        'change #is_registered_sme': '_smeDocUploadOptionVisibility',
        'change #grade': '_get_fee',
    },

    start: function () {
        return this._super.apply(this, arguments);
    },

    get_owner_count: function () {
        var owner_count = $('#vendor_registration').find('.extra-owner')
        console.log(owner_count.length + 2)
        return owner_count.length + 2
    },

     _addOwner: function (ev) {
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#owner_base')
        var $new_el = $base_el.clone()
        var class_name = $base_el.attr('class') + ' extra-owner'
        var el_count = this.get_owner_count()
        var new_id = 'owner_' + el_count
        $new_el.attr({
            id: '',
            class: class_name,
        })
        $new_el.find('input').attr({
            'id': new_id,
            'name': new_id,
        })
        $new_el.find('input').val('')
        $new_el.find('label').attr('for', new_id)
        $new_el.insertBefore('#owner-start-js');
    },

    _remove_owner: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_owner_el = $current.parents('#vendor_registration').find('.extra-owner')
        var $last_el = $extra_owner_el.last().remove()
    },


    _reset_owner: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_owner_el = $current.parents('#vendor_registration').find('.extra-owner')
        $extra_owner_el.remove()
    },


    get_authority_count: function () {
        var authority_count = $('#vendor_registration').find('.extra-authority')
        console.log(authority_count.length + 2)
        return authority_count.length + 2
    },

     _addAuthority: function (ev) {
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#authority_base')
        var $new_el = $base_el.clone()
        var class_name = $base_el.attr('class') + ' extra-authority'
        var el_count = this.get_authority_count()
        var new_id = 'authority_' + el_count
        $new_el.attr({
            id: '',
            class: class_name,
        })
        $new_el.find('input').attr({
        'id': new_id,
        'name': new_id,
        })
        $new_el.find('input').val('')
        $new_el.find('label').attr('for', new_id)
        $new_el.insertBefore('#authority-start-js');
    },

    _remove_authority: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_authority_el = $current.parents('#vendor_registration').find('.extra-authority')
        var $last_el = $extra_authority_el.last().remove()
    },


    _reset_authority: function (ev) {
        var $current = $(ev.currentTarget);
        var $extra_authority_el = $current.parents('#vendor_registration').find('.extra-authority')
        $extra_authority_el.remove()
    },


    get_activity_count: function () {
        var activity_count = $('#vendor_registration').find('.extra-activity')
        console.log(activity_count.length + 2)
        return activity_count.length + 2
    },

     _addActivity: function (ev) {
        console.log(7777777)
        var $current = $(ev.currentTarget);
        var $base_el = $current.parents('.form-field').siblings('#activity_base')
        var $new_el = $base_el.clone()
        var class_name = $base_el.attr('class') + ' extra-activity'
        var el_count = this.get_activity_count()
        var new_id = 'activity_' + el_count
        $new_el.attr({
            id: '',
            class: class_name,
        })
        $new_el.find('input').attr({
        'id': new_id,
        'name': new_id,
        })
        $new_el.find('input').val('')
        $new_el.find('label').attr('for', new_id)
        $new_el.insertBefore('#activity-start-js');
    },

    _remove_activity: function (ev) {
        console.log(555555555)
        var $current = $(ev.currentTarget);
        var $extra_activity_el = $current.parents('#vendor_registration').find('.extra-activity')
        var $last_el = $extra_activity_el.last().remove()
    },


    _reset_activity: function (ev) {
        console.log(88888888)
        var $current = $(ev.currentTarget);
        var $extra_activity_el = $current.parents('#vendor_registration').find('.extra-activity')
        $extra_activity_el.remove()
    },

    _get_fee: function (ev) {
        var $parent = $(ev.currentTarget).parents('.contact-form')
        var $grade_el = $parent.find('#grade')
        var $registration_fee_el = $parent.find('#registration_fee')
        var grade = $grade_el.val()
        return this._rpc({
            route: '/form/vendor_registration/get_fee',
            params: {
                    grade: grade
                }
        }).then(function (result) {
            $registration_fee_el.val(0)
            if(result) {
                $registration_fee_el.val(result)
            }
        });
    },

    _paymentOptionVisibility: function(ev){
        var $checked = $('#is_offline_payment').is(':checked')
        if ($checked){
            $('.offline-payment').css("visibility", "visible");;
        }
        else{
            $('.offline-payment').css("visibility", "collapse");;
        }
    },
    _smeDocUploadOptionVisibility: function(ev){
        var $checked = $('#is_registered_sme').val()
        console.log("$checked",$checked)
        if ($checked == 'yes'){
            $('.sme-doc-upload').css("visibility", "visible");;
        }
        else{
            $('.sme-doc-upload').css("visibility", "collapse");;
        }
    },

});
});

