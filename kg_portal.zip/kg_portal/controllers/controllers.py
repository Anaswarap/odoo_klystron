# -*- coding: utf-8 -*-
import base64

from odoo import http, api, fields, models, _
from odoo.exceptions import UserError
from odoo.http import request


class VendorRegistrationPortal(http.Controller):

    def _create_attachment(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': base64.encodebytes(file.read()),
            'res_model': 'vendor.registration',
            'res_id': res_id
        })
        return attachment_id.datas

    def _save_image(self, file, res_id):
        if not file:
            return False
        Attachment = request.env['ir.attachment'].sudo()
        attachment_id = Attachment.create({
            'name': request.env.user.name,
            'type': 'binary',
            'datas': file.encode(),
            'res_model': 'vendor.registration',
            'res_id': res_id,
        })
        return attachment_id.datas

    @http.route('/form/vendor_registration', type='http', auth="public", methods=['POST', 'GET'], website=True)
    def portal_vendor_registration(self, **post):
        if post and request.httprequest.method == 'POST':
            owner_data = []
            activity_data = []
            authority_data = []
            is_offline_payment = post.get('is_offline_payment')
            for val in post:
                if 'owner_' in val:
                    owner_data.append((0, 0, {
                        'name': post[val]
                    }))
                if 'activity_' in val:
                    activity_data.append((0, 0, {
                        'name': post[val]
                    }))
                if 'authority_' in val:
                    authority_data.append((0, 0, {
                        'name': post[val]
                    }))
            company_id = request.env['res.company'].sudo().search([], limit=1)
            if not company_id.default_partner_id and company_id.default_product_id:
                raise UserError(_("Default Partner and Product are missing.Please Contact System Administrator"))
            registration_fee = request.env['vendor.registration.fee'].sudo().search([('grade', '=', post.get('grade'))],
                                                                                    limit=1).amount
            VendorRegistration = request.env['vendor.registration'].sudo()
            vals = {
                'organization': post.get('organization'),
                'formed_on': post.get('formed_on'),
                'category': post.get('category'),
                'grade': post.get('grade'),
                'registration_fee': registration_fee,
                'phone': post.get('phone'),
                'cr_no': post.get('cr_no'),
                'cr_expiry_date': post.get('cr_expiry_date'),
                'main_office_location': post.get('main_office_location'),
                'landphone': post.get('landphone'),
                'mobile_no': post.get('mobile_no'),
                'email': post.get('email'),
                'account_name': post.get('account_name'),
                'website_address': post.get('website_address'),
                'registered_sme': post.get('registered_sme'),
                'bank': post.get('bank'),
                'branch': post.get('branch'),
                'swift_no': post.get('swift_no'),
                'account_no': post.get('account_no'),
                'total_strength': post.get('total_strength'),
                'total_omanies': post.get('total_omanies'),
                'total_expatriate': post.get('total_expatriate'),
                'qhse_rep': post.get('qhse_rep'),
                'qhse_contact': post.get('qhse_contact'),
                'finance_rep': post.get('finance_rep'),
                'finance_contact': post.get('finance_contact'),
                'owner_lines': owner_data,
                'approved_activity_lines': activity_data,
                'signature_authority_lines': authority_data,
                'street': post.get('street'),
                'street2': post.get('street2'),
                'city': post.get('city'),
                'state': post.get('state'),
                'country_id': post.get('country_id'),
                'zip': post.get('zip'),
                'tax_id': post.get('tax_id'),
                'is_offline_payment': True if post.get('with_cable') == 'on' else False,
                'allocated_to': int(
                    request.env['ir.config_parameter'].sudo().get_param("kg_purchase.vendor_reg_form_responsible_user"))
            }
            search_vendor_registration_id = VendorRegistration.create(vals)
            # payment_receipt = post.get('payment_receipt')
            # payment_receipt = self._create_attachment(payment_receipt, search_vendor_registration_id.id)

            cci = post.get('cci')
            cci = self._create_attachment(cci, search_vendor_registration_id.id)

            decleration_letter = post.get('decleration_letter')
            decleration_letter = self._create_attachment(decleration_letter, search_vendor_registration_id.id)

            registration_request = post.get('registration_request')
            registration_request = self._create_attachment(registration_request, search_vendor_registration_id.id)

            commercial_registration = post.get('commercial_registration')
            commercial_registration = self._create_attachment(commercial_registration, search_vendor_registration_id.id)

            attachment_sign = post.get('contractdata')
            attachment_sign = self._save_image(attachment_sign, search_vendor_registration_id.id)
            search_vendor_registration_id.sudo().write({
                'cci': cci,
                'decleration_letter': decleration_letter,
                'attachment_sign': attachment_sign,
                'registration_request': registration_request,
                'commercial_registration': commercial_registration,

            })

            # if is_offline_payment:
            if post.get('with_cable') == 'on':
                payment_receipt = post.get('payment_receipt')
                payment_receipt = self._create_attachment(payment_receipt,
                                                          search_vendor_registration_id.id)
                search_vendor_registration_id.sudo().write({
                    'payment_receipt': payment_receipt,
                })

            if post.get('registered_sme') and post.get('registered_sme') == 'yes':
                sme_doc_upload = post.get('sme_doc_upload')
                sme_doc_upload = self._create_attachment(sme_doc_upload,
                                                          search_vendor_registration_id.id)
                search_vendor_registration_id.sudo().write({
                    'sme_doc_upload': sme_doc_upload,
                })

            CreateInvoice = request.env['account.move'].sudo().create({
                'move_type': 'out_invoice',
                'partner_id': company_id.default_partner_id.id,
                'invoice_date': fields.Date.today(),
                'date': fields.Date.today(),
                'invoice_line_ids': [
                    (0, 0, {'product_id': company_id.default_product_id.id,
                            'name': '%s[%s]' % (
                            company_id.default_product_id.name, search_vendor_registration_id.display_name),
                            # 'price_unit': company_id.default_product_id.lst_price
                            'price_unit': registration_fee}),
                ],
            })

            if CreateInvoice:
                CreateInvoice.action_post()
                search_vendor_registration_id.sudo().write({
                    'invoice_id': CreateInvoice.id,
                })

                CreatePaymentLink = request.env['payment.link.wizard'].sudo().create({
                    'res_model': 'account.move',
                    'res_id': CreateInvoice.id,
                    'description': CreateInvoice.payment_reference,
                    'amount': CreateInvoice.amount_total,
                    'currency_id': CreateInvoice.currency_id.id,
                    'partner_id': CreateInvoice.partner_id.id,
                    'amount_max': CreateInvoice.amount_total,
                })

                action_context = dict(request._context, link=CreatePaymentLink.link)
                if not is_offline_payment:
                    template_id = request.env.ref('kg_portal.sent_invoice_link')
                    template_id.with_context(action_context).sudo().send_mail(search_vendor_registration_id.id,
                                                                       force_send=True, )

            msg = "Your request for vendor registration is submitted."
            return request.render('kg_tower.form_thankyou_template',
                                  {'message': msg,
                                   'request_ref': search_vendor_registration_id.name, })

        else:

            commercial_registration = request.env['ir.attachment'].sudo().search([
                ('res_field', '=', 'commercial_registration'),
                ('res_model', '=', 'res.company'),
                ('type', '=', 'binary')], limit=1)
            registration_request = request.env['ir.attachment'].sudo().search([
                ('res_field', '=', 'registration_request'),
                ('res_model', '=', 'res.company'),
                ('type', '=', 'binary')], limit=1)
            decleration_letter = request.env['ir.attachment'].sudo().search([
                ('res_field', '=', 'decleration_letter'),
                ('res_model', '=', 'res.company'),
                ('type', '=', 'binary')], limit=1)
            country_id = request.env['res.country'].sudo().search([])
            state_id = request.env['res.country.state'].sudo().search([])

            return request.render('kg_portal.portal_vendor_registration',
                                  {
                                      'partner_id': request.env.user.partner_id.id,
                                      'decleration_letter': decleration_letter,
                                      'registration_request': registration_request,
                                      'commercial_registration': commercial_registration,
                                      'state_id': state_id,
                                      'country_id': country_id,
                                  })

    @http.route('/form/vendor_registration/get_fee', type='json', auth='public')
    def vendor_registration_get_fee(self, **kwargs):
        RegistrationFee = request.env['vendor.registration.fee'].sudo()
        grade = kwargs.get('grade', False)
        fee = RegistrationFee.get_registration_fee(grade)
        return fee or 0.0
