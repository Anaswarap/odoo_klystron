from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, date, timedelta


class VendorRegistration(models.Model):
    _name = 'vendor.registration'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Description'
    _order = 'name desc'

    @api.model
    def _default_get_allocated_to(self):
        pr_allocated_user = self.env['ir.config_parameter'].sudo().get_param(
            'kg_purchase.vendor_reg_form_responsible_user')
        if pr_allocated_user:
            value = int(pr_allocated_user)
        else:
            value = False
        return value

    name = fields.Char(
        'Reference',
        copy=False,
        readonly=True,
        default=lambda x: _('New'),
        required=True)
    organization = fields.Char(
        string='Organization Name',
        required=True)
    """field added for excel importing..........***sumayya***********"""
    formed_on = fields.Date(
        string='Formed On',
        required=False, default=fields.Date.today())
    category = fields.Selection(
        string='Category',
        selection=[('llc', 'LLC'),
                   ('soag', 'SOAG'),
                   ('individual', 'Individual Firm / Merchant'),
                   ('other', 'Other'), ],
        required=True, )
    grade = fields.Selection(
        string='Grade',
        selection=[('excellent', 'Excellent'),
                   ('g1', 'Grade One'),
                   ('g2', 'Grade Two'),
                   ('g3', 'Grade Three'),
                   ('g4', 'Grade Four'),
                   ('international', 'International (Payment USD)'),
                   ('others', 'Others'),
                   ],
        required=True, )
    registration_fee = fields.Float(
        string='Registration Fee',
        required=False)
    owner_lines = fields.One2many(
        comodel_name='owner.lines',
        inverse_name='vendor_registration',
        string='Owner Lines',
        required=False)
    phone = fields.Char(
        string='Phone',
        required=False)
    payment_receipt = fields.Binary(
        string="Payment Receipt",
        copy=False, tracking=True)
    cci = fields.Binary(
        string="Chamber of Commerce and Industry(CCI)",
        copy=False, tracking=True)

    signature_authority_lines = fields.One2many(
        comodel_name='signature.authority.lines',
        inverse_name='vendor_registration',
        string='Signature Authority',
        required=False)

    cr_no = fields.Char(
        string='CR No',
        required=False)
    cr_expiry_date = fields.Date(
        string='CR Expiry Date',
        required=False)

    approved_activity_lines = fields.One2many(
        comodel_name='approved.activity.lines',
        inverse_name='vendor_registration',
        string='Approved Activity',
        required=False)

    main_office_location = fields.Char(
        string='Main Office Location',
        required=False)
    landphone = fields.Char(
        string='Landline No',
        required=False)
    mobile_no = fields.Char(
        string='Mobile No',
        required=False)
    email = fields.Char(
        string='Email',
        required=False)
    website_address = fields.Char(
        string='Website Address',
        required=False)
    registered_sme = fields.Selection(
        string='Registered as SME',
        selection=[('yes', 'YES'),
                   ('no', 'NO'), ],
        required=False, )
    bank = fields.Char(
        string='Bank',
        required=False)
    branch = fields.Char(
        string='Branch',
        required=False)
    swift_no = fields.Char(
        string='Swift Number',
        required=False)
    account_no = fields.Char(
        string='Account No',
        required=False)
    account_name = fields.Char(
        string='Account Name',
        required=False)
    total_strength = fields.Float(
        string='Total Strength',
        required=False)
    total_omanies = fields.Float(
        string='Total Omanies',
        required=False)
    total_expatriate = fields.Float(
        string='Total Expatriate',
        required=False)
    decleration_letter = fields.Binary(
        string="Upload Declaration Letter",
        copy=False, tracking=True)
    registration_request = fields.Binary(
        string=" Upload the Registration request",
        copy=False, tracking=True)
    commercial_registration = fields.Binary(
        string=" Upload Commercial registration",
        copy=False, tracking=True)
    qhse_rep = fields.Char(
        string='QHSE Representative',
        required=False)
    qhse_contact = fields.Char(
        string='QHSE Contact No',
        required=False)
    finance_rep = fields.Char(
        string='Finance Representative',
        required=False)
    finance_contact = fields.Char(
        string='Finance Contact No',
        required=False)
    attachment_sign = fields.Binary(
        string="Signature",
        copy=False, tracking=True)
    publish = fields.Boolean(
        string='Publish',
        required=False, default=False)
    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('on_boarding', 'Onboarding'),
                   ('confirm', 'Confirm'), ],
        required=False, default='draft')
    invoice_id = fields.Many2one('account.move',
                                 string="Invoice")
    date = fields.Date('Date', default=fields.Date.today())
    payment_state = fields.Selection(related='invoice_id.payment_state')
    street = fields.Char()
    street2 = fields.Char()
    city = fields.Char()
    country_id = fields.Many2one('res.country', 'Country')
    state_id = fields.Many2one('res.country.state', 'State', domain="[('country_id', '=?', country_id)]")
    zip = fields.Char()
    allocated_to = fields.Many2one('hr.employee', 'Allocated To', default=_default_get_allocated_to)
    allocated_date = fields.Date('Allocated Date')
    closed_date = fields.Date('Closed Date')
    is_offline_payment = fields.Boolean('Offline Payment')
    tax_id = fields.Char()

    offline_payment_receipt = fields.Binary(
        string=" Upload payment reciept",
        copy=False, tracking=True)
    sme_doc_upload = fields.Binary(
        string=" Upload SME Registration",
        copy=False, tracking=True)

    """field added for excel importing..........***sumayya***********"""
    cr = fields.Selection(
        [
            ("available", "Available"),
            ("expired", "Expired"),
            ("not_available", "Not Available"),
        ], string="CR")
    declaration = fields.Selection(
        [
            ("available", "Available"),
            ("not_available", "Not Available"),
        ], string="Declaration")
    sme_card_if_have = fields.Char(string="SME Card ( if Have )")
    occi = fields.Selection(
        [
            ("available", "Available"),
            ("expired", "Expired"),
            ("not_available", "Not Available"),
        ], string="OCCI")
    payment = fields.Selection(
        [
            ("available", "Available"),
            ("confirm", "Confirm"),
            ("not_available", "Not Available"),
            ("not_confirm", "Not Confirm"),
        ],
        string="Payment")
    pending_documents = fields.Char(string="Pending documents")
    missing_documents = fields.Char(string="Missing documents")
    request_status = fields.Char(string="Request status")
    occi_sme_expiry = fields.Char(string="OCCI & SME Expiry")
    remarks = fields.Char(string="Remarks")
    certificate_expiry = fields.Char(string="Certificate Expiry")
    certificate = fields.Char(string="Certificate")
    certificate_recived = fields.Char(string="certificate recived")
    otc_sign_in = fields.Char(string="OTC sign in")
    # field added by Nafi
    active = fields.Boolean(string='Active', default=True)

    def name_get(self):
        res = []
        for record in self:
            name = "%s - %s" % (record.name, record.organization)
            res.append((record.id, name))
        return res

    @api.onchange('is_offline_payment')
    def onchange_is_offline_payment(self):
        self.payment_state = 'paid'

    def close_onboarding(self):
        self.state = 'confirm'
        self.closed_date = fields.Date.today()

        self.activity_unlink(['kg_portal.onboard_vendor_reg'])

    def start_onboarding(self):
        if not self.allocated_to:
            raise UserError(_("Please Add Internal Employee"))
        if not self.allocated_to.user_id:
            raise UserError(_("Please Add Internal Employee with Access to Odoo"))
        if not self.sudo().allocated_to.parent_id.user_id:
            raise UserError(_("Please Add Internal Employee with Immediate Manager"))

        self.allocated_date = fields.Date.today()
        deadline_date = fields.Date.today() + timedelta(days=3)
        self.activity_unlink(['kg_portal.approve_vendor_reg'])
        self.activity_schedule('kg_portal.onboard_vendor_reg', note=self.allocated_to.user_id.name,
                               user_id=self.allocated_to.user_id.id, date_deadline=deadline_date)
        self.activity_schedule('kg_portal.onboard_vendor_reg', note=self.allocated_to.parent_id.name,
                               user_id=self.allocated_to.parent_id.user_id.id, date_deadline=deadline_date)
        self.state = 'on_boarding'

    def action_publish(self):
        if not self.is_offline_payment and not self.payment_receipt:
            if self.payment_state not in ('in_payment', 'paid'):
                raise UserError(_("Cannot Publish, Vendor not completed the payment yet!"))
        self.publish = True
        for rec in self:
            CreatePartner = self.env['res.partner'].sudo().create({
                'company_type': 'company',
                'vendor_registration': rec.id,
                'name': rec.organization,
                'formed_on': rec.formed_on,
                'category': rec.category,
                'grade': rec.grade,
                'phone': rec.phone,
                'cr_no': rec.cr_no,
                'cr_expiry_date': rec.cr_expiry_date,
                'main_office_location': rec.main_office_location,
                'landphone': rec.landphone,
                'mobile': rec.mobile_no,
                'email': rec.email,
                'account_name': rec.account_name,
                'website': rec.website_address,
                'registered_sme': rec.registered_sme,
                'bank': rec.bank,
                'branch': rec.branch,
                'swift_no': rec.swift_no,
                'account_no': rec.account_no,
                'total_strength': rec.total_strength,
                'total_omanies': rec.total_omanies,
                'total_expatriate': rec.total_expatriate,
                'qhse_rep': rec.qhse_rep,
                'qhse_contact': rec.qhse_contact,
                'finance_rep': rec.finance_rep,
                'finance_contact': rec.finance_contact,
                'street': rec.street,
                'street2': rec.street2,
                'city': rec.city,
                'state_id': rec.state_id.id,
                'country_id': rec.country_id.id,
                'zip': rec.zip,
                'supplier_rank': 1,
                'vat': rec.tax_id,
            })

    def notify_users(self, allowed_group):
        self.activity_unlink(['kg_portal.approve_vendor_reg'])
        print(allowed_group)
        if allowed_group:
            allowed_group_obj = self.env.ref(allowed_group)
            for user in allowed_group_obj.users:
                self.activity_schedule('kg_portal.approve_vendor_reg', note=user.name, user_id=user.id)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('vendor.registration') or _('New')
        res = super(VendorRegistration, self).create(vals)
        # res.start_onboarding()
        return res


    @api.onchange('grade')
    def onchange_grade(self):
        grade = self.env['vendor.registration.fee'].search([('grade', '=', self.grade)])
        if grade:
            registration_fees = grade.amount
            self.registration_fee = registration_fees


class Owner(models.Model):
    _name = 'owner.lines'
    _description = 'Owner'

    vendor_registration = fields.Many2one(
        comodel_name='vendor.registration',
        string='Vendor Registration',
        required=True)
    name = fields.Char(
        string='Name',
        required=True)


class SignatureAuthority(models.Model):
    _name = 'signature.authority.lines'
    _description = 'Signature Authority'

    vendor_registration = fields.Many2one(
        comodel_name='vendor.registration',
        string='Vendor Registration',
        required=True)
    name = fields.Char(
        string='Name',
        required=True)


class ApprovedActivities(models.Model):
    _name = 'approved.activity.lines'
    _description = 'Approved Activities'

    vendor_registration = fields.Many2one(
        comodel_name='vendor.registration',
        string='Vendor Registration',
        required=True)
    name = fields.Char(
        string='Name',
        required=True)


class RegistrationFee(models.Model):
    _name = 'vendor.registration.fee'
    _description = 'Registration Fee'

    grade = fields.Selection(
        string='Grade',
        selection=[('excellent', 'Excellent'),
                   ('g1', 'Grade One'),
                   ('g2', 'Grade Two'),
                   ('g3', 'Grade Three'),
                   ('g4', 'Grade Four'),
                   ('international', 'International (Payment USD)'),
                   ('others', 'Others'),
                   ],
        required=True, )
    amount = fields.Float(
        string='Fee',
        required=True)

    @api.model
    def get_registration_fee(self, grade):
        print('grade', grade)
        rent_id = self.sudo().search(
            [('grade', '=', grade)],
            limit=1, order='create_date desc')
        print(rent_id)
        if not rent_id or not grade:
            return False
        return rent_id.amount
