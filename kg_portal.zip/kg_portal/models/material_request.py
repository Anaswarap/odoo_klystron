from odoo import fields, models


class MaterialRequest(models.Model):
  _name = 'material.request'
  _description = 'Material Request'

  name = fields.Char()
  employee_id = fields.Many2one(
    comodel_name='hr.employee',
    string='Employee',
    required=True)
  department_id = fields.Many2one(
    comodel_name='hr.department',
    string='Department',
    required=True, related='employee_id.department_id')
  date = fields.Date(
    string='Date',
    required=False)
  request_lines = fields.One2many(
    comodel_name='material.request.lines',
    inverse_name='request_id',
    string='Request_lines',
    required=False)
  state = fields.Selection(
    string='State',
    selection=[('draft', 'Draft'),
               ('confirm', 'Confirm'), ],
    required=False, default='draft')

  def action_confirm(self):
    self.state = 'confirm'


class MaterialRequestLines(models.Model):
  _name = 'material.request.lines'
  _description = 'Material Request Lines'

  product_id = fields.Many2one('product.product', 'Product')
  quantity = fields.Float('Quantity')
  request_id = fields.Many2one('material.request', 'Material Request')
