# -*- coding: utf-8 -*-
{
    'name': "KG : Portal",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Kiran K",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','kg_tower','portal','hr','mail','account','website','purchase'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/fine_product.xml',
        'data/ir_sequence.xml',
        'data/email_template.xml',
        'views/vendor_registration.xml',
        'views/material_request.xml',
        'inherited_views/res_company.xml',
        'inherited_views/ring_request.xml',
        'inherited_views/res_partner.xml',
        'views/templates.xml',
        'views/menu_items.xml',
        'views/srr_fine.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
