{
    'name': 'Payment Link Invoice',
    'version': '16.0.1.0.0',
    'depends': [
        'base',
        'account',

    ],
    'data': [
        'views/email_template_views.xml',

    ],
    'installable': True,
}