from odoo import fields, models
from werkzeug import urls
from odoo.addons.payment import utils as payment_utils
from werkzeug.urls import URL, url_parse, url_encode, url_quote


class AccountInvoice(models.Model):
    _inherit = 'account.move'

    link = fields.Char()

    def action_post(self):
        res = super(AccountInvoice, self).action_post()
        # print("abc")

        IrConfig = self.env['ir.config_parameter'].sudo().get_param('web.base.url')

        # print(IrConfig,"aa")
        url_params = {
            'reference': urls.url_quote(self.name),
            'amount': self.invoice_line_ids.price_total,
            'access_token': self._get_access_token(),
            'invoice_id': self.id,

        }
        # print(url_params,"url")
        url = '/payment/pay?#%s' % url_encode(url_params)
        # print(url,"url")
        suggested_url = IrConfig + url
        # print(suggested_url)
        self.link = suggested_url
        # print('yg',self.link)


        template_id = self.env.ref('payment_link.payment_link_email_template_id')
        # print(template_id,'email template')
        template_id.send_mail(self.id, force_send=True)

        return res

    def _get_access_token(self):
        self.ensure_one()
        return payment_utils.generate_access_token(
            self.partner_id.id,
            self.invoice_line_ids.price_total,
            self.currency_id.id,

            # print( self.partner_id.id,"partner"),
            # print(self.invoice_line_ids.price_total),
            # print(self.currency_id.id,"currency")

        )
